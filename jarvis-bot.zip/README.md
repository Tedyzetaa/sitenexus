# J.A.R.V.I.S. — bot de Telegram local (Ollama + Nexus-Bridge)

## Instalação (Windows)
1. `copy .env.example .env` e preencha `TELEGRAM_BOT_TOKEN` e `ALLOWED_USER_IDS`.
2. (Opcional) `ollama create jarvis-persona -f Modelfile` (ajuste o `FROM` para um modelo que você já tenha).
3. `start.bat` (cria o venv, instala e roda `python -m jarvis`).

O `.env.example` já aponta o Nexus para `http://127.0.0.1:666` (porta do `start.bat` do nexus-bridge).
Se o Nexus tiver `TOOLS_API_TOKEN`, copie o mesmo valor para `NEXUS_TOKEN`.

## Segurança
- **Whitelist**: `ALLOWED_USER_IDS` (vírgulas). Vazio → o bot se recusa a iniciar.
- **Silêncio absoluto**: todos os handlers ficam atrás de `filters.User(...)`; quem não está na lista não recebe resposta de nada. Só chegam `message` e `callback_query` (cliques de botão; sem edições nem eventos de membros) e o backlog é descartado na partida.
- **Botões também em silêncio**: o PTB não filtra `callback_query` por usuário, então `panel.on_callback` confere a whitelist (e a lista de admins para os botões `a:`) e não responde nada — nem toast — a quem não pode. Isso protege cenários de grupo.
- **Sem boas-vindas**: não existe handler de `new_chat_members`. O bot também **não** registra a lista de comandos no BotFather/`setMyCommands`, para não expor funcionalidades.
- Token do bot não vaza em log (logs do `httpx` em WARNING). Conteúdo de mensagens não é logado.
- Diretrizes de admin só *acrescentam* instruções ao prompt; a whitelist vive só no `.env` e no filtro.

## Menus interativos (botões)
Tudo abre com **/menu** (ou /start). Os menus são editados no lugar (sem poluir o chat) e todo botão tem "⬅️ Voltar".

- **Menu principal**: 🛠 Ferramentas · 📊 Status · 🧹 Limpar contexto · ❓ Ajuda · ⚙️ Admin (só admins veem).
- **/ferramentas**: lê a lista que o Nexus devolve e vira botões (2 colunas, paginados). Ao tocar numa ferramenta abre um cartão com **▶️ Executar** ou **✍️ Com argumentos** (o bot espera sua próxima mensagem e a usa como argumento). Também tem **✍️ Pedido livre** e **🔄 Atualizar** (a lista fica em cache por 5 min). Se o Nexus não devolver nada parseável, mostra atalhos básicos (`sismo`, `clima`, `noaa`).
- **/admin** (painel): dashboard com modelo, temperatura, nº de diretrizes, contexto, Nexus e whitelist, e botões para:
  - 🤖 **Modelo**: lista os modelos do Ollama, toque para trocar (✅ marca o atual).
  - 🌡 **Temperatura**: presets (0.2 … 1.5) e ➖/➕ 0.1.
  - 📜 **Diretrizes**: lista numerada, 🗑 remove uma, ➕ adiciona (próxima mensagem), 🧨 limpa tudo com confirmação.
  - 🧠 Prompt do sistema · 📊 Status · 🧹 Limpar contexto.
- `/cancelar` ou o botão ❌ cancela uma entrada pendente (que também expira em 5 min).

Botões velhos são seguros: modelo e diretriz levam uma impressão (CRC) e, se a lista mudou, o bot só atualiza a tela em vez de agir no item errado.

## Comandos (continuam todos funcionando)
`/menu` `/reset` `/status` `/video <prompt>` `/nexus [pedido]` `/ferramentas` `/cancelar` — e qualquer comando do Nexus direto (`/sismo forte 3`, `/clima Dourados MS`, `/noaa kp`...). `/nexus` sem argumento abre o menu de ferramentas.
Admin (IDs da whitelist, ou o subconjunto de `ADMIN_USER_IDS`): `/admin` `/diretriz` `/diretrizes` `/remover n` `/limpar_diretrizes` `/sistema` `/modelo [nome]` `/temperatura [0-2]` — persistidos em `data/runtime.json`.

## Ponte com o Nexus (`jarvis/nexus.py`)
`NexusGateway.dispatch_request()` é o ponto de entrada. Ele usa as rotas que o seu Nexus já expõe (`/api/v1/tools/chat`, `/media/...`, `/api/health`). Para plugar um submódulo novo:

```python
@register_action("meunome")          # /nexus meunome <args>
async def _meu(gw: NexusGateway, args: str) -> NexusReply:
    ...
    return NexusReply(handled=True, text="resultado", tool="meunome")
```
`NEXUS_AUTO_INTENT=true` faz frases soltas ("teve terremoto hoje?") acionarem ferramentas; o relatório entra no histórico para o J.A.R.V.I.S. comentar depois.

## Vídeo: `/video` (prompt + imagem de referência)
Gera vídeo pelo Nexus-Bridge (Wan 2.2 5B no Kaggle, ver `LIGACAO_KAGGLE.md` do Nexus).

- **Referência → vídeo:** envie uma **foto do sujeito com a legenda** `/video descreva a cena e a ação` (também aceita imagem enviada como *arquivo*). Com o perfil `r2v` do Nexus (padrão) a imagem é a **referência** do sujeito, não o primeiro quadro; nos perfis antigos (`draft`/`quality`/`hunyuan`) continua sendo o primeiro quadro.
- **Responda a uma imagem** com `/video descreva o movimento` — usa a imagem respondida.
- **Texto → vídeo:** `/video uma raposa correndo na neve` (sem imagem; exige `VIDEO_PROVIDER=kaggle_wan` no Nexus).
- Só a imagem, sem texto (`/video` na legenda): usa um movimento sutil padrão.
- O bot acompanha o job e edita **uma mensagem de progresso** (na fila → refinando o prompt → ligando a GPU no Kaggle → gerando) com o tempo decorrido; ao terminar, responde com o **vídeo** e o prompt refinado na legenda. Roda em segundo plano: o chat continua livre para conversar.
- **Um vídeo por vez por chat** (o Nexus também serializa a fila). Cancelar um job em andamento não é suportado pelo Nexus.
- Imagens até 20 MB (limite do Telegram para download por bots); vídeos até 50 MB (limite de envio).
- Falhas (Nexus fora do ar, OOM, Kaggle indisponível, timeout de `VIDEO_MAX_WAIT_S`) viram uma mensagem clara no lugar do progresso; falhas passageiras de rede na consulta são toleradas.
- `/video` deixou de ser repassado ao Nexus como ferramenta: o bot o trata sozinho (e o tira da lista de ferramentas do `/ferramentas`).

## Resiliência de rede (alta disponibilidade)
O bot foi feito para sobreviver a queda de internet, falha de DNS e reset de socket no Windows sem intervenção:

- **Loop de eventos no Windows** (`jarvis/net.py`): `WindowsSelectorEventLoopPolicy` é aplicada antes de qualquer loop existir. Elimina os `ConnectionResetError [WinError 10054]` / `ConnectionAbortedError [WinError 10053]` do `ProactorBasePipeTransport`. Se algum escapar num callback, vira uma linha de WARNING.
- **Partida sem internet**: `bootstrap_retries=-1`. O bot espera a rede voltar em vez de morrer no `getMe`.
- **Polling**: o PTB já repete com backoff; aqui os erros passam pelo `on_error`, que registra **um aviso por tipo de falha a cada 30 s** (sem traceback, com contagem de repetições).
- **Supervisor** (`app.run_forever`): se o bot cair por rede ou erro inesperado, reinicia com backoff exponencial (2 s → 60 s) num loop novo, sem descartar mensagens recebidas durante a queda. Token inválido (`InvalidToken`) é fatal (exit 2). Ctrl+C sai com 0. O `start.bat` ainda religa o processo se ele morrer por fora do Python.
- **Envio ao Telegram**: `tg_retry` repete 3× em falha de rede. `BadRequest` nunca é repetido (no PTB ele herda de `NetworkError`, mas é erro permanente). Avisos ao usuário (`safe_reply`) nunca levantam exceção. Trade-off: um `TimedOut` de leitura pode ter entregue a mensagem, então no pior caso há uma resposta duplicada, preferível a perder uma resposta do LLM.
- **Ollama / Nexus**: 4 timeouts explícitos (`connect/read/write/pool`), pool de conexões limitado e `trust_env=False` (proxy do Windows não intercepta `127.0.0.1`). `GET` é repetido em qualquer falha transitória; `POST` (gera texto / executa ferramenta) só é repetido se falhou **antes** de chegar ao servidor (`ConnectError`), para nunca duplicar trabalho na GPU.
- **Token nunca vaza em log**: o DEBUG do PTB imprime a URL da API com o token; um filtro de handler descarta qualquer `telegram*` abaixo de INFO.
- Timeouts configuráveis no `.env` (seção "Rede / timeouts"). Testes: `pytest tests/test_resilience.py`.

## Voz (Fish Audio TTS) — `jarvis/tts.py`
Depois que o Ollama responde, o texto é limpo (sem markdown, código, links e emojis), limitado a `TTS_MAX_CHARS` e enviado ao Fish Audio; o áudio volta como bolha de voz. Comandos do Nexus e menus continuam só em texto.

- **Configuração** (`.env`): `FISH_API_KEY`, `FISH_VOICE_ID`, `FISH_MODEL` (`s2.1-pro-free` no plano grátis; vazio no pago). Sem chave ou voz, a voz fica desligada e nada muda.
- **Liga/desliga por chat**: `/voz on` · `/voz off` (ou o botão no `/menu`). Persistido em `data/voice.json`. `TTS_DEFAULT_ON` define o estado inicial.
- **Texto + áudio** (`TTS_SEND_TEXT=true`, padrão): o texto chega na hora e o áudio logo depois, com "gravando áudio…". Com `false`: só áudio; o texto vai se o áudio falhar ou se a resposta passar do limite.
- **Nunca derruba a resposta**: qualquer falha (rede, 402 sem saldo, 503, voz proibida no Telegram) vira 1 linha de WARNING e o texto segue. Após 401/402/403 a voz entra em pausa de 10 min (429: 1 min) para não bater na API a cada mensagem; `/status` mostra isso.
- **Rede**: 4 timeouts explícitos; retry só na fase de conexão (um POST que pode ter chegado nunca é repetido, para não gastar crédito em dobro).
- **Formato**: se o áudio vier em OGG, vai como `send_voice`. Se não vier, converte com `ffmpeg` (se estiver no PATH) ou cai para `send_audio` (player).
- Privacidade: com a voz ligada, o texto de cada resposta passa pela Fish Audio.

## Observações
- O system prompt é enviado a cada requisição (por isso as diretrizes valem na hora); o `Modelfile` é só um espelho opcional.
- Use um modelo próprio (`jarvis-persona`): o Nexus usa o modelo `jarvis` para refinar prompts de imagem/vídeo, e mudar a persona dele afetaria isso. Ollama e Nexus dividem a mesma GPU — `OLLAMA_KEEP_ALIVE` curto ajuda.
- Testes: `pip install pytest && pytest`. A integração real com Telegram, Ollama e Nexus precisa ser validada na sua máquina; a resiliência foi exercitada subindo o bot sem acesso ao Telegram (falha de DNS real): ele fica tentando reconectar, sem traceback, e encerra limpo com Ctrl+C.
