import asyncio
from types import SimpleNamespace
from unittest.mock import AsyncMock, MagicMock

from jarvis import handlers as h
from jarvis import panel
from jarvis.persona import RuntimeState


def test_parse_tools_variants():
    text = (
        "🛠 **Ferramentas**\n"
        "• `/sismo` [forte] [mag] — terremotos recentes\n"
        "- /clima <cidade UF>: previsão do tempo\n"
        "/noaa kp\n"
        "/status e /nexus são do bot, /imagem /video\n"
        "veja https://host/api/docs e a/b\n"
    )
    tools = {t.name: t for t in panel.parse_tools(text)}
    # "video" e comando do proprio bot (/video com imagem de referencia): fica fora da lista do Nexus
    assert list(tools) == ["sismo", "clima", "noaa", "imagem"]
    assert tools["sismo"].usage == "[forte] [mag]" and "terremotos" in tools["sismo"].desc
    assert tools["clima"].usage == "<cidade UF>"


def test_parse_tools_empty():
    assert panel.parse_tools("") == []
    assert panel.parse_tools("nada de comandos aqui") == []


def _deps(tmp_path, admins=(1,), allowed=(1, 2)):
    settings = SimpleNamespace(
        allowed_user_ids=frozenset(allowed), admin_user_ids=frozenset(admins), nexus_auto_intent=False
    )
    ollama = MagicMock()
    ollama.list_models = AsyncMock(return_value=["a-model", "jarvis-persona"])
    d = h.Deps(
        settings=settings, state=RuntimeState(tmp_path / "r.json", "jarvis-persona", 0.8),
        ollama=ollama, nexus=None, history=h.History(10),
    )
    return d


def _all_callbacks(kb):
    return [b.callback_data for row in kb.inline_keyboard for b in row]


def test_callback_data_within_telegram_limit(tmp_path):
    d = _deps(tmp_path)
    d.state.add_directive("x" * 900)
    d.state.set_model("m" * 120)
    screens = [
        panel.screen_main(d, 1, True), panel.screen_help(True), panel.screen_admin(d, 1),
        panel.screen_temp(d), panel.screen_dirs(d), panel.screen_confirm_clear(d),
        asyncio.run(panel.screen_models(d)),
        asyncio.run(panel.screen_tools(d)),
    ]
    for text, kb in screens:
        assert len(text) < 4096
        for cb in _all_callbacks(kb):
            assert len(cb.encode()) <= 64, cb


def _update(user_id, data):
    q = MagicMock()
    q.data = data
    q.from_user = SimpleNamespace(id=user_id)
    q.answer = AsyncMock()
    q.edit_message_text = AsyncMock()
    q.message.reply_text = AsyncMock()
    u = MagicMock()
    u.callback_query = q
    u.effective_chat = SimpleNamespace(id=10)
    u.effective_user = q.from_user
    return u, q


def _ctx(d):
    return SimpleNamespace(application=SimpleNamespace(bot_data={"deps": d}), user_data={}, bot=MagicMock())


def test_unauthorized_and_non_admin_are_silent(tmp_path):
    d = _deps(tmp_path, admins=(1,), allowed=(1, 2))
    ctx = _ctx(d)
    for uid, data in [(99, "m:main"), (99, "a:home"), (2, "a:home")]:
        u, q = _update(uid, data)
        asyncio.run(panel.on_callback(u, ctx))
        q.answer.assert_not_called()
        q.edit_message_text.assert_not_called()


def test_admin_flows(tmp_path):
    d = _deps(tmp_path)
    ctx = _ctx(d)

    def click(data):
        u, q = _update(1, data)
        asyncio.run(panel.on_callback(u, ctx))
        return q

    q = click("a:home")
    assert "Painel de administração" in q.edit_message_text.call_args.args[0]

    click("a:ts:1.5")
    assert d.state.temperature == 1.5
    click("a:td:1")
    assert d.state.temperature == 1.6
    click("a:ts:2.0"); click("a:td:1")
    assert d.state.temperature == 2.0  # limitado

    click("a:ms:0:" + panel._crc("a-model"))
    assert d.state.model == "a-model"
    click("a:ms:1:dead")  # crc errado: nao troca
    assert d.state.model == "a-model"

    # nova diretriz via mensagem seguinte
    click("a:new")
    assert ctx.user_data["pending"]["kind"] == "directive"
    msg = MagicMock(); msg.text = "Seja breve."; msg.reply_text = AsyncMock()
    u = MagicMock(); u.effective_message = msg; u.effective_user = SimpleNamespace(id=1)
    try:
        asyncio.run(panel.on_pending_text(u, ctx))
        raise AssertionError("deveria parar a propagacao")
    except panel.ApplicationHandlerStop:
        pass
    assert d.state.directives == ["Seja breve."]

    # remover com crc velho nao apaga; com crc certo apaga
    click("a:dd:1:0000")
    assert d.state.directives == ["Seja breve."]
    click("a:dd:1:" + panel._crc("Seja breve."))
    assert d.state.directives == []


def test_pending_without_state_falls_through(tmp_path):
    d = _deps(tmp_path)
    ctx = _ctx(d)
    msg = MagicMock(); msg.text = "oi"
    u = MagicMock(); u.effective_message = msg
    asyncio.run(panel.on_pending_text(u, ctx))  # nao levanta Stop: on_text seguiria
