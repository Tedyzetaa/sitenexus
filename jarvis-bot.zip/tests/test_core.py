import pytest

from jarvis.config import ConfigError, parse_ids
from jarvis.persona import BASE_SYSTEM_PROMPT, RuntimeState
from jarvis.utils import format_html, split_message


def test_parse_ids():
    assert parse_ids("1, 2;3,,", "X") == frozenset({1, 2, 3})
    assert parse_ids("", "X") == frozenset()
    with pytest.raises(ConfigError):
        parse_ids("12,abc", "X")


def test_split_message():
    chunks = split_message("a" * 9000, 4000)
    assert all(len(c) <= 4000 for c in chunks) and "".join(chunks) == "a" * 9000


def test_directives_roundtrip(tmp_path):
    p = tmp_path / "runtime.json"
    st = RuntimeState(p, "m", 0.8)
    assert st.system_prompt() == BASE_SYSTEM_PROMPT
    st.add_directive("Seja breve.")
    assert "Seja breve." in st.system_prompt()
    st2 = RuntimeState(p, "m", 0.8)
    assert st2.directives == ["Seja breve."]
    st2.remove_directive(1)
    assert RuntimeState(p, "m", 0.8).directives == []
    with pytest.raises(ValueError):
        st2.set_temperature(5)


def test_format_html():
    assert format_html("🌌 **Órbita** de x") == "🌌 <b>Órbita</b> de x"
    assert format_html("_Fonte: JPL_") == "<i>Fonte: JPL</i>"
    assert format_html("a < b & **c**") == "a &lt; b &amp; <b>c</b>"
    assert format_html("```py\nx = '**no**'\n```") == "<pre>x = '**no**'</pre>"
    assert format_html("use `a<b`") == "use <code>a&lt;b</code>"
