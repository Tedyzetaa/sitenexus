import asyncio
import logging
import socket
from types import SimpleNamespace
from unittest.mock import AsyncMock, MagicMock

import httpx
import pytest
from telegram.error import BadRequest, Conflict, InvalidToken, NetworkError, TimedOut

from jarvis import app as app_mod
from jarvis import handlers as h
from jarvis import net
from jarvis.nexus import NexusError, NexusGateway
from jarvis.ollama_client import OllamaClient, OllamaError


@pytest.fixture(autouse=True)
def _no_sleep(monkeypatch):
    """Backoff instantaneo: os testes nao esperam."""
    monkeypatch.setattr(net, "backoff_delay", lambda *a, **k: 0.0)
    monkeypatch.setattr(app_mod, "backoff_delay", lambda *a, **k: 0.0)
    h._NET_THROTTLE.reset()


# ---------------------------------------------------------------- classificacao
def test_is_network_error_matches_windows_failures():
    assert net.is_network_error(socket.gaierror(11001, "getaddrinfo failed"))
    assert net.is_network_error(ConnectionResetError(10054, "reset"))
    assert net.is_network_error(ConnectionAbortedError(10053, "aborted"))
    assert net.is_network_error(httpx.ConnectError("boom"))
    assert net.is_network_error(httpx.ReadError("boom"))
    assert net.is_network_error(NetworkError("x")) and net.is_network_error(TimedOut())
    winerr = OSError()
    winerr.winerror = 10054
    assert net.is_network_error(winerr)


def test_is_network_error_follows_explicit_cause_only():
    try:
        try:
            raise socket.gaierror(11001, "getaddrinfo failed")
        except socket.gaierror as inner:
            raise RuntimeError("wrapper") from inner
    except RuntimeError as wrapped:
        assert net.is_network_error(wrapped)

    # __context__ implicito NAO conta: um bug dentro de um except de rede continua sendo bug.
    try:
        try:
            raise ConnectionResetError(10054, "reset")
        except ConnectionResetError:
            raise KeyError("bug real")
    except KeyError as bug:
        assert not net.is_network_error(bug)


def test_real_bugs_are_not_network_errors():
    assert not net.is_network_error(FileNotFoundError("runtime.json"))
    assert not net.is_network_error(PermissionError("denied"))
    assert not net.is_network_error(ValueError("x"))
    assert not net.is_network_error(BadRequest("Message is too long"))
    assert not net.is_network_error(None)


def test_event_loop_policy_only_on_windows(monkeypatch):
    calls = []
    monkeypatch.setattr(asyncio, "set_event_loop_policy", lambda p: calls.append(p))
    monkeypatch.setattr(net.sys, "platform", "linux")
    net.configure_event_loop_policy()
    assert calls == []

    monkeypatch.setattr(net.sys, "platform", "win32")
    sentinel = type("WindowsSelectorEventLoopPolicy", (), {})
    monkeypatch.setattr(asyncio, "WindowsSelectorEventLoopPolicy", sentinel, raising=False)
    net.configure_event_loop_policy()
    assert len(calls) == 1 and isinstance(calls[0], sentinel)


def test_loop_exception_filter_swallows_socket_errors(caplog):
    loop = asyncio.new_event_loop()
    try:
        fallback = MagicMock()
        loop.set_exception_handler(fallback)
        net.install_loop_exception_filter(loop)
        with caplog.at_level(logging.WARNING, logger="jarvis.net"):
            loop.call_exception_handler({"message": "Exception in callback", "exception": ConnectionResetError(10054, "x")})
        assert fallback.call_count == 0
        assert any("socket" in r.message for r in caplog.records)
        loop.call_exception_handler({"message": "bug", "exception": ValueError("x")})
        assert fallback.call_count == 1  # o resto segue para o handler original
    finally:
        loop.close()


# ---------------------------------------------------------------- retry_async
def test_retry_async_recovers_after_transient_failures():
    n = {"i": 0}

    async def flaky():
        n["i"] += 1
        if n["i"] < 3:
            raise socket.gaierror(11001, "getaddrinfo failed")
        return "ok"

    assert asyncio.run(net.retry_async(flaky, attempts=3)) == "ok"
    assert n["i"] == 3


def test_retry_async_does_not_retry_real_bugs():
    n = {"i": 0}

    async def buggy():
        n["i"] += 1
        raise KeyError("bug")

    with pytest.raises(KeyError):
        asyncio.run(net.retry_async(buggy, attempts=3))
    assert n["i"] == 1


def test_retry_async_gives_up_and_reraises():
    async def down():
        raise httpx.ConnectError("down")

    with pytest.raises(httpx.ConnectError):
        asyncio.run(net.retry_async(down, attempts=2))


# ---------------------------------------------------------------- Ollama
def _ollama(handler) -> OllamaClient:
    c = OllamaClient("http://127.0.0.1:11434", 5, 4096, "2m")
    c._http = httpx.AsyncClient(base_url="http://127.0.0.1:11434", transport=httpx.MockTransport(handler))
    return c


def test_ollama_timeouts_are_all_explicit():
    c = OllamaClient("http://x", 300, 4096, "2m", connect_timeout_s=4)
    t = c._http.timeout
    assert (t.connect, t.read, t.write, t.pool) == (4, 300, 30.0, 10.0)
    asyncio.run(c.aclose())


def test_ollama_chat_retries_connect_phase_then_succeeds():
    n = {"i": 0}

    def handler(request):
        n["i"] += 1
        if n["i"] < 3:
            raise httpx.ConnectError("getaddrinfo failed", request=request)
        return httpx.Response(200, json={"message": {"content": "olá"}})

    c = _ollama(handler)
    msgs = [{"role": "user", "content": "oi"}]
    assert asyncio.run(c.chat(msgs, "m", 0.8)) == "olá"
    assert n["i"] == 3


def test_ollama_chat_connect_failure_becomes_ollama_error():
    def handler(request):
        raise httpx.ConnectError("getaddrinfo failed", request=request)

    with pytest.raises(OllamaError, match="nao responde"):
        asyncio.run(_ollama(handler).chat([{"role": "user", "content": "x"}], "m", 0.8))


def test_ollama_chat_does_not_resend_post_after_read_failure():
    """Reset no meio da resposta: o modelo pode ja estar gerando; reenviar duplicaria o trabalho na GPU."""
    n = {"i": 0}

    def handler(request):
        n["i"] += 1
        raise httpx.ReadError("connection reset", request=request)

    with pytest.raises(OllamaError, match="falha de comunicacao"):
        asyncio.run(_ollama(handler).chat([{"role": "user", "content": "x"}], "m", 0.8))
    assert n["i"] == 1


def test_ollama_raw_socket_error_is_wrapped():
    def handler(request):
        raise ConnectionAbortedError(10053, "software caused connection abort")

    with pytest.raises(OllamaError):
        asyncio.run(_ollama(handler).chat([{"role": "user", "content": "x"}], "m", 0.8))


def test_ollama_list_models_retries_get():
    n = {"i": 0}

    def handler(request):
        n["i"] += 1
        if n["i"] == 1:
            raise httpx.ReadError("reset", request=request)
        return httpx.Response(200, json={"models": [{"name": "b"}, {"name": "a"}]})

    assert asyncio.run(_ollama(handler).list_models()) == ["a", "b"]
    assert n["i"] == 2


# ---------------------------------------------------------------- Nexus
def _nexus(handler) -> NexusGateway:
    gw = NexusGateway("http://127.0.0.1:666", "", 5)
    gw._http = httpx.AsyncClient(base_url="http://127.0.0.1:666", transport=httpx.MockTransport(handler))
    return gw


def test_nexus_get_retries_but_post_only_on_connect_phase():
    calls = {"GET": 0, "POST": 0}

    def handler(request):
        calls[request.method] += 1
        raise httpx.ReadError("reset", request=request)

    gw = _nexus(handler)
    with pytest.raises(NexusError):
        asyncio.run(gw.health())  # GET: idempotente, 3 tentativas
    with pytest.raises(NexusError):
        asyncio.run(gw.command("/sismo"))  # POST executa ferramenta: sem reenvio apos ReadError
    assert calls == {"GET": 3, "POST": 1}


def test_nexus_connect_error_message_and_wrapping():
    def handler(request):
        raise httpx.ConnectError("refused", request=request)

    with pytest.raises(NexusError, match="offline"):
        asyncio.run(_nexus(handler).health())

    def raw(request):
        raise ConnectionResetError(10054, "reset")

    with pytest.raises(NexusError, match="falha de rede"):
        asyncio.run(_nexus(raw).health())


# ---------------------------------------------------------------- handler global de erros
def _ctx(err):
    return SimpleNamespace(error=err)


def _run_on_error(err, update=None):
    asyncio.run(h.on_error(update, _ctx(err)))


def test_on_error_network_failure_is_one_clean_warning_without_traceback(caplog):
    for err in (
        NetworkError("httpx.ConnectError: [Errno 11001] getaddrinfo failed"),
        TimedOut("Timed out"),
        httpx.ConnectError("x"),
        ConnectionResetError(10054, "reset"),
        socket.gaierror(11001, "getaddrinfo failed"),
    ):
        caplog.clear()
        with caplog.at_level(logging.DEBUG, logger="jarvis.handlers"):
            _run_on_error(err)
        assert len(caplog.records) == 1
        rec = caplog.records[0]
        assert rec.levelno == logging.WARNING
        assert rec.exc_info is None  # sem traceback gigante


def test_on_error_conflict_and_unexpected(caplog):
    with caplog.at_level(logging.DEBUG, logger="jarvis.handlers"):
        _run_on_error(Conflict("terminated by other getUpdates request"))
    assert "outra instancia" in caplog.text and caplog.records[0].exc_info is None

    caplog.clear()
    with caplog.at_level(logging.DEBUG, logger="jarvis.handlers"):
        _run_on_error(KeyError("bug real"))
    assert caplog.records[0].levelno == logging.ERROR and caplog.records[0].exc_info is not None  # bug: traceback completo


def test_on_error_never_replies_to_user():
    update = SimpleNamespace(effective_message=MagicMock(reply_text=AsyncMock()))
    _run_on_error(NetworkError("x"), update)
    update.effective_message.reply_text.assert_not_called()


# ---------------------------------------------------------------- envio ao Telegram
def test_safe_reply_swallows_network_failure():
    msg = MagicMock()
    msg.reply_text = AsyncMock(side_effect=NetworkError("down"))
    assert asyncio.run(h.safe_reply(msg, "oi")) is False
    assert msg.reply_text.await_count == 3  # 3 tentativas


def test_tg_retry_does_not_retry_bad_request():
    fn = AsyncMock(side_effect=BadRequest("can't parse entities"))
    with pytest.raises(BadRequest):
        asyncio.run(h.tg_retry(fn))
    assert fn.await_count == 1


def test_reply_long_retries_then_falls_back_to_plain_text_on_bad_request():
    msg = MagicMock()
    msg.reply_text = AsyncMock(side_effect=[NetworkError("blip"), BadRequest("parse"), None])
    update = SimpleNamespace(effective_message=msg)
    asyncio.run(h._reply_long(update, "texto"))
    assert msg.reply_text.await_count == 3


# ---------------------------------------------------------------- supervisor
def test_run_forever_restarts_after_network_failure_and_stops_cleanly(monkeypatch):
    seq = iter([socket.gaierror(11001, "getaddrinfo failed"), ConnectionResetError(10054, "x"), None])
    seen = []

    def fake_run_once(settings, first_run):
        seen.append(first_run)
        r = next(seq)
        if r is not None:
            raise r

    monkeypatch.setattr(app_mod, "_run_once", fake_run_once)
    monkeypatch.setattr(app_mod.time, "sleep", lambda s: None)
    assert app_mod.run_forever(object()) == 0
    assert seen == [True, False, False]  # backlog so e descartado na primeira partida


def test_run_forever_invalid_token_is_fatal(monkeypatch):
    calls = []
    monkeypatch.setattr(app_mod, "_run_once", lambda s, first_run: (calls.append(1), (_ for _ in ()).throw(InvalidToken()))[1])
    monkeypatch.setattr(app_mod.time, "sleep", lambda s: None)
    assert app_mod.run_forever(object()) == 2
    assert len(calls) == 1  # nao fica em loop com token invalido


def test_run_forever_retries_unexpected_errors_too(monkeypatch):
    seq = iter([RuntimeError("boom"), None])

    def fake_run_once(settings, first_run):
        r = next(seq)
        if r is not None:
            raise r

    monkeypatch.setattr(app_mod, "_run_once", fake_run_once)
    monkeypatch.setattr(app_mod.time, "sleep", lambda s: None)
    assert app_mod.run_forever(object()) == 0


def test_run_forever_ctrl_c_during_backoff_exits(monkeypatch):
    monkeypatch.setattr(app_mod, "_run_once", lambda s, first_run: (_ for _ in ()).throw(ConnectionResetError(10054, "x")))

    def interrupt(_s):
        raise KeyboardInterrupt

    monkeypatch.setattr(app_mod.time, "sleep", interrupt)
    assert app_mod.run_forever(object()) == 0


# ---------------------------------------------------------------- throttle de logs
def test_log_throttle_counts_suppressed():
    t = {"now": 0.0}
    th = net.LogThrottle(30.0, clock=lambda: t["now"])
    assert th.hit("dns") == 0
    assert th.hit("dns") is None and th.hit("dns") is None
    assert th.hit("outro") == 0  # chave diferente nao e afetada
    t["now"] = 31.0
    assert th.hit("dns") == 2  # reporta quantas foram suprimidas


def test_on_error_repeated_network_failures_are_throttled(caplog):
    with caplog.at_level(logging.DEBUG, logger="jarvis.handlers"):
        for _ in range(50):
            _run_on_error(NetworkError("x"))
    assert len(caplog.records) == 1


def test_reconnect_notice_collapses_ptb_debug_retries(caplog):
    flt = net._ReconnectNotice(30.0)
    retry = logging.LogRecord("telegram.ext", logging.DEBUG, "f", 1,
                              "Network Retry Loop (Bootstrap Initialize Application): Failed run number 3 of -1. Retrying.", (), None)
    leak = logging.LogRecord("telegram.ext.ExtBot", logging.DEBUG, "f", 1,
                             "Set Bot API URL: https://api.telegram.org/bot123:SECRET", (), None)
    mine = logging.LogRecord("jarvis.handlers", logging.DEBUG, "f", 1, "debug do jarvis", (), None)
    err = logging.LogRecord("telegram.ext", logging.ERROR, "f", 1, "algo grave", (), None)
    with caplog.at_level(logging.WARNING, logger="jarvis.net"):
        assert all(flt.filter(retry) is False for _ in range(20))
        assert flt.filter(leak) is False  # DEBUG de logger filho do PTB: descartado (continha o TOKEN)
        assert flt.filter(mine) is True  # logs do proprio Jarvis nao sao tocados
        assert flt.filter(err) is True  # ERROR/INFO do PTB passam intactos
    assert len([r for r in caplog.records if "reconectar" in r.message]) == 1


def test_install_reconnect_notice_never_leaks_token_to_handler_output():
    """Integra de ponta a ponta: logging real + handler real. O token nao pode sair em nenhum nivel."""
    import io

    root = logging.getLogger()
    buf = io.StringIO()
    handler = logging.StreamHandler(buf)
    handler.setFormatter(logging.Formatter("%(name)s %(levelname)s %(message)s"))
    saved_level = root.level
    ext_level = logging.getLogger("telegram.ext").level
    root.addHandler(handler)
    root.setLevel(logging.INFO)
    try:
        net.install_reconnect_notice()
        logging.getLogger("telegram.ext.ExtBot").debug("Set Bot API URL: https://api.telegram.org/bot123:SECRET")
        logging.getLogger("telegram.ext").debug("Network Retry Loop (Bootstrap Initialize Application): Failed run number 1 of -1. Retrying.")
        logging.getLogger("telegram.ext.Application").info("info normal do PTB")
    finally:
        root.removeHandler(handler)
        root.setLevel(saved_level)
        logging.getLogger("telegram.ext").setLevel(ext_level)
    out = buf.getvalue()
    assert "SECRET" not in out
    assert "reconectar" in out and "info normal do PTB" in out
