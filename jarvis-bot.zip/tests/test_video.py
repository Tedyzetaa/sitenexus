"""/video: parsing, ponte com o Nexus (submit/wait/fetch) e o fluxo completo com fakes."""
import asyncio
import base64
import json
from types import SimpleNamespace
from unittest.mock import AsyncMock, MagicMock

import httpx
import pytest
from telegram.error import BadRequest

from jarvis import handlers as h
from jarvis.nexus import NexusError, NexusGateway
from jarvis.persona import RuntimeState


# --- parsing -------------------------------------------------------------------------------
@pytest.mark.parametrize("text,expected", [
    ("/video a raposa corre", "a raposa corre"),
    ("/video@jarvis_bot  a raposa\ncorre na neve", "a raposa\ncorre na neve"),
    ("/VIDEO zoom lento", "zoom lento"),
    ("/video", ""),
    ("/video   ", ""),
    ("", ""),
])
def test_parse_video_prompt(text, expected):
    assert h.parse_video_prompt(text) == expected


@pytest.mark.parametrize("text,expected", [
    ("/video a raposa corre", ("a raposa corre", False)),
    ("/video ! slow push-in on cups", ("slow push-in on cups", True)),
    ("/video !slow push-in", ("slow push-in", True)),
    ("/video@jarvis_bot raw: a fox runs", ("a fox runs", True)),
    ("/video RAW:   a fox", ("a fox", True)),
    ("/video !", ("", True)),
    ("/video a raposa! corre", ("a raposa! corre", False)),
    ("/video", ("", False)),
])
def test_parse_video_request_raw_mode(text, expected):
    assert h.parse_video_request(text) == expected


def test_submit_video_raw_sets_skip_refinement_only_when_asked():
    seen = []

    def handler(req: httpx.Request) -> httpx.Response:
        seen.append(json.loads(req.content))
        return httpx.Response(200, json={"id": "job-1"})

    gw = _gw(handler)
    asyncio.run(gw.submit_video("a fox", None))
    asyncio.run(gw.submit_video("a fox", None, raw=True))
    assert "skip_refinement" not in seen[0]
    assert seen[1]["skip_refinement"] is True


def test_image_source_prefers_own_photo_then_reply_then_image_document():
    small, big = SimpleNamespace(file_size=1), SimpleNamespace(file_size=2)
    own = SimpleNamespace(photo=[small, big], document=None, reply_to_message=None)
    assert h._image_source(own) is big
    doc = SimpleNamespace(mime_type="image/png", file_size=5)
    replied = SimpleNamespace(photo=[], document=doc, reply_to_message=None)
    assert h._image_source(SimpleNamespace(photo=[], document=None, reply_to_message=replied)) is doc
    pdf = SimpleNamespace(photo=[], document=SimpleNamespace(mime_type="application/pdf"), reply_to_message=None)
    assert h._image_source(pdf) is None


# --- gateway -------------------------------------------------------------------------------
def _gw(handler) -> NexusGateway:
    gw = NexusGateway("http://127.0.0.1:666", "", 5.0)
    gw._http = httpx.AsyncClient(base_url="http://127.0.0.1:666", transport=httpx.MockTransport(handler))
    return gw


def test_submit_video_sends_base64_only_when_there_is_an_image():
    seen = []

    def handler(req: httpx.Request) -> httpx.Response:
        seen.append(json.loads(req.content))
        return httpx.Response(200, json={"id": "job-1"})

    gw = _gw(handler)
    assert asyncio.run(gw.submit_video("a fox", b"\x89PNGdata")) == "job-1"
    assert seen[0]["input_image_base64"] == base64.b64encode(b"\x89PNGdata").decode()
    assert asyncio.run(gw.submit_video("a fox", None)) == "job-1"
    assert "input_image_base64" not in seen[1]


def test_submit_video_surfaces_validation_detail():
    gw = _gw(lambda r: httpx.Response(400, json={"detail": "T2V exige VIDEO_PROVIDER=kaggle_wan"}))
    with pytest.raises(NexusError, match="HTTP 400: T2V exige"):
        asyncio.run(gw.submit_video("a fox", None))


def _jobs_handler(statuses, **last):
    it = iter(statuses)

    def handler(req: httpx.Request) -> httpx.Response:
        st = next(it, statuses[-1])
        body = {"id": "j", "status": st, **(last if st in ("completed", "failed") else {})}
        return httpx.Response(200, json=body)
    return handler


def test_wait_video_job_reports_progress_and_returns_on_completed():
    gw = _gw(_jobs_handler(["queued", "generating_video", "completed"],
                           file_path="generated_videos/x.mp4", refined_prompt="refined"))
    seen = []

    async def on_update(job):
        seen.append(job.status)

    job = asyncio.run(gw.wait_video_job("j", on_update=on_update, poll_s=0.01))
    assert seen == ["queued", "generating_video"] and job.file_path.endswith("x.mp4")


def test_wait_video_job_failed_raises_with_job_error():
    gw = _gw(_jobs_handler(["generating_video", "failed"], error="CUDA OOM"))
    with pytest.raises(NexusError, match="CUDA OOM"):
        asyncio.run(gw.wait_video_job("j", poll_s=0.01))


def test_wait_video_job_404_aborts_immediately():
    calls = []

    def handler(req):
        calls.append(1)
        return httpx.Response(404, json={"detail": "Job nao encontrado"})

    with pytest.raises(NexusError, match="nao conhece"):
        asyncio.run(_gw(handler).wait_video_job("j", poll_s=0.01))
    assert len(calls) == 1


def test_wait_video_job_tolerates_a_few_errors_then_recovers():
    seq = iter([500, 500, "completed"])

    def handler(req):
        v = next(seq)
        return httpx.Response(v, json={}) if isinstance(v, int) else httpx.Response(
            200, json={"id": "j", "status": v, "file_path": "a.mp4"})

    job = asyncio.run(_gw(handler).wait_video_job("j", poll_s=0.01, max_consecutive_errors=5))
    assert job.status == "completed"


def test_wait_video_job_gives_up_after_too_many_errors_and_on_timeout():
    with pytest.raises(NexusError, match="HTTP 500"):
        asyncio.run(_gw(lambda r: httpx.Response(500, json={})).wait_video_job(
            "j", poll_s=0.01, max_consecutive_errors=3))
    with pytest.raises(NexusError, match="tempo maximo"):
        asyncio.run(_gw(_jobs_handler(["queued"])).wait_video_job("j", poll_s=0.01, max_wait_s=0.05))


def test_video_media_path_handles_posix_and_windows_paths():
    assert NexusGateway.video_media_path("generated_videos/a.mp4") == "/videos/a.mp4"
    assert NexusGateway.video_media_path("generated_videos\\b.mp4") == "/videos/b.mp4"
    assert NexusGateway.video_media_path("C:\\x\\y\\c.webm") == "/videos/c.webm"


def test_kaggle_status_returns_none_when_unavailable():
    assert asyncio.run(_gw(lambda r: httpx.Response(404, json={})).kaggle_status()) is None
    assert asyncio.run(_gw(lambda r: httpx.Response(200, json={"enabled": True, "online": False})).kaggle_status()) == {
        "enabled": True, "online": False}


# --- handler completo com fakes --------------------------------------------------------------
def _deps(tmp_path, nexus):
    settings = SimpleNamespace(video_poll_interval_s=0.01, video_max_wait_s=5.0,
                               allowed_user_ids=frozenset({1}), admin_user_ids=frozenset({1}), nexus_auto_intent=False)
    return h.Deps(settings=settings, state=RuntimeState(tmp_path / "r.json", "m", 0.8),
                  ollama=MagicMock(), nexus=nexus, history=h.History(10))


def _msg(text=None, caption=None, photo=None, reply=None):
    status = SimpleNamespace(edit_text=AsyncMock())
    m = SimpleNamespace(
        text=text, caption=caption, photo=photo or [], document=None, reply_to_message=reply,
        reply_text=AsyncMock(return_value=status), reply_video=AsyncMock(), reply_document=AsyncMock(),
    )
    m._status = status
    return m


def _ctx(deps):
    tasks = []

    def create_task(coro, update=None, **kw):
        tasks.append(coro)
        return None
    app = SimpleNamespace(bot_data={"deps": deps}, create_task=create_task)
    return SimpleNamespace(application=app, bot=MagicMock()), tasks


def _fake_nexus(job_status_seq, **job_kw):
    nx = MagicMock()
    nx.submit_video = AsyncMock(return_value="job-1")
    it = iter(job_status_seq)

    async def wait(job_id, on_update=None, poll_s=1, max_wait_s=1):
        for st in it:
            await on_update(SimpleNamespace(status=st))
        return SimpleNamespace(status="completed", file_path="generated_videos/v.mp4",
                               refined_prompt=job_kw.get("refined", "refined prompt"), error=None)
    nx.wait_video_job = wait
    nx.kaggle_status = AsyncMock(return_value={"enabled": True, "online": False})
    nx.video_media_path = NexusGateway.video_media_path
    nx.fetch_media = AsyncMock(return_value=SimpleNamespace(data=b"MP4", filename="v.mp4", content_type="video/mp4"))
    return nx


def _run(coro_list):
    async def go():
        for c in coro_list:
            await c
    asyncio.run(go())


def test_cmd_video_with_photo_caption_downloads_image_and_delivers_video(tmp_path):
    nx = _fake_nexus(["queued", "generating_video"])
    deps = _deps(tmp_path, nx)
    tg_file = SimpleNamespace(download_as_bytearray=AsyncMock(return_value=bytearray(b"JPEGBYTES")))
    photo = SimpleNamespace(file_size=1000, get_file=AsyncMock(return_value=tg_file))
    msg = _msg(caption="/video a camera se aproxima", photo=[photo])
    ctx, tasks = _ctx(deps)
    upd = SimpleNamespace(effective_message=msg, effective_chat=SimpleNamespace(id=7))

    asyncio.run(h.cmd_video(upd, ctx))
    assert 7 in deps.video_active and len(tasks) == 1          # trabalho em segundo plano agendado
    _run(tasks)
    nx.submit_video.assert_awaited_once_with("a camera se aproxima", b"JPEGBYTES")  # imagem = referencia
    nx.fetch_media.assert_awaited_once_with("/videos/v.mp4")
    kw = msg.reply_video.await_args.kwargs
    assert "refined prompt" in kw["caption"] and "referência" in kw["caption"]
    assert 7 not in deps.video_active                          # libera o chat no fim
    texts = [c.args[0] for c in msg._status.edit_text.await_args_list]
    assert any("Ligando a GPU no Kaggle" in t for t in texts)  # avisou que o Kaggle estava subindo


def test_cmd_video_text_only_is_t2v_and_image_only_uses_default_prompt(tmp_path):
    nx = _fake_nexus([])
    deps = _deps(tmp_path, nx)
    ctx, tasks = _ctx(deps)
    asyncio.run(h.cmd_video(SimpleNamespace(effective_message=_msg(text="/video uma raposa na neve"),
                                            effective_chat=SimpleNamespace(id=1)), ctx))
    _run(tasks)
    nx.submit_video.assert_awaited_once_with("uma raposa na neve", None)

    nx2 = _fake_nexus([])
    deps2 = _deps(tmp_path, nx2)
    ctx2, tasks2 = _ctx(deps2)
    tg_file = SimpleNamespace(download_as_bytearray=AsyncMock(return_value=bytearray(b"IMG")))
    photo = SimpleNamespace(file_size=1, get_file=AsyncMock(return_value=tg_file))
    asyncio.run(h.cmd_video(SimpleNamespace(effective_message=_msg(caption="/video", photo=[photo]),
                                            effective_chat=SimpleNamespace(id=2)), ctx2))
    _run(tasks2)
    nx2.submit_video.assert_awaited_once_with(h.DEFAULT_VIDEO_PROMPT, b"IMG")


def test_cmd_video_raw_prefix_skips_refinement_and_marks_caption(tmp_path):
    nx = _fake_nexus([])
    deps = _deps(tmp_path, nx)
    ctx, tasks = _ctx(deps)
    tg_file = SimpleNamespace(download_as_bytearray=AsyncMock(return_value=bytearray(b"IMG")))
    photo = SimpleNamespace(file_size=1, get_file=AsyncMock(return_value=tg_file))
    msg = _msg(caption="/video ! slow push-in on four glass cups", photo=[photo])
    asyncio.run(h.cmd_video(SimpleNamespace(effective_message=msg, effective_chat=SimpleNamespace(id=3)), ctx))
    _run(tasks)
    nx.submit_video.assert_awaited_once_with("slow push-in on four glass cups", b"IMG", raw=True)
    assert "prompt direto" in msg.reply_video.await_args.kwargs["caption"]


def test_cmd_video_reply_to_photo_uses_replied_image(tmp_path):
    nx = _fake_nexus([])
    deps = _deps(tmp_path, nx)
    tg_file = SimpleNamespace(download_as_bytearray=AsyncMock(return_value=bytearray(b"REPLIED")))
    replied = SimpleNamespace(photo=[SimpleNamespace(file_size=1, get_file=AsyncMock(return_value=tg_file))],
                              document=None, reply_to_message=None)
    ctx, tasks = _ctx(deps)
    asyncio.run(h.cmd_video(SimpleNamespace(effective_message=_msg(text="/video zoom", reply=replied),
                                            effective_chat=SimpleNamespace(id=3)), ctx))
    _run(tasks)
    nx.submit_video.assert_awaited_once_with("zoom", b"REPLIED")


def test_cmd_video_without_prompt_or_image_shows_usage_and_starts_nothing(tmp_path):
    nx = _fake_nexus([])
    deps = _deps(tmp_path, nx)
    msg = _msg(text="/video")
    ctx, tasks = _ctx(deps)
    asyncio.run(h.cmd_video(SimpleNamespace(effective_message=msg, effective_chat=SimpleNamespace(id=1)), ctx))
    assert not tasks and not nx.submit_video.await_count
    assert "Referência → vídeo" in msg.reply_text.await_args.args[0]


def test_cmd_video_blocks_second_job_in_same_chat_and_rejects_huge_image(tmp_path):
    nx = _fake_nexus([])
    deps = _deps(tmp_path, nx)
    deps.video_active.add(5)
    msg = _msg(text="/video algo")
    ctx, tasks = _ctx(deps)
    asyncio.run(h.cmd_video(SimpleNamespace(effective_message=msg, effective_chat=SimpleNamespace(id=5)), ctx))
    assert not tasks and "Já existe um vídeo" in msg.reply_text.await_args.args[0]

    big = SimpleNamespace(file_size=30 * 1024 * 1024, get_file=AsyncMock())
    msg2 = _msg(caption="/video algo", photo=[big])
    asyncio.run(h.cmd_video(SimpleNamespace(effective_message=msg2, effective_chat=SimpleNamespace(id=6)), ctx))
    assert not tasks and "20 MB" in msg2.reply_text.await_args.args[0] and not big.get_file.await_count


def test_job_failure_is_reported_and_chat_is_released(tmp_path):
    nx = _fake_nexus([])

    async def boom(*a, **k):
        raise NexusError("CUDA OOM")
    nx.wait_video_job = boom
    deps = _deps(tmp_path, nx)
    msg = _msg(text="/video algo")
    ctx, tasks = _ctx(deps)
    asyncio.run(h.cmd_video(SimpleNamespace(effective_message=msg, effective_chat=SimpleNamespace(id=9)), ctx))
    _run(tasks)
    assert "CUDA OOM" in msg._status.edit_text.await_args.args[0]
    assert not msg.reply_video.await_count and 9 not in deps.video_active


def test_reply_video_badrequest_falls_back_to_document(tmp_path):
    nx = _fake_nexus([])
    deps = _deps(tmp_path, nx)
    msg = _msg(text="/video algo")
    msg.reply_video = AsyncMock(side_effect=BadRequest("Wrong file type"))
    ctx, tasks = _ctx(deps)
    asyncio.run(h.cmd_video(SimpleNamespace(effective_message=msg, effective_chat=SimpleNamespace(id=4)), ctx))
    _run(tasks)
    assert msg.reply_document.await_count == 1


def test_cmd_video_with_nexus_disabled_says_so(tmp_path):
    deps = _deps(tmp_path, None)
    msg = _msg(text="/video algo")
    ctx, tasks = _ctx(deps)
    asyncio.run(h.cmd_video(SimpleNamespace(effective_message=msg, effective_chat=SimpleNamespace(id=1)), ctx))
    assert not tasks and "desativada" in msg.reply_text.await_args.args[0]


# --- roteamento real do PTB (regressao: legenda de foto nao e vista pelo CommandHandler) -----------
def test_ptb_routes_video_text_and_photo_caption_and_ignores_strangers(tmp_path, monkeypatch):
    import dataclasses
    import datetime

    from telegram import Chat, Document, Message, MessageEntity, PhotoSize, Update, User

    from jarvis.app import build_app
    from jarvis.config import load_settings

    monkeypatch.setenv("TELEGRAM_BOT_TOKEN", "123456:ABC-DEF_ghijklmnopqrstuvwxyz012345678")
    monkeypatch.setenv("ALLOWED_USER_IDS", "1")
    app = build_app(dataclasses.replace(load_settings(env_file=tmp_path / "nao-existe.env"), data_dir=tmp_path))
    app.bot._bot_user = User(999, "Jarvis", True, username="jarvis_bot")  # sem get_me() (sem rede)
    now = datetime.datetime.now(datetime.timezone.utc)

    def upd(uid, text=None, caption=None, photo=False, mime=None, n=6):
        kw = {}
        if photo:
            kw["photo"] = (PhotoSize("f", "u", 10, 10, 1),)
        if mime:
            kw["document"] = Document("f2", "u2", file_name="a", mime_type=mime)
        ent = [MessageEntity("bot_command", 0, n)]
        m = Message(1, now, Chat(1, "private"), from_user=User(uid, "t", False), text=text, caption=caption,
                    entities=ent if text else None, caption_entities=ent if caption else None, **kw)
        m.set_bot(app.bot)
        u = Update(1, message=m)
        u.set_bot(app.bot)
        return u

    def handled_by(u):
        for hd in app.handlers[0]:
            if hd.check_update(u) not in (None, False):
                return hd.callback.__name__
        return None

    assert handled_by(upd(1, text="/video fox")) == "cmd_video"
    assert handled_by(upd(1, text="/video@jarvis_bot fox", n=17)) == "cmd_video"
    assert handled_by(upd(1, caption="/video fox", photo=True)) == "cmd_video"
    assert handled_by(upd(1, caption="/video fox", mime="image/png")) == "cmd_video"
    assert handled_by(upd(1, caption="/video fox", mime="application/pdf")) is None
    assert handled_by(upd(1, caption="so uma foto", photo=True)) is None
    assert handled_by(upd(99, caption="/video fox", photo=True)) is None   # fora da whitelist: silencio
    assert handled_by(upd(99, text="/video fox")) is None
    assert handled_by(upd(1, text="/clima x")) == "on_unknown_command"      # outros comandos seguem p/ o Nexus
