import asyncio
import json
from types import SimpleNamespace
from unittest.mock import AsyncMock, MagicMock

import httpx
import pytest

from jarvis import handlers as h
from jarvis import net, tts
from jarvis.persona import RuntimeState
from jarvis.tts import TTSClient, TTSError, VoicePrefs, clean_for_speech

OGG = b"OggS" + b"\x00" * 400


@pytest.fixture(autouse=True)
def _no_sleep(monkeypatch):
    monkeypatch.setattr(net, "backoff_delay", lambda *a, **k: 0.0)


def _client(handler, **kw):
    return TTSClient("KEY", "VOICE", model="s2.1-pro-free", transport=httpx.MockTransport(handler), **kw)


# ------------------------------------------------------------------ limpeza de texto
def test_clean_strips_markdown_code_links_emojis():
    raw = "# Titulo\n**Negrito** e `codigo` aqui 🚀\n```python\nprint('x')\n```\nVeja [o site](https://x.com) ou https://y.com/z."
    out, trunc = clean_for_speech(raw, 500)
    assert not trunc
    for bad in ("*", "`", "print", "http", "🚀", "#", "]("):
        assert bad not in out
    assert "Negrito" in out and "o site" in out


def test_clean_only_code_is_empty():
    assert clean_for_speech("```py\nx=1\n```", 500) == ("", False)


def test_clean_truncates_at_sentence():
    text = "Primeira frase completa. Segunda frase completa. " + "palavra " * 100
    out, trunc = clean_for_speech(text, 60)
    assert trunc and len(out) <= 61 and out.endswith(("completa.", "…"))


# ------------------------------------------------------------------ cliente HTTP
def test_synthesize_ok_sends_expected_request():
    seen = {}

    def handler(req: httpx.Request) -> httpx.Response:
        seen["url"], seen["auth"], seen["model"] = str(req.url), req.headers["authorization"], req.headers["model"]
        seen["body"] = json.loads(req.content)
        return httpx.Response(200, content=OGG, headers={"content-type": "audio/ogg"})

    c = _client(handler)
    assert asyncio.run(c.synthesize("Olá")) == OGG
    assert seen["url"] == "https://api.fish.audio/v1/tts"
    assert seen["auth"] == "Bearer KEY" and seen["model"] == "s2.1-pro-free"
    assert seen["body"] == {"text": "Olá", "reference_id": "VOICE", "format": "opus", "language": "pt-BR"}


def test_402_raises_and_enters_cooldown():
    calls = []

    def handler(req):
        calls.append(1)
        return httpx.Response(402, json={"message": "payment required"})

    c = _client(handler)
    with pytest.raises(TTSError, match="402"):
        asyncio.run(c.synthesize("oi"))
    assert c.cooling_down
    with pytest.raises(TTSError, match="pausa"):
        asyncio.run(c.synthesize("oi"))
    assert len(calls) == 1  # segunda chamada nem saiu da maquina


def test_503_is_error_without_cooldown():
    c = _client(lambda r: httpx.Response(503, json={"message": "busy"}))
    with pytest.raises(TTSError, match="503"):
        asyncio.run(c.synthesize("oi"))
    assert not c.cooling_down


def test_json_body_with_200_is_rejected():
    c = _client(lambda r: httpx.Response(200, json={"error": "x"}))
    with pytest.raises(TTSError):
        asyncio.run(c.synthesize("oi"))


def test_connect_error_retried_then_ttserror():
    calls = []

    def handler(req):
        calls.append(1)
        raise httpx.ConnectError("getaddrinfo failed")

    with pytest.raises(TTSError, match="conexao"):
        asyncio.run(_client(handler).synthesize("oi"))
    assert len(calls) == 3


def test_read_timeout_not_retried():
    calls = []

    def handler(req):
        calls.append(1)
        raise httpx.ReadTimeout("slow")

    with pytest.raises(TTSError, match="tempo"):
        asyncio.run(_client(handler).synthesize("oi"))
    assert len(calls) == 1  # POST que pode ter chegado: nao repete (nao gasta credito em dobro)


# ------------------------------------------------------------------ preferencia por chat
def test_voice_prefs_persist(tmp_path):
    p = tmp_path / "voice.json"
    v = VoicePrefs(p, default_on=True)
    assert v.enabled(5)
    v.set(5, False)
    assert not VoicePrefs(p, default_on=True).enabled(5)
    assert VoicePrefs(p, default_on=True).enabled(6)


# ------------------------------------------------------------------ on_text / entrega
def _deps(tmp_path, tts_client, send_text=True, on=True):
    settings = SimpleNamespace(
        allowed_user_ids=frozenset({1}), admin_user_ids=frozenset({1}), nexus_auto_intent=False,
        tts_max_chars=500, tts_send_text=send_text,
    )
    ollama = MagicMock()
    ollama.chat = AsyncMock(return_value="Sistemas **online**, senhor.")
    d = h.Deps(
        settings=settings, state=RuntimeState(tmp_path / "r.json", "m", 0.8), ollama=ollama, nexus=None,
        history=h.History(10), tts=tts_client, voice=VoicePrefs(tmp_path / "v.json", on),
    )
    return d


def _update():
    msg = MagicMock(text="oi", reply_text=AsyncMock(), reply_voice=AsyncMock(), reply_audio=AsyncMock())
    return SimpleNamespace(effective_message=msg, effective_chat=SimpleNamespace(id=10), effective_user=SimpleNamespace(id=1)), msg


def _ctx(d):
    return SimpleNamespace(application=SimpleNamespace(bot_data={"deps": d}), user_data={}, bot=MagicMock(send_chat_action=AsyncMock()))


def _ok_client():
    return _client(lambda r: httpx.Response(200, content=OGG, headers={"content-type": "audio/ogg"}))


def test_on_text_sends_text_and_voice(tmp_path):
    d = _deps(tmp_path, _ok_client())
    u, msg = _update()
    asyncio.run(h.on_text(u, _ctx(d)))
    assert msg.reply_text.await_count == 1 and msg.reply_voice.await_count == 1


def test_on_text_voice_failure_falls_back_to_text_only_mode(tmp_path):
    bad = _client(lambda r: httpx.Response(503, json={"message": "busy"}))
    d = _deps(tmp_path, bad, send_text=False)
    u, msg = _update()
    asyncio.run(h.on_text(u, _ctx(d)))
    assert msg.reply_voice.await_count == 0 and msg.reply_text.await_count == 1  # texto salvou a resposta


def test_on_text_audio_only_skips_text_when_voice_ok(tmp_path):
    d = _deps(tmp_path, _ok_client(), send_text=False)
    u, msg = _update()
    asyncio.run(h.on_text(u, _ctx(d)))
    assert msg.reply_voice.await_count == 1 and msg.reply_text.await_count == 0


def test_on_text_voice_off_or_unconfigured(tmp_path):
    for client, on in ((_ok_client(), False), (None, True)):
        d = _deps(tmp_path, client, on=on)
        u, msg = _update()
        asyncio.run(h.on_text(u, _ctx(d)))
        assert msg.reply_voice.await_count == 0 and msg.reply_text.await_count == 1


def test_telegram_voice_error_does_not_break_reply(tmp_path):
    from telegram.error import BadRequest

    d = _deps(tmp_path, _ok_client())
    u, msg = _update()
    msg.reply_voice = AsyncMock(side_effect=BadRequest("VOICE_MESSAGES_FORBIDDEN"))
    asyncio.run(h.on_text(u, _ctx(d)))
    assert msg.reply_text.await_count == 1


def test_non_ogg_without_ffmpeg_uses_send_audio(tmp_path, monkeypatch):
    monkeypatch.setattr(tts, "_ffmpeg_to_ogg_opus", lambda data: None)
    mp3 = _client(lambda r: httpx.Response(200, content=b"ID3" + b"\x00" * 400, headers={"content-type": "audio/mpeg"}))
    d = _deps(tmp_path, mp3)
    u, msg = _update()
    asyncio.run(h.on_text(u, _ctx(d)))
    assert msg.reply_audio.await_count == 1 and msg.reply_voice.await_count == 0


def test_cmd_voice_toggle(tmp_path):
    d = _deps(tmp_path, _ok_client())
    u, msg = _update()
    msg.text = "/voz off"
    asyncio.run(h.cmd_voice(u, _ctx(d)))
    assert not d.voice.enabled(10)
    msg.text = "/voz on"
    asyncio.run(h.cmd_voice(u, _ctx(d)))
    assert d.voice.enabled(10)
