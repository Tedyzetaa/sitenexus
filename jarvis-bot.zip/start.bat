@echo off
setlocal EnableExtensions
chcp 65001 >nul
title J.A.R.V.I.S. Bot
cd /d "%~dp0"

rem ============================================================
rem  J.A.R.V.I.S. - launcher do bot de Telegram
rem  Uso:  start.bat           (interativo)
rem        start.bat silent    (sem perguntas e sem pause; log em logs\jarvis.log)
rem ============================================================

rem ---- Configuracao ----
set "REQ_FILE=requirements.txt"
rem Python usado so para CRIAR a venv, caso ela nao exista (ex.: py -3.12)
set "PY_NEW=py -3"

set "SILENT="
if /i "%~1"=="silent" set "SILENT=1"

set "PYTHONUTF8=1"
set "PYTHONUNBUFFERED=1"

rem ---- 1. venv ----
set "NEED_INSTALL="
if not exist "venv\Scripts\python.exe" (
    echo [*] venv nao encontrada. Criando...
    %PY_NEW% -m venv venv || goto :erro
    set "NEED_INSTALL=1"
)
set "PY=venv\Scripts\python.exe"
set "VIRTUAL_ENV=%CD%\venv"
set "PATH=%CD%\venv\Scripts;%PATH%"

rem ---- 2. dependencias (so instala se faltar algo) ----
if not defined NEED_INSTALL (
    "%PY%" -c "import telegram, httpx, dotenv" >nul 2>&1
    if errorlevel 1 set "NEED_INSTALL=1"
)
if defined NEED_INSTALL (
    echo [*] Instalando dependencias de %REQ_FILE%...
    "%PY%" -m pip install --upgrade pip >nul 2>&1
    "%PY%" -m pip install -r "%REQ_FILE%" || goto :erro
)

rem ---- 3. .env (token e whitelist sao obrigatorios) ----
if not exist ".env" (
    if exist ".env.example" copy /y ".env.example" ".env" >nul
    echo [!] .env criado a partir do .env.example.
    echo     Preencha TELEGRAM_BOT_TOKEN e ALLOWED_USER_IDS e rode de novo.
    if not defined SILENT start "" notepad ".env"
    goto :fatal
)
set "MISSING="
findstr /b /r /c:"TELEGRAM_BOT_TOKEN=[^ ]" ".env" >nul 2>&1 || set "MISSING=TELEGRAM_BOT_TOKEN"
findstr /b /r /c:"ALLOWED_USER_IDS=[^ ]" ".env" >nul 2>&1 || set "MISSING=%MISSING% ALLOWED_USER_IDS"
if defined MISSING (
    echo [X] Faltando no .env: %MISSING%
    if not defined SILENT start "" notepad ".env"
    goto :fatal
)

rem ---- 4. le valores do .env ----
call :getenv OLLAMA_URL   OLLAMA_HOST   http://127.0.0.1:11434
call :getenv OLLAMA_MDL   OLLAMA_MODEL  jarvis-persona
call :getenv NEXUS_ON     NEXUS_ENABLED true
call :getenv NEXUS_ADDR   NEXUS_URL     http://127.0.0.1:666

rem ---- 5. Ollama (sobe sozinho se for local) ----
set "OLLAMA_UP="
curl.exe -s -f -m 3 -o NUL "%OLLAMA_URL%/api/tags" >nul 2>&1
if not errorlevel 1 goto :ollama_up

echo %OLLAMA_URL% | findstr /i "localhost 127.0.0.1" >nul
if errorlevel 1 (
    echo [!] Ollama remoto sem resposta: %OLLAMA_URL%
    goto :ollama_done
)
where ollama >nul 2>&1
if errorlevel 1 (
    echo [!] Ollama offline e nao esta no PATH - o bot nao vai conseguir responder.
    goto :ollama_done
)
echo [*] Ollama offline. Iniciando...
start "Ollama" /min ollama serve
for /l %%i in (1,1,15) do (
    ping -n 2 127.0.0.1 >nul
    curl.exe -s -f -m 2 -o NUL "%OLLAMA_URL%/api/tags" >nul 2>&1 && goto :ollama_up
)
echo [!] Ollama nao respondeu em 15s - seguindo mesmo assim.
goto :ollama_done

:ollama_up
set "OLLAMA_UP=1"
curl.exe -s -m 3 "%OLLAMA_URL%/api/tags" | findstr /i /c:"%OLLAMA_MDL%" >nul
if errorlevel 1 (
    echo [!] Modelo %OLLAMA_MDL% nao existe no Ollama.
    if exist "Modelfile" echo     Crie com: ollama create %OLLAMA_MDL% -f Modelfile
)
:ollama_done

rem ---- 6. Nexus-Bridge (so avisa; o bot funciona sem ele) ----
if /i "%NEXUS_ON%"=="true" (
    curl.exe -s -m 3 -o NUL "%NEXUS_ADDR%/api/health" >nul 2>&1
    if errorlevel 1 echo [!] Nexus-Bridge offline em %NEXUS_ADDR% - ferramentas e /video indisponiveis ate ele subir.
)

rem ---- 7. ja existe outra instancia? (2 bots no mesmo token = erro Conflict) ----
powershell -NoProfile -Command "if (Get-CimInstance Win32_Process | Where-Object { $_.Name -eq 'python.exe' -and $_.CommandLine -like '*-m jarvis*' }) { exit 1 } else { exit 0 }" >nul 2>&1
if errorlevel 1 (
    echo [!] Ja existe outra instancia do J.A.R.V.I.S. rodando.
    if defined SILENT exit /b 1
    choice /c SN /m "Encerrar a outra instancia e continuar"
    if errorlevel 2 exit /b 1
    powershell -NoProfile -Command "Get-CimInstance Win32_Process | Where-Object { $_.Name -eq 'python.exe' -and $_.CommandLine -like '*-m jarvis*' } | ForEach-Object { Stop-Process -Id $_.ProcessId -Force }" >nul 2>&1
    ping -n 3 127.0.0.1 >nul
)

rem ---- 8. log em arquivo no modo silent (janela escondida) ----
set "LOG="
if defined SILENT (
    if not exist "logs" mkdir "logs"
    set "LOG=logs\jarvis.log"
    if exist "logs\jarvis.log" for %%F in ("logs\jarvis.log") do if %%~zF GTR 5242880 move /y "logs\jarvis.log" "logs\jarvis.old.log" >nul
)

rem ---- 9. bot, religa se morrer por fora do Python ----
:loop
echo.
echo [*] J.A.R.V.I.S. iniciando - Ctrl+C para parar
if defined LOG (
    "%PY%" -m jarvis >>"%LOG%" 2>&1
) else (
    "%PY%" -m jarvis
)
set "RC=%errorlevel%"

rem 0 = parada limpa. -1073741510 = Ctrl+C no Windows.
if "%RC%"=="0" goto :fim
if "%RC%"=="-1073741510" goto :fim
rem 2 = config ou token invalido: reiniciar nao adianta.
if "%RC%"=="2" goto :fatal

echo [%date% %time%] J.A.R.V.I.S. encerrou com codigo %RC%. Reiniciando em 5s...
if defined LOG echo [%date% %time%] encerrou com codigo %RC%. Reiniciando em 5s...>>"%LOG%"
ping -n 6 127.0.0.1 >nul
goto :loop

:fatal
echo.
echo [ERRO FATAL] Configuracao ou token invalido. Corrija o .env e rode de novo.
if not defined SILENT pause
exit /b 2

:erro
echo.
echo [X] Falha ao preparar o ambiente. Veja as mensagens acima.
if not defined SILENT pause
exit /b 1

:fim
echo.
echo J.A.R.V.I.S. encerrado.
if not defined SILENT pause
exit /b 0

rem ---- sub-rotina: le CHAVE do .env em VARIAVEL (com valor padrao) ----
rem uso: call :getenv VARIAVEL CHAVE PADRAO
:getenv
set "%~1=%~3"
for /f "usebackq tokens=1,* delims==" %%A in (`findstr /b /i /c:"%~2=" ".env"`) do set "%~1=%%~B"
exit /b 0
