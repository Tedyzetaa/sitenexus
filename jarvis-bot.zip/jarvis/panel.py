"""Menus interativos (teclados inline): menu principal, ferramentas do Nexus e painel de admin.

Seguranca (mesma regra do resto do bot):
- Comandos ja entram atras de `filters.User(...)`.
- Botoes (callback_query) NAO passam por filtros do PTB, entao `on_callback` confere a whitelist
  e, para o namespace `a:` (admin), a lista de admins. Quem nao pode, nao recebe NADA (nem toast).
  Isso importa em grupos, onde qualquer membro consegue apertar um botao.

Convencao de callback_data (limite do Telegram: 64 bytes):
  m:<tela>            menu principal (main | status | help | reset)
  t:<acao>[:<arg>]    ferramentas (l=lista/pagina, o=abrir, r=executar, a=argumentos, f=pedido livre, u=atualizar)
  a:<acao>[:<args>]   admin
  x:<destino>         cancela uma entrada pendente e volta para a tela
"""
from __future__ import annotations

import contextlib
import html
import logging
import re
import time
import zlib
from dataclasses import dataclass

from telegram import InlineKeyboardButton as Btn
from telegram import InlineKeyboardMarkup as Kb
from telegram import Update
from telegram.constants import ParseMode
from telegram.error import BadRequest, NetworkError
from telegram.ext import ApplicationHandlerStop, ContextTypes

from . import handlers as h
from .nexus import NexusError
from .ollama_client import OllamaError
from .persona import MAX_DIRECTIVE_LEN, MAX_DIRECTIVES

log = logging.getLogger("jarvis.panel")

PENDING_TTL = 300      # segundos que o bot espera a proxima mensagem (argumentos / diretriz)
TOOLS_TTL = 300        # cache da lista de ferramentas do Nexus
TOOLS_PER_PAGE = 8
MODELS_PER_PAGE = 6

Screen = tuple[str, Kb]


# --- utilidades ----------------------------------------------------------------------
def _esc(value: object) -> str:
    return html.escape(str(value), quote=False)


def _short(text: str, n: int) -> str:
    text = " ".join(text.split())
    return text if len(text) <= n else text[: n - 1] + "…"


def _crc(text: str) -> str:
    """Impressao curta para detectar botao 'velho' (lista mudou desde que o menu foi desenhado)."""
    return format(zlib.crc32(text.encode("utf-8")) & 0xFFFF, "04x")


def _chunk(items: list, size: int) -> list[list]:
    return [items[i : i + size] for i in range(0, len(items), size)]


def _pager(prefix: str, page: int, pages: int) -> list[Btn]:
    row: list[Btn] = []
    if page > 0:
        row.append(Btn("◀️", callback_data=f"{prefix}:{page - 1}"))
    row.append(Btn(f"{page + 1}/{pages}", callback_data="noop"))
    if page < pages - 1:
        row.append(Btn("▶️", callback_data=f"{prefix}:{page + 1}"))
    return row


def _is_admin(deps: h.Deps, user_id: int | None) -> bool:
    return user_id is not None and user_id in deps.settings.admin_user_ids


# --- entrada pendente (proxima mensagem de texto vira argumento/diretriz) ----------------
def _set_pending(context: ContextTypes.DEFAULT_TYPE, kind: str, **data) -> None:
    context.user_data["pending"] = {"kind": kind, "ts": time.monotonic(), **data}


def _clear_pending(context: ContextTypes.DEFAULT_TYPE) -> None:
    context.user_data.pop("pending", None)


# =======================================================================================
#  TELAS
# =======================================================================================
def screen_main(deps: h.Deps, chat_id: int, admin: bool) -> Screen:
    text = (
        "🤖 <b>J.A.R.V.I.S.</b> — <i>online</i>\n\n"
        "💬 Escreva qualquer mensagem para conversar.\n"
        "🛠 Use os botões para acionar as ferramentas do Nexus.\n\n"
        f"<code>{_esc(deps.state.model)}</code> · contexto: {deps.history.size(chat_id)} msg"
    )
    rows = [
        [Btn("🛠 Ferramentas", callback_data="t:l:0"), Btn("📊 Status", callback_data="m:status")],
        [Btn("🧹 Limpar contexto", callback_data="m:reset"), Btn("❓ Ajuda", callback_data="m:help")],
    ]
    if deps.tts is not None and deps.voice is not None:
        on = deps.voice.enabled(chat_id)
        rows.append([Btn("🔊 Voz: ligada (desligar)" if on else "🔇 Voz: desligada (ligar)", callback_data="m:voice")])
    if admin:
        rows.append([Btn("⚙️ Painel de administração", callback_data="a:home")])
    return text, Kb(rows)


def screen_help(admin: bool) -> Screen:
    text = (
        "❓ <b>Ajuda</b>\n\n"
        "<b>Conversa</b>\nEnvie qualquer texto. /reset limpa o contexto.\n\n"
        "<b>Comandos</b>\n"
        "/menu — painel principal com botões\n"
        "/ferramentas — ferramentas do Nexus\n"
        "/status — estado do núcleo e da ponte Nexus\n"
        "/voz on|off — respostas em áudio neste chat\n"
        "/nexus &lt;pedido&gt; — aciona o Nexus direto\n"
        "/video &lt;prompt&gt; — gera vídeo; anexe uma imagem (ou responda a uma) como referência\n"
        "Qualquer comando do Nexus também funciona (ex.: <code>/clima Dourados MS</code>)."
    )
    if admin:
        text += (
            "\n\n<b>Administração</b>\n"
            "/admin — painel com botões\n"
            "Atalhos: /diretriz &lt;texto&gt; · /diretrizes · /remover &lt;n&gt; · /limpar_diretrizes · "
            "/sistema · /modelo [nome] · /temperatura [0-2]"
        )
    return text, Kb([[Btn("⬅️ Menu", callback_data="m:main")]])


async def screen_status(deps: h.Deps, chat_id: int) -> Screen:
    body = await h.build_status(deps, chat_id)
    text = f"📊 <b>Status</b>\n\n{_esc(body)}"
    return text, Kb([[Btn("🔄 Atualizar", callback_data="m:status"), Btn("⬅️ Menu", callback_data="m:main")]])


# --- Ferramentas ----------------------------------------------------------------------
@dataclass(frozen=True)
class Tool:
    name: str
    desc: str = ""
    usage: str = ""   # trecho de argumentos, ex.: "<local>" ou "[min] [horas]"


_TOOL_EMOJI = {
    "sismo": "🌋", "terremoto": "🌋", "clima": "🌦", "tempo": "🌦", "noaa": "🛰", "nasa": "🚀",
    "imagem": "🖼", "video": "🎬", "audio": "🎧", "dublagem": "🎙", "rag": "📚", "busca": "🔎",
}
# So usado se o Nexus nao devolver nada parseavel (nomes vindos dos exemplos do README).
_FALLBACK_TOOLS = (
    Tool("sismo", "Terremotos recentes", "[forte] [mag]"),
    Tool("clima", "Previsão do tempo", "<cidade UF>"),
    Tool("noaa", "Dados NOAA (ex.: índice Kp)", "[kp]"),
)
_SELF_COMMANDS = {"ferramentas", "ajuda", "help", "start", "menu", "reset", "status", "nexus", "admin", "cancelar", "video"}
_TOOL_TOKEN = re.compile(r"(?<![\w/:.])/([A-Za-z_]\w{1,30})\b")
_ARG_HINT = re.compile(r"[<\[][^<>\[\]]*[>\]]")
_NAME_OK = re.compile(r"^\w{1,31}$")


def parse_tools(text: str) -> list[Tool]:
    """Extrai ferramentas do texto que o Nexus devolve para /ferramentas.

    Tolerante: aceita qualquer linha com `/comando` (com ou sem bullet/markdown). Se a linha tem
    um unico comando, o resto vira descricao/uso; com varios, cada um entra sem descricao.
    """
    found: dict[str, Tool] = {}
    for raw in (text or "").splitlines():
        line = re.sub(r"[*`_]", "", raw)
        matches = list(_TOOL_TOKEN.finditer(line))
        if not matches:
            continue
        if len(matches) == 1:
            m = matches[0]
            name = m.group(1).lower()
            rest = line[m.end():]
            usage = " ".join(_ARG_HINT.findall(rest))
            desc = _ARG_HINT.sub("", rest).strip(" -–—:·•|\t")
            cand = [Tool(name, _short(desc, 200), usage)]
        else:
            cand = [Tool(m.group(1).lower()) for m in matches]
        for t in cand:
            if t.name not in _SELF_COMMANDS and t.name not in found:
                found[t.name] = t
    return list(found.values())


async def _load_tools(deps: h.Deps, force: bool = False) -> tuple[list[Tool], bool]:
    """(ferramentas, veio_do_fallback). Levanta NexusError se o Nexus estiver fora."""
    cached = deps.cache.get("tools")
    if cached and not force and time.monotonic() - cached[0] < TOOLS_TTL:
        return cached[1], cached[2]
    reply = await deps.nexus.dispatch_request("/ferramentas")  # type: ignore[union-attr]
    tools = parse_tools(reply.text) if reply.handled else []
    fallback = not tools
    if fallback:
        tools = list(_FALLBACK_TOOLS)
    deps.cache["tools"] = (time.monotonic(), tools, fallback)
    return tools, fallback


async def screen_tools(deps: h.Deps, page: int = 0, force: bool = False) -> Screen:
    back = [Btn("⬅️ Menu", callback_data="m:main")]
    if deps.nexus is None:
        return "🛠 <b>Ferramentas</b>\n\nPonte Nexus desativada (<code>NEXUS_ENABLED=false</code>).", Kb([back])
    try:
        tools, fallback = await _load_tools(deps, force)
    except NexusError as exc:
        text = f"🛠 <b>Ferramentas</b>\n\n⚠️ {_esc(exc)}"
        return text, Kb([[Btn("🔄 Tentar de novo", callback_data="t:u")], back])

    pages = max(1, -(-len(tools) // TOOLS_PER_PAGE))
    page = min(max(page, 0), pages - 1)
    chunk = tools[page * TOOLS_PER_PAGE : (page + 1) * TOOLS_PER_PAGE]
    buttons = [
        Btn(f"{_TOOL_EMOJI.get(t.name, '🔧')} /{t.name}", callback_data=f"t:o:{t.name}") for t in chunk
    ]
    rows = _chunk(buttons, 2)
    if pages > 1:
        rows.append(_pager("t:l", page, pages))
    rows.append([Btn("✍️ Pedido livre", callback_data="t:f"), Btn("🔄 Atualizar", callback_data="t:u")])
    rows.append(back)

    text = f"🛠 <b>Ferramentas do Nexus</b> — {len(tools)} disponível(is)\nToque numa ferramenta para abrir."
    if fallback:
        text += "\n\n<i>Não consegui ler a lista do Nexus; mostrando atalhos básicos. Use ✍️ Pedido livre para o resto.</i>"
    return text, Kb(rows)


async def screen_tool_card(deps: h.Deps, name: str) -> Screen:
    tool = None
    with contextlib.suppress(NexusError):
        tools, _ = await _load_tools(deps)
        tool = next((t for t in tools if t.name == name), None)
    tool = tool or Tool(name)
    emoji = _TOOL_EMOJI.get(name, "🔧")
    lines = [f"{emoji} <b>/{_esc(name)}</b>"]
    if tool.desc:
        lines.append(_esc(tool.desc))
    if tool.usage:
        lines.append(f"\n<b>Uso:</b> <code>/{_esc(name)} {_esc(tool.usage)}</code>")
    needs_args = "<" in tool.usage
    run = Btn("▶️ Executar", callback_data=f"t:r:{name}")
    args = Btn("✍️ Com argumentos", callback_data=f"t:a:{name}")
    rows = [[args, run] if needs_args else [run, args], [Btn("⬅️ Ferramentas", callback_data="t:l:0")]]
    return "\n".join(lines), Kb(rows)


# --- Admin ------------------------------------------------------------------------------
def screen_admin(deps: h.Deps, chat_id: int) -> Screen:
    st, cfg = deps.state, deps.settings
    text = (
        "⚙️ <b>Painel de administração</b>\n\n"
        f"🤖 Modelo: <code>{_esc(st.model)}</code>\n"
        f"🌡 Temperatura: <b>{st.temperature}</b>\n"
        f"📜 Diretrizes: <b>{len(st.directives)}</b>/{MAX_DIRECTIVES}\n"
        f"💬 Contexto deste chat: {deps.history.size(chat_id)} msg\n"
        f"🔗 Nexus: {'ativado' if deps.nexus else 'desativado'}"
        f"{' · auto-intent' if deps.nexus and cfg.nexus_auto_intent else ''}\n"
        f"👥 Whitelist: {len(cfg.allowed_user_ids)} · Admins: {len(cfg.admin_user_ids)}"
    )
    rows = [
        [Btn("🤖 Modelo", callback_data="a:model:0"), Btn("🌡 Temperatura", callback_data="a:temp")],
        [Btn("📜 Diretrizes", callback_data="a:dirs"), Btn("➕ Nova diretriz", callback_data="a:new")],
        [Btn("🧠 Prompt do sistema", callback_data="a:prompt"), Btn("📊 Status", callback_data="a:status")],
        [Btn("🧹 Limpar contexto", callback_data="a:reset"), Btn("⬅️ Menu", callback_data="m:main")],
    ]
    return text, Kb(rows)


async def screen_models(deps: h.Deps, page: int = 0) -> Screen:
    back = [Btn("⬅️ Admin", callback_data="a:home")]
    try:
        models = await deps.ollama.list_models()
    except OllamaError as exc:
        return f"🤖 <b>Modelo</b>\n\n⚠️ {_esc(exc)}", Kb([[Btn("🔄 Tentar de novo", callback_data="a:model:0")], back])
    if not models:
        return "🤖 <b>Modelo</b>\n\nNenhum modelo instalado no Ollama.", Kb([back])

    pages = max(1, -(-len(models) // MODELS_PER_PAGE))
    page = min(max(page, 0), pages - 1)
    start = page * MODELS_PER_PAGE
    rows = []
    for i, name in enumerate(models[start : start + MODELS_PER_PAGE], start):
        mark = "✅ " if name == deps.state.model else ""
        rows.append([Btn(_short(f"{mark}{name}", 40), callback_data=f"a:ms:{i}:{_crc(name)}")])
    if pages > 1:
        rows.append(_pager("a:model", page, pages))
    rows.append(back)
    text = f"🤖 <b>Modelo ativo</b>\n<code>{_esc(deps.state.model)}</code>\n\nToque para trocar (vale já na próxima resposta)."
    if deps.state.model not in models:
        text += "\n\n⚠️ <i>O modelo atual não foi encontrado no Ollama.</i>"
    return text, Kb(rows)


_TEMP_PRESETS = (0.2, 0.5, 0.8, 1.0, 1.2, 1.5)


def screen_temp(deps: h.Deps) -> Screen:
    cur = deps.state.temperature
    presets = [
        Btn(f"● {v}" if abs(v - cur) < 1e-9 else f"{v}", callback_data=f"a:ts:{v}") for v in _TEMP_PRESETS
    ]
    rows = _chunk(presets, 3)
    rows.append([Btn("➖ 0.1", callback_data="a:td:-1"), Btn("➕ 0.1", callback_data="a:td:1")])
    rows.append([Btn("⬅️ Admin", callback_data="a:home")])
    text = (
        f"🌡 <b>Temperatura:</b> {cur}\n\n"
        "<i>Baixa (0.2) = respostas precisas e previsíveis.\n"
        "Alta (1.5) = mais criativo e imprevisível. Máx. 2.0.</i>"
    )
    return text, Kb(rows)


def screen_dirs(deps: h.Deps) -> Screen:
    ds = deps.state.directives
    head = f"📜 <b>Diretrizes</b> ({len(ds)}/{MAX_DIRECTIVES})"
    if ds:
        body = "\n".join(f"<b>{i}.</b> {_esc(_short(d, 140))}" for i, d in enumerate(ds, 1))
        head += "\nToque em 🗑 para remover uma."
    else:
        body = "<i>Nenhuma diretriz adicional ativa.</i>"
    rows = _chunk([Btn(f"🗑 {i}", callback_data=f"a:dd:{i}:{_crc(d)}") for i, d in enumerate(ds, 1)], 5)
    actions = [Btn("➕ Nova", callback_data="a:new")]
    if ds:
        actions.append(Btn("🧨 Limpar todas", callback_data="a:dc"))
    rows.append(actions)
    rows.append([Btn("⬅️ Admin", callback_data="a:home")])
    return f"{head}\n\n{body}", Kb(rows)


def screen_confirm_clear(deps: h.Deps) -> Screen:
    n = len(deps.state.directives)
    text = f"🧨 <b>Remover as {n} diretriz(es)?</b>\nEsta ação não pode ser desfeita."
    rows = [[Btn("✅ Sim, limpar", callback_data="a:dcy"), Btn("❌ Cancelar", callback_data="a:dirs")]]
    return text, Kb(rows)


# =======================================================================================
#  COMANDOS (abrem as telas como mensagem nova)
# =======================================================================================
async def _send(update: Update, screen: Screen) -> None:
    await update.effective_message.reply_text(screen[0], parse_mode=ParseMode.HTML, reply_markup=screen[1])


def _admin_of(update: Update, context: ContextTypes.DEFAULT_TYPE) -> bool:
    user = update.effective_user
    return _is_admin(h._deps(context), user.id if user else None)


async def cmd_menu(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    _clear_pending(context)
    deps = h._deps(context)
    await _send(update, screen_main(deps, update.effective_chat.id, _admin_of(update, context)))


async def cmd_help(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    await _send(update, screen_help(_admin_of(update, context)))


async def cmd_tools(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    _clear_pending(context)
    await _send(update, await screen_tools(h._deps(context)))


async def cmd_nexus(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    """/nexus sem argumento abre o menu de ferramentas; com argumento, executa o pedido."""
    if h._arg_text(update):
        await h.cmd_nexus(update, context)
    else:
        await cmd_tools(update, context)


@h.admin_only
async def cmd_admin(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    _clear_pending(context)
    await _send(update, screen_admin(h._deps(context), update.effective_chat.id))


async def cmd_cancel(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    had = context.user_data.pop("pending", None)
    await update.effective_message.reply_text("Cancelado." if had else "Nada pendente.")


# =======================================================================================
#  BOTOES
# =======================================================================================
class _Cb:
    """Contexto de um clique: garante um unico `answerCallbackQuery` (toast opcional)."""

    def __init__(self, update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
        self.update, self.context = update, context
        self.q = update.callback_query
        self.deps = h._deps(context)
        self.chat_id = update.effective_chat.id if update.effective_chat else 0
        self.admin = _is_admin(self.deps, self.q.from_user.id)
        self._acked = False

    async def ack(self, text: str | None = None, alert: bool = False) -> None:
        if self._acked:
            return
        self._acked = True
        # clique velho demais (BadRequest) ou rede instavel (NetworkError): o toast e opcional e,
        # como roda em `finally`, nao pode mascarar o erro real nem gerar outro.
        with contextlib.suppress(BadRequest, NetworkError):
            await self.q.answer(text, show_alert=alert)

    async def show(self, screen: Screen) -> None:
        """Edita a mensagem do menu no lugar; se nao der, manda uma nova."""
        text, kb = screen
        try:
            await h.tg_retry(
                lambda: self.q.edit_message_text(text, parse_mode=ParseMode.HTML, reply_markup=kb), "edicao de menu"
            )
        except BadRequest as exc:
            if "not modified" in str(exc).lower():
                return
            log.debug("edit falhou (%s); enviando mensagem nova", exc)
            await h.tg_retry(lambda: self.q.message.reply_text(text, parse_mode=ParseMode.HTML, reply_markup=kb))


async def _cb_main(c: _Cb, arg: str) -> None:
    if arg == "status":
        await c.ack("Consultando…")
        await c.show(await screen_status(c.deps, c.chat_id))
    elif arg == "help":
        await c.show(screen_help(c.admin))
    elif arg == "voice":
        if c.deps.voice is not None:
            c.deps.voice.set(c.chat_id, not c.deps.voice.enabled(c.chat_id))
            await c.ack("🔊 Voz ligada" if c.deps.voice.enabled(c.chat_id) else "🔇 Voz desligada")
        await c.show(screen_main(c.deps, c.chat_id, c.admin))
    elif arg == "reset":
        c.deps.history.reset(c.chat_id)
        await c.ack("🧹 Contexto limpo")
        await c.show(screen_main(c.deps, c.chat_id, c.admin))
    else:
        _clear_pending(c.context)
        await c.show(screen_main(c.deps, c.chat_id, c.admin))


async def _cb_tools(c: _Cb, arg: str) -> None:
    action, _, val = arg.partition(":")
    if action in {"l", "u"}:
        if action == "u":
            await c.ack("Atualizando…")
        _clear_pending(c.context)
        page = int(val) if val.isdigit() else 0
        await c.show(await screen_tools(c.deps, page, force=(action == "u")))
    elif action == "o" and _NAME_OK.match(val):
        _clear_pending(c.context)
        await c.show(await screen_tool_card(c.deps, val))
    elif action == "r" and _NAME_OK.match(val):
        await c.ack(f"Executando /{val}…")
        await h._run_nexus(c.update, c.context, f"/{val}")
    elif action == "a" and _NAME_OK.match(val):
        _set_pending(c.context, "tool", tool=val)
        text = (
            f"✍️ <b>/{_esc(val)}</b>\n\nEnvie os argumentos na <b>próxima mensagem</b>.\n"
            f"Ex.: <code>/{_esc(val)} </code>+ o que você mandar."
        )
        await c.show((text, Kb([[Btn("❌ Cancelar", callback_data=f"t:o:{val}")]])))
    elif action == "f":
        _set_pending(c.context, "free")
        text = (
            "✍️ <b>Pedido livre ao Nexus</b>\n\nEnvie o pedido na <b>próxima mensagem</b>.\n"
            "Ex.: <code>clima Dourados MS</code> ou <code>sismo forte 3</code>."
        )
        await c.show((text, Kb([[Btn("❌ Cancelar", callback_data="t:l:0")]])))
    else:
        await c.ack("Botão expirado — reabra com /ferramentas", alert=True)


async def _cb_admin(c: _Cb, arg: str) -> None:
    deps, st = c.deps, c.deps.state
    action, _, val = arg.partition(":")

    if action == "home":
        _clear_pending(c.context)
        await c.show(screen_admin(deps, c.chat_id))

    elif action == "status":
        await c.ack("Consultando…")
        text, _kb = await screen_status(deps, c.chat_id)
        await c.show((text, Kb([[Btn("🔄 Atualizar", callback_data="a:status"), Btn("⬅️ Admin", callback_data="a:home")]])))

    elif action == "reset":
        deps.history.reset(c.chat_id)
        await c.ack("🧹 Contexto limpo")
        await c.show(screen_admin(deps, c.chat_id))

    elif action == "prompt":
        await c.ack()
        await h._reply_long(c.update, st.system_prompt())

    elif action == "model":
        await c.show(await screen_models(deps, int(val) if val.isdigit() else 0))

    elif action == "ms":  # a:ms:<idx>:<crc>
        idx_s, _, crc = val.partition(":")
        try:
            models = await deps.ollama.list_models()
        except OllamaError as exc:
            await c.ack(f"⚠️ {exc}"[:190], alert=True)
            return
        if not idx_s.isdigit() or int(idx_s) >= len(models) or _crc(models[int(idx_s)]) != crc:
            await c.ack("A lista mudou — atualizei.")
        else:
            st.set_model(models[int(idx_s)])
            await c.ack(f"✅ Modelo: {_short(st.model, 150)}")
        await c.show(await screen_models(deps, 0))

    elif action == "temp":
        await c.show(screen_temp(deps))

    elif action in {"ts", "td"}:
        try:
            new = float(val) if action == "ts" else round(st.temperature + 0.1 * int(val), 1)
            st.set_temperature(min(2.0, max(0.0, new)))
            await c.ack(f"🌡 {st.temperature}")
        except ValueError:
            await c.ack("Valor inválido", alert=True)
        await c.show(screen_temp(deps))

    elif action == "dirs":
        _clear_pending(c.context)
        await c.show(screen_dirs(deps))

    elif action == "dd":  # a:dd:<n>:<crc>
        n_s, _, crc = val.partition(":")
        ds = st.directives
        if n_s.isdigit() and 1 <= int(n_s) <= len(ds) and _crc(ds[int(n_s) - 1]) == crc:
            st.remove_directive(int(n_s))
            await c.ack("🗑 Diretriz removida")
        else:
            await c.ack("A lista mudou — atualizei.")
        await c.show(screen_dirs(deps))

    elif action == "dc":
        await c.show(screen_confirm_clear(deps))

    elif action == "dcy":
        n = st.clear_directives()
        await c.ack(f"🧨 {n} diretriz(es) removida(s)")
        await c.show(screen_dirs(deps))

    elif action == "new":
        _set_pending(c.context, "directive")
        text = (
            "➕ <b>Nova diretriz</b>\n\nEnvie a instrução na <b>próxima mensagem</b> "
            f"(até {MAX_DIRECTIVE_LEN} caracteres).\nValerá já na próxima resposta e fica salva."
        )
        await c.show((text, Kb([[Btn("❌ Cancelar", callback_data="x:dirs")]])))

    else:
        await c.ack("Botão expirado — reabra com /admin", alert=True)


async def _cb_cancel(c: _Cb, arg: str) -> None:
    _clear_pending(c.context)
    await c.ack("Cancelado")
    if arg == "dirs" and c.admin:
        await c.show(screen_dirs(c.deps))
    elif arg == "tools":
        await c.show(await screen_tools(c.deps))
    else:
        await c.show(screen_main(c.deps, c.chat_id, c.admin))


async def on_callback(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    q = update.callback_query
    if q is None or q.from_user is None:
        return
    deps = h._deps(context)
    if q.from_user.id not in deps.settings.allowed_user_ids:
        return  # silencio absoluto: nem toast
    ns, _, arg = (q.data or "").partition(":")
    if ns == "a" and q.from_user.id not in deps.settings.admin_user_ids:
        return  # botao de admin apertado por nao-admin (ex.: em grupo): silencio
    c = _Cb(update, context)
    try:
        if ns == "m":
            await _cb_main(c, arg)
        elif ns == "t":
            await _cb_tools(c, arg)
        elif ns == "a":
            await _cb_admin(c, arg)
        elif ns == "x":
            await _cb_cancel(c, arg)
    finally:
        await c.ack()  # garante que o spinner do botao sempre some


# =======================================================================================
#  TEXTO LIVRE QUANDO HA ENTRADA PENDENTE
# =======================================================================================
async def on_pending_text(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    """Registrado antes do on_text. Sem pendencia (ou expirada) nao faz nada e a conversa segue."""
    pending = context.user_data.pop("pending", None)
    msg = update.effective_message
    if not pending or msg is None or not msg.text:
        return
    if time.monotonic() - pending["ts"] > PENDING_TTL:
        return  # expirou: trata como conversa normal
    deps = h._deps(context)
    text = msg.text.strip()
    kind = pending["kind"]

    if kind == "directive":
        if not _is_admin(deps, update.effective_user.id if update.effective_user else None):
            raise ApplicationHandlerStop
        kb = Kb([[Btn("📜 Diretrizes", callback_data="a:dirs"), Btn("⚙️ Admin", callback_data="a:home")]])
        try:
            n = deps.state.add_directive(text)
        except ValueError as exc:
            await msg.reply_text(f"⚠️ {exc}", reply_markup=kb)
        else:
            await msg.reply_text(f"✅ Diretriz #{n} ativa.", reply_markup=kb)
    elif kind == "tool":
        await h._run_nexus(update, context, f"/{pending['tool']} {text}")
    elif kind == "free":
        await h._run_nexus(update, context, text)
    raise ApplicationHandlerStop
