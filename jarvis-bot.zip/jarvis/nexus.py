"""Ponte com o Nexus-Bridge.

Ponto de entrada unico para pedidos personalizados: `NexusGateway.dispatch_request(texto)`.

 1. Se a primeira palavra casar com uma ACAO registrada (`@register_action`), ela roda aqui.
    E o gancho para futuros submodulos do sistema central (imagem, video, dublagem, RAG...).
 2. Senao o texto vai para `POST /api/v1/tools/chat` do Nexus (comandos /sismo, /clima, /noaa...).
"""
from __future__ import annotations

import asyncio
import base64
import json
import re
import time
from dataclasses import dataclass, field
from typing import Awaitable, Callable
from urllib.parse import quote, urlparse

import httpx

from .net import describe_network_error, retry_async

MAX_MEDIA_BYTES = 50 * 1024 * 1024  # limite de upload de bots do Telegram


class NexusError(RuntimeError):
    """Falha ao falar com o Nexus. `status_code` traz o HTTP quando houve resposta (ex.: 404)."""

    def __init__(self, message: str = "", status_code: int | None = None) -> None:
        super().__init__(message)
        self.status_code = status_code


def _is_not_found(exc: "NexusError") -> bool:
    return exc.status_code == 404 or "HTTP 404" in str(exc)


@dataclass
class NexusReply:
    handled: bool
    text: str = ""
    media: list[str] = field(default_factory=list)
    tool: str | None = None
    ok: bool = True


@dataclass
class VideoJob:
    """Recorte do `Job` do Nexus (`/api/jobs/{id}`) que o bot precisa."""
    id: str
    status: str
    refined_prompt: str | None = None
    file_path: str | None = None
    error: str | None = None


@dataclass
class CodeTask:
    """Recorte de GET /api/v1/openhands/tasks/{id}."""
    id: str
    status: str
    done: bool = False
    progress: str = ""
    result: str = ""
    error: str = ""


@dataclass
class MediaFile:
    data: bytes
    filename: str
    content_type: str


ActionFn = Callable[["NexusGateway", str], Awaitable[NexusReply]]
_ACTIONS: dict[str, ActionFn] = {}


def register_action(name: str) -> Callable[[ActionFn], ActionFn]:
    """Registra um submodulo: `/nexus <name> <argumentos>` chama fn(gateway, argumentos)."""
    def deco(fn: ActionFn) -> ActionFn:
        _ACTIONS[name.lower()] = fn
        return fn
    return deco


def _http_detail(r: httpx.Response) -> str:
    """': <detail>' do corpo de erro do FastAPI (curto), ou '' se nao houver."""
    try:
        d = r.json().get("detail")
    except (ValueError, AttributeError):
        return ""
    if isinstance(d, list):  # 422 de validacao do pydantic: [{"loc": [...], "msg": "..."}]
        d = "; ".join(str(i.get("msg", i)) if isinstance(i, dict) else str(i) for i in d)
    return f": {str(d)[:300]}" if d else ""


class NexusGateway:
    def __init__(self, base_url: str, token: str, timeout_s: float, connect_timeout_s: float = 5.0) -> None:
        headers = {"X-Nexus-Token": token} if token else {}
        self._base_url = base_url
        self._http = httpx.AsyncClient(
            base_url=base_url,
            headers=headers,
            timeout=httpx.Timeout(connect=connect_timeout_s, read=timeout_s, write=30.0, pool=10.0),
            limits=httpx.Limits(max_connections=10, max_keepalive_connections=2, keepalive_expiry=15.0),
            trust_env=False,  # o Nexus e local: proxy do sistema nao deve interceptar
        )

    # -- HTTP ----------------------------------------------------------------
    async def _request(self, method: str, path: str, **kw) -> httpx.Response:
        # GET e idempotente: repete em qualquer falha transitoria. POST (executa ferramenta) so e
        # repetido se falhou na fase de conexao, quando a requisicao nem chegou ao Nexus.
        only = None if method.upper() == "GET" else (httpx.ConnectError, httpx.ConnectTimeout)
        try:
            r = await retry_async(
                lambda: self._http.request(method, path, **kw),
                attempts=3, base=0.5, cap=3.0, what=f"Nexus {method} {path.split('?')[0]}", only=only,
            )
        except httpx.ConnectError as exc:
            raise NexusError(f"Nexus-Bridge offline em {self._base_url}") from exc
        except httpx.TimeoutException as exc:
            raise NexusError("tempo esgotado aguardando o Nexus-Bridge") from exc
        except (httpx.HTTPError, OSError) as exc:  # ReadError, RemoteProtocolError, WinError 10053/10054...
            raise NexusError(f"falha de rede com o Nexus: {describe_network_error(exc)}") from exc
        self._raise_for_status(r)
        return r

    @staticmethod
    def _raise_for_status(r: httpx.Response) -> None:
        if r.status_code == 401:
            raise NexusError("Nexus recusou o token (confira NEXUS_TOKEN = TOOLS_API_TOKEN).", 401)
        if r.status_code == 403:
            raise NexusError("Nexus negou: ferramenta sensivel exige token configurado.", 403)
        if r.status_code >= 400:
            raise NexusError(f"Nexus respondeu HTTP {r.status_code}{_http_detail(r)}", r.status_code)

    # -- API publica -----------------------------------------------------------
    async def command(self, message: str, auto_intent: bool = False) -> NexusReply:
        """`/api/v1/tools/chat`: handled=False significa 'nao e comigo, siga para o LLM'."""
        r = await self._request(
            "POST", "/api/v1/tools/chat",
            json={"message": message[:2000], "auto_intent": auto_intent},
        )
        try:
            d = r.json()
        except ValueError as exc:
            raise NexusError("resposta invalida do Nexus") from exc
        if not d.get("handled"):
            return NexusReply(handled=False)
        return NexusReply(
            handled=True,
            text=str(d.get("reply") or ""),
            media=[str(m) for m in d.get("media") or []],
            tool=d.get("tool"),
            ok=bool(d.get("ok", True)),
        )

    async def dispatch_request(self, text: str) -> NexusReply:
        """Ponto de entrada de pedidos personalizados (acoes registradas > ferramentas)."""
        text = text.strip()
        first, _, rest = text.partition(" ")
        action = _ACTIONS.get(first.lower().lstrip("/"))
        if action is not None:
            return await action(self, rest.strip())
        return await self.command(text if text.startswith("/") else "/" + text)

    async def health(self) -> dict:
        r = await self._request("GET", "/api/health")
        try:
            return r.json()
        except ValueError:
            return {"raw": r.text[:500]}

    async def fetch_media(self, url: str) -> MediaFile:
        """Baixa midia gerada pelo Nexus. Usa so o PATH da URL: o host e sempre o configurado."""
        p = urlparse(url)
        path = p.path if p.path.startswith("/") else "/" + p.path
        if p.query:
            path += "?" + p.query

        async def _download() -> tuple[bytes, str]:
            async with self._http.stream("GET", path) as r:
                if r.status_code >= 400:
                    await r.aread()
                    self._raise_for_status(r)
                declared = r.headers.get("content-length")
                if declared and declared.isdigit() and int(declared) > MAX_MEDIA_BYTES:
                    raise NexusError("midia maior que 50 MB")
                buf = bytearray()
                async for chunk in r.aiter_bytes():
                    buf.extend(chunk)
                    if len(buf) > MAX_MEDIA_BYTES:
                        raise NexusError("midia maior que 50 MB")
                return bytes(buf), r.headers.get("content-type", "application/octet-stream")

        try:
            data, ctype = await retry_async(_download, attempts=3, base=0.5, cap=3.0, what=f"Nexus GET {path.split('?')[0]}")
        except httpx.ConnectError as exc:
            raise NexusError(f"Nexus-Bridge offline em {self._base_url}") from exc
        except httpx.TimeoutException as exc:
            raise NexusError("tempo esgotado aguardando o Nexus-Bridge") from exc
        except (httpx.HTTPError, OSError) as exc:
            raise NexusError(f"falha de rede com o Nexus: {describe_network_error(exc)}") from exc
        return MediaFile(
            data=data,
            filename=path.rsplit("/", 1)[-1].split("?")[0] or "arquivo",
            content_type=ctype.split(";")[0],
        )

    # -- Video (Wan 2.2 via Kaggle / LTX local) -------------------------------------------
    async def submit_video(self, prompt: str, image: bytes | None = None, seed: int | None = None,
                           raw: bool = False) -> str:
        """Enfileira um job de video no Nexus e devolve o job_id. Com `image` = referencia do sujeito (reference-to-video no perfil r2v do Nexus; image-to-video nos outros perfis);
        sem imagem = texto-para-video (exige VIDEO_PROVIDER=kaggle_wan no Nexus).
        `raw=True` pula o refinamento do Ollama: o prompt vai exatamente como escrito para o Wan."""
        payload: dict = {"user_prompt": prompt[:2000]}
        if raw:
            payload["skip_refinement"] = True
        if image:
            payload["input_image_base64"] = base64.b64encode(image).decode("ascii")
        if seed is not None:
            payload["seed"] = seed
        r = await self._request("POST", "/api/generate-video", json=payload)
        try:
            job_id = r.json().get("id")
        except ValueError as exc:
            raise NexusError("resposta invalida do Nexus") from exc
        if not job_id:
            raise NexusError("o Nexus nao devolveu o id do job de video")
        return str(job_id)

    async def get_video_job(self, job_id: str) -> VideoJob:
        r = await self._request("GET", f"/api/jobs/{quote(str(job_id), safe='')}")
        try:
            d = r.json()
        except ValueError as exc:
            raise NexusError("resposta invalida do Nexus") from exc
        return VideoJob(
            id=str(d.get("id") or job_id),
            status=str(d.get("status") or "").lower(),
            refined_prompt=d.get("refined_prompt"),
            file_path=d.get("file_path"),
            error=d.get("error"),
        )

    async def wait_video_job(
        self,
        job_id: str,
        on_update: Callable[[VideoJob], Awaitable[None]] | None = None,
        poll_s: float = 5.0,
        max_wait_s: float = 3600.0,
        max_consecutive_errors: int = 6,
    ) -> VideoJob:
        """Consulta o job ate `completed` (devolve) ou `failed` (NexusError com o motivo).

        Falhas passageiras de rede/Nexus sao toleradas (o Nexus pode reiniciar no meio); um 404
        aborta na hora, porque o historico de jobs vive em memoria e foi perdido.
        """
        deadline = time.monotonic() + max_wait_s
        errors = 0
        while True:
            try:
                job = await self.get_video_job(job_id)
                errors = 0
            except NexusError as exc:
                if _is_not_found(exc):
                    raise NexusError("o Nexus nao conhece mais esse job (foi reiniciado?)", 404) from exc
                errors += 1
                if errors >= max_consecutive_errors:
                    raise
                job = None
            if job is not None:
                if job.status == "completed":
                    return job
                if job.status == "failed":
                    raise NexusError(job.error or "o Nexus marcou o job como falho")
                if on_update is not None:
                    await on_update(job)
            if time.monotonic() >= deadline:
                raise NexusError(f"tempo maximo de espera ({int(max_wait_s // 60)} min) esgotado")
            await asyncio.sleep(poll_s)

    # -- Agente de codigo (OpenHands via Nexus) -----------------------------------------
    async def submit_code(self, prompt: str, project: str = "") -> str:
        r = await self._request("POST", "/api/v1/openhands/tasks",
                                json={"prompt": prompt[:8000], "project": project})
        try:
            tid = r.json().get("id")
        except ValueError as exc:
            raise NexusError("resposta invalida do Nexus") from exc
        if not tid:
            raise NexusError("o Nexus nao devolveu o id da tarefa de codigo")
        return str(tid)

    async def get_code_task(self, task_id: str) -> CodeTask:
        r = await self._request("GET", f"/api/v1/openhands/tasks/{quote(str(task_id), safe='')}")
        try:
            d = r.json()
        except ValueError as exc:
            raise NexusError("resposta invalida do Nexus") from exc
        return CodeTask(
            id=str(d.get("id") or task_id), status=str(d.get("status") or ""),
            done=bool(d.get("done")), progress=str(d.get("progress") or ""),
            result=str(d.get("result") or ""), error=str(d.get("error") or ""),
        )

    async def stop_code_task(self, task_id: str) -> None:
        await self._request("POST", f"/api/v1/openhands/tasks/{quote(str(task_id), safe='')}/stop")

    async def wait_code_task(
        self, task_id: str,
        on_update: Callable[[CodeTask], Awaitable[None]] | None = None,
        poll_s: float = 4.0, max_wait_s: float = 1800.0, max_consecutive_errors: int = 6,
    ) -> CodeTask:
        """Consulta ate a tarefa terminar. Falhas passageiras sao toleradas; 404 aborta."""
        deadline = time.monotonic() + max_wait_s
        errors = 0
        while True:
            task = None
            try:
                task = await self.get_code_task(task_id)
                errors = 0
            except NexusError as exc:
                if _is_not_found(exc):
                    raise NexusError("o OpenHands nao conhece mais essa tarefa (reiniciou?)", 404) from exc
                errors += 1
                if errors >= max_consecutive_errors:
                    raise
            if task is not None:
                if task.done:
                    return task
                if on_update is not None:
                    await on_update(task)
            if time.monotonic() >= deadline:
                raise NexusError(f"tempo maximo de espera ({int(max_wait_s // 60)} min) esgotado")
            await asyncio.sleep(poll_s)

    async def kaggle_status(self) -> dict | None:
        """`/api/kaggle/status` do Nexus; None se indisponivel (Nexus antigo ou fora do ar)."""
        try:
            r = await self._request("GET", "/api/kaggle/status")
            d = r.json()
        except (NexusError, ValueError):
            return None
        return d if isinstance(d, dict) else None

    @staticmethod
    def video_media_path(file_path: str) -> str:
        """`generated_videos/<uuid>.mp4` (ou com barras do Windows) -> `/videos/<uuid>.mp4`."""
        name = re.split(r"[\\/]", file_path.strip())[-1]
        return f"/videos/{name}"

    async def aclose(self) -> None:
        await self._http.aclose()


# --- Acoes de exemplo (copie o padrao para plugar novos submodulos) -------------------
@register_action("status")
async def _status(gw: NexusGateway, _args: str) -> NexusReply:
    data = await gw.health()
    text = json.dumps(data, ensure_ascii=False, indent=2)
    return NexusReply(handled=True, text=f"Nexus-Bridge:\n{text[:3500]}", tool="status")
