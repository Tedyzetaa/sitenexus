"""Handlers do Telegram. Todos (exceto o audit) ja sao registrados atras do filtro de whitelist."""
from __future__ import annotations

import asyncio
import contextlib
import io
import logging
import re
import time
from collections import defaultdict
from contextlib import asynccontextmanager
from dataclasses import dataclass, field
from functools import wraps

from telegram import Update
from telegram.constants import ChatAction, ParseMode
from telegram.error import BadRequest, Conflict, Forbidden, NetworkError, RetryAfter, TelegramError
from telegram.ext import ContextTypes

from .config import Settings
from .memory import History
from .net import LogThrottle, describe_network_error, is_network_error, retry_async
from .nexus import CodeTask, NexusError, NexusGateway, NexusReply, VideoJob
from .ollama_client import OllamaClient, OllamaError
from .persona import RuntimeState
from .tts import TTSClient, TTSError, VoicePrefs, clean_for_speech, is_ogg, to_voice_note
from .utils import format_html, split_message

log = logging.getLogger("jarvis.handlers")
_NET_THROTTLE = LogThrottle(30.0)  # 1 aviso de rede por tipo de falha a cada 30 s


@dataclass
class Deps:
    settings: Settings
    state: RuntimeState
    ollama: OllamaClient
    nexus: NexusGateway | None
    history: History
    locks: defaultdict = field(default_factory=lambda: defaultdict(asyncio.Lock))
    cache: dict = field(default_factory=dict)  # cache leve dos menus (lista de ferramentas etc.)
    tts: TTSClient | None = None  # None = voz nao configurada
    voice: VoicePrefs | None = None
    video_active: set = field(default_factory=set)  # chats com um /video em andamento (1 por chat)
    code_active: dict = field(default_factory=dict)  # chat_id -> task_id do /code em andamento (1 por chat)


def _deps(context: ContextTypes.DEFAULT_TYPE) -> Deps:
    return context.application.bot_data["deps"]


def _arg_text(update: Update) -> str:
    """Texto apos o comando, preservando quebras de linha."""
    parts = (update.effective_message.text or "").split(None, 1)
    return parts[1].strip() if len(parts) > 1 else ""


@asynccontextmanager
async def typing(bot, chat_id: int, action: str = ChatAction.TYPING):
    async def _loop() -> None:
        while True:
            with contextlib.suppress(Exception):
                await bot.send_chat_action(chat_id, action)
            await asyncio.sleep(4)

    task = asyncio.create_task(_loop())
    try:
        yield
    finally:
        task.cancel()
        # gather(return_exceptions=True) engole so o cancelamento da tarefa interna; se o HANDLER for
        # cancelado enquanto espera, o CancelledError propaga (suppress(CancelledError) o engolia).
        await asyncio.gather(task, return_exceptions=True)


async def tg_retry(fn, what: str = "envio ao Telegram"):
    """Repete uma chamada ao Telegram em falha de rede (3 tentativas, backoff curto).

    Trade-off consciente: um TimedOut de leitura pode ter entregue a mensagem, entao no pior caso ha
    uma resposta duplicada; isso e preferivel a perder uma resposta do LLM que levou minutos.
    BadRequest/Forbidden NAO sao repetidos (nao sao transitorios).
    """
    return await retry_async(fn, attempts=3, base=1.0, cap=8.0, what=what)  # BadRequest fica de fora (ver net.py)


async def safe_reply(msg, text: str, **kw) -> bool:
    """reply_text que nunca levanta por falha de rede: avisos/erros nao podem gerar novo erro."""
    try:
        await tg_retry(lambda: msg.reply_text(text, **kw))
        return True
    except (NetworkError, RetryAfter, Forbidden) as exc:  # inclui BadRequest: aviso nunca deve levantar
        log.warning("nao consegui enviar aviso ao usuario (%s)", describe_network_error(exc))
        return False


async def _reply_long(update: Update, text: str) -> None:
    msg = update.effective_message
    for chunk in split_message(text):
        try:
            await tg_retry(lambda: msg.reply_text(format_html(chunk), parse_mode=ParseMode.HTML))
        except BadRequest:  # HTML malformado (ex.: bloco cortado ao meio): manda texto puro
            await tg_retry(lambda: msg.reply_text(chunk))


async def _deliver_nexus(update: Update, deps: Deps, reply: NexusReply) -> None:
    if reply.text:
        await _reply_long(update, reply.text)
    msg = update.effective_message
    for url in reply.media:
        try:
            f = await deps.nexus.fetch_media(url)  # type: ignore[union-attr]
            buf = io.BytesIO(f.data)
            buf.name = f.filename
            ct = f.content_type
            if ct.startswith("image/") and len(f.data) <= 10 * 1024 * 1024:
                await msg.reply_photo(buf)
            elif ct.startswith("video/"):
                await msg.reply_video(buf)
            elif ct.startswith("audio/"):
                await msg.reply_audio(buf)
            else:
                await msg.reply_document(buf)
        except Exception as exc:  # midia nunca derruba a resposta de texto
            log.warning("falha ao anexar midia do Nexus: %s", describe_network_error(exc) if is_network_error(exc) else exc)
            await safe_reply(msg, "⚠️ Não consegui anexar uma das mídias.")


def admin_only(fn):
    """Silencio total para quem nao e admin (mesma regra da whitelist)."""
    @wraps(fn)
    async def wrapper(update: Update, context: ContextTypes.DEFAULT_TYPE):
        user = update.effective_user
        if user is None or user.id not in _deps(context).settings.admin_user_ids:
            return
        await fn(update, context)
    return wrapper


# --- Auditoria silenciosa -----------------------------------------------------------
async def audit_unauthorized(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    """Nunca responde. So registra (DEBUG, sem conteudo) para voce enxergar tentativas."""
    user = update.effective_user
    if user is not None and user.id not in _deps(context).settings.allowed_user_ids:
        log.debug("update descartado de usuario nao autorizado id=%s", user.id)


# --- Conversa -----------------------------------------------------------------------
async def on_text(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    deps = _deps(context)
    msg, chat = update.effective_message, update.effective_chat
    if msg is None or chat is None or not msg.text:
        return
    text = msg.text.strip()
    if not text:
        return

    async with deps.locks[chat.id]:  # uma conversa por vez por chat (contexto coerente)
        async with typing(context.bot, chat.id):
            if deps.nexus is not None and deps.settings.nexus_auto_intent:
                try:
                    reply = await deps.nexus.command(text, auto_intent=True)
                except NexusError as exc:
                    log.warning("Nexus indisponivel no auto-intent: %s", exc)
                else:
                    if reply.handled:
                        await _deliver_nexus(update, deps, reply)
                        deps.history.add(chat.id, "user", text)
                        deps.history.add(
                            chat.id, "assistant",
                            f"[Relatório da ferramenta {reply.tool}]\n{reply.text[:1500]}",
                        )
                        return

            messages = [
                {"role": "system", "content": deps.state.system_prompt()},
                *deps.history.get(chat.id),
                {"role": "user", "content": text},
            ]
            try:
                answer = await deps.ollama.chat(messages, deps.state.model, deps.state.temperature)
            except OllamaError as exc:
                await safe_reply(msg, f"⚠️ Núcleo cognitivo indisponível: {exc}")
                return
            deps.history.add(chat.id, "user", text)
            deps.history.add(chat.id, "assistant", answer)
        await _deliver_answer(update, context, deps, answer)


# --- Voz (TTS) --------------------------------------------------------------------------
def voice_on(deps: Deps, chat_id: int) -> bool:
    return deps.tts is not None and deps.voice is not None and deps.voice.enabled(chat_id)


async def _send_voice(msg, audio: bytes) -> None:
    """Bolha de voz se for (ou der para virar) OGG/Opus; senao player de audio."""
    note = audio if is_ogg(audio) else await to_voice_note(audio)

    def _file(data: bytes, name: str) -> io.BytesIO:
        buf = io.BytesIO(data)
        buf.name = name
        return buf

    if note is not None:
        await retry_async(lambda: msg.reply_voice(_file(note, "jarvis.ogg")), attempts=2, base=1.0, cap=4.0, what="envio de voz")
    else:
        await retry_async(lambda: msg.reply_audio(_file(audio, "jarvis.mp3"), title="J.A.R.V.I.S."), attempts=2, base=1.0, cap=4.0, what="envio de audio")


async def _try_voice(update: Update, context: ContextTypes.DEFAULT_TYPE, deps: Deps, answer: str) -> tuple[bool, bool]:
    """Tenta responder em voz. Devolve (enviou, truncou). Nunca levanta: qualquer falha = (False, ...)."""
    chat, msg = update.effective_chat, update.effective_message
    spoken, truncated = clean_for_speech(answer, deps.settings.tts_max_chars)
    if not spoken or deps.tts is None or deps.tts.cooling_down:
        return False, truncated
    try:
        async with typing(context.bot, chat.id, ChatAction.RECORD_VOICE):
            audio = await deps.tts.synthesize(spoken)
            await _send_voice(msg, audio)
        return True, truncated
    except TTSError as exc:
        log.warning("voz indisponivel, seguindo so com texto: %s", exc)
    except (TelegramError, OSError) as exc:  # inclui rede e VOICE_MESSAGES_FORBIDDEN
        log.warning("nao consegui enviar o audio (%s)", describe_network_error(exc) if is_network_error(exc) else exc)
    except Exception as exc:  # noqa: BLE001 - bug no caminho da voz nao pode matar a resposta de texto
        log.error("erro inesperado na voz: %s", exc, exc_info=exc)
    return False, truncated


async def _deliver_answer(update: Update, context: ContextTypes.DEFAULT_TYPE, deps: Deps, answer: str) -> None:
    """Texto sempre chega. Voz e um extra: falhou = so texto."""
    chat = update.effective_chat
    if not voice_on(deps, chat.id):
        await _reply_long(update, answer)
        return
    if deps.settings.tts_send_text:
        await _reply_long(update, answer)  # texto primeiro (imediato); o audio chega depois
        await _try_voice(update, context, deps, answer)
        return
    sent, truncated = await _try_voice(update, context, deps, answer)
    if not sent or truncated:  # so-audio, mas o audio falhou ou cobriu apenas o comeco
        await _reply_long(update, answer)


async def cmd_voice(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    deps = _deps(context)
    msg, chat = update.effective_message, update.effective_chat
    if deps.tts is None or deps.voice is None:
        await msg.reply_text("Voz não configurada (defina FISH_API_KEY e FISH_VOICE_ID no .env).")
        return
    arg = _arg_text(update).lower()
    if arg in {"on", "ligar", "sim"}:
        deps.voice.set(chat.id, True)
    elif arg in {"off", "desligar", "nao", "não"}:
        deps.voice.set(chat.id, False)
    elif arg:
        await msg.reply_text("Uso: /voz on | /voz off")
        return
    estado = "🔊 ligada" if deps.voice.enabled(chat.id) else "🔇 desligada"
    extra = "\n⏸ Em pausa temporária (erro de chave/saldo); respondendo só em texto." if deps.tts.cooling_down else ""
    await msg.reply_text(f"Voz {estado} neste chat.{extra}\nUso: /voz on | /voz off")


# --- Comandos gerais ------------------------------------------------------------------
async def cmd_reset(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    _deps(context).history.reset(update.effective_chat.id)
    await update.effective_message.reply_text("Contexto limpo.")


async def build_status(deps: Deps, chat_id: int) -> str:
    """Texto de status (puro, sem HTML). Usado por /status e pelo painel."""
    lines = [
        f"🤖 Modelo: {deps.state.model} (temp {deps.state.temperature})",
        f"📜 Diretrizes ativas: {len(deps.state.directives)}",
        f"💬 Contexto desta conversa: {deps.history.size(chat_id)} mensagens",
    ]
    try:
        models = await deps.ollama.list_models()
        lines.append("🧠 Ollama: 🟢 online" + ("" if deps.state.model in models else " (modelo configurado NÃO encontrado)"))
    except OllamaError as exc:
        lines.append(f"🧠 Ollama: 🔴 offline ({exc})")
    if deps.tts is None or deps.voice is None:
        lines.append("🔊 Voz: ⚪ não configurada")
    elif deps.tts.cooling_down:
        lines.append("🔊 Voz: 🟡 em pausa (chave/saldo); só texto")
    else:
        lines.append("🔊 Voz: " + ("🟢 ligada" if deps.voice.enabled(chat_id) else "⚪ desligada") + " neste chat")
    if deps.nexus is None:
        lines.append("🔗 Nexus: ⚪ desativado")
    else:
        try:
            await deps.nexus.health()
            lines.append("🔗 Nexus: 🟢 online")
        except NexusError as exc:
            lines.append(f"🔗 Nexus: 🔴 offline ({exc})")
    return "\n".join(lines)


async def cmd_status(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    text = await build_status(_deps(context), update.effective_chat.id)
    await update.effective_message.reply_text(text)


# --- Ponte Nexus ------------------------------------------------------------------------
async def _run_nexus(update: Update, context: ContextTypes.DEFAULT_TYPE, request: str) -> None:
    deps = _deps(context)
    if deps.nexus is None:
        await update.effective_message.reply_text("Ponte Nexus desativada (NEXUS_ENABLED=false).")
        return
    async with typing(context.bot, update.effective_chat.id):
        try:
            reply = await deps.nexus.dispatch_request(request)
        except NexusError as exc:
            await update.effective_message.reply_text(f"⚠️ {exc}")
            return
        if not reply.handled:
            await update.effective_message.reply_text("O Nexus não reconheceu esse pedido. Tente /ferramentas.")
            return
        await _deliver_nexus(update, deps, reply)


async def cmd_nexus(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    await _run_nexus(update, context, _arg_text(update) or "/ferramentas")


async def on_unknown_command(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    """Comando que o bot nao conhece: tenta o Nexus (/sismo, /clima...); senao avisa."""
    deps = _deps(context)
    text = re.sub(r"^(/\w+)@\w+", r"\1", (update.effective_message.text or "").strip())
    if deps.nexus is None:
        await update.effective_message.reply_text("Comando desconhecido. /ajuda")
        return
    async with typing(context.bot, update.effective_chat.id):
        try:
            reply = await deps.nexus.command(text)
        except NexusError as exc:
            await update.effective_message.reply_text(f"⚠️ {exc}")
            return
        if reply.handled:
            await _deliver_nexus(update, deps, reply)
        else:
            await update.effective_message.reply_text("Comando desconhecido. /ajuda")


# --- /video: prompt + imagem de referencia -> video (Nexus -> Wan/VACE no Kaggle) -------------
VIDEO_USAGE = (
    "🎬 <b>/video</b>\n\n"
    "• <b>Referência → vídeo:</b> envie uma foto do sujeito com a legenda <code>/video descreva a cena e a ação</code>\n"
    "• Ou <b>responda a uma imagem</b> com <code>/video descreva a cena e a ação</code>\n"
    "• <b>Texto → vídeo:</b> <code>/video uma raposa correndo na neve</code> (sem imagem)\n"
    "• <b>Prompt direto:</b> comece com <code>!</code> (ex.: <code>/video ! slow push-in on four glass cups…</code>) "
    "para pular o refinamento do Ollama e mandar seu texto exatamente como está ao Wan. "
    "Nesse modo escreva em <b>inglês</b> (o Wan entende bem melhor).\n\n"
    "A imagem enviada é a referência do sujeito (no perfil r2v ela não é o primeiro quadro). Na 1ª vez do dia o Kaggle leva uns 10–15 min "
    "para ligar; depois é só a geração."
)
DEFAULT_VIDEO_PROMPT = "subtle natural motion, gentle cinematic camera movement"
MAX_TG_DOWNLOAD = 20 * 1024 * 1024  # limite de download de arquivos pela API de bots do Telegram
_VIDEO_CMD = re.compile(r"^\s*/video(?:@\w+)?(?:\s+(.*))?$", re.IGNORECASE | re.DOTALL)
_VIDEO_LABELS = {
    "queued": "⏳ Na fila do Nexus",
    "refining_prompt": "✍️ Refinando o prompt",
    "unloading_llm": "🧹 Liberando a GPU",
    "generating_video": "🎞️ Gerando o vídeo",
}


def parse_video_prompt(text: str) -> str:
    """Tira `/video` (ou `/video@bot`) do comeco do texto/legenda; o resto vem intacto."""
    m = _VIDEO_CMD.match(text or "")
    return (m.group(1) or "").strip() if m else (text or "").strip()


_RAW_PREFIX = re.compile(r"^\s*(?:!|raw\s*:)\s*", re.IGNORECASE)


def parse_video_request(text: str) -> tuple[str, bool]:
    """Como parse_video_prompt, mas reconhece o modo direto: prompt iniciado por `!` (ou `raw:`).
    Devolve (prompt, raw); em modo raw o prompt NAO passa pelo refinador/tradutor do Ollama."""
    prompt = parse_video_prompt(text)
    m = _RAW_PREFIX.match(prompt)
    if m:
        return prompt[m.end():].strip(), True
    return prompt, False


def _image_source(msg):
    """Imagem de referencia: da propria mensagem ou da mensagem respondida (foto ou arquivo de imagem)."""
    for m in (msg, getattr(msg, "reply_to_message", None)):
        if m is None:
            continue
        if getattr(m, "photo", None):
            return m.photo[-1]  # maior resolucao
        doc = getattr(m, "document", None)
        if doc is not None and (doc.mime_type or "").startswith("image/"):
            return doc
    return None


def _fmt_elapsed(seconds: float) -> str:
    m, s = divmod(int(seconds), 60)
    return f"{m}min{s:02d}s" if m else f"{s}s"


async def _edit_status(status_msg, text: str) -> None:
    """Atualiza a mensagem de progresso; falha aqui (igual, apagada, rede) nunca derruba o job."""
    try:
        await status_msg.edit_text(text)
    except (TelegramError, OSError) as exc:
        log.debug("nao consegui editar o status do video: %s", exc)


async def _send_video_file(msg, f, caption: str) -> None:
    def _buf() -> io.BytesIO:  # buffer novo a cada tentativa (o anterior fica no fim apos um envio)
        b = io.BytesIO(f.data)
        b.name = f.filename or "video.mp4"
        return b

    try:
        await tg_retry(
            lambda: msg.reply_video(_buf(), caption=caption, supports_streaming=True, write_timeout=120),
            what="envio do video",
        )
    except BadRequest as exc:  # formato que o Telegram nao aceita como video: manda como arquivo
        log.warning("reply_video recusado (%s); enviando como documento", exc)
        await tg_retry(lambda: msg.reply_document(_buf(), caption=caption, write_timeout=120), what="envio do arquivo")


async def _run_video_job(msg, status_msg, deps: Deps, chat_id: int, prompt: str, image: bytes | None,
                         raw: bool = False) -> None:
    """Corpo do /video em segundo plano: envia ao Nexus, acompanha, baixa e entrega o video."""
    t0 = time.monotonic()
    mode = "referência → vídeo" if image else "texto → vídeo"
    if raw:
        mode += ", prompt direto"
    try:
        try:
            extra = {"raw": True} if raw else {}
            job_id = await deps.nexus.submit_video(prompt, image, **extra)  # type: ignore[union-attr]
        except NexusError as exc:
            await _edit_status(status_msg, f"⚠️ Não consegui enviar o pedido de vídeo: {exc}")
            return

        state = {"label": "", "edited": 0.0, "kaggle_checked": 0.0, "kaggle_starting": False}

        async def on_update(job: VideoJob) -> None:
            now = time.monotonic()
            label = _VIDEO_LABELS.get(job.status, f"🎬 {job.status}")
            if job.status == "generating_video" and now - state["kaggle_checked"] > 30:
                # Enquanto "gera" o Nexus pode estar so esperando o Kaggle ligar: avisa isso.
                state["kaggle_checked"] = now
                ks = await deps.nexus.kaggle_status()  # type: ignore[union-attr]
                state["kaggle_starting"] = bool(ks and ks.get("enabled") and not ks.get("online"))
            if job.status == "generating_video" and state["kaggle_starting"]:
                label = "☁️ Ligando a GPU no Kaggle (instalando e baixando modelos; ~10–15 min na 1ª vez)"
            if label != state["label"] or now - state["edited"] >= 45:
                state["label"], state["edited"] = label, now
                await _edit_status(status_msg, f"🎬 Vídeo ({mode})\n{label}\n⏱ {_fmt_elapsed(now - t0)}")

        try:
            job = await deps.nexus.wait_video_job(  # type: ignore[union-attr]
                job_id, on_update=on_update,
                poll_s=deps.settings.video_poll_interval_s, max_wait_s=deps.settings.video_max_wait_s,
            )
        except NexusError as exc:
            await _edit_status(status_msg, f"⚠️ O vídeo não foi gerado: {exc}")
            return

        if not job.file_path:
            await _edit_status(status_msg, "⚠️ O Nexus concluiu o job, mas não informou o arquivo do vídeo.")
            return
        try:
            f = await deps.nexus.fetch_media(deps.nexus.video_media_path(job.file_path))  # type: ignore[union-attr]
        except NexusError as exc:
            await _edit_status(status_msg, f"⚠️ O vídeo foi gerado, mas não consegui baixá-lo do Nexus: {exc}")
            return

        caption = f"✅ Pronto em {_fmt_elapsed(time.monotonic() - t0)} ({mode})"
        if job.refined_prompt:
            caption += "\n\nPrompt: " + job.refined_prompt
        try:
            await _send_video_file(msg, f, caption[:1000])
        except (TelegramError, OSError) as exc:
            log.warning("falha ao enviar o video ao Telegram: %s", describe_network_error(exc) if is_network_error(exc) else exc)
            await _edit_status(status_msg, "⚠️ O vídeo ficou pronto, mas não consegui enviá-lo pelo Telegram.")
            return
        await _edit_status(status_msg, f"✅ Vídeo entregue ({_fmt_elapsed(time.monotonic() - t0)}).")
    except Exception as exc:  # noqa: BLE001 - tarefa em segundo plano: nunca morre calada
        log.error("erro inesperado no /video: %s", exc, exc_info=exc)
        await _edit_status(status_msg, "⚠️ Erro inesperado ao gerar o vídeo (detalhes no log do bot).")
    finally:
        deps.video_active.discard(chat_id)


async def cmd_video(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    """/video <prompt> + imagem anexada (ou respondida) = referencia; sem imagem = texto-para-video."""
    deps = _deps(context)
    msg, chat = update.effective_message, update.effective_chat
    if msg is None or chat is None:
        return
    if deps.nexus is None:
        await safe_reply(msg, "Ponte Nexus desativada (NEXUS_ENABLED=false); o /video precisa dela.")
        return

    prompt, raw = parse_video_request(msg.text or msg.caption or "")
    src = _image_source(msg)
    if not prompt and src is None:
        await safe_reply(msg, VIDEO_USAGE, parse_mode=ParseMode.HTML)
        return
    if not prompt:
        prompt = DEFAULT_VIDEO_PROMPT  # so a imagem: movimento sutil padrao
    if len(prompt) < 2:
        await safe_reply(msg, "Descreva um pouco mais o vídeo. Exemplo: /video a câmera se aproxima devagar")
        return
    if chat.id in deps.video_active:
        await safe_reply(msg, "⏳ Já existe um vídeo sendo gerado neste chat. Aguarde ele terminar.")
        return

    image: bytes | None = None
    if src is not None:
        if (src.file_size or 0) > MAX_TG_DOWNLOAD:
            await safe_reply(msg, "⚠️ Imagem grande demais (o Telegram só deixa o bot baixar até 20 MB).")
            return
        try:
            tg_file = await tg_retry(lambda: src.get_file(), what="download da imagem")
            image = bytes(await tg_retry(lambda: tg_file.download_as_bytearray(), what="download da imagem"))
        except TelegramError as exc:
            await safe_reply(msg, f"⚠️ Não consegui baixar a imagem do Telegram: {exc}")
            return
        except OSError as exc:
            await safe_reply(msg, f"⚠️ Falha de rede ao baixar a imagem ({describe_network_error(exc)}).")
            return

    deps.video_active.add(chat.id)
    try:
        status_msg = await tg_retry(
            lambda: msg.reply_text(
                f"🎬 Pedido recebido ({'referência → vídeo' if image else 'texto → vídeo'}"
                f"{', prompt direto' if raw else ''}). Enviando ao Nexus…"
            ),
        )
    except (TelegramError, OSError):
        deps.video_active.discard(chat.id)
        raise
    # Em segundo plano: o handler volta na hora (a espera pode levar 20+ min) e o chat segue livre.
    context.application.create_task(
        _run_video_job(msg, status_msg, deps, chat.id, prompt, image, raw), update=update,
    )


# --- /code: agente de codigo (OpenHands via Nexus) ------------------------------------------
CODE_USAGE = (
    "💻 <b>/code</b> <i>[projeto:nome]</i> <i>tarefa</i>\n\n"
    "Ex.: <code>/code projeto:site crie um index.html com uma landing page</code>\n"
    "O agente trabalha só dentro da pasta do projeto no PC. "
    "<code>/code parar</code> interrompe a tarefa em andamento."
)
_CODE_CMD = re.compile(r"^\s*/code(?:@\w+)?(?:\s+(.*))?$", re.IGNORECASE | re.DOTALL)
_CODE_PROJECT = re.compile(r"^projeto:([A-Za-z0-9_-]{1,40})\s+(.*)$", re.IGNORECASE | re.DOTALL)


def parse_code_request(text: str) -> tuple[str, str]:
    """`/code [projeto:x] tarefa` -> (projeto, tarefa)."""
    m = _CODE_CMD.match(text or "")
    body = (m.group(1) or "").strip() if m else ""
    pm = _CODE_PROJECT.match(body)
    if pm:
        return pm.group(1), pm.group(2).strip()
    return "", body


async def _run_code_task(msg, status_msg, deps: Deps, chat_id: int, task_id: str) -> None:
    started = time.monotonic()
    last = {"text": ""}
    try:
        async def on_update(t: CodeTask) -> None:
            text = f"💻 Agente trabalhando… {_fmt_elapsed(time.monotonic() - started)}"
            if t.progress:
                text += f"\n🔧 {t.progress}"
            if text != last["text"]:
                last["text"] = text
                await _edit_status(status_msg, text)

        try:
            task = await deps.nexus.wait_code_task(  # type: ignore[union-attr]
                task_id, on_update=on_update,
                poll_s=deps.settings.code_poll_interval_s, max_wait_s=deps.settings.code_max_wait_s,
            )
        except NexusError as exc:
            await _edit_status(status_msg, f"⚠️ Falha no agente de código: {exc}")
            return
        took = _fmt_elapsed(time.monotonic() - started)
        if task.error:
            await _edit_status(status_msg, f"⚠️ O agente terminou com problema ({took}): {task.error}"[:4000])
        else:
            await _edit_status(status_msg, f"✅ Agente concluiu em {took}.")
        if task.result:
            for chunk in split_message(task.result):
                await tg_retry(lambda c=chunk: msg.reply_text(c))
    except Exception as exc:  # nunca deixar o chat preso
        log.error("erro inesperado no /code: %s", exc, exc_info=exc)
    finally:
        deps.code_active.pop(chat_id, None)


async def cmd_code(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    """/code [projeto:x] <tarefa>: roda o agente OpenHands (via Nexus) em segundo plano."""
    deps = _deps(context)
    msg, chat = update.effective_message, update.effective_chat
    if msg is None or chat is None:
        return
    if deps.nexus is None:
        await safe_reply(msg, "Ponte Nexus desativada (NEXUS_ENABLED=false); o /code precisa dela.")
        return
    project, prompt = parse_code_request(msg.text or "")
    if prompt.lower() in {"parar", "stop", "cancelar"}:
        tid = deps.code_active.get(chat.id)
        if not tid:
            await safe_reply(msg, "Nenhuma tarefa de código em andamento neste chat.")
            return
        try:
            await deps.nexus.stop_code_task(tid)
            await safe_reply(msg, "⏹ Pedi ao agente para parar.")
        except NexusError as exc:
            await safe_reply(msg, f"⚠️ Não consegui parar: {exc}")
        return
    if len(prompt) < 5:
        await safe_reply(msg, CODE_USAGE, parse_mode=ParseMode.HTML)
        return
    if chat.id in deps.code_active:
        await safe_reply(msg, "⏳ Já existe uma tarefa de código neste chat. Use /code parar ou aguarde.")
        return
    deps.code_active[chat.id] = ""  # reserva o slot antes de qualquer await
    try:
        status_msg = await tg_retry(lambda: msg.reply_text("💻 Enviando a tarefa ao agente…"))
        task_id = await deps.nexus.submit_code(prompt, project)
    except NexusError as exc:
        deps.code_active.pop(chat.id, None)
        await safe_reply(msg, f"⚠️ Não consegui iniciar o agente: {exc}")
        return
    except (TelegramError, OSError):
        deps.code_active.pop(chat.id, None)
        raise
    deps.code_active[chat.id] = task_id
    context.application.create_task(_run_code_task(msg, status_msg, deps, chat.id, task_id), update=update)


# --- Modo administrador -----------------------------------------------------------------
@admin_only
async def cmd_directive(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    text = _arg_text(update)
    if not text:
        await update.effective_message.reply_text("Uso: /diretriz <instrução de comportamento>")
        return
    try:
        n = _deps(context).state.add_directive(text)
    except ValueError as exc:
        await update.effective_message.reply_text(f"⚠️ {exc}")
        return
    await update.effective_message.reply_text(f"Diretriz #{n} ativa.")


@admin_only
async def cmd_directives(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    ds = _deps(context).state.directives
    body = "\n".join(f"{i}. {d}" for i, d in enumerate(ds, 1)) if ds else "Nenhuma diretriz adicional."
    await _reply_long(update, body)


@admin_only
async def cmd_remove(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    arg = _arg_text(update)
    if not (arg.isascii() and arg.isdigit()):
        await update.effective_message.reply_text("Uso: /remover <número da diretriz>")
        return
    try:
        _deps(context).state.remove_directive(int(arg))
    except ValueError as exc:
        await update.effective_message.reply_text(f"⚠️ {exc}")
        return
    await update.effective_message.reply_text("Diretriz removida.")


@admin_only
async def cmd_clear_directives(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    n = _deps(context).state.clear_directives()
    await update.effective_message.reply_text(f"{n} diretriz(es) removida(s).")


@admin_only
async def cmd_system(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    await _reply_long(update, _deps(context).state.system_prompt())


@admin_only
async def cmd_model(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    deps = _deps(context)
    name = _arg_text(update)
    try:
        models = await deps.ollama.list_models()
    except OllamaError as exc:
        await update.effective_message.reply_text(f"⚠️ {exc}")
        return
    if not name:
        await update.effective_message.reply_text(
            f"Atual: {deps.state.model}\nDisponíveis:\n" + "\n".join(f"• {m}" for m in models)
        )
        return
    if name not in models:
        await update.effective_message.reply_text("⚠️ Modelo não encontrado no Ollama. Use /modelo para listar.")
        return
    deps.state.set_model(name)
    await update.effective_message.reply_text(f"Modelo ativo: {name}")


@admin_only
async def cmd_temperature(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    deps = _deps(context)
    arg = _arg_text(update).replace(",", ".")
    if not arg:
        await update.effective_message.reply_text(f"Temperatura atual: {deps.state.temperature}")
        return
    try:
        deps.state.set_temperature(float(arg))
    except ValueError as exc:
        await update.effective_message.reply_text(f"⚠️ {exc}")
        return
    await update.effective_message.reply_text(f"Temperatura: {deps.state.temperature}")


async def on_error(update: object, context: ContextTypes.DEFAULT_TYPE) -> None:
    """Handler global de erros. Nunca responde ao usuario e nunca loga conteudo de mensagens.

    Falhas de rede (DNS, reset/abort de socket, timeouts) sao esperadas e transitorias: viram UMA linha
    de WARNING, sem traceback. Tambem cobre os erros do getUpdates (update=None) vindos do polling.
    """
    err = context.error
    if err is None:
        return
    if is_network_error(err):
        why = describe_network_error(err)
        skipped = _NET_THROTTLE.hit(why)
        if skipped is not None:
            log.warning("falha de rede ignorada (%s)%s%s", why,
                        "" if update is None else " ao processar um update",
                        f" [+{skipped} repeticoes]" if skipped else "")
        return
    if isinstance(err, RetryAfter):
        log.warning("Telegram pediu para aguardar %ss (flood control)", err.retry_after)
        return
    if isinstance(err, Conflict):
        log.error("Conflict: outra instancia do bot esta fazendo polling com este token. Feche a outra.")
        return
    if isinstance(err, Forbidden):
        log.warning("Telegram recusou a acao (usuario bloqueou o bot ou sem permissao): %s", err)
        return
    if isinstance(err, TelegramError):
        log.error("erro da API do Telegram: %s", err)
        return
    log.error("erro nao tratado: %s", err, exc_info=err)
