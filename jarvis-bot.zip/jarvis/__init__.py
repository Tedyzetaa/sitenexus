"""J.A.R.V.I.S. - bot de Telegram local (Ollama + Nexus-Bridge)."""
