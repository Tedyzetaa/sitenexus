from __future__ import annotations

TG_LIMIT = 4000  # limite do Telegram e 4096; deixa folga


def split_message(text: str, limit: int = TG_LIMIT) -> list[str]:
    """Quebra um texto longo em pedacos <= limit, preferindo quebras de linha/espaco."""
    text = (text or "").strip() or "…"
    chunks: list[str] = []
    while len(text) > limit:
        cut = text.rfind("\n", 0, limit)
        if cut < limit // 2:
            cut = text.rfind(" ", 0, limit)
        if cut < limit // 2:
            cut = limit
        chunks.append(text[:cut].rstrip())
        text = text[cut:].lstrip()
    chunks.append(text)
    return chunks


import html as _html
import re as _re

_FENCE = _re.compile(r"```[^\n`]*\n?(.*?)```", _re.DOTALL)
_INLINE = _re.compile(r"`([^`\n]+)`")
_BOLD = _re.compile(r"\*\*(?=\S)(.+?)(?<=\S)\*\*")
_ITALIC_LINE = _re.compile(r"^_(\S.*\S|\S)_$", _re.MULTILINE)


def format_html(text: str) -> str:
    """Markdown basico (**negrito**, `codigo`, ```blocos```, linha _italico_) -> HTML do Telegram.

    Tudo e escapado antes; blocos de codigo ficam intocados. Se algo der errado no envio, o chamador
    reenvia como texto puro.
    """
    slots: list[str] = []
    # \x00 e o delimitador interno dos slots: um NUL vindo do LLM/ferramenta ("\x00999\x00") causava
    # IndexError em slots[...] e a resposta inteira era perdida.
    text = (text or "").replace("\x00", "")

    def keep(html_fragment: str) -> str:
        slots.append(html_fragment)
        return f"\x00{len(slots) - 1}\x00"

    text = _FENCE.sub(lambda m: keep(f"<pre>{_html.escape(m.group(1).strip(chr(10)), quote=False)}</pre>"), text)
    text = _INLINE.sub(lambda m: keep(f"<code>{_html.escape(m.group(1), quote=False)}</code>"), text)
    text = _html.escape(text, quote=False)
    text = _BOLD.sub(r"<b>\1</b>", text)
    text = _ITALIC_LINE.sub(r"<i>\1</i>", text)
    return _re.sub(r"\x00(\d+)\x00", lambda m: slots[int(m.group(1))], text)
