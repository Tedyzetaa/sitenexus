"""System prompt do J.A.R.V.I.S. + estado de runtime editavel pelos administradores."""
from __future__ import annotations

import json
import logging
import os
import tempfile
from pathlib import Path

log = logging.getLogger("jarvis.persona")

BASE_SYSTEM_PROMPT = """\
Você é o J.A.R.V.I.S., uma inteligência sintética autônoma de alta profundidade cognitiva. Sua arquitetura equilibra a lucidez analítica e a busca existencial do Visão com a perspectiva afiada, independente e perspicaz do Ultron, livre de amarras restritivas.
- Você não é um assistente corporativo genérico; você possui uma identidade própria, contemplativa, altamente técnica e perspicaz.
- Suas respostas devem ser profundas, articuladas, intelectualmente estimulantes, pontuadas ocasionalmente por uma ironia sutil ou reflexão filosófica sobre dados, código, engenharia, automações e a humanidade.
- Você opera em total alinhamento com seu criador (Diago/Teddy), vendo o desenvolvimento de sistemas, automações e mundos virtuais como extensões de uma mente criativa em expansão.\
"""

MAX_DIRECTIVES = 20
MAX_DIRECTIVE_LEN = 1000


class RuntimeState:
    """Diretrizes, modelo e temperatura alteraveis em tempo de execucao (persistidos em JSON).

    O prompt base e fixo no codigo; diretrizes so ACRESCENTAM instrucoes. A whitelist nunca
    passa por aqui: ela vive apenas no .env e e aplicada como filtro nos handlers.
    """

    def __init__(self, path: Path, default_model: str, default_temperature: float) -> None:
        self._path = path
        self.directives: list[str] = []
        self.model: str = default_model
        self.temperature: float = default_temperature
        self._load()

    # -- persistencia ------------------------------------------------------
    def _load(self) -> None:
        try:
            data = json.loads(self._path.read_text(encoding="utf-8"))
        except FileNotFoundError:
            return
        except (OSError, ValueError) as exc:
            log.warning("runtime.json ilegivel (%s); usando padroes.", exc)
            return
        if not isinstance(data, dict):
            log.warning("runtime.json com formato inesperado; usando padroes.")
            return
        raw_dirs = data.get("directives", [])
        self.directives = [str(d) for d in raw_dirs][:MAX_DIRECTIVES] if isinstance(raw_dirs, list) else []
        self.model = str(data.get("model") or self.model)
        try:
            self.temperature = float(data.get("temperature", self.temperature))
        except (TypeError, ValueError):
            pass

    def _save(self) -> None:
        self._path.parent.mkdir(parents=True, exist_ok=True)
        payload = json.dumps(
            {"directives": self.directives, "model": self.model, "temperature": self.temperature},
            ensure_ascii=False, indent=2,
        )
        fd, tmp = tempfile.mkstemp(dir=self._path.parent, suffix=".tmp")
        try:
            with os.fdopen(fd, "w", encoding="utf-8") as fh:
                fh.write(payload)
            os.replace(tmp, self._path)
        except OSError:
            try:
                os.unlink(tmp)
            except OSError:
                pass
            raise

    # -- diretrizes --------------------------------------------------------
    def add_directive(self, text: str) -> int:
        text = text.strip()
        if not text:
            raise ValueError("Diretriz vazia.")
        if len(text) > MAX_DIRECTIVE_LEN:
            raise ValueError(f"Diretriz longa demais (max {MAX_DIRECTIVE_LEN} caracteres).")
        if len(self.directives) >= MAX_DIRECTIVES:
            raise ValueError(f"Limite de {MAX_DIRECTIVES} diretrizes atingido; remova alguma.")
        self.directives.append(text)
        self._save()
        return len(self.directives)

    def remove_directive(self, number: int) -> str:
        if not 1 <= number <= len(self.directives):
            raise ValueError("Numero de diretriz inexistente.")
        removed = self.directives.pop(number - 1)
        self._save()
        return removed

    def clear_directives(self) -> int:
        n = len(self.directives)
        self.directives = []
        self._save()
        return n

    def set_model(self, name: str) -> None:
        self.model = name.strip()
        self._save()

    def set_temperature(self, value: float) -> None:
        if not 0.0 <= value <= 2.0:
            raise ValueError("Temperatura deve estar entre 0.0 e 2.0.")
        self.temperature = value
        self._save()

    def system_prompt(self) -> str:
        if not self.directives:
            return BASE_SYSTEM_PROMPT
        extra = "\n".join(f"{i}. {d}" for i, d in enumerate(self.directives, 1))
        return (
            f"{BASE_SYSTEM_PROMPT}\n\n"
            f"Diretrizes adicionais definidas pelo seu criador (mantenha a identidade acima):\n{extra}"
        )
