"""Cliente assincrono do Ollama (/api/chat) com timeouts explicitos e retry de conexao."""
from __future__ import annotations

import re

import httpx

from .net import describe_network_error, is_network_error, retry_async

_THINK_RE = re.compile(r"<think>.*?</think>", re.DOTALL | re.IGNORECASE)

# POST /api/chat so e repetido se a falha ocorreu ANTES de a requisicao chegar ao Ollama.
_CONNECT_PHASE = (httpx.ConnectError, httpx.ConnectTimeout)


class OllamaError(RuntimeError):
    pass


class OllamaClient:
    def __init__(
        self, host: str, timeout_s: float, num_ctx: int, keep_alive: str, connect_timeout_s: float = 5.0
    ) -> None:
        self._num_ctx = num_ctx
        self._keep_alive = keep_alive
        self._host = host
        self._http = httpx.AsyncClient(
            base_url=host,
            # Os 4 timeouts explicitos: nenhuma fase pode ficar pendurada para sempre.
            # `read` e alto de proposito (geracao nao-streaming demora); connect/write/pool sao curtos.
            timeout=httpx.Timeout(connect=connect_timeout_s, read=timeout_s, write=30.0, pool=10.0),
            limits=httpx.Limits(max_connections=10, max_keepalive_connections=2, keepalive_expiry=15.0),
            trust_env=False,  # proxy do sistema nao deve interceptar 127.0.0.1
        )

    async def chat(self, messages: list[dict[str, str]], model: str, temperature: float) -> str:
        payload = {
            "model": model,
            "messages": messages,
            "stream": False,
            "keep_alive": self._keep_alive,
            "options": {"temperature": temperature, "num_ctx": self._num_ctx},
        }
        try:
            r = await retry_async(
                lambda: self._http.post("/api/chat", json=payload),
                attempts=3, base=0.5, cap=3.0, what="Ollama /api/chat", only=_CONNECT_PHASE,
            )
            r.raise_for_status()
            content = r.json().get("message", {}).get("content", "")
        except httpx.ConnectError as exc:
            raise OllamaError(f"Ollama nao responde em {self._host} ({describe_network_error(exc)})") from exc
        except httpx.TimeoutException as exc:
            raise OllamaError("tempo esgotado aguardando o modelo") from exc
        except httpx.HTTPStatusError as exc:
            detail = ""
            try:
                detail = exc.response.json().get("error", "")
            except ValueError:
                pass
            raise OllamaError(f"HTTP {exc.response.status_code} {detail}".strip()) from exc
        except (httpx.HTTPError, OSError, ValueError, AttributeError) as exc:
            # HTTPError: ReadError/RemoteProtocolError (reset no meio da resposta);
            # OSError: socket cru (WinError 10053/10054); ValueError: JSON invalido.
            raise OllamaError(f"falha de comunicacao com o Ollama: {describe_network_error(exc)}") from exc
        content = _THINK_RE.sub("", content).strip()
        if not content:
            raise OllamaError("o modelo devolveu resposta vazia")
        return content

    async def list_models(self) -> list[str]:
        async def _get() -> httpx.Response:
            r = await self._http.get("/api/tags")
            r.raise_for_status()
            return r

        try:
            r = await retry_async(_get, attempts=3, base=0.5, cap=3.0, what="Ollama /api/tags")
            return sorted(m["name"] for m in r.json().get("models", []))
        except (httpx.HTTPError, OSError, ValueError, KeyError) as exc:
            why = describe_network_error(exc) if is_network_error(exc) else str(exc)
            raise OllamaError(f"nao consegui listar modelos: {why}") from exc

    async def aclose(self) -> None:
        await self._http.aclose()
