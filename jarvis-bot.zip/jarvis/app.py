from __future__ import annotations

import asyncio
import contextlib
import logging
import sys
import time

from telegram import Update
from telegram.error import InvalidToken
from telegram.ext import (
    Application, ApplicationBuilder, CallbackQueryHandler, CommandHandler, MessageHandler, TypeHandler, filters,
)

from . import handlers as h
from . import panel
from .config import ConfigError, Settings, load_settings
from .memory import History
from .net import (
    backoff_delay, configure_event_loop_policy, describe_network_error, install_loop_exception_filter,
    install_reconnect_notice, is_network_error,
)
from .nexus import NexusGateway
from .ollama_client import OllamaClient, OllamaError
from .persona import RuntimeState
from .tts import TTSClient, VoicePrefs

log = logging.getLogger("jarvis")


def build_app(s: Settings) -> Application:
    deps = h.Deps(
        settings=s,
        state=RuntimeState(s.data_dir / "runtime.json", s.ollama_model, s.ollama_temperature),
        ollama=OllamaClient(
            s.ollama_host, s.ollama_timeout_s, s.ollama_num_ctx, s.ollama_keep_alive, s.http_connect_timeout_s
        ),
        nexus=(
            NexusGateway(s.nexus_url, s.nexus_token, s.nexus_timeout_s, s.http_connect_timeout_s)
            if s.nexus_enabled else None
        ),
        history=History(s.history_max_messages),
        tts=(
            TTSClient(
                s.fish_api_key, s.fish_voice_id, model=s.fish_model, language=s.fish_language,
                audio_format=s.fish_format, timeout_s=s.tts_timeout_s, connect_timeout_s=s.http_connect_timeout_s,
            )
            if s.tts_enabled else None
        ),
        voice=VoicePrefs(s.data_dir / "voice.json", s.tts_default_on) if s.tts_enabled else None,
    )

    async def post_init(app: Application) -> None:
        try:
            models = await deps.ollama.list_models()
            if deps.state.model not in models:
                log.warning("Modelo '%s' nao existe no Ollama (disponiveis: %s)", deps.state.model, models)
        except OllamaError as exc:
            log.warning("Ollama indisponivel na partida: %s", exc)
        except Exception as exc:  # noqa: BLE001 - a checagem de partida nunca pode impedir o bot de subir
            log.warning("Checagem inicial do Ollama falhou: %s", exc)

    async def post_shutdown(app: Application) -> None:
        await deps.ollama.aclose()
        if deps.nexus is not None:
            await deps.nexus.aclose()
        if deps.tts is not None:
            await deps.tts.aclose()

    app = (
        ApplicationBuilder()
        .token(s.telegram_token)
        .concurrent_updates(True)  # /reset e afins nao esperam uma resposta longa do LLM
        # Chamadas normais (sendMessage, editMessage...): falham rapido em vez de pendurar.
        .connect_timeout(s.telegram_connect_timeout_s)
        .read_timeout(s.telegram_read_timeout_s)
        .write_timeout(s.telegram_write_timeout_s)
        .pool_timeout(s.telegram_pool_timeout_s)
        .connection_pool_size(16)
        # getUpdates (long polling) tem pool proprio: read_timeout PRECISA ser > timeout do long poll,
        # senao toda espera ociosa vira TimedOut.
        .get_updates_connect_timeout(s.telegram_connect_timeout_s)
        .get_updates_read_timeout(s.telegram_poll_timeout_s + 15.0)
        .get_updates_write_timeout(s.telegram_write_timeout_s)
        .get_updates_pool_timeout(s.telegram_pool_timeout_s)
        .get_updates_connection_pool_size(2)
        .post_init(post_init)
        .post_shutdown(post_shutdown)
        .build()
    )
    app.bot_data["deps"] = deps

    # Whitelist: tudo abaixo so dispara para IDs autorizados; o resto cai no vazio, sem resposta.
    allowed = filters.User(user_id=sorted(s.allowed_user_ids))

    app.add_handler(TypeHandler(Update, h.audit_unauthorized), group=-1)

    for name, fn in [
        ("start", panel.cmd_menu), ("menu", panel.cmd_menu),
        ("ajuda", panel.cmd_help), ("help", panel.cmd_help),
        ("reset", h.cmd_reset), ("status", h.cmd_status), ("voz", h.cmd_voice),
        ("nexus", panel.cmd_nexus), ("ferramentas", panel.cmd_tools),
        ("video", h.cmd_video),
        ("code", h.admin_only(h.cmd_code)),  # agente de codigo: so admins
        ("cancelar", panel.cmd_cancel),
        ("admin", panel.cmd_admin),
        ("diretriz", h.cmd_directive), ("diretrizes", h.cmd_directives),
        ("remover", h.cmd_remove), ("limpar_diretrizes", h.cmd_clear_directives),
        ("sistema", h.cmd_system), ("modelo", h.cmd_model), ("temperatura", h.cmd_temperature),
    ]:
        app.add_handler(CommandHandler(name, fn, filters=allowed))

    # /video como LEGENDA de foto/arquivo de imagem: o CommandHandler so enxerga texto, nao legendas.
    video_caption = (
        allowed
        & (filters.PHOTO | filters.Document.IMAGE)
        & filters.CaptionRegex(r"(?i)^\s*/video(@\w+)?(\s|$)")
    )
    app.add_handler(MessageHandler(video_caption, h.cmd_video))

    # Botoes: o CallbackQueryHandler nao aceita filtros, entao panel.on_callback confere a
    # whitelist/admin por conta propria (e fica em silencio para quem nao pode).
    app.add_handler(CallbackQueryHandler(panel.on_callback))

    # Ordem importa: comandos desconhecidos (-> Nexus) antes do texto livre (-> Ollama).
    app.add_handler(MessageHandler(allowed & filters.COMMAND, h.on_unknown_command))
    text_filter = allowed & filters.TEXT & ~filters.COMMAND
    # group 0: se ha entrada pendente (argumentos de ferramenta / nova diretriz) consome e para;
    # group 1: conversa normal com o LLM.
    app.add_handler(MessageHandler(text_filter, panel.on_pending_text), group=0)
    app.add_handler(MessageHandler(text_filter, h.on_text), group=1)
    # Sem handler para new_chat_members / mensagens de servico: nenhuma boas-vindas, por construcao.
    app.add_error_handler(h.on_error)
    return app


_ALLOWED_UPDATES = [Update.MESSAGE, Update.CALLBACK_QUERY]
_HEALTHY_RUN_S = 60.0  # execucao mais longa que isso zera o contador de backoff


async def _close_deps(app: Application) -> None:
    """Fecha os clientes HTTP (idempotente). Garante que nada vaza se o PTB nao chegou ao shutdown."""
    deps = app.bot_data.get("deps")
    if deps is None:
        return
    with contextlib.suppress(Exception):
        await deps.ollama.aclose()
    if deps.nexus is not None:
        with contextlib.suppress(Exception):
            await deps.nexus.aclose()
    if deps.tts is not None:
        with contextlib.suppress(Exception):
            await deps.tts.aclose()


def _run_once(settings: Settings, first_run: bool) -> None:
    """Uma vida do bot em um event loop novo. Retorna em parada limpa (Ctrl+C/SIGTERM); levanta se cair."""
    loop = asyncio.new_event_loop()
    asyncio.set_event_loop(loop)
    install_loop_exception_filter(loop)
    app = build_app(settings)
    try:
        app.run_polling(
            timeout=settings.telegram_poll_timeout_s,
            allowed_updates=_ALLOWED_UPDATES,
            # Backlog so e descartado na primeira partida; apos queda de rede as mensagens que
            # chegaram durante a falha ainda sao respondidas.
            drop_pending_updates=first_run,
            bootstrap_retries=-1,  # get_me/deleteWebhook na partida: tenta para sempre (internet pode voltar)
            close_loop=False,  # o supervisor controla o loop, para poder reiniciar
        )
    finally:
        with contextlib.suppress(Exception):
            loop.run_until_complete(_close_deps(app))
        with contextlib.suppress(Exception):
            pending = [t for t in asyncio.all_tasks(loop) if not t.done()]
            for t in pending:
                t.cancel()
            if pending:
                loop.run_until_complete(asyncio.gather(*pending, return_exceptions=True))
            loop.run_until_complete(loop.shutdown_asyncgens())
        loop.close()


def run_forever(settings: Settings) -> int:
    """Supervisor: reinicia o bot com backoff exponencial se ele cair por rede ou erro inesperado."""
    attempt, first = 0, True
    while True:
        started = time.monotonic()
        try:
            _run_once(settings, first_run=first)
            return 0  # parada limpa pedida pelo usuario
        except KeyboardInterrupt:
            return 0
        except InvalidToken:
            log.critical("Token do Telegram invalido (confira TELEGRAM_BOT_TOKEN). Encerrando.")
            return 2
        except Exception as exc:  # noqa: BLE001
            if time.monotonic() - started > _HEALTHY_RUN_S:
                attempt = 0
            delay = backoff_delay(attempt, base=2.0, cap=60.0)
            if is_network_error(exc):
                log.warning("Conexao perdida (%s). Reiniciando em %.0fs...", describe_network_error(exc), delay)
            else:
                log.error("Falha inesperada; reiniciando em %.0fs.", delay, exc_info=exc)
            attempt += 1
            first = False
            try:
                time.sleep(delay)
            except KeyboardInterrupt:
                return 0


def main() -> None:
    # Windows: precisa ser a PRIMEIRA coisa, antes de qualquer loop existir (mitiga WinError 10053/10054).
    configure_event_loop_policy()
    logging.basicConfig(format="%(asctime)s [%(name)s] %(levelname)s: %(message)s", level=logging.INFO)
    # httpx loga URLs completas em INFO e a URL da API do Telegram contem o token do bot.
    for noisy in ("httpx", "httpcore"):
        logging.getLogger(noisy).setLevel(logging.WARNING)
    install_reconnect_notice()  # retentativas silenciosas do PTB viram 1 aviso a cada 30 s
    try:
        settings = load_settings()
    except ConfigError as exc:
        print(f"Configuração inválida: {exc}", file=sys.stderr)
        raise SystemExit(2)
    log.info("J.A.R.V.I.S. iniciando (%d usuário(s) na whitelist).", len(settings.allowed_user_ids))
    raise SystemExit(run_forever(settings))
