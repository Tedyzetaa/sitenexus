"""Historico recente de contexto por chat (em memoria; some ao reiniciar o bot)."""
from __future__ import annotations

from collections import deque


class History:
    def __init__(self, max_messages: int) -> None:
        self._max = max_messages
        self._chats: dict[int, deque[dict[str, str]]] = {}

    def get(self, chat_id: int) -> list[dict[str, str]]:
        return list(self._chats.get(chat_id, ()))

    def add(self, chat_id: int, role: str, content: str) -> None:
        self._chats.setdefault(chat_id, deque(maxlen=self._max)).append(
            {"role": role, "content": content}
        )

    def reset(self, chat_id: int) -> None:
        self._chats.pop(chat_id, None)

    def size(self, chat_id: int) -> int:
        return len(self._chats.get(chat_id, ()))
