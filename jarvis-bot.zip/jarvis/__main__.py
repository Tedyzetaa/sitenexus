from jarvis.net import configure_event_loop_policy

# Antes de qualquer outra coisa: no Windows troca ProactorEventLoop -> SelectorEventLoop
# (evita ConnectionResetError/ConnectionAbortedError [WinError 10054/10053] no ProactorBasePipeTransport).
configure_event_loop_policy()

from jarvis.app import main  # noqa: E402

main()
