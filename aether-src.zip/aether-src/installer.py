# -*- coding: utf-8 -*-
"""Instalador / gerador do bot Aether para Termux (chamado pelo Instalar_Aether.sh).

Fluxo: perguntas (pasta, personalidade JSON, .env pronto ou manual, Ollama local/remoto, modelo)
-> geracao do bot -> venv + bibliotecas -> testes -> Ollama + modelo -> .env, launcher e atalho
do Termux:Widget -> teste final. Idempotente: pode ser executado de novo para reparar ou trocar
a personalidade/modelo.
"""
from __future__ import annotations

import argparse
import json
import os
import re
import shlex
import shutil
import subprocess
import sys
import time
import unicodedata
import urllib.error
import urllib.request
from datetime import datetime
from pathlib import Path
from urllib.parse import urlparse

if hasattr(sys.stdout, "reconfigure"):
    sys.stdout.reconfigure(encoding="utf-8", errors="replace")
    sys.stderr.reconfigure(encoding="utf-8", errors="replace")

HERE = Path(__file__).resolve().parent
BOT_SRC = HERE / "bot"
HOME = Path(os.environ.get("HOME") or Path.home())
IS_TERMUX = "TERMUX_VERSION" in os.environ or Path("/data/data/com.termux/files/usr").exists()
ORIG_PWD = Path(os.environ.get("AETHER_ORIG_PWD") or os.getcwd())  # pasta de onde o .sh foi chamado
LOCAL_OLLAMA_URL = "http://127.0.0.1:11434"
OLLAMA_URL = LOCAL_OLLAMA_URL
PERSONA_MODEL = "aether-persona"
ASSUME_YES = False

# ---------------------------------------------------------------------------------------------
#  UI
# ---------------------------------------------------------------------------------------------
_COLOR = sys.stdout.isatty()


def _c(code: str, text: str) -> str:
    return f"\033[{code}m{text}\033[0m" if _COLOR else text


def info(msg: str) -> None:
    print(_c("36", "[*] ") + msg)


def ok(msg: str) -> None:
    print(_c("32", "[OK] ") + msg)


def warn(msg: str) -> None:
    print(_c("33", "[!] ") + msg)


def err(msg: str) -> None:
    print(_c("31", "[X] ") + msg)


def title(msg: str) -> None:
    print()
    print(_c("1;35", "=" * 72))
    print(_c("1;35", f"  {msg}"))
    print(_c("1;35", "=" * 72))


def ask(prompt: str, default: str = "") -> str:
    if ASSUME_YES:
        return default
    try:
        value = input(prompt).strip()
    except (EOFError, KeyboardInterrupt):
        print()
        return default
    return value or default


def yesno(prompt: str, default: bool = True) -> bool:
    hint = "S/n" if default else "s/N"
    ans = ask(f"{prompt} [{hint}]: ", "").lower()
    if not ans:
        return default
    return ans in {"s", "sim", "y", "yes"}


def fold_ascii(text: str) -> str:
    return unicodedata.normalize("NFKD", text).encode("ascii", "ignore").decode("ascii")


# ---------------------------------------------------------------------------------------------
#  Arquivos do celular (storage) / utilidades de caminho
# ---------------------------------------------------------------------------------------------
def ensure_storage() -> None:
    """No Termux, pede acesso aos arquivos do celular (cria ~/storage) se ainda nao foi concedido."""
    if not IS_TERMUX or (HOME / "storage").exists() or not shutil.which("termux-setup-storage"):
        return
    info("Pedindo acesso aos arquivos do celular — aceite a permissão na janela do Android...")
    subprocess.run(["termux-setup-storage"])
    for _ in range(25):
        if (HOME / "storage").exists():
            return
        time.sleep(1)
    warn("Acesso aos arquivos não concedido. Rode 'termux-setup-storage' manualmente e tente de novo.")


def storage_dirs() -> list[Path]:
    base = [ORIG_PWD, HOME / "storage" / "downloads", HOME / "storage" / "shared" / "Download",
            HOME / "storage" / "shared" / "Documents", HOME / "storage" / "shared", HOME]
    out: list[Path] = []
    seen = set()
    for d in base:
        try:
            if not d.is_dir():
                continue
            key = d.resolve()
        except OSError:
            continue
        if key not in seen:
            seen.add(key)
            out.append(d)
    return out


def find_candidates(match, limit: int = 15) -> list[Path]:
    """Arquivos (1 nivel) das pastas comuns cujo nome passa em match(), do mais novo para o mais antigo."""
    found: list[tuple[float, Path]] = []
    seen = set()
    for d in storage_dirs():
        try:
            entries = list(d.iterdir())
        except OSError:
            continue
        for p in entries:
            try:
                if not p.is_file() or not match(p.name):
                    continue
                key = p.resolve()
                if key in seen:
                    continue
                seen.add(key)
                found.append((p.stat().st_mtime, p))
            except OSError:
                continue
    found.sort(key=lambda t: t[0], reverse=True)
    return [p for _, p in found[:limit]]


def pick_from_list(cands: list[Path], what: str) -> str:
    if not cands:
        return ""
    print(f"\n  {what} encontrados:")
    for i, p in enumerate(cands, 1):
        print(f"   {i:>2}) {p}")
    raw = ask("  Número do arquivo (Enter = nenhum): ", "")
    if raw.isdigit() and 1 <= int(raw) <= len(cands):
        return str(cands[int(raw) - 1])
    return ""


def resolve_user_path(raw: str) -> Path:
    path = Path(os.path.expandvars(raw.strip().strip('"').strip("'"))).expanduser()
    return path if path.is_absolute() else ORIG_PWD / path


_ENV_NAME = re.compile(r"^(\.?env([._-].*)?|.*\.env)$", re.I)


def is_env_name(name: str) -> bool:
    low = name.lower()
    return bool(_ENV_NAME.match(name)) and not any(t in low for t in ("example", "sample", "template", ".bak"))


def is_local_url(url: str) -> bool:
    try:
        host = urlparse(url if "://" in url else "http://" + url).hostname or ""
    except ValueError:
        return False
    return host in {"127.0.0.1", "localhost", "::1", "0.0.0.0"}


# ---------------------------------------------------------------------------------------------
#  Processos
# ---------------------------------------------------------------------------------------------
def run(cmd, timeout: float = 60, cwd=None, env=None) -> tuple[int, str]:
    try:
        cp = subprocess.run(
            cmd, capture_output=True, text=True, timeout=timeout, cwd=cwd, env=env,
            encoding="utf-8", errors="replace",
        )
        return cp.returncode, (cp.stdout or "") + (cp.stderr or "")
    except subprocess.TimeoutExpired:
        return 124, "timeout"
    except OSError as exc:
        return 1, str(exc)


def detect_hardware() -> dict:
    hw: dict = {"gpus": [], "ram_total": 0.0, "ram_free": 0.0, "notes": [], "device": "", "cores": os.cpu_count() or 0}
    try:
        mem = Path("/proc/meminfo").read_text()
        hw["ram_total"] = int(re.search(r"MemTotal:\s+(\d+)", mem).group(1)) / (1024 ** 2)
        hw["ram_free"] = int(re.search(r"MemAvailable:\s+(\d+)", mem).group(1)) / (1024 ** 2)
    except (OSError, AttributeError):
        pass
    if shutil.which("getprop"):  # Android
        parts = []
        for prop in ("ro.product.manufacturer", "ro.product.model"):
            rc, out = run(["getprop", prop], timeout=5)
            if rc == 0 and out.strip():
                parts.append(out.strip())
        hw["device"] = " ".join(parts)
    return hw


def choose_mode(hw: dict) -> dict:
    return {"kind": "cpu", "vram": 0.0, "name": "", "free": 0.0}  # Termux: sem GPU para o Ollama


# Catalogo (ordem = qualidade crescente). Tamanhos aproximados do download no Ollama.
# Catalogo (ordem = qualidade crescente). Tamanhos aproximados do download no Ollama.
MODELS = [
    ("qwen2.5:0.5b-instruct", 0.4, "minúsculo — só para aparelhos muito fracos, qualidade básica"),
    ("llama3.2:1b", 1.3, "muito leve — respostas curtas, rápido"),
    ("qwen2.5:1.5b-instruct", 1.0, "leve — bom para celulares com 4–6 GB de RAM"),
    ("gemma2:2b", 1.6, "leve e bom em português (celulares com 6 GB+)"),
    ("qwen2.5:3b-instruct", 1.9, "leve e esperto — ideal para celulares com 8 GB de RAM"),
    ("llama3.2:3b", 2.0, "leve e equilibrado — celulares com 8 GB de RAM"),
    ("qwen2.5:7b-instruct", 4.7, "ótimo em português, mas só em celulares com 12 GB+ de RAM (lento)"),
    ("llama3.1:8b", 4.9, "muito bom em geral — precisa de 12 GB+ de RAM (lento)"),
    ("gemma2:9b", 5.4, "excelente em português — precisa de 12 GB+ de RAM (muito lento)"),
    ("qwen2.5:14b-instruct", 9.0, "qualidade alta — recomendado só em PC/servidor remoto"),
    ("qwen2.5:32b-instruct", 20.0, "qualidade máxima — só em PC/servidor remoto com GPU"),
]


def fit(size_gb: float, hw: dict, mode: dict) -> tuple[str, str]:
    """Estima se o modelo cabe na RAM do celular (Android reserva ~3 GB para o sistema)."""
    need = size_gb * 1.1 + 1.0
    if hw["ram_total"] <= 0:
        return "unknown", "RAM não detectada"
    usable = max(hw["ram_total"] - 3.0, 0.0)
    if need <= usable:
        return ("cpu" if size_gb <= 2.6 else "cpu_slow"), ("OK — roda na CPU" if size_gb <= 2.6 else "roda na CPU, mas LENTO")
    return "no", "NÃO recomendado — falta RAM"


def recommend(hw: dict, mode: dict) -> str:
    if hw["ram_total"] <= 0:
        return "qwen2.5:1.5b-instruct"
    best = None
    for tag, size, _ in MODELS:
        if size <= 2.6 and fit(size, hw, mode)[0] == "cpu":
            best = tag
    return best or MODELS[0][0]


def hardware_report(hw: dict, mode: dict) -> None:
    title("TESTE DE HARDWARE")
    if hw.get("device"):
        print(f"  Aparelho : {hw['device']}")
    if hw.get("cores"):
        print(f"  CPU      : {hw['cores']} núcleos")
    if hw["ram_total"]:
        print(f"  RAM      : {hw['ram_total']:.1f} GB (livre agora: {hw['ram_free']:.1f} GB)")
    warn("Sem GPU no Termux: o Ollama roda na CPU/RAM do celular. Modelos de 1–3 GB são o ideal.")


# ---------------------------------------------------------------------------------------------
#  Ollama
# ---------------------------------------------------------------------------------------------
def ollama_api(path: str, data: dict | None = None, timeout: float = 10):
    req = urllib.request.Request(
        OLLAMA_URL + path,
        data=json.dumps(data).encode("utf-8") if data is not None else None,
        headers={"Content-Type": "application/json"},
        method="POST" if data is not None else "GET",
    )
    with urllib.request.urlopen(req, timeout=timeout) as resp:
        return json.loads(resp.read().decode("utf-8"))


def ollama_up() -> bool:
    try:
        ollama_api("/api/tags", timeout=3)
        return True
    except (urllib.error.URLError, OSError, ValueError):
        return False


def find_ollama() -> str | None:
    return shutil.which("ollama")


def start_ollama(exe: str) -> bool:
    if ollama_up():
        return True
    info("Iniciando o servidor do Ollama...")
    try:
        subprocess.Popen([exe, "serve"], stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL,
                         stdin=subprocess.DEVNULL, start_new_session=True)
    except OSError as exc:
        err(f"Não consegui iniciar o Ollama: {exc}")
        return False
    for _ in range(40):
        time.sleep(1)
        if ollama_up():
            ok("Ollama respondendo.")
            return True
    err("O Ollama não respondeu em 40 s.")
    return False


def installed_models() -> list[dict]:
    try:
        data = ollama_api("/api/tags", timeout=5)
    except (urllib.error.URLError, OSError, ValueError):
        return []
    out = []
    for m in data.get("models", []):
        out.append({"name": m.get("name", ""), "size": float(m.get("size", 0)) / (1024 ** 3)})
    return out


def _same_tag(a: str, b: str) -> bool:
    def norm(t: str) -> str:
        t = t.strip().lower()
        return t[:-7] if t.endswith(":latest") else t
    return norm(a) == norm(b)


def install_ollama() -> str | None:
    if not shutil.which("pkg"):
        err("Instale o Ollama manualmente (https://ollama.com/download) e rode este instalador de novo.")
        return None
    info("Instalando o Ollama (pkg install ollama)...")
    rc = subprocess.run(["pkg", "install", "-y", "ollama"]).returncode
    exe = find_ollama()
    if exe:
        ok("Ollama instalado.")
        return exe
    err(f"Não consegui instalar o pacote 'ollama' (código {rc}). Alternativa: rode o instalador de novo e "
        "escolha usar um Ollama em outro computador.")
    return None


def remote_pull(tag: str) -> bool:
    """Pede ao Ollama remoto (OLLAMA_URL) para baixar um modelo."""
    info(f"Pedindo ao servidor remoto para baixar {tag} (pode demorar bastante)...")
    try:
        ollama_api("/api/pull", {"model": tag, "name": tag, "stream": False}, timeout=3600)
    except (urllib.error.URLError, OSError, ValueError) as exc:
        err(f"Falha ao baixar no servidor remoto: {exc}")
        return False
    return any(_same_tag(m["name"], tag) for m in installed_models())


def pull_model(exe: str, tag: str) -> bool:
    for attempt in range(1, 4):
        info(f"Baixando o modelo {tag} (tentativa {attempt}/3)...")
        try:
            rc = subprocess.run([exe, "pull", tag]).returncode
        except OSError as exc:
            err(str(exc))
            return False
        if rc == 0 and any(_same_tag(m["name"], tag) for m in installed_models()):
            ok(f"Modelo {tag} pronto.")
            return True
        warn("Download interrompido; tentando de novo em 5 s...")
        time.sleep(5)
    return False


def create_persona_model(exe: str, base: str, prompt: str, ctx: int, install_dir: Path) -> bool:
    safe = prompt.replace('"""', "'''")
    modelfile = install_dir / "Modelfile"
    modelfile.write_text(
        f"# Gerado pelo instalador do Aether. Recriar: ollama create {PERSONA_MODEL} -f Modelfile\n"
        f"FROM {base}\nPARAMETER temperature 0.8\nPARAMETER num_ctx {ctx}\nSYSTEM \"\"\"\n{safe}\n\"\"\"\n",
        encoding="utf-8",
    )
    info(f"Criando o modelo '{PERSONA_MODEL}' com a personalidade...")
    rc, out = run([exe, "create", PERSONA_MODEL, "-f", str(modelfile)], timeout=600, cwd=str(install_dir))
    if rc == 0:
        ok(f"Modelo {PERSONA_MODEL} criado a partir de {base}.")
        return True
    detail = out.strip().splitlines()[-1][:200] if out.strip() else "sem detalhes"
    warn("Não consegui criar o modelo com a personalidade: " + detail)
    return False


def live_test(model: str, prompt: str, ctx: int) -> tuple[bool, str]:
    info(f"Teste final: o modelo '{model}' vai gerar uma frase (a 1ª carga pode levar alguns minutos)...")
    try:
        r = ollama_api("/api/chat", {
            "model": model, "stream": False, "keep_alive": "1m",
            "messages": [{"role": "system", "content": prompt[:1500]},
                         {"role": "user", "content": "Apresente-se em uma frase curta."}],
            "options": {"num_predict": 60, "num_ctx": ctx},
        }, timeout=900)
    except (urllib.error.URLError, OSError, ValueError) as exc:
        return False, f"falhou: {exc}"
    text = (r.get("message", {}).get("content") or "").strip().replace("\n", " ")
    speed = ""
    if r.get("eval_count") and r.get("eval_duration"):
        speed = f" (~{r['eval_count'] / (r['eval_duration'] / 1e9):.1f} tokens/s)"
    placement = ""
    try:
        for m in ollama_api("/api/ps", timeout=5).get("models", []):
            size, vram = float(m.get("size", 0)), float(m.get("size_vram", 0))
            if size > 0:
                pct = int(round(100 * vram / size))
                placement = f" | na GPU: {pct}%" + ("" if pct >= 95 else " (o resto está na RAM -> mais lento)")
                break
    except (urllib.error.URLError, OSError, ValueError):
        pass
    return bool(text), f"\"{text[:140]}\"{speed}{placement}"


# ---------------------------------------------------------------------------------------------
#  Personalidade (JSON)
# ---------------------------------------------------------------------------------------------
def _persona_module():
    sys.path.insert(0, str(BOT_SRC))
    from aether import persona as mod  # type: ignore
    return mod


EXAMPLE_PERSONA = {
    "_comentario": "Use 'system_prompt' (texto livre, tem prioridade) OU os campos estruturados abaixo. Campos com _ são ignorados.",
    "name": "Luna",
    "language": "pt-BR",
    "description": "Uma assistente noturna, calma e poética, que ajuda com ideias e organização.",
    "tone": "sereno, acolhedor e levemente poético",
    "traits": ["empática", "criativa", "paciente"],
    "rules": ["Responda de forma concisa.", "Admita quando não souber algo."],
    "creator": "",
}


def get_persona(install_dir: Path, preset: str | None):
    """Retorna (dados_json, Persona, origem). Pede o JSON; Enter = manter atual ou Aether padrao."""
    mod = _persona_module()
    current = install_dir / "persona.json"
    if preset:
        candidates = [preset]
    else:
        candidates = []
    title("PERSONALIDADE")
    print("  O bot carrega a personalidade de um arquivo JSON (a cada instalação você pode trocar).")
    print("  Campos: name, description, tone, traits[], rules[], language, creator  — ou  system_prompt (texto livre).")
    print("  Um exemplo será salvo em persona.exemplo.json dentro da pasta do bot.")
    for _ in range(6):
        if candidates:
            raw = candidates.pop(0)
        else:
            keep = "manter a atual" if current.exists() else "usar a Aether padrão"
            raw = ask(f"\n  Caminho do JSON (cole o caminho | L = listar JSON do celular | Enter = {keep}): ", "")
        raw = raw.strip().strip('"').strip("'")
        if raw.lower() == "l":
            ensure_storage()
            raw = pick_from_list(find_candidates(
                lambda n: n.lower().endswith(".json") and not n.lower().startswith(("persona.exemplo", "install_info"))), "JSON")
            if not raw:
                warn("Nenhum JSON encontrado/selecionado nas pastas do celular (Downloads, Documentos, pasta atual, home).")
                continue
        if not raw:
            if current.exists():
                try:
                    p = mod.persona_from_file(current)
                    ok(f"Mantendo a personalidade atual: {p.name}")
                    return json.loads(current.read_text(encoding="utf-8-sig")), p, "mantida"
                except ValueError as exc:
                    warn(f"persona.json atual está inválido ({exc}); usando a Aether padrão.")
            data = dict(mod.DEFAULT_PERSONA_DATA)
            p = mod.persona_from_data(data)
            ok("Usando a personalidade genérica: Aether")
            return data, p, "padrão"
        if raw.startswith(("/sdcard", "/storage")) or "/storage/" in raw:
            ensure_storage()
        path = resolve_user_path(raw)
        if not path.is_file():
            err(f"Arquivo não encontrado: {path}")
            continue
        try:
            p = mod.persona_from_file(path)
            data = json.loads(path.read_text(encoding="utf-8-sig"))
        except ValueError as exc:
            err(str(exc))
            continue
        ok(f"Personalidade carregada: {p.name} (prompt de {len(p.system_prompt)} caracteres)")
        if len(p.system_prompt) > mod.WARN_PROMPT_LEN:
            warn("Prompt grande: em modelos pequenos/contexto de 2048 tokens isso reduz a memória da conversa.")
        return data, p, f"arquivo {path.name}"
    warn("Muitas tentativas inválidas; usando a Aether padrão.")
    data = dict(mod.DEFAULT_PERSONA_DATA)
    return data, mod.persona_from_data(data), "padrão"


# ---------------------------------------------------------------------------------------------
#  Modelo (Ollama) - perguntas
# ---------------------------------------------------------------------------------------------
def choose_model(hw: dict, mode: dict, installed: list[dict], preset: str | None, remote: bool = False) -> str:
    rec = recommend(hw, mode)
    title("MODELO DE IA (Ollama)")
    if remote:
        print("  O modelo roda no computador/servidor remoto: a coluna 'Status' (calculada para ESTE celular) não se aplica.\n")
        rec = next((m["name"] for m in installed if not m["name"].startswith(PERSONA_MODEL)), "qwen2.5:7b-instruct")
    else:
        print("  ⚠ LEMBRETE: celulares têm pouca RAM. A coluna 'Status' foi calculada com a RAM deste aparelho;")
        print("    modelos maiores que a memória livre ficam MUITO lentos ou fazem o Android fechar o Termux.\n")
    rows = []
    for tag, size, desc in MODELS:
        rows.append((tag, size, desc, any(_same_tag(m["name"], tag) for m in installed)))
    for m in installed:
        if m["name"] == PERSONA_MODEL or m["name"].startswith(PERSONA_MODEL + ":"):
            continue
        if not any(_same_tag(m["name"], r[0]) for r in rows):
            rows.append((m["name"], m["size"], "já instalado no Ollama", True))
    print(f"  {'#':>2}  {'Modelo':<24} {'Tamanho':>8}  Status")
    for i, (tag, size, desc, inst) in enumerate(rows, 1):
        have = " [instalado]" if inst else ""
        star = "  ★ PADRÃO" if _same_tag(tag, rec) else ""
        if remote:
            label = "no servidor remoto" if inst else "será baixado no servidor"
        else:
            label = fit(size, hw, mode)[1]
        print(f"  {i:>2}  {tag:<24} ~{size:>5.1f} GB  {label}{have}{star}")
        print(f"      {desc}")
    print(f"\n  ★ {'Modelo padrão' if remote else 'Melhor modelo para este celular'}: {rec}")
    if preset:
        info(f"Modelo definido por parâmetro: {preset}")
        return preset
    while True:
        raw = ask(f"\n  Digite o número, ou o nome de outro modelo do Ollama (ex.: mistral:7b). Enter = {rec}: ", rec)
        if raw.isdigit() and 1 <= int(raw) <= len(rows):
            tag, size, _, _ = rows[int(raw) - 1]
            if not remote:
                code, label = fit(size, hw, mode)
                if code in {"no", "cpu_slow", "partial"}:
                    warn(f"{tag}: {label}.")
                    if not yesno("Usar mesmo assim?", False):
                        continue
            return tag
        if re.fullmatch(r"[A-Za-z0-9._\-/]+(:[A-Za-z0-9._\-]+)?", raw):
            known = next((r for r in rows if _same_tag(r[0], raw)), None)
            if not known and not remote:
                warn("Modelo fora da lista: não consigo estimar se ele cabe no celular (confira o tamanho em ollama.com/library).")
                if not yesno("Continuar com esse modelo?", True):
                    continue
            return raw
        err("Entrada inválida.")


# ---------------------------------------------------------------------------------------------
#  Credenciais do Telegram / .env
# ---------------------------------------------------------------------------------------------
def parse_env_text(text: str) -> dict:
    """Le CHAVE=valor (aceita 'export ', aspas e comentarios de fim de linha, como o python-dotenv)."""
    out: dict = {}
    for line in text.lstrip("\ufeff").splitlines():
        s = line.strip()
        if not s or s.startswith("#") or "=" not in s:
            continue
        if s.startswith("export "):
            s = s[7:].lstrip()
        k, _, v = s.partition("=")
        k, v = k.strip(), v.strip()
        if not re.fullmatch(r"[A-Za-z_][A-Za-z0-9_]*", k):
            continue
        if len(v) >= 2 and v[0] == v[-1] and v[0] in "\"'":
            v = v[1:-1]
        elif " #" in v:
            v = v.split(" #", 1)[0].rstrip()
        out[k] = v
    return out


def read_env(path: Path) -> dict:
    if not path.exists():
        return {}
    return parse_env_text(path.read_text(encoding="utf-8", errors="replace"))


def set_env_key(path: Path, key: str, value: str) -> None:
    text = path.read_text(encoding="utf-8") if path.exists() else ""
    line = f"{key}={value}"
    if re.search(rf"^{re.escape(key)}=.*$", text, flags=re.M):
        text = re.sub(rf"^{re.escape(key)}=.*$", lambda _m: line, text, count=1, flags=re.M)
    else:
        text = text.rstrip("\n") + ("\n" if text else "") + line + "\n"
    path.write_text(text, encoding="utf-8")


def telegram_get_me(token: str) -> tuple[str, str]:
    """('ok', @usuario) | ('invalid', '') | ('offline', erro)"""
    try:
        with urllib.request.urlopen(f"https://api.telegram.org/bot{token}/getMe", timeout=15) as resp:
            data = json.loads(resp.read().decode("utf-8"))
            return ("ok", "@" + str(data.get("result", {}).get("username", "?"))) if data.get("ok") else ("invalid", "")
    except urllib.error.HTTPError as exc:
        return ("invalid", "") if exc.code in (401, 404) else ("offline", str(exc))
    except (urllib.error.URLError, OSError, ValueError) as exc:
        return "offline", str(exc)


# ---- chaves / integracoes: coleta + teste de cada uma -------------------------------------------
def mask(value: str) -> str:
    return (value[:4] + "…" + value[-4:]) if len(value) > 10 else "****"


def ask_secret(prompt: str) -> str:
    """Pede um segredo sem eco na tela (cole e dê Enter). Em modo --yes ou sem terminal, devolve vazio/lê a linha."""
    if ASSUME_YES:
        return ""
    try:
        import getpass
        return getpass.getpass(prompt).strip()
    except (EOFError, KeyboardInterrupt):
        print()
        return ""


def http_call(url: str, method: str = "GET", data: bytes | None = None, headers: dict | None = None,
              timeout: float = 20) -> tuple[int, bytes, str, str]:
    """(status, corpo, content-type, erro). status 0 = sem conexão (erro descreve o motivo, sem URL/segredos)."""
    req = urllib.request.Request(url, data=data, headers=headers or {}, method=method)
    try:
        with urllib.request.urlopen(req, timeout=timeout) as resp:
            return resp.status, resp.read(), resp.headers.get("Content-Type", ""), ""
    except urllib.error.HTTPError as exc:
        try:
            body = exc.read()
        except OSError:
            body = b""
        return exc.code, body, exc.headers.get("Content-Type", "") if exc.headers else "", ""
    except urllib.error.URLError as exc:
        return 0, b"", "", str(exc.reason)[:120]
    except (OSError, ValueError) as exc:
        return 0, b"", "", type(exc).__name__


def test_telegram_token(token: str) -> tuple[str, str]:
    status, who = telegram_get_me(token)
    if status == "ok":
        return "PASSOU", f"bot {who}"
    if status == "invalid":
        return "FALHOU", "o Telegram recusou o token (copie de novo do @BotFather)"
    return "AVISO", "sem conexão com o Telegram agora; não foi possível validar"


def test_telegram_ids(token: str, ids: str, bot_name: str) -> tuple[str, str]:
    if not token:
        return "AVISO", "sem token para testar o envio"
    if not yesno("  Enviar uma mensagem de teste para esse(s) ID(s) no Telegram?", True):
        return "PULADO", "teste de envio dispensado"
    bad = []
    for uid in ids.split(","):
        body = json.dumps({"chat_id": int(uid), "text": f"✅ {bot_name} instalado. Seu ID está na whitelist e o bot consegue falar com você."}).encode()
        code, resp, _, e = http_call(f"https://api.telegram.org/bot{token}/sendMessage", "POST", body,
                                     {"Content-Type": "application/json"}, 20)
        if code == 0:
            return "AVISO", f"sem conexão com o Telegram ({e})"
        if code != 200:
            bad.append(uid)
    if not bad:
        return "PASSOU", "mensagem entregue (confira o Telegram)"
    return "AVISO", (f"não consegui enviar para {', '.join(bad)}: abra o bot no Telegram e envie /start "
                     "(o bot só pode escrever depois disso) ou confira se o ID está certo")


FISH_WHY = {401: "chave de API inválida", 402: "sem saldo, ou o plano não cobre esse modelo/voz (FISH_MODEL)",
            403: "acesso negado à voz ou ao recurso", 404: "voz não encontrada (confira o ID da voz)",
            422: "parâmetros recusados (confira o ID da voz)", 429: "limite de requisições atingido"}


def test_fish(key: str, voice: str, model: str, language: str = "pt-BR") -> tuple[str, str]:
    if not voice:
        return "FALHOU", "falta o ID da voz (reference_id)"
    headers = {"Authorization": f"Bearer {key}", "Content-Type": "application/json"}
    if model:
        headers["model"] = model
    payload = json.dumps({"text": "Olá.", "reference_id": voice, "format": "opus", "language": language}).encode()
    code, body, ctype, e = http_call("https://api.fish.audio/v1/tts", "POST", payload, headers, 60)
    if code == 0:
        return "AVISO", f"sem conexão com a Fish Audio ({e})"
    if code == 200 and not ctype.startswith(("application/json", "text/")) and len(body) > 300:
        return "PASSOU", f"áudio de teste gerado ({len(body) / 1024:.1f} KB)"
    return "FALHOU", f"HTTP {code}: {FISH_WHY.get(code, 'resposta inesperada')}"


def nexus_url_default(existing_url: str) -> str:
    """URL padrao do Nexus: 1666 (o Android nao abre portas < 1024). Migra o padrao antigo local (666/8666)."""
    url = (existing_url or "").strip().rstrip("/")
    if not url:
        return "http://127.0.0.1:1666"
    for old in (":666", ":8666"):
        if url.endswith(old) and ("127.0.0.1" in url or "localhost" in url):
            return url[: -len(old)] + ":1666"
    return url


def test_nexus(url: str, token: str) -> tuple[str, str]:
    code, _, _, e = http_call(url.rstrip("/") + "/api/health", "GET", None, {"X-Nexus-Token": token} if token else {}, 8)
    if code == 0:
        return "AVISO", f"o Nexus não está rodando agora ({e}); será usado quando ele subir"
    if code == 200:
        return "PASSOU", "Nexus respondendo" + (" (token aceito)" if token else "")
    if code in (401, 403):
        return "FALHOU", "o Nexus recusou o token (NEXUS_TOKEN deve ser igual ao TOOLS_API_TOKEN dele)"
    return "FALHOU", f"HTTP {code} em /api/health"


def acquire_secret(label: str, prompt: str, current: str, check_format, tester, preset: str = "") -> tuple[str, str, str]:
    """Obtém um segredo, testa e deixa corrigir. Retorna (valor|'' , status, detalhe)."""
    value = preset
    if not value and current and yesno(f"  {label}: já existe ({mask(current)}). Manter e testar?", True):
        value = current
    bad_format = 0
    while True:
        if not value:
            raw = ask_secret(prompt)
            if not raw:
                return "", "PULADO", "não informado"
            msg = check_format(raw) if check_format else ""
            if msg:
                err(msg)
                bad_format += 1
                if bad_format >= 5:
                    return "", "PULADO", "formato inválido"
                continue
            value = raw
            print(f"      recebido: {len(value)} caracteres, termina em …{value[-4:]}")
        status, detail = tester(value)
        if status == "PASSOU":
            ok(f"{label}: {detail}")
            return value, status, detail
        if status in {"AVISO", "PULADO"}:
            warn(f"{label}: {detail}")
            return value, status, detail
        err(f"{label}: {detail}")
        choice = ask("  [R] digitar de novo   [M] manter assim mesmo   [P] pular   (padrão P): ", "p").lower()
        if choice == "r":
            value = ""
            continue
        if choice == "m":
            return value, "FALHOU", detail
        return "", "PULADO", f"descartada ({detail})"


def _fmt_token(raw: str) -> str:
    return "" if re.fullmatch(r"\d{6,}:[A-Za-z0-9_\-]{30,}", raw) else "Formato inesperado de token. Copie exatamente o que o @BotFather enviou."


def ask_keys_manual(existing: dict, preset_token: str | None, preset_ids: str | None, bot_name: str):
    """Seção de chaves: Telegram (obrigatório), Fish Audio e Nexus (opcionais). Testa cada uma na hora."""
    title("CHAVES E INTEGRAÇÕES")
    print("  Cada chave é testada assim que você a informa. Digitação oculta: cole e dê Enter.")
    print("  Enter em branco = pular (dá para preencher depois no .env e conferir com  --test-keys).\n")
    updates: dict[str, str] = {}
    results: list[tuple[str, str, str]] = []

    # --- Telegram (obrigatório) ---
    print(_c("1", "  [1] Telegram — token do bot (@BotFather)"))
    token, st, det = acquire_secret("Token do Telegram", "  Token (ex.: 123456789:AAH...): ",
                                    existing.get("TELEGRAM_BOT_TOKEN", ""), _fmt_token, test_telegram_token, preset_token or "")
    results.append(("Telegram: token do bot", st, det))
    if token:
        updates["TELEGRAM_BOT_TOKEN"] = token

    print(_c("1", "\n  [2] Telegram — seu ID numérico (veja em @userinfobot)"))
    cur_ids = existing.get("ALLOWED_USER_IDS", "")
    ids = preset_ids or ""
    if not ids and cur_ids and yesno(f"  ID(s) já existente(s) ({cur_ids}). Manter?", True):
        ids = cur_ids
    tries = 0
    while not ids and tries < 4 and not ASSUME_YES:
        raw = ask("  Seu ID (vários: separe por vírgula): ", "")
        if not raw:
            break
        if re.fullmatch(r"\d+(\s*,\s*\d+)*", raw):
            ids = raw.replace(" ", "")
        else:
            err("Use só números (e vírgulas).")
            tries += 1
    if ids:
        st, det = test_telegram_ids(token or existing.get("TELEGRAM_BOT_TOKEN", ""), ids, bot_name)
        (ok if st == "PASSOU" else warn)(f"ID: {det}")
        updates["ALLOWED_USER_IDS"] = ids
    else:
        st, det = "PULADO", "não informado (o bot não inicia sem whitelist)"
        warn("ID pulado — o bot só inicia depois que ALLOWED_USER_IDS estiver no .env.")
    results.append(("Telegram: seu ID (whitelist)", st, det))

    # --- Fish Audio (opcional) ---
    print(_c("1", "\n  [3] Fish Audio — voz (opcional)"))
    has_fish = bool(existing.get("FISH_API_KEY"))
    if yesno("  Configurar a voz da Fish Audio?", has_fish):
        voice = ask(f"  ID da voz (reference_id){' [Enter = ' + existing['FISH_VOICE_ID'] + ']' if existing.get('FISH_VOICE_ID') else ''}: ",
                    existing.get("FISH_VOICE_ID", "")).strip()
        model = ask(f"  Modelo [Enter = {existing.get('FISH_MODEL') or 's2.1-pro-free'}; '-' = padrão do plano pago]: ",
                    existing.get("FISH_MODEL") or "s2.1-pro-free").strip()
        model = "" if model == "-" else model
        lang = existing.get("FISH_LANGUAGE") or "pt-BR"
        print("      (o teste gera 1 áudio de ~1 palavra: consome uma fração mínima do seu crédito)")
        key, st, det = acquire_secret("Fish Audio", "  FISH_API_KEY: ", existing.get("FISH_API_KEY", ""), None,
                                      lambda k: test_fish(k, voice, model, lang))
        results.append(("Fish Audio: chave + voz + modelo", st, det))
        if key:
            updates.update({"FISH_API_KEY": key, "FISH_VOICE_ID": voice, "FISH_MODEL": model})
    else:
        results.append(("Fish Audio", "PULADO", "voz desligada (o bot responde só em texto)"))

    # --- Nexus (opcional) ---
    print(_c("1", "\n  [4] Nexus-Bridge — ferramentas, /video e /code (opcional)"))
    nex_on = (existing.get("NEXUS_ENABLED", "").lower() in {"1", "true", "yes", "sim", "on"})
    if yesno("  Conectar ao Nexus-Bridge?", nex_on):
        _nex_def = nexus_url_default(existing.get("NEXUS_URL", ""))
        url = ask(f"  URL do Nexus [Enter = {_nex_def}]: ", _nex_def).strip().rstrip("/")
        while True:
            tok = existing.get("NEXUS_TOKEN", "")
            if tok and yesno(f"  NEXUS_TOKEN já existe ({mask(tok)}). Manter?", True):
                pass
            else:
                tok = ask_secret("  NEXUS_TOKEN (igual ao TOOLS_API_TOKEN do Nexus; Enter = sem token): ")
            st, det = test_nexus(url, tok)
            (ok if st == "PASSOU" else warn if st == "AVISO" else err)(f"Nexus: {det}")
            if st != "FALHOU":
                break
            ch = ask("  [R] digitar de novo   [M] manter assim mesmo   [P] pular   (padrão P): ", "p").lower()
            existing = {**existing, "NEXUS_TOKEN": ""}
            if ch == "r":
                continue
            if ch != "m":
                st, det = "PULADO", f"descartado ({det})"
                tok = None
            break
        results.append(("Nexus-Bridge: URL + token", st, det))
        if tok is not None:
            updates.update({"NEXUS_ENABLED": "true", "NEXUS_URL": url, "NEXUS_TOKEN": tok})
    else:
        results.append(("Nexus-Bridge", "PULADO", "desligado"))

    title("RESULTADO DOS TESTES DAS CHAVES")
    print_key_results(results)
    return updates, results


# ---------------------------------------------------------------------------------------------
#  .env: importar pronto OU preencher manualmente
# ---------------------------------------------------------------------------------------------
ENV_SHOW = ["TELEGRAM_BOT_TOKEN", "ALLOWED_USER_IDS", "ADMIN_USER_IDS", "OLLAMA_HOST", "OLLAMA_MODEL",
            "NEXUS_ENABLED", "NEXUS_URL", "NEXUS_TOKEN", "FISH_API_KEY", "FISH_VOICE_ID", "FISH_MODEL"]
ENV_SECRET = {"TELEGRAM_BOT_TOKEN", "NEXUS_TOKEN", "FISH_API_KEY"}


def import_env_file(preset: str | None) -> tuple[str, dict, str] | None:
    """Pede o caminho de um .env pronto. Retorna (texto normalizado, valores, caminho) ou None se desistiu."""
    print("\n  Informe o caminho do .env pronto (ex.: ~/storage/downloads/.env ou /sdcard/Download/.env).")
    print("  L = listar arquivos .env encontrados no celular  |  Enter = desistir e preencher manualmente")
    candidates = [preset] if preset else []
    for _ in range(6):
        raw = candidates.pop(0) if candidates else ask("\n  Caminho do .env: ", "")
        raw = raw.strip()
        if raw.lower() == "l":
            ensure_storage()
            raw = pick_from_list(find_candidates(is_env_name), ".env")
            if not raw:
                warn("Nenhum .env encontrado/selecionado nas pastas do celular (Downloads, Documentos, pasta atual, home).")
                continue
        if not raw:
            return None
        if raw.startswith(("/sdcard", "/storage")) or "/storage/" in raw:
            ensure_storage()
        path = resolve_user_path(raw)
        if not path.is_file():
            err(f"Arquivo não encontrado: {path}")
            continue
        try:
            if path.stat().st_size > 262144:
                err("Arquivo grande demais para ser um .env.")
                continue
            text = path.read_bytes().decode("utf-8-sig", errors="replace")
        except OSError as exc:
            err(f"Não consegui ler o arquivo: {exc}")
            continue
        text = text.replace("\r\n", "\n").replace("\r", "\n")
        text = text if text.endswith("\n") else text + "\n"
        # 'export CHAVE = valor' -> 'CHAVE=valor' (o launcher le o .env com grep; o python-dotenv aceita os dois)
        text = "\n".join(
            ln if ln.lstrip().startswith("#") else re.sub(r"^\s*(?:export\s+)?([A-Za-z_][A-Za-z0-9_]*)\s*=\s*", r"\1=", ln)
            for ln in text.split("\n"))
        vals = parse_env_text(text)
        if not vals:
            err("Não encontrei nenhuma linha CHAVE=valor nesse arquivo.")
            continue
        ok(f"{len(vals)} variáveis lidas de {path}")
        for k in ENV_SHOW:
            if k in vals:
                shown = mask(vals[k]) if (k in ENV_SECRET and vals[k]) else (vals[k] or "(vazio)")
                print(f"     {k:<20} {shown}")
        return text, vals, str(path)
    warn("Muitas tentativas sem sucesso.")
    return None


def ask_env(existing: dict, preset_env: str | None, preset_token: str | None, preset_ids: str | None, bot_name: str):
    """Escolha: importar .env pronto ou preencher manualmente.

    Retorna (updates, results, env_text|None, valores_efetivos). Com env_text, o instalador grava
    esse texto como .env e aplica 'updates' (correcoes manuais) por cima.
    """
    title("CONFIGURAÇÃO DO .env")
    print("  O .env guarda o token do Telegram, a whitelist e as integrações (Fish Audio, Nexus...).\n")
    print("   [1] Importar um .env pronto  (copia o arquivo inteiro e testa as chaves)")
    print("   [2] Preencher manualmente    (passo a passo, com teste de cada chave)")
    choice = "1" if preset_env else ask("\n  Escolha [1/2] (Enter = 2): ", "2")
    if choice == "1":
        imported = import_env_file(preset_env)
        if imported and existing and not yesno(
                "\n  Já existe um .env nesta instalação. Substituir pelo importado? (uma cópia de segurança é feita)", True):
            warn("Mantendo o .env atual; seguindo para o preenchimento manual.")
            imported = None
        if imported:
            text, vals, _src = imported
            title("TESTE DAS CHAVES DO .env IMPORTADO")
            tvals = dict(vals)
            tvals["ALLOWED_USER_IDS"] = tvals.get("ALLOWED_USER_IDS", "").replace(";", ",").replace(" ", "")
            results = test_saved_keys(tvals, bot_name)
            print()
            print_key_results(results)
            ids_ok = bool(re.fullmatch(r"\d+(,\d+)*", tvals["ALLOWED_USER_IDS"]))
            needs_fix = (not vals.get("TELEGRAM_BOT_TOKEN")) or (not ids_ok) or any(r[1] == "FALHOU" for r in results)
            if needs_fix:
                warn("O .env importado tem pendências (token/ID ausente ou recusado).")
                if yesno("  Corrigir agora preenchendo manualmente (você pode manter o que já está certo)?", True):
                    updates, res2 = ask_keys_manual(vals, preset_token, preset_ids, bot_name)
                    return updates, res2, text, {**vals, **updates}
            return {}, results, text, vals
        warn("Seguindo para o preenchimento manual.")
    updates, results = ask_keys_manual(existing, preset_token, preset_ids, bot_name)
    return updates, results, None, {**existing, **updates}


def choose_ollama_location(env: dict, preset_url: str | None) -> str | None:
    """None = Ollama neste celular; string = URL de um Ollama em outro computador/servidor."""
    title("ONDE RODA O OLLAMA?")
    env_host = (env.get("OLLAMA_HOST") or "").strip().rstrip("/")
    env_remote = env_host if env_host and not is_local_url(env_host) else ""
    if preset_url:
        url = preset_url.strip().rstrip("/")
    else:
        default = "2" if env_remote else "1"
        print("   [1] Neste celular (Termux): instala o pacote 'ollama'. Só modelos pequenos (até ~3B).")
        print("   [2] Em outro computador/servidor (PC com GPU, VPS...): você informa a URL.")
        if env_remote:
            print(f"       (o .env informa um Ollama remoto: {env_remote})")
        if ask(f"\n  Escolha [1/2] (Enter = {default}): ", default) != "2":
            return None
        url = ""
    for _ in range(5):
        if not url:
            url = ask(f"  URL do Ollama{' [Enter = ' + env_remote + ']' if env_remote else ''} (ex.: http://192.168.0.10:11434): ",
                      env_remote).strip().rstrip("/")
            if not url:
                if ASSUME_YES:
                    return None
                continue
        if "://" not in url:
            url = "http://" + url
        code, _, _, e = http_call(url + "/api/tags", timeout=6)
        if code == 200:
            ok(f"Ollama remoto respondendo em {url}")
            return url
        warn(f"Sem resposta de {url} ({e or 'HTTP ' + str(code)}). No PC, o Ollama precisa escutar na rede "
             "(inicie-o com OLLAMA_HOST=0.0.0.0) e o celular precisa estar na mesma rede.")
        if ASSUME_YES or yesno("  Usar essa URL mesmo assim?", False):
            return url
        url = ""
    warn("Sem URL válida; usando o Ollama deste celular.")
    return None


def print_key_results(results) -> None:
    color = {"PASSOU": "32", "FALHOU": "31", "AVISO": "33", "PULADO": "90"}
    for name, st, det in results:
        print(f"   {_c(color.get(st, '0'), f'{st:<7}')} {name:<34} {det}")


def test_saved_keys(env: dict, bot_name: str = "Aether") -> list[tuple[str, str, str]]:
    """Reexecuta os testes com o que já está no .env (modo --test-keys)."""
    results = []
    tok = env.get("TELEGRAM_BOT_TOKEN", "")
    if tok:
        results.append(("Telegram: token do bot", *test_telegram_token(tok)))
    else:
        results.append(("Telegram: token do bot", "FALHOU", "TELEGRAM_BOT_TOKEN vazio"))
    ids = env.get("ALLOWED_USER_IDS", "")
    if ids and re.fullmatch(r"\d+(\s*,\s*\d+)*", ids):
        results.append(("Telegram: seu ID (whitelist)", *test_telegram_ids(tok, ids.replace(" ", ""), bot_name)))
    else:
        results.append(("Telegram: seu ID (whitelist)", "FALHOU", "ALLOWED_USER_IDS vazio ou inválido"))
    if env.get("FISH_API_KEY"):
        results.append(("Fish Audio: chave + voz + modelo",
                        *test_fish(env["FISH_API_KEY"], env.get("FISH_VOICE_ID", ""), env.get("FISH_MODEL", ""), env.get("FISH_LANGUAGE") or "pt-BR")))
    else:
        results.append(("Fish Audio", "PULADO", "voz desligada"))
    if env.get("NEXUS_ENABLED", "").lower() in {"1", "true", "yes", "sim", "on"}:
        results.append(("Nexus-Bridge: URL + token", *test_nexus(nexus_url_default(env.get("NEXUS_URL", "")), env.get("NEXUS_TOKEN", ""))))
    else:
        results.append(("Nexus-Bridge", "PULADO", "desligado"))
    return results


# ---------------------------------------------------------------------------------------------
#  Python / venv / bibliotecas / testes
# ---------------------------------------------------------------------------------------------
def stop_running_bot(install_dir: Path) -> None:
    launcher = install_dir / "start.sh"
    if launcher.exists():
        run(["bash", str(launcher), "stop"], timeout=40)


def venv_python(install_dir: Path) -> Path:
    return install_dir / "venv" / "bin" / "python"


def setup_venv(install_dir: Path) -> Path | None:
    vpy = venv_python(install_dir)
    if vpy.exists() and run([str(vpy), "-c", "import sys"], timeout=30)[0] != 0:
        warn("venv existente está quebrada; recriando.")
        shutil.rmtree(install_dir / "venv", ignore_errors=True)
    if not vpy.exists():
        info(f"Criando ambiente virtual com Python {sys.version.split()[0]}...")
        rc, out = run([sys.executable, "-m", "venv", str(install_dir / "venv")], timeout=600)
        if rc != 0 or not vpy.exists():
            err("Falha ao criar a venv:\n" + out[-800:])
            return None
    ok("Ambiente virtual pronto.")
    return vpy


def pip_install(vpy: Path, install_dir: Path, extra: list[str] | None = None) -> bool:
    run([str(vpy), "-m", "pip", "install", "--upgrade", "pip", "--disable-pip-version-check"], timeout=600)
    cmd = [str(vpy), "-m", "pip", "install", "--disable-pip-version-check", "-r", str(install_dir / "requirements.txt")] + (extra or [])
    for attempt in range(1, 4):
        info(f"Instalando bibliotecas (tentativa {attempt}/3) — aguarde...")
        rc, out = run(cmd, timeout=1800)
        if rc == 0:
            ok("Bibliotecas instaladas.")
            return True
        warn("pip falhou: " + (out.strip().splitlines()[-1][:200] if out.strip() else "sem detalhes"))
        time.sleep(3)
    err("Não foi possível instalar as bibliotecas. Verifique a internet/proxy e rode o instalador de novo.")
    return False


SELFTEST = r'''
import importlib, io, os, pkgutil, sys, tempfile
sys.path.insert(0, os.getcwd())
def emit(ok, name, detail=""):
    print(("PASS|" if ok else "FAIL|") + name + "|" + str(detail).replace("\n", " ")[:200], flush=True)
def t(name, fn):
    try:
        emit(True, name, fn() or "")
    except Exception as exc:  # noqa
        emit(False, name, f"{type(exc).__name__}: {exc}")

def py():
    import ssl, asyncio, json, zlib  # noqa
    ssl.create_default_context()
    return sys.version.split()[0]
def tg():
    import telegram
    from telegram.ext import Application
    Application.builder().token("123456:TEST-offline-token").build()
    return "python-telegram-bot " + telegram.__version__
def hx():
    import httpx
    c = httpx.Client(timeout=3); c.close()
    httpx.Request("GET", "http://127.0.0.1:11434/api/tags")
    return "httpx " + httpx.__version__
def de():
    import dotenv
    from dotenv import dotenv_values
    assert dotenv_values(stream=io.StringIO("A=1")).get("A") == "1"
    return "python-dotenv ok"
def mods():
    import aether
    names = [m.name for m in pkgutil.iter_modules(aether.__path__) if m.name != "__main__"]
    for n in names:
        importlib.import_module("aether." + n)
    return f"{len(names)} módulos importados"
def cfg():
    from pathlib import Path
    os.environ["TELEGRAM_BOT_TOKEN"] = "123456:TEST"; os.environ["ALLOWED_USER_IDS"] = "1"
    from aether.config import load_settings
    s = load_settings(Path(tempfile.gettempdir()) / "aether_inexistente.env")
    return "load_settings ok (modelo padrão " + s.ollama_model + ")"
def per():
    from aether.persona import load_persona
    p = load_persona()
    return f"personalidade '{p.name}' ({len(p.system_prompt)} caracteres)"
for n, f in [("Python/SSL/asyncio", py), ("python-telegram-bot", tg), ("httpx", hx), ("python-dotenv", de),
             ("Módulos do bot", mods), ("Configuração (.env)", cfg), ("Personalidade (persona.json)", per)]:
    t(n, f)
'''


def run_selftest(vpy: Path, install_dir: Path) -> list[tuple[bool, str, str]]:
    script = install_dir / "_selftest.py"
    script.write_text(SELFTEST, encoding="utf-8")
    env = {**os.environ, "PYTHONUTF8": "1"}
    rc, out = run([str(vpy), "-X", "utf8", str(script)], timeout=180, cwd=str(install_dir), env=env)
    try:
        script.unlink()
    except OSError:
        pass
    results = []
    for line in out.splitlines():
        parts = line.split("|", 2)
        if len(parts) == 3 and parts[0] in {"PASS", "FAIL"}:
            results.append((parts[0] == "PASS", parts[1], parts[2]))
    if not results:
        results.append((False, "Execução dos testes", out.strip()[-200:] or f"código {rc}"))
    return results


def print_results(results) -> bool:
    all_ok = True
    for good, name, detail in results:
        print(f"   {_c('32', 'PASSOU') if good else _c('31', 'FALHOU')}  {name:<30} {detail}")
        all_ok &= good
    return all_ok


LAUNCHER = r'''#!/usr/bin/env bash
# ============================================================
#  Launcher do bot __TITLE__ (gerado pelo Instalar_Aether.sh)
#  Uso:  ./start.sh          primeiro plano (Ctrl+C para parar)
#        ./start.sh silent   segundo plano; log em logs/bot.log
#        ./start.sh stop     encerra o bot
#        ./start.sh status   mostra se esta rodando
# ============================================================
SELF="$(readlink -f "$0")"
cd "$(dirname "$SELF")" || exit 1
export PYTHONUTF8=1 PYTHONUNBUFFERED=1
MODE="${1:-}"
PY="./venv/bin/python"
PIDFILE=".bot.pid"
mkdir -p logs data

is_running() {
    [ -f "$PIDFILE" ] || return 1
    local pid
    pid="$(cat "$PIDFILE" 2>/dev/null)"
    [ -n "$pid" ] && kill -0 "$pid" 2>/dev/null
}

stop_bot() {
    if ! is_running; then
        rm -f "$PIDFILE"
        echo "[*] O bot nao esta rodando."
        return 0
    fi
    local pid i
    pid="$(cat "$PIDFILE")"
    echo "[*] Encerrando o bot (PID $pid)..."
    kill -TERM "$pid" 2>/dev/null
    for i in $(seq 1 15); do
        kill -0 "$pid" 2>/dev/null || break
        sleep 1
    done
    if kill -0 "$pid" 2>/dev/null; then
        kill -KILL "$pid" 2>/dev/null
        command -v pkill >/dev/null 2>&1 && pkill -f "venv/bin/python -m aether" 2>/dev/null
    fi
    rm -f "$PIDFILE"
    command -v termux-wake-unlock >/dev/null 2>&1 && termux-wake-unlock
    echo "[OK] Bot encerrado."
}

getenv() {  # getenv CHAVE padrao  -> valor no .env (sem aspas)
    local v
    v="$(grep -m1 "^$1=" .env 2>/dev/null | cut -d= -f2- | tr -d '\r')"
    case "$v" in
        \"*|\'*) ;;
        *) v="${v%%[[:space:]]#*}"; v="${v%"${v##*[![:space:]]}"}" ;;
    esac
    v="${v%\"}"; v="${v#\"}"; v="${v%\'}"; v="${v#\'}"
    echo "${v:-$2}"
}

preflight() {
    # ---- 1. venv e dependencias ----
    if [ ! -x "$PY" ]; then
        echo "[X] Ambiente Python nao encontrado. Rode Instalar_Aether.sh de novo para reparar."
        exit 1
    fi
    if ! "$PY" -c "import telegram, httpx, dotenv" >/dev/null 2>&1; then
        echo "[*] Reparando dependencias..."
        "$PY" -m pip install -r requirements.txt || { echo "[X] Falha ao preparar o ambiente."; exit 1; }
    fi

    # ---- 2. .env (token e whitelist sao obrigatorios) ----
    if [ ! -f .env ]; then
        [ -f .env.example ] && cp .env.example .env
        echo "[!] .env criado. Preencha TELEGRAM_BOT_TOKEN e ALLOWED_USER_IDS (ex.: nano .env) e rode de novo."
        exit 2
    fi
    local missing=""
    grep -Eq '^TELEGRAM_BOT_TOKEN=[^[:space:]]' .env || missing="TELEGRAM_BOT_TOKEN"
    grep -Eq '^ALLOWED_USER_IDS=[^[:space:]]' .env || missing="$missing ALLOWED_USER_IDS"
    if [ -n "$missing" ]; then
        echo "[X] Faltando no .env:$missing   (edite com: nano .env)"
        exit 2
    fi

    # ---- 3. Ollama (sobe sozinho se for local) ----
    local url mdl i
    url="$(getenv OLLAMA_HOST http://127.0.0.1:11434)"
    mdl="$(getenv OLLAMA_MODEL aether-persona)"
    if ! curl -sf -m 3 -o /dev/null "$url/api/tags"; then
        if echo "$url" | grep -Eq 'localhost|127\.0\.0\.1'; then
            if command -v ollama >/dev/null 2>&1; then
                echo "[*] Ollama offline. Iniciando..."
                nohup ollama serve >>logs/ollama.log 2>&1 &
                for i in $(seq 1 20); do
                    sleep 1
                    curl -sf -m 2 -o /dev/null "$url/api/tags" && break
                done
                curl -sf -m 2 -o /dev/null "$url/api/tags" || echo "[!] Ollama nao respondeu em 20s - seguindo mesmo assim."
            else
                echo "[!] Ollama nao encontrado - o bot nao vai conseguir responder. Rode Instalar_Aether.sh."
            fi
        else
            echo "[!] Ollama remoto sem resposta: $url"
        fi
    fi
    if curl -sf -m 3 -o /dev/null "$url/api/tags"; then
        curl -s -m 3 "$url/api/tags" | grep -qF "\"$mdl" || echo "[!] Modelo $mdl nao existe no Ollama. Rode Instalar_Aether.sh para recriar."
    fi

    # ---- 4. evita o celular dormir e matar o bot ----
    command -v termux-wake-lock >/dev/null 2>&1 && termux-wake-lock
}

run_loop() {
    echo $$ > "$PIDFILE"
    local STOP=0 CHILD="" RC=0
    trap 'rm -f "$PIDFILE"' EXIT
    trap 'STOP=1; [ -n "$CHILD" ] && kill -TERM "$CHILD" 2>/dev/null' INT TERM
    export AETHER_SUPERVISED=1   # o painel (/env) so oferece "Reiniciar" quando ha este supervisor para religar o bot
    while [ "$STOP" = 0 ]; do
        echo
        echo "[*] Bot iniciando - Ctrl+C para parar"
        "$PY" -m aether &
        CHILD=$!
        wait "$CHILD"; RC=$?
        while kill -0 "$CHILD" 2>/dev/null; do wait "$CHILD"; RC=$?; done
        CHILD=""
        [ "$STOP" = 1 ] && break
        case "$RC" in
            0|130|143) break ;;
            2) echo; echo "[ERRO FATAL] Configuracao ou token invalido. Corrija o .env e rode de novo."; exit 2 ;;
        esac
        echo "[$(date '+%F %T')] encerrou com codigo $RC. Reiniciando em 5s..."
        sleep 5
    done
    echo
    echo "Bot encerrado."
}

case "$MODE" in
    stop)   stop_bot; exit 0 ;;
    status) if is_running; then echo "[OK] Rodando (PID $(cat "$PIDFILE")). Log: logs/bot.log"; else echo "[*] Parado."; fi; exit 0 ;;
    _loop)  run_loop; exit 0 ;;   # supervisor em segundo plano (uso interno)
esac

# ---- ja existe outra instancia? (2 bots no mesmo token = erro Conflict) ----
if is_running; then
    echo "[!] Ja existe outra instancia rodando (PID $(cat "$PIDFILE"))."
    [ "$MODE" = "silent" ] && exit 1
    read -r -p "Encerrar a outra instancia e continuar? [s/N] " ans
    case "$ans" in s|S|sim|SIM) stop_bot; sleep 2 ;; *) exit 1 ;; esac
fi

preflight

if [ "$MODE" = "silent" ]; then
    nohup bash "$SELF" _loop >>logs/bot.log 2>&1 &
    echo "[OK] Bot iniciado em segundo plano (PID $!). Log: logs/bot.log  |  parar: ./start.sh stop"
    exit 0
fi
run_loop
'''


def write_launcher(install_dir: Path, name: str) -> Path:
    label = fold_ascii(name).strip() or "Aether"
    text = LAUNCHER.replace("__TITLE__", re.sub(r"[^A-Za-z0-9 ._-]", "", label) or "Aether")
    if IS_TERMUX:  # shebang real do Termux (funciona mesmo sem o /usr/bin/env)
        text = text.replace("#!/usr/bin/env bash", "#!" + os.environ.get("PREFIX", "/data/data/com.termux/files/usr") + "/bin/bash", 1)
    path = install_dir / "start.sh"
    path.write_bytes(text.encode("utf-8"))
    path.chmod(0o755)
    return path


def safe_filename(name: str) -> str:
    cleaned = re.sub(r'[<>:"/\\|?*\x00-\x1f]', "", name).strip(" .")
    return cleaned or "Aether"


def create_shortcut(install_dir: Path, name: str) -> str | None:
    """Atalhos do Termux:Widget (~/.shortcuts): um para iniciar e outro para parar o bot."""
    if not IS_TERMUX:
        return None
    sh = os.environ.get("PREFIX", "/data/data/com.termux/files/usr") + "/bin/bash"
    base = safe_filename(name).replace(" ", "_")
    try:
        d = HOME / ".shortcuts"
        d.mkdir(mode=0o700, exist_ok=True)
        start = d / f"{base}.sh"
        stop = d / f"{base}-parar.sh"
        q = shlex.quote(str(install_dir / "start.sh"))
        start.write_text(f"#!{sh}\nexec bash {q}\n", encoding="utf-8")
        stop.write_text(f"#!{sh}\nexec bash {q} stop\n", encoding="utf-8")
        start.chmod(0o700)
        stop.chmod(0o700)
        return str(start)
    except OSError:
        return None


# ---------------------------------------------------------------------------------------------
#  Gerador do bot
# ---------------------------------------------------------------------------------------------
README = """AETHER - bot de Telegram local (Ollama) para Termux
====================================================
Iniciar ........ bash start.sh            (primeiro plano; Ctrl+C para parar)
                 bash start.sh silent      (segundo plano; log em logs/bot.log)
Parar .......... bash start.sh stop
Status ......... bash start.sh status
Atalhos ........ com o app Termux:Widget, os atalhos ficam em ~/.shortcuts
Personalidade .. persona.json (veja persona.exemplo.json). Para trocar: no Telegram, como admin, use /persona
                 e envie o .json (vale na hora, sem reiniciar); ou edite e reinicie o bot; ou rode Instalar_Aether.sh de novo e informe outro JSON (recria o modelo no Ollama).
Configuracao ... .env (token, whitelist, modelo, timeouts). Para importar outro .env pronto, rode
                 Instalar_Aether.sh de novo e escolha a opcao 1 na etapa do .env.
Chaves ......... bash Instalar_Aether.sh --test-keys  (retesta Telegram, Fish Audio e Nexus)
Reparar ........ rode Instalar_Aether.sh de novo (e idempotente)
Dica ........... desative a otimizacao de bateria do Termux (Configuracoes do Android) para o
                 bot nao ser fechado com a tela apagada.
"""


def deploy_bot(dest: Path) -> None:
    dest.mkdir(parents=True, exist_ok=True)
    pkg = dest / "aether"
    if pkg.exists():
        shutil.rmtree(pkg)
    shutil.copytree(BOT_SRC / "aether", pkg, ignore=shutil.ignore_patterns("__pycache__", "*.pyc"))
    for f in ("requirements.txt", ".env.example"):
        shutil.copy2(BOT_SRC / f, dest / f)
    for d in ("data", "logs"):
        (dest / d).mkdir(exist_ok=True)
    (dest / "persona.exemplo.json").write_text(json.dumps(EXAMPLE_PERSONA, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
    (dest / "LEIA-ME.txt").write_text(README, encoding="utf-8")
    ok(f"Bot gerado em {dest}")


# ---------------------------------------------------------------------------------------------
#  Principal
# ---------------------------------------------------------------------------------------------
def main() -> int:
    global ASSUME_YES, OLLAMA_URL
    ap = argparse.ArgumentParser(description="Instalador do Aether (Termux)")
    ap.add_argument("--dir", help="pasta de instalacao (padrao: ~/Aether)")
    ap.add_argument("--persona", help="caminho do JSON da personalidade")
    ap.add_argument("--env", help="caminho de um .env pronto para importar (pula a pergunta de como configurar)")
    ap.add_argument("--model", help="modelo base do Ollama (pula a pergunta)")
    ap.add_argument("--ollama-url", help="usa um Ollama em outro computador/servidor (ex.: http://192.168.0.10:11434)")
    ap.add_argument("--token", help="token do bot (pula a pergunta)")
    ap.add_argument("--user-id", help="ID(s) do Telegram permitidos (pula a pergunta)")
    ap.add_argument("--check", action="store_true", help="so faz o teste de hardware/RAM e mostra os modelos")
    ap.add_argument("--test-keys", action="store_true", help="retesta as chaves ja salvas no .env (Telegram, Fish Audio, Nexus)")
    ap.add_argument("--yes", action="store_true", help="nao pergunta nada; usa os padroes")
    ap.add_argument("--no-shortcut", action="store_true", help="nao cria os atalhos do Termux:Widget")
    ap.add_argument("--skip-ollama", action="store_true", help="nao instala/configura o Ollama")
    args = ap.parse_args()
    ASSUME_YES = args.yes

    print(_c("1;36", "\n   AETHER  -  instalador do bot de Telegram com IA local (Termux)\n"))

    if args.test_keys:
        d = resolve_user_path(args.dir) if args.dir else HOME / "Aether"
        if not (d / ".env").exists():
            err(f"Não achei {d / '.env'} — informe a pasta com --dir ou instale primeiro.")
            return 1
        title("TESTE DAS CHAVES SALVAS")
        res = test_saved_keys(read_env(d / ".env"))
        print()
        print_key_results(res)
        return 0 if not any(r[1] == "FALHOU" for r in res) else 1

    hw = detect_hardware()
    mode = choose_mode(hw)

    if args.check:
        hardware_report(hw, mode)
        print()
        rec = recommend(hw, mode)
        for tag, size, _ in MODELS:
            print(f"  {tag:<24} ~{size:>5.1f} GB  {fit(size, hw, mode)[1]}{'   <== recomendado' if tag == rec else ''}")
        return 0

    # ---------------- FASE A: perguntas ----------------
    default_dir = HOME / "Aether"
    title("PASTA DE INSTALAÇÃO")
    raw_dir = args.dir or ask(f"  Instalar em [{default_dir}]: ", str(default_dir))
    install_dir = resolve_user_path(raw_dir)
    try:
        install_dir.mkdir(parents=True, exist_ok=True)
    except OSError as exc:
        err(f"Não consegui criar {install_dir}: {exc}")
        return 1
    meta_path = install_dir / "install_info.json"
    meta: dict = {}
    if meta_path.exists():
        try:
            meta = json.loads(meta_path.read_text(encoding="utf-8"))
            info("Instalação anterior encontrada: vou reparar/atualizar (suas configurações são mantidas).")
        except ValueError:
            meta = {}

    persona_data, persona, persona_src = get_persona(install_dir, args.persona)

    hardware_report(hw, mode)

    existing_env = read_env(install_dir / ".env")
    key_updates, key_results, env_text, eff_env = ask_env(existing_env, args.env, args.token, args.user_id, persona.name)

    remote_url: str | None = None
    ollama_exe = None
    models: list[dict] = []
    base_model = ""
    if args.skip_ollama:
        base_model = args.model or ""
    else:
        remote_url = choose_ollama_location(eff_env, args.ollama_url)
        if remote_url:
            OLLAMA_URL = remote_url
            if ollama_up():
                models = installed_models()
            else:
                warn(f"O Ollama em {remote_url} não respondeu agora; o bot só responderá quando ele estiver no ar.")
        else:
            ollama_exe = find_ollama()
            if ollama_exe:
                ok(f"Ollama já instalado: {ollama_exe}")
                if start_ollama(ollama_exe):
                    models = installed_models()
            else:
                warn("Ollama NÃO está instalado — será instalado automaticamente (pkg install ollama).")
        preset_model = args.model
        env_model = (eff_env.get("OLLAMA_MODEL") or "").strip()
        if not preset_model and remote_url and env_model and any(_same_tag(m["name"], env_model) for m in models):
            preset_model = env_model
            info(f"Usando o modelo do .env, que já existe no servidor remoto: {env_model}")
        base_model = choose_model(hw, mode, models, preset_model, remote=bool(remote_url))
    num_ctx = 2048

    # ---------------- FASE B: trabalho ----------------
    title("INSTALANDO")
    stop_running_bot(install_dir)
    deploy_bot(install_dir)
    (install_dir / "persona.json").write_text(json.dumps(persona_data, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
    ok(f"Personalidade aplicada: {persona.name} ({persona_src})")

    results: list[tuple[bool, str, str]] = []
    vpy = setup_venv(install_dir)
    if not vpy or not pip_install(vpy, install_dir):
        err("Não foi possível preparar o Python do bot. Instalação interrompida.")
        return 1

    title("TESTE DAS BIBLIOTECAS E DO BOT")
    results = run_selftest(vpy, install_dir)
    if not all(r[0] for r in results):
        warn("Alguma verificação falhou. Tentando reparar (reinstalação forçada)...")
        pip_install(vpy, install_dir, ["--force-reinstall", "--no-cache-dir"])
        results = run_selftest(vpy, install_dir)
    libs_ok = print_results(results)

    final_model = ""
    live_msg = "pulado"
    live_ok = None
    if not args.skip_ollama:
        title("OLLAMA E MODELO")
        if remote_url:
            if ollama_up():
                if not any(_same_tag(m["name"], base_model) for m in installed_models()):
                    remote_pull(base_model)
                if any(_same_tag(m["name"], base_model) for m in installed_models()):
                    final_model = base_model  # o prompt da personalidade vai a cada requisicao (nao precisa de modelo proprio)
                    ok(f"Modelo {base_model} disponível no servidor remoto.")
                else:
                    err(f"O modelo {base_model} não está no servidor remoto. Rode no PC:  ollama pull {base_model}")
            else:
                warn("Ollama remoto indisponível: o bot foi instalado, mas só responderá quando ele estiver no ar.")
        else:
            if not ollama_exe:
                ollama_exe = install_ollama()
            if ollama_exe and start_ollama(ollama_exe):
                if not any(_same_tag(m["name"], base_model) for m in installed_models()):
                    if not pull_model(ollama_exe, base_model):
                        err(f"Não consegui baixar {base_model}. Rode o instalador de novo ou use: ollama pull {base_model}")
                if any(_same_tag(m["name"], base_model) for m in installed_models()):
                    final_model = PERSONA_MODEL if create_persona_model(ollama_exe, base_model, persona.system_prompt, num_ctx, install_dir) else base_model
                    size = next((m["size"] for m in installed_models() if _same_tag(m["name"], base_model)), 0.0)
                    if size and not any(_same_tag(base_model, t) for t, _, _ in MODELS):
                        code, label = fit(size, hw, mode)
                        (ok if code in {"gpu", "cpu"} else warn)(f"{base_model} ({size:.1f} GB): {label}")
            else:
                warn("Ollama indisponível: o bot foi instalado, mas só responderá depois que o Ollama estiver rodando.")

    # .env
    env_path = install_dir / ".env"
    if env_text is not None:
        if env_path.exists() and env_path.stat().st_size > 0:
            backup = install_dir / f".env.bak-{datetime.now().strftime('%Y%m%d-%H%M%S')}"
            shutil.copy2(env_path, backup)
            info(f"Cópia de segurança do .env anterior: {backup.name}")
        env_path.write_text(env_text, encoding="utf-8")
        ok("Seu .env pronto foi importado.")
    elif not env_path.exists():
        shutil.copy2(install_dir / ".env.example", env_path)
    for k, v in key_updates.items():
        set_env_key(env_path, k, v)
    if not args.skip_ollama:
        cur_host = read_env(env_path).get("OLLAMA_HOST", "")
        if remote_url:
            set_env_key(env_path, "OLLAMA_HOST", remote_url)
        elif not cur_host or not is_local_url(cur_host):
            set_env_key(env_path, "OLLAMA_HOST", LOCAL_OLLAMA_URL)
    if final_model:
        set_env_key(env_path, "OLLAMA_MODEL", final_model)
        if not remote_url:
            set_env_key(env_path, "OLLAMA_NUM_CTX", str(num_ctx))
    try:
        env_path.chmod(0o600)
    except OSError:
        pass
    ok(".env configurado.")

    # launcher + atalhos
    launcher = write_launcher(install_dir, persona.name)
    shortcut = None
    if not args.no_shortcut:
        old = meta.get("shortcut")
        shortcut = create_shortcut(install_dir, persona.name)
        if shortcut:
            ok(f"Atalhos do Termux:Widget criados em ~/.shortcuts ({Path(shortcut).name})")
            if old and old != shortcut:
                for stale in (Path(old), Path(old).with_name(Path(old).stem + "-parar.sh")):
                    try:
                        stale.unlink()
                    except OSError:
                        pass
        elif IS_TERMUX:
            warn("Não consegui criar os atalhos; use 'bash start.sh' dentro da pasta de instalação.")

    # teste final com o modelo
    if final_model and ollama_up():
        ctx = num_ctx if not remote_url else int(eff_env.get("OLLAMA_NUM_CTX") or 2048)
        live_ok, live_msg = live_test(final_model, persona.system_prompt, ctx)
        (ok if live_ok else warn)(f"Resposta do modelo {live_msg}")

    meta.update({"persona": persona.name, "model": final_model or base_model, "base_model": base_model,
                 "ollama": remote_url or "local", "python": sys.version.split()[0],
                 "shortcut": shortcut or meta.get("shortcut"),
                 "installed_at": datetime.now().isoformat(timespec="seconds")})
    meta_path.write_text(json.dumps(meta, ensure_ascii=False, indent=2), encoding="utf-8")

    # ---------------- Resumo ----------------
    title("RESUMO")
    print(f"  Pasta ............ {install_dir}")
    print(f"  Personalidade .... {persona.name} ({persona_src})")
    print(f"  Bibliotecas ...... {'todas OK' if libs_ok else 'COM FALHAS (veja acima)'}")
    print(f"  Ollama ........... {remote_url or 'neste celular'}")
    print(f"  Modelo ........... {final_model or base_model or '(não configurado)'}")
    fenv = read_env(env_path)
    tg_ok = bool(fenv.get("TELEGRAM_BOT_TOKEN")) and bool(fenv.get("ALLOWED_USER_IDS"))
    print(f"  .env ............. {'importado' if env_text is not None else 'preenchido manualmente'}")
    print(f"  Telegram ......... {'token + ID configurados' if tg_ok else 'FALTA token e/ou ID -> edite o .env (nano .env)'}")
    n_ok = sum(1 for r in key_results if r[1] == "PASSOU")
    n_bad = sum(1 for r in key_results if r[1] == "FALHOU")
    n_warn = sum(1 for r in key_results if r[1] == "AVISO")
    print(f"  Chaves testadas .. {n_ok} OK, {n_bad} com falha, {n_warn} não verificáveis agora (revalide com: bash Instalar_Aether.sh --test-keys)")
    print(f"  Atalho ........... {shortcut or '(não criado)'}")
    print()
    if libs_ok and final_model:
        ok(f"Tudo pronto! Inicie com:  bash {launcher}   (ou 'bash {launcher} silent' para rodar em segundo plano)")
        print("  Dica: desative a otimização de bateria do Termux para o bot não ser fechado com a tela apagada.")
    else:
        warn("Instalação concluída com pendências — rode este instalador novamente depois de resolver os avisos acima.")
    return 0 if libs_ok else 1


if __name__ == "__main__":
    try:
        sys.exit(main())
    except KeyboardInterrupt:
        print("\nCancelado.")
        sys.exit(130)
