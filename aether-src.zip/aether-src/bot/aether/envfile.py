"""Leitura, validacao e gravacao segura do .env para o painel de administracao (sem Telegram aqui).

Principios:
- O que o painel mostra e o que o bot le: o parser e o do python-dotenv (o mesmo do config.py).
- Nenhum valor e salvo sem passar pelas MESMAS regras da partida do bot (`settings_from_getter`), entao o
  painel nao consegue gravar algo que impeca o bot de subir de novo.
- Toda gravacao e atomica (arquivo temporario + os.replace), preserva comentarios/ordem e deixa um
  backup (`.env.panel-bak`) para o botao "Desfazer".
"""
from __future__ import annotations

import io
import os
import re
import shutil
import tempfile
from dataclasses import dataclass
from pathlib import Path

from dotenv import dotenv_values

from .config import BASE_DIR, ConfigError, parse_ids, settings_from_getter

ENV_PATH = BASE_DIR / ".env"
EXAMPLE_PATH = BASE_DIR / ".env.example"
BACKUP_NAME = ".env.panel-bak"

REQUIRED = frozenset({"TELEGRAM_BOT_TOKEN", "ALLOWED_USER_IDS"})
ID_KEYS = frozenset({"ALLOWED_USER_IDS", "ADMIN_USER_IDS"})
BOOL_KEYS = frozenset({"NEXUS_ENABLED", "NEXUS_AUTO_INTENT", "TTS_SEND_TEXT", "TTS_DEFAULT_ON"})
URL_KEYS = frozenset({"OLLAMA_HOST", "NEXUS_URL"})
SECRET_HINTS = ("TOKEN", "KEY", "SECRET", "PASSWORD")

_TRUE = {"1", "true", "yes", "sim", "on"}
_FALSE = {"0", "false", "no", "nao", "não", "off"}
_TOKEN_RE = re.compile(r"^\d{5,}:[A-Za-z0-9_-]{30,}$")
_URL_RE = re.compile(r"^https?://[^\s/]+\S*$", re.I)
_KEY_RE = re.compile(r"^[A-Za-z_][A-Za-z0-9_]*$")
_LINE_KEY_RE = re.compile(r"^\s*(?:export\s+)?([A-Za-z_][A-Za-z0-9_]*)\s*=")
# Caracteres que o python-dotenv, o launcher (grep) e o instalador interpretam de formas diferentes:
# espaco, '#', aspas, barra invertida e '$' (interpolacao). Nenhuma chave legitima precisa deles.
_BAD_CHARS = re.compile(r"[\s#\"'\\$]")


class EnvError(ValueError):
    """Valor recusado. A mensagem ja e legivel para o usuario final."""


@dataclass(frozen=True)
class EnvKey:
    name: str
    value: str            # "" se vazia ou ausente
    in_env: bool          # existe uma linha para ela no .env
    default: str | None   # valor em .env.example (None se a chave nao esta no exemplo)
    help: str             # comentario que antecede a chave no .env.example
    secret: bool

    @property
    def is_new(self) -> bool:
        """No .env.example mas ainda nao no .env (chave que chegou com uma atualizacao)."""
        return self.default is not None and not self.in_env


# --- leitura ---------------------------------------------------------------------------
def is_secret(key: str) -> bool:
    k = key.upper()
    return any(h in k for h in SECRET_HINTS)


def parse_env_text(text: str) -> dict[str, str]:
    vals = dotenv_values(stream=io.StringIO(text.lstrip("\ufeff")))
    return {k: (v or "") for k, v in vals.items()}


def read_env(path: Path | None = None) -> dict[str, str]:
    path = path or ENV_PATH
    try:
        return parse_env_text(path.read_text(encoding="utf-8", errors="replace"))
    except FileNotFoundError:
        return {}


def read_example(path: Path | None = None) -> tuple[dict[str, str], dict[str, str]]:
    """(valores, ajuda) do .env.example, na ordem do arquivo. A ajuda e o bloco de '#' logo acima da chave."""
    path = path or EXAMPLE_PATH
    try:
        text = path.read_text(encoding="utf-8", errors="replace").lstrip("\ufeff")
    except FileNotFoundError:
        return {}, {}
    values = parse_env_text(text)
    helps: dict[str, str] = {}
    buf: list[str] = []
    for raw in text.splitlines():
        line = raw.strip()
        if not line:
            buf = []
        elif line.startswith("#"):
            body = line.lstrip("#").strip()
            if re.match(r"^-{2,}", body):   # cabecalho de secao: "# --- Telegram ---"
                buf = []
            elif body:
                buf.append(body)
        else:
            m = _LINE_KEY_RE.match(line)
            if m:
                helps[m.group(1)] = " ".join(buf)
            buf = []
    return values, helps


def list_keys(env_path: Path | None = None, example_path: Path | None = None) -> list[EnvKey]:
    """Todas as chaves: primeiro as do .env.example (na ordem dele), depois as extras que so existem no .env."""
    env = read_env(env_path)
    ex_vals, ex_help = read_example(example_path)
    out: list[EnvKey] = []
    for name, default in ex_vals.items():
        out.append(EnvKey(name, env.get(name, ""), name in env, default, ex_help.get(name, ""), is_secret(name)))
    for name, value in env.items():
        if name not in ex_vals:
            out.append(EnvKey(name, value, True, None, "", is_secret(name)))
    return out


def mask(key: str, value: str, limit: int = 40) -> str:
    if not value:
        return "(vazio)"
    if is_secret(key):
        return f"{value[:4]}…{value[-2:]}" if len(value) > 12 else "••••"
    return value if len(value) <= limit else value[: limit - 1] + "…"


# --- validacao -------------------------------------------------------------------------
def hint(key: str) -> str:
    if key in ID_KEYS:
        return "IDs numéricos do Telegram separados por vírgula (ex.: 123456789,987654321)"
    if key in BOOL_KEYS:
        return "true ou false"
    if key in URL_KEYS:
        return "endereço completo, ex.: http://127.0.0.1:11434"
    if key == "TELEGRAM_BOT_TOKEN":
        return "token do @BotFather (ex.: 123456789:AAE…)"
    return ""


def prepare_value(key: str, raw: str, *, editor_id: int, current: dict[str, str]) -> str:
    """Normaliza e valida `raw` como novo valor de `key`. Devolve o texto a gravar ou levanta EnvError.

    `current` e o .env atual (dict). `editor_id` e quem esta editando (para nao se trancar para fora).
    """
    if not _KEY_RE.match(key):
        raise EnvError(f"Nome de variável inválido: {key}")
    value = (raw or "").strip()
    if not value and key in REQUIRED:
        raise EnvError(f"{key} é obrigatória e não pode ficar vazia.")

    if value:
        if key in ID_KEYS:
            try:
                ids = parse_ids(value, key)
            except ConfigError as exc:
                raise EnvError(str(exc)) from None
            value = ",".join(str(i) for i in sorted(ids))
        elif key in BOOL_KEYS:
            low = value.lower()
            if low in _TRUE:
                value = "true"
            elif low in _FALSE:
                value = "false"
            else:
                raise EnvError("Use true ou false.")
        elif key in URL_KEYS:
            if not _URL_RE.match(value):
                raise EnvError("Endereço inválido: comece com http:// ou https://")
            value = value.rstrip("/")
        elif key == "TELEGRAM_BOT_TOKEN":
            if not _TOKEN_RE.match(value):
                raise EnvError("Formato de token inválido (esperado algo como 123456789:AAE…).")
        if _BAD_CHARS.search(value):
            raise EnvError("O valor não pode ter espaços, # , aspas, \\ ou $ (o .env interpretaria errado).")

    candidate = {**current, key: value}

    # Trancar o proprio admin para fora seria irreversivel pelo Telegram.
    if key == "ALLOWED_USER_IDS" and editor_id not in parse_ids(value, key):
        raise EnvError("Você ficaria fora da whitelist e perderia o acesso. Inclua seu próprio ID.")
    if key == "ADMIN_USER_IDS" and value:
        ids = parse_ids(value, key)
        if editor_id not in ids:
            raise EnvError("Você ficaria sem acesso de admin. Inclua seu próprio ID.")
        allowed = parse_ids(candidate.get("ALLOWED_USER_IDS", ""), "ALLOWED_USER_IDS")
        outside = sorted(ids - allowed)
        if outside:
            raise EnvError(f"IDs fora da whitelist: {', '.join(map(str, outside))}. Adicione-os antes em ALLOWED_USER_IDS.")

    # Mesmas regras da partida do bot: se isto passa, o bot sobe.
    try:
        settings_from_getter(candidate.get)
    except ConfigError as exc:
        raise EnvError(str(exc)) from None
    return value


# --- gravacao --------------------------------------------------------------------------
def write_env(updates: dict[str, str], path: Path | None = None) -> None:
    """Aplica `updates` ao .env: troca a linha da chave (removendo duplicatas) ou acrescenta no fim.

    Mantem comentarios e ordem. Faz backup antes e grava de forma atomica.
    """
    path = path or ENV_PATH
    for k in updates:
        if not _KEY_RE.match(k):
            raise EnvError(f"Nome de variável inválido: {k}")
    try:
        text = path.read_text(encoding="utf-8")
    except FileNotFoundError:
        text = ""
    else:
        backup = path.with_name(BACKUP_NAME)
        shutil.copy2(path, backup)
        _chmod600(backup)

    pending = dict(updates)
    out: list[str] = []
    for line in text.splitlines():
        m = _LINE_KEY_RE.match(line)
        if m and m.group(1) in updates:
            key = m.group(1)
            if key in pending:                  # primeira ocorrencia: substitui
                out.append(f"{key}={pending.pop(key)}")
            continue                            # ocorrencias repetidas: descarta
        out.append(line)
    for key, value in pending.items():
        out.append(f"{key}={value}")
    new_text = "\n".join(out).rstrip("\n") + "\n"

    fd, tmp = tempfile.mkstemp(dir=path.parent, prefix=".env.", suffix=".tmp")
    try:
        with os.fdopen(fd, "w", encoding="utf-8", newline="\n") as fh:
            fh.write(new_text)
        _chmod600(Path(tmp))
        os.replace(tmp, path)
    except OSError:
        try:
            os.unlink(tmp)
        except OSError:
            pass
        raise


def has_backup(path: Path | None = None) -> bool:
    return (path or ENV_PATH).with_name(BACKUP_NAME).is_file()


def restore_backup(path: Path | None = None) -> bool:
    """Volta o .env para o estado anterior a ultima alteracao feita pelo painel."""
    path = path or ENV_PATH
    backup = path.with_name(BACKUP_NAME)
    if not backup.is_file():
        return False
    fd, tmp = tempfile.mkstemp(dir=path.parent, prefix=".env.", suffix=".tmp")
    os.close(fd)
    try:
        shutil.copyfile(backup, tmp)
        _chmod600(Path(tmp))
        os.replace(tmp, path)
    finally:
        try:
            os.unlink(tmp)
        except OSError:
            pass
    return True


def _chmod600(p: Path) -> None:
    try:
        p.chmod(0o600)
    except OSError:
        pass
