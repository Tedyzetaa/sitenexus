"""TTS via Fish Audio (POST /v1/tts) com timeouts explicitos, retry so na fase de conexao e fallback.

Contrato: `TTSClient.synthesize()` ou devolve bytes de audio ou levanta `TTSError`. Quem chama
(handlers.on_text) trata TTSError mandando so o texto: a voz NUNCA derruba a resposta.
"""
from __future__ import annotations

import asyncio
import json
import logging
import os
import re
import shutil
import subprocess
import tempfile
import time
from pathlib import Path

import httpx

from .net import describe_network_error, retry_async

log = logging.getLogger("aether.tts")

_API_URL = "https://api.fish.audio"
# POST /v1/tts so e repetido se a falha foi ANTES de a requisicao chegar (nao gasta credito em dobro).
_CONNECT_PHASE = (httpx.ConnectError, httpx.ConnectTimeout)
# Depois de 401/402/403 (chave, saldo, permissao) nao adianta bater na API a cada mensagem.
_COOLDOWN_S = {401: 600.0, 402: 600.0, 403: 600.0, 429: 60.0}
_MIN_AUDIO_BYTES = 200


class TTSError(RuntimeError):
    pass


class TTSClient:
    def __init__(
        self,
        api_key: str,
        voice_id: str,
        *,
        model: str = "",
        language: str = "pt-BR",
        audio_format: str = "opus",
        timeout_s: float = 60.0,
        connect_timeout_s: float = 5.0,
        transport: httpx.AsyncBaseTransport | None = None,  # so para testes
    ) -> None:
        self._voice_id = voice_id
        self._language = language
        self._format = audio_format
        self._disabled_until = 0.0
        self._disabled_reason = ""
        headers = {"Authorization": f"Bearer {api_key}", "Content-Type": "application/json"}
        if model:  # sem o header a API usa o modelo padrao pago (s2.1-pro)
            headers["model"] = model
        self._http = httpx.AsyncClient(
            base_url=_API_URL,
            headers=headers,
            timeout=httpx.Timeout(connect=connect_timeout_s, read=timeout_s, write=30.0, pool=10.0),
            limits=httpx.Limits(max_connections=4, max_keepalive_connections=1, keepalive_expiry=15.0),
            transport=transport,
        )

    @property
    def cooling_down(self) -> bool:
        return time.monotonic() < self._disabled_until

    def _trip(self, status: int, reason: str) -> None:
        secs = _COOLDOWN_S.get(status)
        if secs:
            self._disabled_until = time.monotonic() + secs
            self._disabled_reason = reason

    async def synthesize(self, text: str) -> bytes:
        if self.cooling_down:
            raise TTSError(f"TTS em pausa ({self._disabled_reason})")
        payload = {"text": text, "reference_id": self._voice_id, "format": self._format, "language": self._language}
        try:
            r = await retry_async(
                lambda: self._http.post("/v1/tts", content=json.dumps(payload)),
                attempts=3, base=0.5, cap=3.0, what="Fish Audio /v1/tts", only=_CONNECT_PHASE,
            )
        except httpx.ConnectError as exc:
            raise TTSError(f"sem conexao com a Fish Audio ({describe_network_error(exc)})") from exc
        except httpx.TimeoutException as exc:
            raise TTSError("tempo esgotado gerando o audio") from exc
        except (httpx.HTTPError, OSError) as exc:
            raise TTSError(f"falha de comunicacao com a Fish Audio: {describe_network_error(exc)}") from exc

        if r.status_code != 200:
            why = {
                401: "chave de API invalida (FISH_API_KEY)",
                402: "sem saldo/plano nao cobre este modelo ou voz (FISH_MODEL)",
                403: "acesso negado a voz ou ao recurso",
                429: "limite de requisicoes atingido",
            }.get(r.status_code)
            if why is None:
                detail = ""
                try:
                    detail = str(r.json().get("message", ""))[:120]
                except (ValueError, AttributeError):
                    pass
                why = f"erro {detail}".strip()
            self._trip(r.status_code, why)
            raise TTSError(f"HTTP {r.status_code}: {why}")
        ctype = r.headers.get("content-type", "")
        data = r.content
        if ctype.startswith(("application/json", "text/")) or len(data) < _MIN_AUDIO_BYTES:
            raise TTSError("a API nao devolveu audio valido")
        return data

    async def aclose(self) -> None:
        await self._http.aclose()


# ----------------------------------------------------------------------------- texto -> fala
_FENCE = re.compile(r"```.*?(```|$)", re.DOTALL)
_LINK = re.compile(r"\[([^\]]+)\]\((?:[^)]+)\)")
_URL = re.compile(r"https?://\S+|www\.\S+")
_MD_MARKS = re.compile(r"(\*\*|__|`|~~)")
_HEADING = re.compile(r"^\s{0,3}#{1,6}\s*", re.MULTILINE)
_BULLET = re.compile(r"^\s*(?:[-*•]|\d+[.)])\s+", re.MULTILINE)
_EMOJI = re.compile(
    "[\U0001F000-\U0001FAFF\U00002600-\U000027BF\U0001F1E6-\U0001F1FF\u200d\ufe0f\u2190-\u21FF\u2B00-\u2BFF]"
)
_SENTENCE_END = re.compile(r"[.!?…](?=\s|$)")


def clean_for_speech(text: str, max_chars: int) -> tuple[str, bool]:
    """Tira o que soaria mal falado (codigo, markdown, links, emojis) e limita o tamanho.

    Devolve (texto, truncado). Texto vazio = nada falavel (ex.: resposta so de codigo).
    """
    t = _FENCE.sub(" ", text or "")
    t = _LINK.sub(r"\1", t)
    t = _URL.sub(" ", t)
    t = _HEADING.sub("", t)
    t = _BULLET.sub("", t)
    t = _MD_MARKS.sub("", t)
    t = _EMOJI.sub("", t)
    t = re.sub(r"[ \t]+", " ", t)
    t = re.sub(r"\s*\n+\s*", ". ", t)  # quebra de linha vira pausa
    t = re.sub(r"([.!?…:;])\s*\.\s", r"\1 ", t).strip(" .") if t.strip() else ""
    if t and t[-1] not in ".!?…":
        t += "."
    if len(t) <= max_chars:
        return t, False
    cut = t[:max_chars]
    ends = [m.end() for m in _SENTENCE_END.finditer(cut)]
    if ends and ends[-1] >= max_chars // 2:
        cut = cut[: ends[-1]]
    else:
        sp = cut.rfind(" ")
        cut = (cut[:sp] if sp > max_chars // 2 else cut).rstrip(",;: ") + "…"
    return cut.strip(), True


# ----------------------------------------------------------------------------- formato do audio
def is_ogg(data: bytes) -> bool:
    return data[:4] == b"OggS"


def _ffmpeg_to_ogg_opus(data: bytes) -> bytes | None:
    exe = shutil.which("ffmpeg")
    if not exe:
        return None
    try:
        p = subprocess.run(
            [exe, "-loglevel", "error", "-i", "pipe:0", "-c:a", "libopus", "-b:a", "32k", "-f", "ogg", "pipe:1"],
            input=data, capture_output=True, timeout=30, check=False,
        )
    except (OSError, subprocess.SubprocessError):
        return None
    return p.stdout if p.returncode == 0 and is_ogg(p.stdout) else None


async def to_voice_note(data: bytes) -> bytes | None:
    """OGG/Opus pronto para send_voice, ou None se nao der (entao use send_audio).

    Thread, nao asyncio.create_subprocess_exec: o SelectorEventLoop do Windows nao suporta subprocessos.
    """
    if is_ogg(data):
        return data
    return await asyncio.to_thread(_ffmpeg_to_ogg_opus, data)


# ----------------------------------------------------------------------------- preferencia por chat
class VoicePrefs:
    """/voz on|off por chat, persistido em JSON (sobrevive a reinicio)."""

    def __init__(self, path: Path, default_on: bool) -> None:
        self._path, self._default = path, default_on
        self._chats: dict[str, bool] = {}
        try:
            raw = json.loads(path.read_text(encoding="utf-8"))
            self._chats = {str(k): bool(v) for k, v in raw.items()}
        except (OSError, ValueError, AttributeError):
            pass

    def enabled(self, chat_id: int) -> bool:
        return self._chats.get(str(chat_id), self._default)

    def set(self, chat_id: int, on: bool) -> None:
        self._chats[str(chat_id)] = on
        try:
            self._path.parent.mkdir(parents=True, exist_ok=True)
            fd, tmp = tempfile.mkstemp(dir=self._path.parent, suffix=".tmp")
            with os.fdopen(fd, "w", encoding="utf-8") as f:
                json.dump(self._chats, f)
            os.replace(tmp, self._path)
        except OSError as exc:
            log.warning("nao consegui salvar a preferencia de voz: %s", exc)
