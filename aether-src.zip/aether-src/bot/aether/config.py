"""Configuracao via .env (python-dotenv) com validacao estrita da whitelist.

v8.0 (notebook i3 / 8 GB, so CPU): padroes mais leves -- contexto 2048, historico de 8 mensagens,
timeouts maiores (CPU gera poucos tokens/s) e consultas de job menos frequentes. Tudo continua
sobrescrevivel pelo .env.
"""
from __future__ import annotations

import os
from dataclasses import dataclass
from pathlib import Path

from dotenv import load_dotenv

BASE_DIR = Path(__file__).resolve().parent.parent


class ConfigError(RuntimeError):
    pass


def parse_ids(raw: str, var: str) -> frozenset[int]:
    ids: set[int] = set()
    for part in (raw or "").replace(";", ",").split(","):
        part = part.strip()
        if not part:
            continue
        # str.isdigit() aceita '²'/'٣' e int() quebra neles com ValueError (fora do try do load_settings)
        if not (part.isascii() and part.isdigit()):
            raise ConfigError(f"{var}: '{part}' nao e um ID numerico valido do Telegram.")
        ids.add(int(part))
    return frozenset(ids)


def _bool(raw: str | None, default: bool) -> bool:
    if raw is None or raw.strip() == "":
        return default
    return raw.strip().lower() in {"1", "true", "yes", "sim", "on"}


def _pos(raw: str | None, default: float, var: str) -> float:
    """Float estritamente positivo (timeout 0 ou negativo viraria espera infinita/erro obscuro)."""
    if raw is None or raw.strip() == "":
        return float(default)
    try:
        val = float(raw)
    except ValueError:
        raise ConfigError(f"{var}: '{raw}' nao e um numero valido.") from None
    if not (0 < val < float("inf")):  # rejeita 0, negativos, 'nan' e 'inf' (nan <= 0 e False e passava)
        raise ConfigError(f"{var}: precisa ser um numero finito maior que zero (recebido {raw}).")
    return val


@dataclass(frozen=True)
class Settings:
    telegram_token: str
    allowed_user_ids: frozenset[int]
    admin_user_ids: frozenset[int]

    ollama_host: str
    ollama_model: str
    ollama_temperature: float
    ollama_num_ctx: int
    ollama_keep_alive: str
    ollama_timeout_s: float
    history_max_messages: int

    nexus_enabled: bool
    nexus_url: str
    nexus_token: str
    nexus_timeout_s: float
    nexus_auto_intent: bool

    # Timeouts explicitos (segundos). Nada de espera infinita.
    http_connect_timeout_s: float
    telegram_connect_timeout_s: float
    telegram_read_timeout_s: float
    telegram_write_timeout_s: float
    telegram_pool_timeout_s: float
    telegram_poll_timeout_s: int

    data_dir: Path

    # TTS (Fish Audio). Desligado se FISH_API_KEY ou FISH_VOICE_ID estiverem vazios.
    fish_api_key: str = ""
    fish_voice_id: str = ""
    fish_model: str = ""
    fish_language: str = "pt-BR"
    fish_format: str = "opus"
    tts_timeout_s: float = 60.0
    tts_max_chars: int = 500
    tts_send_text: bool = True
    tts_default_on: bool = True

    # Comando /video: intervalo de consulta do job no Nexus e espera maxima total (fila do Kaggle +
    # instalacao/download na 1a vez + geracao).
    video_poll_interval_s: float = 5.0
    video_max_wait_s: float = 3600.0

    # Comando /code (OpenHands via Nexus): intervalo de consulta e espera maxima.
    code_poll_interval_s: float = 4.0
    code_max_wait_s: float = 1800.0

    @property
    def tts_enabled(self) -> bool:
        return bool(self.fish_api_key and self.fish_voice_id)


def load_settings(env_file: Path | None = None) -> Settings:
    load_dotenv(env_file or (BASE_DIR / ".env"))
    return settings_from_getter(os.environ.get)


def settings_from_getter(g) -> Settings:
    """Monta e valida o Settings a partir de qualquer `g(chave, padrao=None)` (os.environ.get, dict.get...).

    O painel de admin usa isto para testar um .env candidato com as MESMAS regras da partida do bot,
    sem tocar em os.environ.
    """
    token = (g("TELEGRAM_BOT_TOKEN") or "").strip()
    if not token:
        raise ConfigError("TELEGRAM_BOT_TOKEN ausente no .env.")

    allowed = parse_ids(g("ALLOWED_USER_IDS", ""), "ALLOWED_USER_IDS")
    if not allowed:
        # Whitelist vazia nunca pode significar "todos": o bot recusa iniciar.
        raise ConfigError("ALLOWED_USER_IDS vazio: defina ao menos um ID. O bot nao inicia sem whitelist.")

    admins = parse_ids(g("ADMIN_USER_IDS", ""), "ADMIN_USER_IDS") or allowed
    admins = admins & allowed  # admin so existe dentro da whitelist

    try:
        return Settings(
            telegram_token=token,
            allowed_user_ids=allowed,
            admin_user_ids=admins,
            ollama_host=(g("OLLAMA_HOST") or "http://127.0.0.1:11434").rstrip("/"),
            ollama_model=(g("OLLAMA_MODEL") or "aether-persona").strip(),
            ollama_temperature=float(g("OLLAMA_TEMPERATURE") or 0.8),
            ollama_num_ctx=int(g("OLLAMA_NUM_CTX") or 2048),
            ollama_keep_alive=(g("OLLAMA_KEEP_ALIVE") or "2m").strip(),
            ollama_timeout_s=_pos(g("OLLAMA_TIMEOUT_S"), 600, "OLLAMA_TIMEOUT_S"),
            history_max_messages=max(2, int(g("HISTORY_MAX_MESSAGES") or 8)),
            nexus_enabled=_bool(g("NEXUS_ENABLED"), False),
            nexus_url=(g("NEXUS_URL") or "http://127.0.0.1:1666").rstrip("/"),
            nexus_token=(g("NEXUS_TOKEN") or "").strip(),
            nexus_timeout_s=_pos(g("NEXUS_TIMEOUT_S"), 600, "NEXUS_TIMEOUT_S"),
            nexus_auto_intent=_bool(g("NEXUS_AUTO_INTENT"), False),
            http_connect_timeout_s=_pos(g("HTTP_CONNECT_TIMEOUT_S"), 5.0, "HTTP_CONNECT_TIMEOUT_S"),
            telegram_connect_timeout_s=_pos(g("TELEGRAM_CONNECT_TIMEOUT_S"), 10.0, "TELEGRAM_CONNECT_TIMEOUT_S"),
            telegram_read_timeout_s=_pos(g("TELEGRAM_READ_TIMEOUT_S"), 20.0, "TELEGRAM_READ_TIMEOUT_S"),
            telegram_write_timeout_s=_pos(g("TELEGRAM_WRITE_TIMEOUT_S"), 30.0, "TELEGRAM_WRITE_TIMEOUT_S"),
            telegram_pool_timeout_s=_pos(g("TELEGRAM_POOL_TIMEOUT_S"), 10.0, "TELEGRAM_POOL_TIMEOUT_S"),
            telegram_poll_timeout_s=int(_pos(g("TELEGRAM_POLL_TIMEOUT_S"), 30, "TELEGRAM_POLL_TIMEOUT_S")),
            data_dir=BASE_DIR / "data",
            fish_api_key=(g("FISH_API_KEY") or "").strip(),
            fish_voice_id=(g("FISH_VOICE_ID") or "").strip(),
            fish_model=(g("FISH_MODEL") or "").strip(),
            fish_language=(g("FISH_LANGUAGE") or "pt-BR").strip(),
            fish_format=(g("FISH_FORMAT") or "opus").strip(),
            tts_timeout_s=_pos(g("TTS_TIMEOUT_S"), 60, "TTS_TIMEOUT_S"),
            tts_max_chars=max(50, int(g("TTS_MAX_CHARS") or 500)),
            tts_send_text=_bool(g("TTS_SEND_TEXT"), True),
            tts_default_on=_bool(g("TTS_DEFAULT_ON"), True),
            video_poll_interval_s=_pos(g("VIDEO_POLL_INTERVAL_S"), 10, "VIDEO_POLL_INTERVAL_S"),
            video_max_wait_s=_pos(g("VIDEO_MAX_WAIT_S"), 3600, "VIDEO_MAX_WAIT_S"),
            code_poll_interval_s=_pos(g("CODE_POLL_INTERVAL_S"), 8, "CODE_POLL_INTERVAL_S"),
            code_max_wait_s=_pos(g("CODE_MAX_WAIT_S"), 1800, "CODE_MAX_WAIT_S"),
        )
    except ValueError as exc:
        raise ConfigError(f"Valor numerico invalido no .env: {exc}") from exc
