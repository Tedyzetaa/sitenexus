"""Resiliencia de rede: politica do loop (Windows), classificacao de erros e retry com backoff.

Tudo que e especifico de "a rede caiu / o DNS falhou / o socket foi resetado" vive aqui, para que
app.py, handlers.py, ollama_client.py e nexus.py compartilhem a mesma definicao de erro transitorio.
"""
from __future__ import annotations

import asyncio
import errno
import logging
import random
import socket
import sys
import time
from typing import Awaitable, Callable, TypeVar

import httpx
from telegram.error import BadRequest, NetworkError, TimedOut

log = logging.getLogger("aether.net")

T = TypeVar("T")

# Erros de rede "de verdade": a causa e a conexao, nao o codigo. Todos sao transitorios.
# - socket.gaierror      -> getaddrinfo failed (WinError 11001), DNS fora do ar
# - ConnectionError      -> engloba ConnectionResetError (10054) e ConnectionAbortedError (10053)
# - TimeoutError         -> timeouts de socket (socket.timeout e alias)
# - httpx.TransportError -> ConnectError, ReadError, WriteError, ConnectTimeout, PoolTimeout...
# - telegram.error.NetworkError (e TimedOut, que herda dela)
# OSError generico NAO entra aqui (FileNotFoundError/PermissionError sao bugs, nao rede):
# so os codigos de errno/winerror de rede abaixo.
NETWORK_EXCEPTIONS: tuple[type[BaseException], ...] = (
    NetworkError,
    TimedOut,
    httpx.TransportError,
    httpx.TimeoutException,
    socket.gaierror,
    ConnectionError,
    TimeoutError,
)

# No PTB, BadRequest HERDA de NetworkError, mas e erro permanente (HTML invalido, mensagem longa
# demais, botao velho): nunca repetir nem tratar como queda de rede.
_NEVER_NETWORK: tuple[type[BaseException], ...] = (BadRequest,)

_NETWORK_ERRNOS = frozenset(
    getattr(errno, n) for n in (
        "ENETUNREACH", "EHOSTUNREACH", "ENETDOWN", "ENETRESET", "ECONNREFUSED", "ECONNRESET",
        "ECONNABORTED", "ETIMEDOUT", "EPIPE", "EHOSTDOWN",
    ) if hasattr(errno, n)
)
# Winsock: 10050 rede fora, 10051 rede inalcancavel, 10053 abortada, 10054 reset, 10060 timeout,
# 10061 recusada, 10065 host inalcancavel, 11001 host nao encontrado (getaddrinfo), 11002/11004 DNS.
_NETWORK_WINERRORS = frozenset({10050, 10051, 10052, 10053, 10054, 10057, 10060, 10061, 10064, 10065, 11001, 11002, 11004})


def _is_network_oserror(exc: BaseException) -> bool:
    if not isinstance(exc, OSError):
        return False
    return getattr(exc, "winerror", None) in _NETWORK_WINERRORS or exc.errno in _NETWORK_ERRNOS


def is_network_error(exc: BaseException | None) -> bool:
    """True se `exc` (ou uma causa explicita `raise ... from`) e uma falha transitoria de rede.

    So segue `__cause__` (encadeamento explicito, como o PTB e o httpx fazem). `__context__` implicito
    ficou de fora de proposito: um bug real levantado dentro de um `except` de rede nao pode ser
    classificado como rede e engolido.
    """
    seen: set[int] = set()
    while exc is not None and id(exc) not in seen:
        seen.add(id(exc))
        if isinstance(exc, _NEVER_NETWORK):
            return False
        if isinstance(exc, NETWORK_EXCEPTIONS) or _is_network_oserror(exc):
            return True
        exc = exc.__cause__
    return False


def describe_network_error(exc: BaseException) -> str:
    """Resumo de uma linha, sem traceback e sem URL (a URL da API do Telegram contem o token)."""
    cur: BaseException | None = exc
    seen: set[int] = set()
    while cur is not None and id(cur) not in seen:
        seen.add(id(cur))
        if isinstance(cur, socket.gaierror):
            return "falha de DNS (getaddrinfo) - sem internet ou DNS indisponivel"
        if isinstance(cur, ConnectionResetError):
            return "conexao reiniciada pelo servidor (reset)"
        if isinstance(cur, ConnectionAbortedError):
            return "conexao abortada localmente"
        if isinstance(cur, httpx.ConnectError):
            return "nao foi possivel conectar (servidor offline ou sem rede)"
        if isinstance(cur, (httpx.TimeoutException, TimedOut, TimeoutError)):
            return "tempo esgotado"
        cur = cur.__cause__
    return type(exc).__name__


def configure_event_loop_policy() -> None:
    """Windows: troca o ProactorEventLoop pelo SelectorEventLoop.

    O Proactor gera `ConnectionResetError [WinError 10054]` / `ConnectionAbortedError [WinError 10053]`
    em `_ProactorBasePipeTransport._call_connection_lost` quando o peer derruba o socket, e esses
    erros aparecem como "Exception in callback" no log. O Selector nao tem esse problema.
    Deve ser chamado ANTES de criar o loop (antes de run_polling/asyncio.run).
    """
    if sys.platform == "win32":
        asyncio.set_event_loop_policy(asyncio.WindowsSelectorEventLoopPolicy())


def install_loop_exception_filter(loop: asyncio.AbstractEventLoop) -> None:
    """Rede de seguranca: erros de socket que escapam em callbacks viram 1 linha de WARNING."""
    default = loop.get_exception_handler()

    def handler(lp: asyncio.AbstractEventLoop, ctx: dict) -> None:
        exc = ctx.get("exception")
        if exc is not None and isinstance(exc, (ConnectionError, socket.gaierror)):
            log.warning("erro de socket ignorado no loop (%s): %s", describe_network_error(exc), ctx.get("message", ""))
            return
        if default is not None:
            default(lp, ctx)
        else:
            lp.default_exception_handler(ctx)

    loop.set_exception_handler(handler)


class LogThrottle:
    """Deixa passar no maximo 1 log por chave a cada `interval` s e conta o que foi suprimido.

    Numa queda longa de internet o polling falha dezenas de vezes: sem isso o log vira spam.
    """

    def __init__(self, interval: float = 30.0, clock: Callable[[], float] = time.monotonic) -> None:
        self._interval, self._clock = interval, clock
        self._last: dict[str, float] = {}
        self._skipped: dict[str, int] = {}

    def hit(self, key: str) -> int | None:
        """None = suprimir este log; int = pode logar (valor = quantas repeticoes foram suprimidas antes)."""
        now = self._clock()
        last = self._last.get(key)
        if last is not None and now - last < self._interval:
            self._skipped[key] = self._skipped.get(key, 0) + 1
            return None
        self._last[key] = now
        return self._skipped.pop(key, 0)

    def reset(self) -> None:
        self._last.clear()
        self._skipped.clear()


class _ReconnectNotice(logging.Filter):
    """Filtro de HANDLER (enxerga registros de todos os loggers filhos, ao contrario de filtro de logger).

    O PTB loga cada retentativa de rede em DEBUG (1 por segundo na partida). Aqui isso vira um unico
    WARNING legivel a cada 30 s. Todo registro `telegram*` abaixo de INFO e descartado: alem de ruido,
    o DEBUG do PTB imprime a URL da API, que contem o TOKEN do bot.
    """

    def __init__(self, interval: float = 30.0) -> None:
        super().__init__()
        self._throttle = LogThrottle(interval)

    def filter(self, record: logging.LogRecord) -> bool:
        if not record.name.startswith("telegram") or record.levelno >= logging.INFO:
            return True
        msg = record.getMessage()
        if "Network Retry Loop" in msg and "Retrying" in msg:
            what = "partida" if "Bootstrap" in msg else "polling"
            n = self._throttle.hit(what)
            if n is not None:
                extra = f" ({n} tentativas desde o ultimo aviso)" if n else ""
                log.warning("Sem conexao com o Telegram (%s); tentando reconectar...%s", what, extra)
        return False


def install_reconnect_notice(interval: float = 30.0) -> None:
    """Chame uma vez no startup, DEPOIS de logging.basicConfig. Idempotente."""
    root = logging.getLogger()
    flt = _ReconnectNotice(interval)
    for handler in root.handlers:
        if not any(isinstance(f, _ReconnectNotice) for f in handler.filters):
            handler.addFilter(flt)
    # O PTB so cria os registros de retry se o logger `telegram.ext` estiver em DEBUG...
    logging.getLogger("telegram.ext").setLevel(logging.DEBUG)
    # ...mas os filhos herdariam DEBUG (e vazariam o token). Trava-os em INFO (defesa em profundidade;
    # a barreira principal e o filtro de handler acima).
    for name, lg in list(logging.root.manager.loggerDict.items()):
        if isinstance(lg, logging.Logger) and name.startswith("telegram.") and lg.level == logging.NOTSET:
            lg.setLevel(logging.INFO)


def backoff_delay(attempt: int, base: float = 1.0, cap: float = 60.0) -> float:
    """Backoff exponencial com jitter: ~1s, 2s, 4s ... ate `cap`."""
    return min(cap, base * (2 ** max(0, attempt))) * (0.8 + 0.4 * random.random())


async def retry_async(
    fn: Callable[[], Awaitable[T]],
    *,
    attempts: int = 3,
    base: float = 0.5,
    cap: float = 5.0,
    what: str = "requisicao",
    only: tuple[type[BaseException], ...] | None = None,
) -> T:
    """Repete `fn` em erro transitorio de rede.

    Use so em operacoes idempotentes, ou passe `only=(httpx.ConnectError, httpx.ConnectTimeout)` para
    repetir apenas falhas de FASE DE CONEXAO (a requisicao nem chegou ao servidor: seguro para POST).
    """
    last: BaseException | None = None
    for i in range(max(1, attempts)):
        try:
            return await fn()
        except asyncio.CancelledError:
            raise
        except Exception as exc:  # noqa: BLE001
            retryable = isinstance(exc, only) if only is not None else is_network_error(exc)
            if not retryable:
                raise
            last = exc
            if i + 1 >= attempts:
                break
            delay = backoff_delay(i, base, cap)
            log.warning(
                "%s falhou (%s); tentativa %d/%d, nova em %.1fs", what, describe_network_error(exc), i + 1, attempts, delay
            )
            await asyncio.sleep(delay)
    assert last is not None
    raise last
