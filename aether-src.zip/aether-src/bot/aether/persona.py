"""Personalidade (persona.json) + estado de runtime editavel pelos administradores."""
from __future__ import annotations

import json
import logging
import os
import tempfile
from dataclasses import dataclass, field
from pathlib import Path

from .rag import Chunk, RagIndex, clip, fold, format_memories

log = logging.getLogger("aether.persona")

# ---------------------------------------------------------------------------------------
#  Personalidade: carregada de persona.json (na raiz do bot). Sem arquivo valido -> Aether.
# ---------------------------------------------------------------------------------------
PERSONA_FILE = Path(__file__).resolve().parent.parent / "persona.json"
MAX_NAME_LEN = 40
MAX_PROMPT_LEN = 12000  # personas do Vision House com Nucleo embutido passam de 8000
MAX_CHUNKS = 1500
MAX_CHUNK_CHARS = 500
MAX_PERSONA_FILE_BYTES = 3 * 1024 * 1024
WARN_PROMPT_LEN = 3000  # contexto padrao e pequeno (2048 tokens): prompt enorme come o historico

DEFAULT_PERSONA_DATA: dict = {
    "name": "Aether",
    "language": "pt-BR",
    "description": (
        "Uma assistente de IA generica, gentil e curiosa, que roda localmente no computador do usuario "
        "e conversa pelo Telegram."
    ),
    "tone": "claro, cordial e direto, com um toque leve de bom humor quando cabe",
    "traits": ["prestativa", "honesta sobre o que nao sabe", "objetiva", "paciente"],
    "rules": [
        "Responda sempre no idioma do usuario.",
        "Seja concisa por padrao e aprofunde apenas quando pedirem.",
        "Se nao souber algo, diga isso em vez de inventar.",
    ],
}


@dataclass(frozen=True)
class Persona:
    name: str
    system_prompt: str
    index: RagIndex | None = None  # lembrancas (Subconsciente) quando o JSON traz chunks/memorias
    stats: dict = field(default_factory=dict)

    @property
    def chunk_count(self) -> int:
        return self.index.n if self.index else 0


def _str_list(value, field_name: str) -> list[str]:
    if value in (None, ""):
        return []
    if isinstance(value, str):
        return [value.strip()] if value.strip() else []
    if isinstance(value, dict):  # traits numericos do Vision House: {"empatia": 70}
        return [f"{k}: {v}/100" if isinstance(v, (int, float)) else f"{k}: {v}" for k, v in value.items()]
    if isinstance(value, list) and all(isinstance(v, str) for v in value):
        return [v.strip() for v in value if v.strip()]
    raise ValueError(f'Campo "{field_name}" deve ser texto ou lista de textos.')


def _first_str(data: dict, *keys: str) -> str | None:
    """Primeiro campo texto nao vazio entre sinonimos (formato Aether / formato Vision House)."""
    for k in keys:
        v = data.get(k)
        if v not in (None, ""):
            if not isinstance(v, str):
                raise ValueError(f'Campo "{k}" deve ser texto.')
            if v.strip():
                return v.strip()
    return None


def _chunk_of(x, i: int) -> Chunk | None:
    if isinstance(x, str):
        return Chunk(f"c{i}", x.strip()) if x.strip() else None
    if not isinstance(x, dict):
        return None
    text = ""
    for k in ("texto", "text", "conteudo", "content", "chunk", "fato_aprendido", "fato", "resumo", "evento"):
        v = x.get(k)
        if isinstance(v, str) and v.strip():
            text = v.strip()
            break
    if not text:
        return None
    topico = str(x.get("topico") or x.get("tópico") or "").strip()
    if topico and not text.lower().startswith(topico.lower()):
        text = f"{topico}: {text}"
    return Chunk(
        id=str(x.get("id") or f"c{i}"),
        text=text,
        area=str(x.get("area") or x.get("área") or "").strip(),
        tema=str(x.get("tema") or x.get("topico") or x.get("tópico") or "").strip(),
        sessao=str(x.get("sessao") or x.get("sessão") or x.get("ano") or x.get("data") or "").strip(),
    )


def _raw_chunks(data: dict) -> list:
    rag = data.get("rag")
    sub = data.get("subconsciente")
    cands = [
        data.get("chunks"), data.get("rag_chunks"), data.get("chunks_jsonl"),
        rag.get("chunks") if isinstance(rag, dict) else rag,
        (sub.get("chunks") or sub.get("rag")) if isinstance(sub, dict) else None,
    ]
    for c in cands:
        if isinstance(c, str) and c.strip():  # JSONL embutido como texto
            try:
                c = [json.loads(line) for line in c.splitlines() if line.strip()]
            except ValueError:
                c = None
        if isinstance(c, list) and c:
            return c
    return []


def persona_from_data(data) -> Persona:
    """Valida um dict (JSON ja carregado) e monta a Persona. Levanta ValueError com mensagem clara.

    Aceita o formato enxuto do Aether (name, description, tone, traits, rules, system_prompt) e o completo exportado
    pelo Vision House (nome, papel, voz, memoria_semantica, memoria_episodica, chunks/rag, afinidades).
    """
    if not isinstance(data, dict):
        raise ValueError("O JSON precisa ser um objeto ( { ... } ) na raiz.")
    if isinstance(data.get("persona"), dict):  # exportacoes embrulhadas em {"persona": {...}}
        data = {**data, **data["persona"]}
    elif isinstance(data.get("personas"), list) and data["personas"] and isinstance(data["personas"][0], dict):
        data = {**data, **data["personas"][0]}

    name = _first_str(data, "name", "nome") or "Aether"
    name = " ".join(name.split())
    if len(name) > MAX_NAME_LEN:
        raise ValueError(f'Campo "name" muito longo (max {MAX_NAME_LEN} caracteres).')

    # lembrancas: chunks do RAG ou, na falta deles, as memorias semantica/episodica
    sem = data.get("memoria_semantica") if isinstance(data.get("memoria_semantica"), list) else []
    epi = data.get("memoria_episodica") if isinstance(data.get("memoria_episodica"), list) else []
    raw = _raw_chunks(data)
    if not raw and (sem or epi):
        raw = list(sem) + [
            {"texto": f"({m['data']}) {m['evento']}"} if isinstance(m, dict) and m.get("data") and m.get("evento") else m
            for m in epi
        ]
    chunks: list[Chunk] = []
    seen: set[str] = set()
    truncated = len(raw) > MAX_CHUNKS
    for i, x in enumerate(raw[: MAX_CHUNKS * 2]):
        c = _chunk_of(x, i)
        if c is None:
            continue
        key = fold(c.text)[:80]
        if key in seen:
            continue
        seen.add(key)
        if len(c.text) > MAX_CHUNK_CHARS:
            c = Chunk(c.id, clip(c.text, MAX_CHUNK_CHARS), c.area, c.tema, c.sessao)
            truncated = True
        chunks.append(c)
    chunks = chunks[:MAX_CHUNKS]

    afin = data.get("afinidades") or data.get("affinities")
    if afin is None and isinstance(data.get("subconsciente"), dict):
        afin = data["subconsciente"].get("afinidades")
    if isinstance(afin, dict):
        afin = list(afin)
    affinities = [str(a.get("tema") or a.get("area") or a.get("nome") or "") if isinstance(a, dict) else str(a)
                  for a in (afin if isinstance(afin, list) else [])][:40]

    prompt = _first_str(data, "system_prompt", "systemPrompt", "prompt")
    if not prompt:
        desc = _first_str(data, "description", "descricao", "descrição", "papel")
        tone = _first_str(data, "tone", "voz", "tom")
        lang = data.get("language")
        if lang is not None and not isinstance(lang, str):
            raise ValueError('Campo "language" deve ser texto.')
        creator = data.get("creator")
        if creator is not None and not isinstance(creator, str):
            raise ValueError('Campo "creator" deve ser texto.')
        traits = _str_list(data.get("traits") if data.get("traits") is not None else data.get("tracos"), "traits")
        rules = _str_list(data.get("rules") if data.get("rules") is not None else data.get("regras"), "rules")
        if not any([desc, tone, traits, rules]) and not chunks:
            raise ValueError('Informe "system_prompt" ou pelo menos um de: description, tone, traits, rules.')
        parts = [f"Você é {name}." + (f" {desc}" if desc else "")]
        if tone:
            parts.append(f"Tom de voz: {tone}.")
        if traits:
            parts.append("Traços de personalidade:\n" + "\n".join(f"- {t}" for t in traits))
        if rules:
            parts.append("Regras de comportamento:\n" + "\n".join(f"- {r}" for r in rules))
        if creator and creator.strip():
            parts.append(f"Seu criador é {creator.strip()}.")
        if lang and lang.strip():
            parts.append(f"Idioma padrão das respostas: {lang.strip()}.")
        prompt = "\n".join(parts)
    if not prompt:
        raise ValueError("O prompt da personalidade ficou vazio.")
    if len(prompt) > MAX_PROMPT_LEN:
        raise ValueError(f"Prompt da personalidade longo demais ({len(prompt)} > {MAX_PROMPT_LEN} caracteres).")
    index = RagIndex(chunks, affinities) if chunks else None
    return Persona(
        name=name, system_prompt=prompt, index=index,
        stats={"chunks": len(chunks), "semantic": len(sem), "episodic": len(epi), "truncated": truncated},
    )


def persona_from_text(raw: str) -> Persona:
    """Texto JSON (arquivo lido ou colado no chat) -> Persona. Levanta ValueError com mensagem clara."""
    try:
        data = json.loads(raw.lstrip("\ufeff"))
    except ValueError as exc:
        raise ValueError(f"JSON invalido: {exc}") from exc
    if isinstance(data, list):
        raise ValueError("Esse arquivo e so uma lista de lembrancas; envie o JSON da persona (com nome e prompt).")
    return persona_from_data(data)


def persona_from_file(path: Path) -> Persona:
    try:
        raw = path.read_text(encoding="utf-8-sig")
    except OSError as exc:
        raise ValueError(f"Nao consegui ler o arquivo: {exc}") from exc
    return persona_from_text(raw)


def load_persona(path: Path = PERSONA_FILE) -> Persona:
    """Nunca levanta: sem arquivo (ou arquivo invalido) cai na Aether padrao."""
    if path.exists():
        try:
            return persona_from_file(path)
        except ValueError as exc:
            log.warning("persona.json invalido (%s); usando a Aether padrao.", exc)
    return persona_from_data(DEFAULT_PERSONA_DATA)


PERSONA = load_persona()
BOT_NAME = PERSONA.name
BASE_SYSTEM_PROMPT = PERSONA.system_prompt

MAX_DIRECTIVES = 20
MAX_DIRECTIVE_LEN = 1000


class RuntimeState:
    """Diretrizes, modelo e temperatura alteraveis em tempo de execucao (persistidos em JSON).

    O prompt base vem do persona.json (lido ao iniciar); diretrizes so ACRESCENTAM instrucoes. A whitelist nunca
    passa por aqui: ela vive apenas no .env e e aplicada como filtro nos handlers.
    """

    def __init__(
        self, path: Path, default_model: str, default_temperature: float, persona_path: Path | None = None
    ) -> None:
        self._path = path
        self._persona_path = persona_path or PERSONA_FILE
        self.directives: list[str] = []
        self.model: str = default_model
        self.temperature: float = default_temperature
        self.rag_enabled: bool = True  # lembrancas dinamicas (Subconsciente) a cada mensagem
        self.persona: Persona = load_persona(self._persona_path)
        self._load()

    # -- persistencia ------------------------------------------------------
    def _load(self) -> None:
        try:
            data = json.loads(self._path.read_text(encoding="utf-8"))
        except FileNotFoundError:
            return
        except (OSError, ValueError) as exc:
            log.warning("runtime.json ilegivel (%s); usando padroes.", exc)
            return
        if not isinstance(data, dict):
            log.warning("runtime.json com formato inesperado; usando padroes.")
            return
        raw_dirs = data.get("directives", [])
        self.directives = [str(d) for d in raw_dirs][:MAX_DIRECTIVES] if isinstance(raw_dirs, list) else []
        self.model = str(data.get("model") or self.model)
        self.rag_enabled = bool(data.get("rag", True))
        try:
            self.temperature = float(data.get("temperature", self.temperature))
        except (TypeError, ValueError):
            pass

    def _save(self) -> None:
        self._path.parent.mkdir(parents=True, exist_ok=True)
        payload = json.dumps(
            {"directives": self.directives, "model": self.model, "temperature": self.temperature, "rag": self.rag_enabled},
            ensure_ascii=False, indent=2,
        )
        fd, tmp = tempfile.mkstemp(dir=self._path.parent, suffix=".tmp")
        try:
            with os.fdopen(fd, "w", encoding="utf-8") as fh:
                fh.write(payload)
            os.replace(tmp, self._path)
        except OSError:
            try:
                os.unlink(tmp)
            except OSError:
                pass
            raise

    # -- diretrizes --------------------------------------------------------
    def add_directive(self, text: str) -> int:
        text = text.strip()
        if not text:
            raise ValueError("Diretriz vazia.")
        if len(text) > MAX_DIRECTIVE_LEN:
            raise ValueError(f"Diretriz longa demais (max {MAX_DIRECTIVE_LEN} caracteres).")
        if len(self.directives) >= MAX_DIRECTIVES:
            raise ValueError(f"Limite de {MAX_DIRECTIVES} diretrizes atingido; remova alguma.")
        self.directives.append(text)
        self._save()
        return len(self.directives)

    def remove_directive(self, number: int) -> str:
        if not 1 <= number <= len(self.directives):
            raise ValueError("Numero de diretriz inexistente.")
        removed = self.directives.pop(number - 1)
        self._save()
        return removed

    def clear_directives(self) -> int:
        n = len(self.directives)
        self.directives = []
        self._save()
        return n

    def set_model(self, name: str) -> None:
        self.model = name.strip()
        self._save()

    def set_temperature(self, value: float) -> None:
        if not 0.0 <= value <= 2.0:
            raise ValueError("Temperatura deve estar entre 0.0 e 2.0.")
        self.temperature = value
        self._save()

    def set_rag_enabled(self, value: bool) -> None:
        self.rag_enabled = bool(value)
        self._save()

    # -- persona (troca em tempo de execucao, sem reiniciar) -----------------
    @property
    def backup_path(self) -> Path:
        return self._persona_path.with_name(self._persona_path.name + ".bak")

    def has_persona_backup(self) -> bool:
        return self.backup_path.exists()

    def _write_text_atomic(self, target: Path, text: str) -> None:
        target.parent.mkdir(parents=True, exist_ok=True)
        fd, tmp = tempfile.mkstemp(dir=target.parent, suffix=".tmp")
        try:
            with os.fdopen(fd, "w", encoding="utf-8", newline="\n") as fh:
                fh.write(text)
            os.replace(tmp, target)
        except OSError:
            try:
                os.unlink(tmp)
            except OSError:
                pass
            raise

    def _backup_current(self) -> None:
        """Guarda o persona.json atual (ou a Aether padrao, se nao houver arquivo) para o botao Desfazer."""
        if self._persona_path.exists():
            try:
                self._write_text_atomic(self.backup_path, self._persona_path.read_text(encoding="utf-8-sig"))
                return
            except OSError as exc:
                log.warning("Nao consegui salvar o backup da persona: %s", exc)
        self._write_text_atomic(self.backup_path, json.dumps(DEFAULT_PERSONA_DATA, ensure_ascii=False, indent=2) + "\n")

    def set_persona_from_text(self, raw: str) -> Persona:
        """Valida o JSON, grava persona.json (com backup) e passa a usar a persona ja na proxima resposta.

        Levanta ValueError (mensagem legivel) e nao muda nada se o JSON for invalido.
        """
        if len(raw.encode("utf-8")) > MAX_PERSONA_FILE_BYTES:
            raise ValueError(f"Arquivo grande demais (max {MAX_PERSONA_FILE_BYTES // 1024 // 1024} MB).")
        persona = persona_from_text(raw)  # valida ANTES de tocar em qualquer arquivo
        data = json.loads(raw.lstrip("\ufeff"))
        try:
            self._backup_current()
            self._write_text_atomic(self._persona_path, json.dumps(data, ensure_ascii=False, indent=2) + "\n")
        except OSError as exc:
            raise ValueError(f"Nao consegui gravar o persona.json: {exc}") from exc
        self.persona = persona
        return persona

    def undo_persona(self) -> Persona:
        """Volta para a persona anterior (a que estava valendo antes da ultima troca)."""
        try:
            raw = self.backup_path.read_text(encoding="utf-8-sig")
        except OSError as exc:
            raise ValueError("Nao ha troca de persona para desfazer.") from exc
        persona = persona_from_text(raw)
        current_ok = self._persona_path.exists()
        try:
            if current_ok:  # troca os dois: Desfazer duas vezes = Refazer
                cur = self._persona_path.read_text(encoding="utf-8-sig")
                self._write_text_atomic(self.backup_path, cur)
            self._write_text_atomic(self._persona_path, raw)
        except OSError as exc:
            raise ValueError(f"Nao consegui restaurar o persona.json: {exc}") from exc
        self.persona = persona
        return persona

    def reset_persona(self) -> Persona:
        """Volta para a Aether padrao (guarda a atual no backup)."""
        try:
            self._backup_current()
            self._persona_path.unlink(missing_ok=True)
        except OSError as exc:
            raise ValueError(f"Nao consegui restaurar a persona padrao: {exc}") from exc
        self.persona = persona_from_data(DEFAULT_PERSONA_DATA)
        return self.persona

    def system_prompt(self, query: str = "") -> str:
        """Prompt do turno: persona + diretrizes + (se `query` casar com alguma) lembrancas do Subconsciente."""
        base = self.persona.system_prompt
        if self.directives:
            extra = "\n".join(f"{i}. {d}" for i, d in enumerate(self.directives, 1))
            base = (
                f"{base}\n\n"
                f"Diretrizes adicionais definidas pelo seu criador (mantenha a identidade acima):\n{extra}"
            )
        if query and self.rag_enabled and self.persona.index:
            mem = format_memories(self.persona.index.retrieve(query))
            if mem:
                base = f"{base}\n\n{mem}"
        return base
