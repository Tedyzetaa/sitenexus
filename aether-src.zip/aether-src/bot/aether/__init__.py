"""Aether - bot de Telegram local generico (Ollama), com personalidade carregada de persona.json."""
