"""Menus interativos (teclados inline): menu principal, ferramentas do Nexus e painel de admin.

Seguranca (mesma regra do resto do bot):
- Comandos ja entram atras de `filters.User(...)`.
- Botoes (callback_query) NAO passam por filtros do PTB, entao `on_callback` confere a whitelist
  e, para o namespace `a:` (admin), a lista de admins. Quem nao pode, nao recebe NADA (nem toast).
  Isso importa em grupos, onde qualquer membro consegue apertar um botao.

Convencao de callback_data (limite do Telegram: 64 bytes):
  m:<tela>            menu principal (main | status | help | reset)
  t:<acao>[:<arg>]    ferramentas (l=lista/pagina, o=abrir, r=executar, a=argumentos, f=pedido livre, u=atualizar)
  a:<acao>[:<args>]   admin (a:env*, a:ev/ee/ed/ex/eu/er/ery = editor de variaveis do .env)
  x:<destino>         cancela uma entrada pendente e volta para a tela
"""
from __future__ import annotations

import asyncio
import contextlib
import html
import logging
import os
import re
import time
import zlib
from dataclasses import dataclass

import httpx
from telegram import InlineKeyboardButton as Btn
from telegram import InlineKeyboardMarkup as Kb
from telegram import Update
from telegram.constants import ParseMode
from telegram.error import BadRequest, NetworkError, TelegramError
from telegram.ext import ApplicationHandlerStop, ContextTypes

from . import envfile
from . import handlers as h
from .nexus import NexusError
from .ollama_client import OllamaError
from .persona import MAX_DIRECTIVE_LEN, MAX_DIRECTIVES, MAX_PERSONA_FILE_BYTES, WARN_PROMPT_LEN

log = logging.getLogger("aether.panel")

PENDING_TTL = 300      # segundos que o bot espera a proxima mensagem (argumentos / diretriz)
TOOLS_TTL = 300        # cache da lista de ferramentas do Nexus
TOOLS_PER_PAGE = 8
MODELS_PER_PAGE = 6
ENV_PER_PAGE = 8
# O launcher (start.sh) religa o bot quando ele sai com qualquer codigo fora de 0/130/143/2.
RESTART_EXIT_CODE = 3

Screen = tuple[str, Kb]


# --- utilidades ----------------------------------------------------------------------
def _esc(value: object) -> str:
    return html.escape(str(value), quote=False)


def _short(text: str, n: int) -> str:
    text = " ".join(text.split())
    return text if len(text) <= n else text[: n - 1] + "…"


def _crc(text: str) -> str:
    """Impressao curta para detectar botao 'velho' (lista mudou desde que o menu foi desenhado)."""
    return format(zlib.crc32(text.encode("utf-8")) & 0xFFFF, "04x")


def _chunk(items: list, size: int) -> list[list]:
    return [items[i : i + size] for i in range(0, len(items), size)]


def _pager(prefix: str, page: int, pages: int) -> list[Btn]:
    row: list[Btn] = []
    if page > 0:
        row.append(Btn("◀️", callback_data=f"{prefix}:{page - 1}"))
    row.append(Btn(f"{page + 1}/{pages}", callback_data="noop"))
    if page < pages - 1:
        row.append(Btn("▶️", callback_data=f"{prefix}:{page + 1}"))
    return row


def _is_admin(deps: h.Deps, user_id: int | None) -> bool:
    return user_id is not None and user_id in deps.settings.admin_user_ids


# --- entrada pendente (proxima mensagem de texto vira argumento/diretriz) ----------------
def _set_pending(context: ContextTypes.DEFAULT_TYPE, kind: str, **data) -> None:
    context.user_data["pending"] = {"kind": kind, "ts": time.monotonic(), **data}


def _clear_pending(context: ContextTypes.DEFAULT_TYPE) -> None:
    context.user_data.pop("pending", None)


# =======================================================================================
#  TELAS
# =======================================================================================
def screen_main(deps: h.Deps, chat_id: int, admin: bool) -> Screen:
    text = (
        f"🤖 <b>{_esc(deps.state.persona.name)}</b> — <i>online</i>\n\n"
        "💬 Escreva qualquer mensagem para conversar.\n"
        "🛠 Use os botões para acionar as ferramentas do Nexus.\n\n"
        f"<code>{_esc(deps.state.model)}</code> · contexto: {deps.history.size(chat_id)} msg"
    )
    rows = [
        [Btn("🛠 Ferramentas", callback_data="t:l:0"), Btn("📊 Status", callback_data="m:status")],
        [Btn("🧹 Limpar contexto", callback_data="m:reset"), Btn("❓ Ajuda", callback_data="m:help")],
    ]
    if deps.tts is not None and deps.voice is not None:
        on = deps.voice.enabled(chat_id)
        rows.append([Btn("🔊 Voz: ligada (desligar)" if on else "🔇 Voz: desligada (ligar)", callback_data="m:voice")])
    if admin:
        rows.append([Btn("⚙️ Painel de administração", callback_data="a:home")])
    return text, Kb(rows)


def screen_help(admin: bool) -> Screen:
    text = (
        "❓ <b>Ajuda</b>\n\n"
        "<b>Conversa</b>\nEnvie qualquer texto. /reset limpa o contexto.\n\n"
        "<b>Comandos</b>\n"
        "/menu — painel principal com botões\n"
        "/ferramentas — ferramentas do Nexus\n"
        "/status — estado do núcleo e da ponte Nexus\n"
        "/voz on|off — respostas em áudio neste chat\n"
        "/nexus &lt;pedido&gt; — aciona o Nexus direto\n"
        "/video &lt;prompt&gt; — gera vídeo; anexe uma imagem (ou responda a uma) como referência\n"
        "Qualquer comando do Nexus também funciona (ex.: <code>/clima Dourados MS</code>)."
    )
    if admin:
        text += (
            "\n\n<b>Administração</b>\n"
            "/admin — painel com botões\n"
            "/env — variáveis do .env (ver e editar)\n"
            "/persona — trocar a personalidade (envie o .json; vale na hora)\n"
            "Atalhos: /diretriz &lt;texto&gt; · /diretrizes · /remover &lt;n&gt; · /limpar_diretrizes · "
            "/sistema · /modelo [nome] · /temperatura [0-2]"
        )
    return text, Kb([[Btn("⬅️ Menu", callback_data="m:main")]])


async def screen_status(deps: h.Deps, chat_id: int) -> Screen:
    body = await h.build_status(deps, chat_id)
    text = f"📊 <b>Status</b>\n\n{_esc(body)}"
    return text, Kb([[Btn("🔄 Atualizar", callback_data="m:status"), Btn("⬅️ Menu", callback_data="m:main")]])


# --- Ferramentas ----------------------------------------------------------------------
@dataclass(frozen=True)
class Tool:
    name: str
    desc: str = ""
    usage: str = ""   # trecho de argumentos, ex.: "<local>" ou "[min] [horas]"


_TOOL_EMOJI = {
    "sismo": "🌋", "terremoto": "🌋", "clima": "🌦", "tempo": "🌦", "noaa": "🛰", "nasa": "🚀",
    "imagem": "🖼", "video": "🎬", "audio": "🎧", "dublagem": "🎙", "rag": "📚", "busca": "🔎",
}
# So usado se o Nexus nao devolver nada parseavel (nomes vindos dos exemplos do README).
_FALLBACK_TOOLS = (
    Tool("sismo", "Terremotos recentes", "[forte] [mag]"),
    Tool("clima", "Previsão do tempo", "<cidade UF>"),
    Tool("noaa", "Dados NOAA (ex.: índice Kp)", "[kp]"),
)
_SELF_COMMANDS = {"ferramentas", "ajuda", "help", "start", "menu", "reset", "status", "nexus", "admin", "env", "persona", "cancelar", "video"}
_TOOL_TOKEN = re.compile(r"(?<![\w/:.])/([A-Za-z_]\w{1,30})\b")
_ARG_HINT = re.compile(r"[<\[][^<>\[\]]*[>\]]")
_NAME_OK = re.compile(r"^\w{1,31}$")


def parse_tools(text: str) -> list[Tool]:
    """Extrai ferramentas do texto que o Nexus devolve para /ferramentas.

    Tolerante: aceita qualquer linha com `/comando` (com ou sem bullet/markdown). Se a linha tem
    um unico comando, o resto vira descricao/uso; com varios, cada um entra sem descricao.
    """
    found: dict[str, Tool] = {}
    for raw in (text or "").splitlines():
        line = re.sub(r"[*`_]", "", raw)
        matches = list(_TOOL_TOKEN.finditer(line))
        if not matches:
            continue
        if len(matches) == 1:
            m = matches[0]
            name = m.group(1).lower()
            rest = line[m.end():]
            usage = " ".join(_ARG_HINT.findall(rest))
            desc = _ARG_HINT.sub("", rest).strip(" -–—:·•|\t")
            cand = [Tool(name, _short(desc, 200), usage)]
        else:
            cand = [Tool(m.group(1).lower()) for m in matches]
        for t in cand:
            if t.name not in _SELF_COMMANDS and t.name not in found:
                found[t.name] = t
    return list(found.values())


async def _load_tools(deps: h.Deps, force: bool = False) -> tuple[list[Tool], bool]:
    """(ferramentas, veio_do_fallback). Levanta NexusError se o Nexus estiver fora."""
    cached = deps.cache.get("tools")
    if cached and not force and time.monotonic() - cached[0] < TOOLS_TTL:
        return cached[1], cached[2]
    reply = await deps.nexus.dispatch_request("/ferramentas")  # type: ignore[union-attr]
    tools = parse_tools(reply.text) if reply.handled else []
    fallback = not tools
    if fallback:
        tools = list(_FALLBACK_TOOLS)
    deps.cache["tools"] = (time.monotonic(), tools, fallback)
    return tools, fallback


async def screen_tools(deps: h.Deps, page: int = 0, force: bool = False) -> Screen:
    back = [Btn("⬅️ Menu", callback_data="m:main")]
    if deps.nexus is None:
        return "🛠 <b>Ferramentas</b>\n\nPonte Nexus desativada (<code>NEXUS_ENABLED=false</code>).", Kb([back])
    try:
        tools, fallback = await _load_tools(deps, force)
    except NexusError as exc:
        text = f"🛠 <b>Ferramentas</b>\n\n⚠️ {_esc(exc)}"
        return text, Kb([[Btn("🔄 Tentar de novo", callback_data="t:u")], back])

    pages = max(1, -(-len(tools) // TOOLS_PER_PAGE))
    page = min(max(page, 0), pages - 1)
    chunk = tools[page * TOOLS_PER_PAGE : (page + 1) * TOOLS_PER_PAGE]
    buttons = [
        Btn(f"{_TOOL_EMOJI.get(t.name, '🔧')} /{t.name}", callback_data=f"t:o:{t.name}") for t in chunk
    ]
    rows = _chunk(buttons, 2)
    if pages > 1:
        rows.append(_pager("t:l", page, pages))
    rows.append([Btn("✍️ Pedido livre", callback_data="t:f"), Btn("🔄 Atualizar", callback_data="t:u")])
    rows.append(back)

    text = f"🛠 <b>Ferramentas do Nexus</b> — {len(tools)} disponível(is)\nToque numa ferramenta para abrir."
    if fallback:
        text += "\n\n<i>Não consegui ler a lista do Nexus; mostrando atalhos básicos. Use ✍️ Pedido livre para o resto.</i>"
    return text, Kb(rows)


async def screen_tool_card(deps: h.Deps, name: str) -> Screen:
    tool = None
    with contextlib.suppress(NexusError):
        tools, _ = await _load_tools(deps)
        tool = next((t for t in tools if t.name == name), None)
    tool = tool or Tool(name)
    emoji = _TOOL_EMOJI.get(name, "🔧")
    lines = [f"{emoji} <b>/{_esc(name)}</b>"]
    if tool.desc:
        lines.append(_esc(tool.desc))
    if tool.usage:
        lines.append(f"\n<b>Uso:</b> <code>/{_esc(name)} {_esc(tool.usage)}</code>")
    needs_args = "<" in tool.usage
    run = Btn("▶️ Executar", callback_data=f"t:r:{name}")
    args = Btn("✍️ Com argumentos", callback_data=f"t:a:{name}")
    rows = [[args, run] if needs_args else [run, args], [Btn("⬅️ Ferramentas", callback_data="t:l:0")]]
    return "\n".join(lines), Kb(rows)


# --- Admin ------------------------------------------------------------------------------
def screen_admin(deps: h.Deps, chat_id: int) -> Screen:
    st, cfg = deps.state, deps.settings
    text = (
        "⚙️ <b>Painel de administração</b>\n\n"
        f"🤖 Modelo: <code>{_esc(st.model)}</code>\n"
        f"🌡 Temperatura: <b>{st.temperature}</b>\n"
        f"🎭 Persona: <b>{_esc(st.persona.name)}</b>"
        f"{f' · {st.persona.chunk_count} lembranças' if st.persona.chunk_count else ''}\n"
        f"📜 Diretrizes: <b>{len(st.directives)}</b>/{MAX_DIRECTIVES}\n"
        f"💬 Contexto deste chat: {deps.history.size(chat_id)} msg\n"
        f"🔗 Nexus: {'ativado' if deps.nexus else 'desativado'}"
        f"{' · auto-intent' if deps.nexus and cfg.nexus_auto_intent else ''}\n"
        f"👥 Whitelist: {len(cfg.allowed_user_ids)} · Admins: {len(cfg.admin_user_ids)}"
    )
    rows = [
        [Btn("🤖 Modelo", callback_data="a:model:0"), Btn("🌡 Temperatura", callback_data="a:temp")],
        [Btn("📜 Diretrizes", callback_data="a:dirs"), Btn("➕ Nova diretriz", callback_data="a:new")],
        [Btn("🎭 Persona (trocar .json)", callback_data="a:pers")],
        [Btn("🧠 Prompt do sistema", callback_data="a:prompt"), Btn("📊 Status", callback_data="a:status")],
        [Btn("🔐 Variáveis (.env)", callback_data="a:env:0")],
        [Btn("🧹 Limpar contexto", callback_data="a:reset"), Btn("⬅️ Menu", callback_data="m:main")],
    ]
    return text, Kb(rows)


async def screen_models(deps: h.Deps, page: int = 0) -> Screen:
    back = [Btn("⬅️ Admin", callback_data="a:home")]
    try:
        models = await deps.ollama.list_models()
    except OllamaError as exc:
        return f"🤖 <b>Modelo</b>\n\n⚠️ {_esc(exc)}", Kb([[Btn("🔄 Tentar de novo", callback_data="a:model:0")], back])
    if not models:
        return "🤖 <b>Modelo</b>\n\nNenhum modelo instalado no Ollama.", Kb([back])

    pages = max(1, -(-len(models) // MODELS_PER_PAGE))
    page = min(max(page, 0), pages - 1)
    start = page * MODELS_PER_PAGE
    rows = []
    for i, name in enumerate(models[start : start + MODELS_PER_PAGE], start):
        mark = "✅ " if name == deps.state.model else ""
        rows.append([Btn(_short(f"{mark}{name}", 40), callback_data=f"a:ms:{i}:{_crc(name)}")])
    if pages > 1:
        rows.append(_pager("a:model", page, pages))
    rows.append(back)
    text = f"🤖 <b>Modelo ativo</b>\n<code>{_esc(deps.state.model)}</code>\n\nToque para trocar (vale já na próxima resposta)."
    if deps.state.model not in models:
        text += "\n\n⚠️ <i>O modelo atual não foi encontrado no Ollama.</i>"
    return text, Kb(rows)


_TEMP_PRESETS = (0.2, 0.5, 0.8, 1.0, 1.2, 1.5)


def screen_temp(deps: h.Deps) -> Screen:
    cur = deps.state.temperature
    presets = [
        Btn(f"● {v}" if abs(v - cur) < 1e-9 else f"{v}", callback_data=f"a:ts:{v}") for v in _TEMP_PRESETS
    ]
    rows = _chunk(presets, 3)
    rows.append([Btn("➖ 0.1", callback_data="a:td:-1"), Btn("➕ 0.1", callback_data="a:td:1")])
    rows.append([Btn("⬅️ Admin", callback_data="a:home")])
    text = (
        f"🌡 <b>Temperatura:</b> {cur}\n\n"
        "<i>Baixa (0.2) = respostas precisas e previsíveis.\n"
        "Alta (1.5) = mais criativo e imprevisível. Máx. 2.0.</i>"
    )
    return text, Kb(rows)


def screen_dirs(deps: h.Deps) -> Screen:
    ds = deps.state.directives
    head = f"📜 <b>Diretrizes</b> ({len(ds)}/{MAX_DIRECTIVES})"
    if ds:
        body = "\n".join(f"<b>{i}.</b> {_esc(_short(d, 140))}" for i, d in enumerate(ds, 1))
        head += "\nToque em 🗑 para remover uma."
    else:
        body = "<i>Nenhuma diretriz adicional ativa.</i>"
    rows = _chunk([Btn(f"🗑 {i}", callback_data=f"a:dd:{i}:{_crc(d)}") for i, d in enumerate(ds, 1)], 5)
    actions = [Btn("➕ Nova", callback_data="a:new")]
    if ds:
        actions.append(Btn("🧨 Limpar todas", callback_data="a:dc"))
    rows.append(actions)
    rows.append([Btn("⬅️ Admin", callback_data="a:home")])
    return f"{head}\n\n{body}", Kb(rows)


# --- Persona (trocar o JSON pelo Telegram) -----------------------------------------------
def screen_persona(deps: h.Deps, notice: str = "") -> Screen:
    st = deps.state
    p = st.persona
    lines = []
    if notice:
        lines.append(notice + "\n")
    lines.append(f"🎭 <b>Persona ativa: {_esc(p.name)}</b>")
    lines.append(f"Prompt: {len(p.system_prompt)} caracteres")
    if p.chunk_count:
        lines.append(
            f"🧠 Lembranças: <b>{p.chunk_count}</b> · busca a cada mensagem: <b>{'ligada' if st.rag_enabled else 'desligada'}</b>"
        )
    else:
        lines.append("🧠 Sem lembranças (só o prompt).")
    lines.append("\nToque em <b>Enviar JSON</b> e mande o arquivo da persona (Vision House com Subconsciente ou persona.json do Aether). "
                 "Vale já na próxima resposta; não precisa reiniciar.")
    rows = [[Btn("📥 Enviar JSON da persona", callback_data="a:pup")]]
    row2 = []
    if p.chunk_count:
        row2.append(Btn("🧠 Lembranças: desligar" if st.rag_enabled else "🧠 Lembranças: ligar", callback_data="a:prag"))
    row2.append(Btn("📄 Ver prompt", callback_data="a:prompt"))
    rows.append(row2)
    row3 = []
    if st.has_persona_backup():
        row3.append(Btn("↩️ Desfazer última troca", callback_data="a:pun"))
    row3.append(Btn("♻️ Voltar à Aether padrão", callback_data="a:prs"))
    rows.append(row3)
    rows.append([Btn("⬅️ Admin", callback_data="a:home")])
    return "\n".join(lines), Kb(rows)


def screen_persona_upload() -> Screen:
    text = (
        "📥 <b>Enviar persona</b>\n\nMande o arquivo <b>.json</b> como <b>documento</b> na <b>próxima mensagem</b> "
        f"(até {MAX_PERSONA_FILE_BYTES // 1024 // 1024} MB). Também aceito o JSON colado como texto, se for curto.\n"
        "<i>Dica: se o seu app do Telegram mostrar o arquivo como texto, envie como “arquivo”, não como mídia.</i>"
    )
    return text, Kb([[Btn("❌ Cancelar", callback_data="x:pers")]])


def screen_persona_reset_confirm(deps: h.Deps) -> Screen:
    text = (
        f"♻️ <b>Voltar à Aether padrão?</b>\nA persona <b>{_esc(deps.state.persona.name)}</b> sai de uso "
        "(fica guardada no botão Desfazer)."
    )
    return text, Kb([[Btn("✅ Sim, voltar", callback_data="a:prsy"), Btn("❌ Cancelar", callback_data="a:pers")]])


def _persona_applied_text(p, verb: str = "ativada") -> str:
    out = f"✅ Persona <b>{_esc(p.name)}</b> {verb}."
    if p.chunk_count:
        out += f"\n🧠 {p.chunk_count} lembranças para busca"
        if p.stats.get("truncated"):
            out += " (algumas foram cortadas para caber)"
        out += "."
    if len(p.system_prompt) > WARN_PROMPT_LEN:
        out += (
            f"\n⚠️ O prompt tem {len(p.system_prompt)} caracteres; com o contexto padrão do Ollama (2048) "
            "ele ocupa bastante espaço do histórico. Se as respostas ficarem esquecidas, aumente OLLAMA_NUM_CTX no /env."
        )
    out += "\n\nDica: use 🧹 Limpar contexto para a conversa começar já com a nova persona."
    return out


def screen_confirm_clear(deps: h.Deps) -> Screen:
    n = len(deps.state.directives)
    text = f"🧨 <b>Remover as {n} diretriz(es)?</b>\nEsta ação não pode ser desfeita."
    rows = [[Btn("✅ Sim, limpar", callback_data="a:dcy"), Btn("❌ Cancelar", callback_data="a:dirs")]]
    return text, Kb(rows)


# --- Variaveis de ambiente (.env) -------------------------------------------------------
def _supervised() -> bool:
    """True se o bot roda sob o launcher (start.sh/start.bat exportam AETHER_SUPERVISED e religam o processo)."""
    return bool(os.environ.get("AETHER_SUPERVISED"))


def _env_resolve(idx_s: str, crc: str) -> tuple[int, envfile.EnvKey] | None:
    """(indice, chave) se o botao ainda aponta para a mesma chave; None se a lista mudou."""
    keys = envfile.list_keys()
    if idx_s.isdigit() and int(idx_s) < len(keys) and _crc(keys[int(idx_s)].name) == crc:
        return int(idx_s), keys[int(idx_s)]
    return None


def screen_env(deps: h.Deps, page: int = 0, notice: str = "") -> Screen:
    keys = envfile.list_keys()
    pages = max(1, -(-len(keys) // ENV_PER_PAGE))
    page = min(max(page, 0), pages - 1)
    start = page * ENV_PER_PAGE
    chunk = keys[start : start + ENV_PER_PAGE]
    new = sum(1 for k in keys if k.is_new)

    head = f"🔐 <b>Variáveis de ambiente</b> — {len(keys)} chaves"
    if new:
        head += f" · 🆕 {new} nova(s)"
    parts = []
    if notice:
        parts.append(notice)
    if deps.cache.get("env_dirty"):
        parts.append("⚠️ <b>Alterações pendentes</b> — reinicie o bot para aplicar.")
    parts.append(head)
    lines = []
    for k in chunk:
        mark = "🆕" if k.is_new else ("🔒" if k.secret else "▫️")
        val = "<i>(padrão do bot)</i>" if k.is_new else f"<code>{_esc(envfile.mask(k.name, k.value))}</code>"
        lines.append(f"{mark} <code>{_esc(k.name)}</code> = {val}")
    parts.append("\n".join(lines) if lines else "<i>Nenhuma variável encontrada.</i>")
    parts.append("<i>Toque numa chave para ver ou alterar. Segredos aparecem mascarados.</i>")

    buttons = [
        Btn(_short(f"{'🆕 ' if k.is_new else ''}{k.name}", 30), callback_data=f"a:ev:{start + i}:{_crc(k.name)}")
        for i, k in enumerate(chunk)
    ]
    rows = _chunk(buttons, 2)
    if pages > 1:
        rows.append(_pager("a:env", page, pages))
    tools = [Btn("🔄 Reiniciar bot", callback_data="a:er")]
    if envfile.has_backup():
        tools.insert(0, Btn("↩️ Desfazer última", callback_data="a:eu"))
    rows.append(tools)
    rows.append([Btn("⬅️ Admin", callback_data="a:home")])
    return "\n\n".join(parts), Kb(rows)


def screen_env_key(deps: h.Deps, idx: int, k: envfile.EnvKey, notice: str = "") -> Screen:
    lines = []
    if notice:
        lines.append(notice + "\n")
    lines.append(f"🔐 <b>{_esc(k.name)}</b>{' 🔒' if k.secret else ''}")
    if k.is_new:
        lines.append("Valor atual: <i>não definida — o bot usa o padrão interno</i>")
    else:
        lines.append(f"Valor atual: <code>{_esc(envfile.mask(k.name, k.value))}</code>")
    show_default = k.default and not k.secret
    if show_default:
        lines.append(f"No .env.example: <code>{_esc(k.default)}</code>")
    if k.help:
        lines.append(f"\n<i>{_esc(k.help)}</i>")
    fmt = envfile.hint(k.name)
    if fmt:
        lines.append(f"Formato: {_esc(fmt)}")
    lines.append("\n⚠️ A mudança só vale depois de reiniciar o bot.")

    ref = f"{idx}:{_crc(k.name)}"
    rows = [[Btn("✏️ Alterar", callback_data=f"a:ee:{ref}")]]
    extra = []
    if show_default and k.value != k.default:
        extra.append(Btn("↩️ Usar o do exemplo", callback_data=f"a:ed:{ref}"))
    if k.in_env and k.value and k.name not in envfile.REQUIRED:
        extra.append(Btn("🗑 Limpar", callback_data=f"a:ex:{ref}"))
    if extra:
        rows.append(extra)
    rows.append([Btn("⬅️ Variáveis", callback_data=f"a:env:{idx // ENV_PER_PAGE}")])
    return "\n".join(lines), Kb(rows)


def screen_env_restart(deps: h.Deps) -> Screen:
    back = [Btn("⬅️ Variáveis", callback_data="a:env:0")]
    if not _supervised():
        launcher = "start.bat" if os.name == "nt" else "start.sh"
        how = (
            "Feche a janela do bot e abra de novo (ícone na área de trabalho ou <code>start.bat</code>)."
            if os.name == "nt"
            else "Reinicie manualmente no Termux:\n<code>bash start.sh stop &amp;&amp; bash start.sh silent</code>"
        )
        text = (
            f"🔄 <b>Reiniciar o bot</b>\n\nEste bot não foi iniciado pelo <code>{launcher}</code>, "
            f"então não consigo religá-lo sozinho. {how}"
        )
        return text, Kb([back])
    busy = len(deps.video_active) + len(deps.code_active)
    text = "🔄 <b>Reiniciar o bot agora?</b>\n\nEle volta em cerca de 10 segundos."
    if busy:
        text += f"\n⚠️ Há {busy} tarefa(s) em andamento (/video ou /code) que serão interrompidas."
    rows = [[Btn("✅ Sim, reiniciar", callback_data="a:ery"), Btn("❌ Cancelar", callback_data="a:env:0")]]
    return text, Kb(rows)


_restarting = False


def request_restart(delay: float = 1.5) -> None:
    """Encerra o processo com RESTART_EXIT_CODE; o start.sh o religa. Idempotente (toque duplo)."""
    global _restarting
    if _restarting:
        return
    _restarting = True
    log.warning("Reinicio solicitado pelo painel de administracao.")

    def _go() -> None:
        logging.shutdown()
        os._exit(RESTART_EXIT_CODE)

    asyncio.get_running_loop().call_later(delay, _go)


async def _verify_token(token: str) -> None:
    """Confere o token novo no Telegram ANTES de salvar (token errado = bot que nao volta apos reiniciar)."""
    try:
        async with httpx.AsyncClient(timeout=10.0) as cli:
            resp = await cli.get(f"https://api.telegram.org/bot{token}/getMe")
    except httpx.HTTPError:  # sem log/mensagem do erro: a URL contem o token
        raise envfile.EnvError("Não consegui falar com o Telegram para validar o token agora. Nada foi salvo.") from None
    if resp.status_code == 200:
        return
    if resp.status_code in (401, 404):
        raise envfile.EnvError("O Telegram recusou esse token. Nada foi salvo.")
    raise envfile.EnvError(f"O Telegram respondeu {resp.status_code} ao validar o token. Nada foi salvo.")


# =======================================================================================
#  COMANDOS (abrem as telas como mensagem nova)
# =======================================================================================
async def _send(update: Update, screen: Screen) -> None:
    await update.effective_message.reply_text(screen[0], parse_mode=ParseMode.HTML, reply_markup=screen[1])


def _admin_of(update: Update, context: ContextTypes.DEFAULT_TYPE) -> bool:
    user = update.effective_user
    return _is_admin(h._deps(context), user.id if user else None)


async def cmd_menu(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    _clear_pending(context)
    deps = h._deps(context)
    await _send(update, screen_main(deps, update.effective_chat.id, _admin_of(update, context)))


async def cmd_help(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    await _send(update, screen_help(_admin_of(update, context)))


async def cmd_tools(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    _clear_pending(context)
    await _send(update, await screen_tools(h._deps(context)))


async def cmd_nexus(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    """/nexus sem argumento abre o menu de ferramentas; com argumento, executa o pedido."""
    if h._arg_text(update):
        await h.cmd_nexus(update, context)
    else:
        await cmd_tools(update, context)


@h.admin_only
async def cmd_admin(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    _clear_pending(context)
    await _send(update, screen_admin(h._deps(context), update.effective_chat.id))


@h.admin_only
async def cmd_persona(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    """/persona: tela da persona. Sem pendencia, um .json enviado com a legenda /persona tambem vale (ver on_document)."""
    _clear_pending(context)
    await _send(update, screen_persona(h._deps(context)))


@h.admin_only
async def cmd_env(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    _clear_pending(context)
    chat = update.effective_chat
    if chat is None or chat.type != "private":
        await update.effective_message.reply_text("🔐 Por segurança, use /env no chat privado comigo.")
        return
    await _send(update, screen_env(h._deps(context)))


async def cmd_cancel(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    had = context.user_data.pop("pending", None)
    await update.effective_message.reply_text("Cancelado." if had else "Nada pendente.")


# =======================================================================================
#  BOTOES
# =======================================================================================
class _Cb:
    """Contexto de um clique: garante um unico `answerCallbackQuery` (toast opcional)."""

    def __init__(self, update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
        self.update, self.context = update, context
        self.q = update.callback_query
        self.deps = h._deps(context)
        self.chat_id = update.effective_chat.id if update.effective_chat else 0
        self.admin = _is_admin(self.deps, self.q.from_user.id)
        self._acked = False

    async def ack(self, text: str | None = None, alert: bool = False) -> None:
        if self._acked:
            return
        self._acked = True
        # clique velho demais (BadRequest) ou rede instavel (NetworkError): o toast e opcional e,
        # como roda em `finally`, nao pode mascarar o erro real nem gerar outro.
        with contextlib.suppress(BadRequest, NetworkError):
            await self.q.answer(text, show_alert=alert)

    async def show(self, screen: Screen) -> None:
        """Edita a mensagem do menu no lugar; se nao der, manda uma nova."""
        text, kb = screen
        try:
            await h.tg_retry(
                lambda: self.q.edit_message_text(text, parse_mode=ParseMode.HTML, reply_markup=kb), "edicao de menu"
            )
        except BadRequest as exc:
            if "not modified" in str(exc).lower():
                return
            log.debug("edit falhou (%s); enviando mensagem nova", exc)
            await h.tg_retry(lambda: self.q.message.reply_text(text, parse_mode=ParseMode.HTML, reply_markup=kb))


async def _cb_main(c: _Cb, arg: str) -> None:
    if arg == "status":
        await c.ack("Consultando…")
        await c.show(await screen_status(c.deps, c.chat_id))
    elif arg == "help":
        await c.show(screen_help(c.admin))
    elif arg == "voice":
        if c.deps.voice is not None:
            c.deps.voice.set(c.chat_id, not c.deps.voice.enabled(c.chat_id))
            await c.ack("🔊 Voz ligada" if c.deps.voice.enabled(c.chat_id) else "🔇 Voz desligada")
        await c.show(screen_main(c.deps, c.chat_id, c.admin))
    elif arg == "reset":
        c.deps.history.reset(c.chat_id)
        await c.ack("🧹 Contexto limpo")
        await c.show(screen_main(c.deps, c.chat_id, c.admin))
    else:
        _clear_pending(c.context)
        await c.show(screen_main(c.deps, c.chat_id, c.admin))


async def _cb_tools(c: _Cb, arg: str) -> None:
    action, _, val = arg.partition(":")
    if action in {"l", "u"}:
        if action == "u":
            await c.ack("Atualizando…")
        _clear_pending(c.context)
        page = int(val) if val.isdigit() else 0
        await c.show(await screen_tools(c.deps, page, force=(action == "u")))
    elif action == "o" and _NAME_OK.match(val):
        _clear_pending(c.context)
        await c.show(await screen_tool_card(c.deps, val))
    elif action == "r" and _NAME_OK.match(val):
        await c.ack(f"Executando /{val}…")
        await h._run_nexus(c.update, c.context, f"/{val}")
    elif action == "a" and _NAME_OK.match(val):
        _set_pending(c.context, "tool", tool=val)
        text = (
            f"✍️ <b>/{_esc(val)}</b>\n\nEnvie os argumentos na <b>próxima mensagem</b>.\n"
            f"Ex.: <code>/{_esc(val)} </code>+ o que você mandar."
        )
        await c.show((text, Kb([[Btn("❌ Cancelar", callback_data=f"t:o:{val}")]])))
    elif action == "f":
        _set_pending(c.context, "free")
        text = (
            "✍️ <b>Pedido livre ao Nexus</b>\n\nEnvie o pedido na <b>próxima mensagem</b>.\n"
            "Ex.: <code>clima Dourados MS</code> ou <code>sismo forte 3</code>."
        )
        await c.show((text, Kb([[Btn("❌ Cancelar", callback_data="t:l:0")]])))
    else:
        await c.ack("Botão expirado — reabra com /ferramentas", alert=True)


_ENV_ACTIONS = frozenset({"env", "ev", "ee", "ed", "ex", "eu", "er", "ery"})


async def _cb_env(c: _Cb, action: str, val: str) -> None:
    """Editor de variaveis do .env (so admin, so chat privado: o valor digitado pode ser um segredo)."""
    deps = c.deps
    if c.q.message is None or c.q.message.chat.type != "private":
        await c.ack("Por segurança, o editor de .env só funciona no chat privado com o bot.", alert=True)
        return

    if action == "env":
        _clear_pending(c.context)
        await c.show(screen_env(deps, int(val) if val.isdigit() else 0))
        return
    if action == "eu":
        if envfile.restore_backup():
            deps.cache["env_dirty"] = True
            await c.ack("↩️ .env anterior restaurado")
            await c.show(screen_env(deps, 0, "↩️ Última alteração desfeita."))
        else:
            await c.ack("Não há alteração para desfazer.", alert=True)
            await c.show(screen_env(deps, 0))
        return
    if action == "er":
        await c.show(screen_env_restart(deps))
        return
    if action == "ery":
        if not _supervised():
            await c.ack("O bot não está sob o start.sh; reinicie manualmente.", alert=True)
            return
        await c.show(("🔄 <b>Reiniciando…</b>\n\nVolto em cerca de 10 segundos. Se não responder, veja logs/bot.log.", Kb([])))
        request_restart()
        return

    idx_s, _, crc = val.partition(":")
    found = _env_resolve(idx_s, crc)
    if found is None:
        await c.ack("A lista mudou — atualizei.")
        await c.show(screen_env(deps, 0))
        return
    idx, key = found

    if action == "ev":
        _clear_pending(c.context)
        await c.show(screen_env_key(deps, idx, key))
    elif action == "ee":
        _set_pending(c.context, "env", key=key.name, chat_id=c.chat_id, idx=idx)
        text = f"✏️ <b>{_esc(key.name)}</b>\n\nEnvie o novo valor na <b>próxima mensagem</b>."
        fmt = envfile.hint(key.name)
        if fmt:
            text += f"\nFormato: {_esc(fmt)}"
        if key.secret:
            text += "\n🔒 Vou apagar a sua mensagem logo depois de ler."
        await c.show((text, Kb([[Btn("❌ Cancelar", callback_data="x:env")]])))
    elif action in {"ed", "ex"}:  # usar o valor do .env.example / limpar
        raw = (key.default or "") if action == "ed" else ""
        try:
            value = envfile.prepare_value(key.name, raw, editor_id=c.q.from_user.id, current=envfile.read_env())
            envfile.write_env({key.name: value})
        except (envfile.EnvError, OSError) as exc:
            await c.ack(f"⚠️ {exc}"[:190], alert=True)
            return
        deps.cache["env_dirty"] = True
        await c.ack("Salvo — reinicie para aplicar")
        fresh = _env_resolve(str(idx), crc)
        await c.show(screen_env_key(deps, idx, fresh[1] if fresh else key, "✅ Salvo."))


_PERSONA_ACTIONS = frozenset({"pers", "pup", "prag", "pun", "prs", "prsy"})


async def _cb_persona(c: _Cb, action: str) -> None:
    deps, st = c.deps, c.deps.state
    if action == "pers":
        _clear_pending(c.context)
        await c.show(screen_persona(deps))
    elif action == "pup":
        _set_pending(c.context, "persona_file", chat_id=c.chat_id)
        await c.show(screen_persona_upload())
    elif action == "prag":
        st.set_rag_enabled(not st.rag_enabled)
        await c.ack("🧠 Lembranças ligadas" if st.rag_enabled else "🧠 Lembranças desligadas")
        await c.show(screen_persona(deps))
    elif action == "pun":
        try:
            p = st.undo_persona()
        except ValueError as exc:
            await c.ack(f"⚠️ {exc}"[:190], alert=True)
            await c.show(screen_persona(deps))
            return
        await c.ack("↩️ Persona anterior restaurada")
        await c.show(screen_persona(deps, _persona_applied_text(p, "restaurada")))
    elif action == "prs":
        await c.show(screen_persona_reset_confirm(deps))
    elif action == "prsy":
        try:
            p = st.reset_persona()
        except ValueError as exc:
            await c.ack(f"⚠️ {exc}"[:190], alert=True)
            return
        await c.ack("♻️ Aether padrão")
        await c.show(screen_persona(deps, _persona_applied_text(p, "restaurada")))


async def _cb_admin(c: _Cb, arg: str) -> None:
    deps, st = c.deps, c.deps.state
    action, _, val = arg.partition(":")

    if action in _ENV_ACTIONS:
        await _cb_env(c, action, val)

    elif action == "home":
        _clear_pending(c.context)
        await c.show(screen_admin(deps, c.chat_id))

    elif action in _PERSONA_ACTIONS:
        await _cb_persona(c, action)

    elif action == "status":
        await c.ack("Consultando…")
        text, _kb = await screen_status(deps, c.chat_id)
        await c.show((text, Kb([[Btn("🔄 Atualizar", callback_data="a:status"), Btn("⬅️ Admin", callback_data="a:home")]])))

    elif action == "reset":
        deps.history.reset(c.chat_id)
        await c.ack("🧹 Contexto limpo")
        await c.show(screen_admin(deps, c.chat_id))

    elif action == "prompt":
        await c.ack()
        await h._reply_long(c.update, st.system_prompt())

    elif action == "model":
        await c.show(await screen_models(deps, int(val) if val.isdigit() else 0))

    elif action == "ms":  # a:ms:<idx>:<crc>
        idx_s, _, crc = val.partition(":")
        try:
            models = await deps.ollama.list_models()
        except OllamaError as exc:
            await c.ack(f"⚠️ {exc}"[:190], alert=True)
            return
        if not idx_s.isdigit() or int(idx_s) >= len(models) or _crc(models[int(idx_s)]) != crc:
            await c.ack("A lista mudou — atualizei.")
        else:
            st.set_model(models[int(idx_s)])
            await c.ack(f"✅ Modelo: {_short(st.model, 150)}")
        await c.show(await screen_models(deps, 0))

    elif action == "temp":
        await c.show(screen_temp(deps))

    elif action in {"ts", "td"}:
        try:
            new = float(val) if action == "ts" else round(st.temperature + 0.1 * int(val), 1)
            st.set_temperature(min(2.0, max(0.0, new)))
            await c.ack(f"🌡 {st.temperature}")
        except ValueError:
            await c.ack("Valor inválido", alert=True)
        await c.show(screen_temp(deps))

    elif action == "dirs":
        _clear_pending(c.context)
        await c.show(screen_dirs(deps))

    elif action == "dd":  # a:dd:<n>:<crc>
        n_s, _, crc = val.partition(":")
        ds = st.directives
        if n_s.isdigit() and 1 <= int(n_s) <= len(ds) and _crc(ds[int(n_s) - 1]) == crc:
            st.remove_directive(int(n_s))
            await c.ack("🗑 Diretriz removida")
        else:
            await c.ack("A lista mudou — atualizei.")
        await c.show(screen_dirs(deps))

    elif action == "dc":
        await c.show(screen_confirm_clear(deps))

    elif action == "dcy":
        n = st.clear_directives()
        await c.ack(f"🧨 {n} diretriz(es) removida(s)")
        await c.show(screen_dirs(deps))

    elif action == "new":
        _set_pending(c.context, "directive")
        text = (
            "➕ <b>Nova diretriz</b>\n\nEnvie a instrução na <b>próxima mensagem</b> "
            f"(até {MAX_DIRECTIVE_LEN} caracteres).\nValerá já na próxima resposta e fica salva."
        )
        await c.show((text, Kb([[Btn("❌ Cancelar", callback_data="x:dirs")]])))

    else:
        await c.ack("Botão expirado — reabra com /admin", alert=True)


async def _cb_cancel(c: _Cb, arg: str) -> None:
    _clear_pending(c.context)
    await c.ack("Cancelado")
    if arg == "dirs" and c.admin:
        await c.show(screen_dirs(c.deps))
    elif arg == "env" and c.admin:
        await c.show(screen_env(c.deps))
    elif arg == "pers" and c.admin:
        await c.show(screen_persona(c.deps))
    elif arg == "tools":
        await c.show(await screen_tools(c.deps))
    else:
        await c.show(screen_main(c.deps, c.chat_id, c.admin))


async def on_callback(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    q = update.callback_query
    if q is None or q.from_user is None:
        return
    deps = h._deps(context)
    if q.from_user.id not in deps.settings.allowed_user_ids:
        return  # silencio absoluto: nem toast
    ns, _, arg = (q.data or "").partition(":")
    if ns == "a" and q.from_user.id not in deps.settings.admin_user_ids:
        return  # botao de admin apertado por nao-admin (ex.: em grupo): silencio
    c = _Cb(update, context)
    try:
        if ns == "m":
            await _cb_main(c, arg)
        elif ns == "t":
            await _cb_tools(c, arg)
        elif ns == "a":
            await _cb_admin(c, arg)
        elif ns == "x":
            await _cb_cancel(c, arg)
    finally:
        await c.ack()  # garante que o spinner do botao sempre some


# =======================================================================================
#  TEXTO LIVRE QUANDO HA ENTRADA PENDENTE
# =======================================================================================
async def _apply_env_edit(update: Update, context: ContextTypes.DEFAULT_TYPE, pending: dict, raw: str) -> None:
    deps = h._deps(context)
    msg, chat, key = update.effective_message, update.effective_chat, pending["key"]
    idx = int(pending.get("idx", 0))
    with contextlib.suppress(Exception):  # o valor pode ser um segredo: some do historico do chat
        await msg.delete()
    back = Btn("🔐 Variáveis", callback_data=f"a:env:{idx // ENV_PER_PAGE}")
    try:
        value = envfile.prepare_value(
            key, raw, editor_id=update.effective_user.id, current=envfile.read_env()
        )
        if key == "TELEGRAM_BOT_TOKEN":
            await _verify_token(value)
        envfile.write_env({key: value})
    except (envfile.EnvError, OSError) as exc:
        kb = Kb([[Btn("🔁 Tentar de novo", callback_data=f"a:ee:{idx}:{_crc(key)}"), back]])
        await context.bot.send_message(chat.id, f"⚠️ {_esc(exc)}", parse_mode=ParseMode.HTML, reply_markup=kb)
        return
    deps.cache["env_dirty"] = True
    shown = _esc(envfile.mask(key, value))
    kb = Kb([[Btn("🔄 Reiniciar agora", callback_data="a:er"), back]])
    await context.bot.send_message(
        chat.id,
        f"✅ <code>{_esc(key)}</code> salvo: <code>{shown}</code>\n⚠️ Reinicie o bot para aplicar.",
        parse_mode=ParseMode.HTML, reply_markup=kb,
    )


async def _apply_persona_text(update: Update, context: ContextTypes.DEFAULT_TYPE, raw: str) -> None:
    """Valida e ativa a persona; responde com o resultado (ou o motivo da recusa) e botoes de atalho."""
    deps = h._deps(context)
    msg = update.effective_message
    try:
        p = deps.state.set_persona_from_text(raw)
    except ValueError as exc:
        kb = Kb([[Btn("🔁 Tentar de novo", callback_data="a:pup"), Btn("🎭 Persona", callback_data="a:pers")]])
        await h.safe_reply(msg, f"⚠️ Não troquei a persona: {_esc(exc)}", parse_mode=ParseMode.HTML, reply_markup=kb)
        return
    log.info("Persona trocada pelo painel: %s (%d lembrancas)", p.name, p.chunk_count)
    kb = Kb([
        [Btn("🧹 Limpar contexto", callback_data="a:reset"), Btn("🎭 Persona", callback_data="a:pers")],
        [Btn("⬅️ Admin", callback_data="a:home")],
    ])
    await h.safe_reply(msg, _persona_applied_text(p), parse_mode=ParseMode.HTML, reply_markup=kb)


_PERSONA_CAPTION = re.compile(r"(?i)^\s*/persona(@\w+)?(\s|$)")


async def on_document(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    """.json da persona: vale quando o admin tocou em "Enviar JSON" (pendencia) ou mandou o arquivo com a legenda /persona."""
    msg, user, chat = update.effective_message, update.effective_user, update.effective_chat
    if msg is None or msg.document is None or user is None or chat is None:
        return
    deps = h._deps(context)
    if user.id not in deps.settings.admin_user_ids:
        return  # silencio para quem nao e admin
    pending = context.user_data.get("pending")
    waiting = bool(
        pending
        and pending.get("kind") == "persona_file"
        and pending.get("chat_id") == chat.id
        and time.monotonic() - pending["ts"] <= PENDING_TTL
    )
    if not (waiting or _PERSONA_CAPTION.match(msg.caption or "")):
        return
    _clear_pending(context)
    doc = msg.document
    retry = Kb([[Btn("🔁 Tentar de novo", callback_data="a:pup"), Btn("🎭 Persona", callback_data="a:pers")]])
    if doc.file_size and doc.file_size > MAX_PERSONA_FILE_BYTES:
        await h.safe_reply(
            msg, f"⚠️ Arquivo grande demais (máx. {MAX_PERSONA_FILE_BYTES // 1024 // 1024} MB).", reply_markup=retry
        )
        return
    try:
        tg_file = await h.tg_retry(lambda: doc.get_file(), "download da persona")
        data = await h.tg_retry(lambda: tg_file.download_as_bytearray(), "download da persona")
        raw = bytes(data).decode("utf-8-sig")
    except UnicodeDecodeError:
        await h.safe_reply(msg, "⚠️ O arquivo não está em UTF-8; salve o JSON como UTF-8 e envie de novo.", reply_markup=retry)
        return
    except (TelegramError, OSError) as exc:
        log.warning("download da persona falhou: %s", exc)
        await h.safe_reply(msg, "⚠️ Não consegui baixar o arquivo agora. Tente de novo.", reply_markup=retry)
        return
    await _apply_persona_text(update, context, raw)


async def on_pending_text(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    """Registrado antes do on_text. Sem pendencia (ou expirada) nao faz nada e a conversa segue."""
    peek = context.user_data.get("pending")
    chat = update.effective_chat
    if peek and peek.get("kind") == "env" and (chat is None or chat.id != peek.get("chat_id")):
        return  # valor de .env so e aceito no mesmo chat privado onde foi pedido (nunca em grupo)
    pending = context.user_data.pop("pending", None)
    msg = update.effective_message
    if not pending or msg is None or not msg.text:
        return
    if time.monotonic() - pending["ts"] > PENDING_TTL:
        return  # expirou: trata como conversa normal
    deps = h._deps(context)
    text = msg.text.strip()
    kind = pending["kind"]

    if kind == "directive":
        if not _is_admin(deps, update.effective_user.id if update.effective_user else None):
            raise ApplicationHandlerStop
        kb = Kb([[Btn("📜 Diretrizes", callback_data="a:dirs"), Btn("⚙️ Admin", callback_data="a:home")]])
        try:
            n = deps.state.add_directive(text)
        except ValueError as exc:
            await msg.reply_text(f"⚠️ {exc}", reply_markup=kb)
        else:
            await msg.reply_text(f"✅ Diretriz #{n} ativa.", reply_markup=kb)
    elif kind == "env":
        if not _is_admin(deps, update.effective_user.id if update.effective_user else None):
            raise ApplicationHandlerStop
        await _apply_env_edit(update, context, pending, text)
    elif kind == "persona_file":  # JSON colado como texto
        if not _is_admin(deps, update.effective_user.id if update.effective_user else None):
            raise ApplicationHandlerStop
        await _apply_persona_text(update, context, text)
    elif kind == "tool":
        await h._run_nexus(update, context, f"/{pending['tool']} {text}")
    elif kind == "free":
        await h._run_nexus(update, context, text)
    raise ApplicationHandlerStop
