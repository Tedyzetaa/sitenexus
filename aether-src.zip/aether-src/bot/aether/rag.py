"""Lembrancas dinamicas ("Subconsciente"): RAG local, so biblioteca padrao.

Mesmo algoritmo do app mobile (lucy-expo/src/personaFile.js) e, em espirito, do subconsciente.py do Vision House:
TF-IDF simples sobre os chunks da persona, com stemmer leve de portugues e os limiares COBERTURA_MIN / IDF_MIN /
IDF_RARO. Se a mensagem nao tem relacao com nenhuma lembranca, nada e injetado.
"""
from __future__ import annotations

import math
import re
import unicodedata
from dataclasses import dataclass
from typing import Iterable

COBERTURA_MIN = 0.4
IDF_MIN = 3.5
IDF_RARO = 6.5
MAX_LEMBRANCAS = 3
MAX_CHARS = 400

_STOP = frozenset(
    (
        "que com para por uma uns umas dos das nos nas num numa como mais mas foi sao ser ter tem tinha ele ela eles elas "
        "isso isto esse essa esses essas aquele aquela seu sua seus suas meu minha meus minhas voce voces nao sim ate "
        "sobre entre quando onde qual quais quem porque pois ainda tambem muito muita pouco ja so la aqui ali tudo todo toda "
        "fala diz fazer faz pode poder quero queria gostaria vamos vai ola oi"
    ).split()
)
_WORD = re.compile(r"[a-z0-9]{3,}")


@dataclass(frozen=True)
class Chunk:
    id: str
    text: str
    area: str = ""
    tema: str = ""
    sessao: str = ""


def fold(s: str) -> str:
    s = unicodedata.normalize("NFD", str(s or "").lower())
    return "".join(ch for ch in s if unicodedata.category(ch) != "Mn")


def stem(w: str) -> str:
    """Stemmer leve: corta plural e sufixos comuns. Nao precisa ser perfeito, so consistente."""
    if len(w) > 6 and w.endswith("mente"):
        w = w[:-5]
    if len(w) > 5 and (w.endswith("coes") or w.endswith("cao")):
        w = re.sub(r"(coes|cao)$", "c", w)
    elif len(w) > 5 and w.endswith("oes"):
        w = w[:-3] + "ao"
    elif len(w) > 5 and w.endswith("ais"):
        w = w[:-3] + "al"
    elif len(w) > 4 and w.endswith("es"):
        w = w[:-2]
    elif len(w) > 3 and w.endswith("s"):
        w = w[:-1]
    return w


def tokenize(s: str) -> list[str]:
    return [stem(w) for w in _WORD.findall(fold(s)) if w not in _STOP]


def clip(s: str, n: int) -> str:
    return s if len(s) <= n else s[: n - 1].rstrip() + "…"


class RagIndex:
    """Indice imutavel sobre os chunks da persona (montado uma vez, na importacao)."""

    def __init__(self, chunks: Iterable[Chunk], affinities: Iterable[str] = ()) -> None:
        self.chunks = tuple(chunks)
        self.affinities = tuple(a for a in (fold(x) for x in affinities) if a)
        self._df: dict[str, int] = {}
        self._docs: list[tuple[Chunk, frozenset[str], str]] = []
        for c in self.chunks:
            toks = frozenset(tokenize(f"{c.text} {c.tema}"))
            for t in toks:
                self._df[t] = self._df.get(t, 0) + 1
            self._docs.append((c, toks, fold(f"{c.area} {c.tema}")))
        self.n = len(self._docs)

    def __bool__(self) -> bool:
        return self.n > 0

    def retrieve(self, query: str, max_results: int = MAX_LEMBRANCAS) -> list[Chunk]:
        if not self.n:
            return []
        q = list(dict.fromkeys(tokenize(query)))
        if not q:
            return []
        ln_n = math.log(self.n + 1)
        idf_min = min(IDF_MIN, 0.5 * ln_n)
        idf_raro = min(IDF_RARO, 0.85 * ln_n)

        def idf(t: str) -> float:
            return math.log((self.n + 1) / (self._df.get(t, 0) + 0.5))

        # palavras-chave: conhecidas pelo corpus e nao genericas
        kw = [(t, idf(t)) for t in q if t in self._df]
        kw = [(t, w) for t, w in kw if w >= idf_min]
        if not kw:
            return []
        total = sum(w for _, w in kw)

        hits: list[tuple[float, Chunk]] = []
        for chunk, toks, tag in self._docs:
            got, n, rare = 0.0, 0, False
            for t, w in kw:
                if t in toks:
                    got += w
                    n += 1
                    rare = rare or w >= idf_raro
            if not n:
                continue
            if got / total < COBERTURA_MIN or (n < 2 and not rare):
                continue
            boost = 1.25 if self.affinities and any(a in tag for a in self.affinities) else 1.0
            hits.append((got * boost, chunk))
        hits.sort(key=lambda h: -h[0])
        return [c for _, c in hits[:max_results]]


def format_memories(chunks: Iterable[Chunk]) -> str:
    rows = [f"- {clip(c.text, MAX_CHARS)}" for c in chunks]
    if not rows:
        return ""
    return (
        "LEMBRANÇAS DE FUNDO (impressões que você tem sobre o assunto; use só se combinarem com a conversa, "
        "sem citar fonte, id nem dizer de onde vêm):\n" + "\n".join(rows)
    )
