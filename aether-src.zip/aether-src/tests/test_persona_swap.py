import asyncio
import json
import re
import time
from pathlib import Path
from types import SimpleNamespace
from unittest.mock import AsyncMock, MagicMock

import pytest

from aether import panel
from aether.persona import DEFAULT_PERSONA_DATA, RuntimeState, persona_from_data, persona_from_text
from aether.rag import RagIndex, Chunk, tokenize

AETHER = {"name": "Aether", "description": "Assistente tecnica", "tone": "direta", "traits": ["curiosa"], "rules": ["Seja breve"]}

VH = {
    "nome": "Nyx", "papel": "Hacker etica", "voz": "sarcastica",
    "traits": {"empatia": 70, "orgulho": 40},
    "system_prompt": "Você é a Nyx.\nNÚCLEO: sabe de física quântica.",
    "memoria_semantica": [{"topico": "quantica", "fato_aprendido": "A computação quântica usa qubits e superposição."}],
    "memoria_episodica": [{"data": "2026-11-18", "evento": "O grupo pesquisou o ano de 2003."}],
    "rag": {"chunks": [
        {"id": "a1", "area": "ciencia", "tema": "quantica", "texto": "Qubits permitem superposição e emaranhamento em computadores quânticos."},
        {"id": "a2", "area": "cultura", "tema": "kpop", "texto": "O K-pop surgiu na Coreia do Sul na década de 1990."},
        {"id": "a3", "area": "esporte", "tema": "f1", "texto": "A Fórmula 1 de 2026 trouxe novos regulamentos de unidades de potência."},
        {"id": "a4", "area": "cotidiano", "tema": "culinaria", "texto": "Feijoada é um prato brasileiro com feijão preto e carnes."},
    ]},
}


def state(tmp_path):
    return RuntimeState(tmp_path / "runtime.json", "m", 0.7, persona_path=tmp_path / "persona.json")


def test_formato_aether_continua_funcionando():
    p = persona_from_data(AETHER)
    assert p.name == "Aether" and "Seja breve" in p.system_prompt and p.index is None
    assert persona_from_data(DEFAULT_PERSONA_DATA).name == "Aether"


def test_formato_vision_house_completo():
    p = persona_from_text("\ufeff" + json.dumps(VH))
    assert p.name == "Nyx" and p.chunk_count == 4 and p.system_prompt.startswith("Você é a Nyx")


def test_vision_house_sem_prompt_compoe_e_usa_memorias():
    d = {k: v for k, v in VH.items() if k not in ("system_prompt", "rag")}
    p = persona_from_data(d)
    assert "Hacker etica" in p.system_prompt and "empatia: 70/100" in p.system_prompt
    assert p.chunk_count == 2  # semantica + episodica viram lembrancas


def test_persona_embrulhada():
    assert persona_from_data({"persona": VH}).name == "Nyx"


@pytest.mark.parametrize("raw", ["", "{quebrado", '{"foo": 1}', "[1,2]", "[]"])
def test_json_invalido_da_erro_claro(raw):
    with pytest.raises(ValueError):
        persona_from_text(raw)


def test_rag_acha_o_certo_e_fica_quieto_fora_do_assunto():
    idx = persona_from_data(VH).index
    hit = idx.retrieve("me explica como qubits e superposição funcionam num computador quântico")
    assert hit and hit[0].id == "a1"
    assert idx.retrieve("bom dia, tudo bem com você hoje?") == []
    assert idx.retrieve("qual a capital da Mongólia") == []


def test_tokenize_ignora_acento_e_plural():
    assert tokenize("As eleições Americanas") == tokenize("eleicao americana")


def test_troca_persiste_e_vale_no_prompt(tmp_path):
    st = state(tmp_path)
    assert st.persona.name == "Aether"
    p = st.set_persona_from_text(json.dumps(VH))
    assert p.name == "Nyx" and st.persona.name == "Nyx"
    assert (tmp_path / "persona.json").exists() and st.has_persona_backup()
    assert "LEMBRANÇAS DE FUNDO" in st.system_prompt("fala sobre qubits e superposição quântica")
    assert "LEMBRANÇAS" not in st.system_prompt("bom dia")
    assert "LEMBRANÇAS" not in st.system_prompt()  # /sistema e "Ver prompt" nao injetam
    # reinicio: o novo RuntimeState le o persona.json gravado
    assert state(tmp_path).persona.name == "Nyx"


def test_diretrizes_continuam_depois_da_persona(tmp_path):
    st = state(tmp_path)
    st.set_persona_from_text(json.dumps(AETHER | {"name": "Lia"}))
    st.add_directive("Sempre responda em rimas")
    sp = st.system_prompt("oi")
    assert "Lia" in sp and "Sempre responda em rimas" in sp


def test_json_invalido_nao_mexe_em_nada(tmp_path):
    st = state(tmp_path)
    st.set_persona_from_text(json.dumps(VH))
    with pytest.raises(ValueError):
        st.set_persona_from_text("{quebrado")
    assert st.persona.name == "Nyx"
    assert json.loads((tmp_path / "persona.json").read_text(encoding="utf-8"))["nome"] == "Nyx"


def test_arquivo_grande_demais_e_recusado(tmp_path):
    with pytest.raises(ValueError, match="grande demais"):
        state(tmp_path).set_persona_from_text(" " * (3 * 1024 * 1024 + 1))


def test_desfazer_e_voltar_ao_padrao(tmp_path):
    st = state(tmp_path)
    st.set_persona_from_text(json.dumps(VH))
    st.set_persona_from_text(json.dumps(AETHER | {"name": "Lia"}))
    assert st.undo_persona().name == "Nyx"
    assert st.undo_persona().name == "Lia"  # desfazer de novo = refazer
    st.reset_persona()
    assert st.persona.name == "Aether" and not (tmp_path / "persona.json").exists()
    assert st.undo_persona().name == "Lia"  # o reset tambem e desfazivel


def test_desfazer_sem_historico(tmp_path):
    with pytest.raises(ValueError):
        state(tmp_path).undo_persona()


def test_primeira_troca_pode_voltar_a_aether(tmp_path):
    st = state(tmp_path)
    st.set_persona_from_text(json.dumps(VH))
    assert st.undo_persona().name == "Aether"


def test_toggle_rag_persiste(tmp_path):
    st = state(tmp_path)
    st.set_persona_from_text(json.dumps(VH))
    st.set_rag_enabled(False)
    assert "LEMBRANÇAS" not in st.system_prompt("fala sobre qubits e superposição quântica")
    assert state(tmp_path).rag_enabled is False


def test_nenhuma_mencao_ao_olho_de_deus_no_codigo():
    root = Path(__file__).resolve().parent.parent
    pat = re.compile(r"godseye|god'?s eye|olho de deus|cloudflared|tunnel", re.I)
    for f in list((root / "bot").rglob("*.py")) + [root / "bot" / ".env.example"]:
        if f.name == "conftest.py":
            continue
        assert not pat.search(f.read_text(encoding="utf-8")), f


# ---- painel: fluxo com arquivo enviado ------------------------------------------------------
def fakes(tmp_path, admin=True, caption=None, doc_bytes=b"", pending=True, size=None):
    st = state(tmp_path)
    deps = SimpleNamespace(settings=SimpleNamespace(admin_user_ids={1}, allowed_user_ids={1, 2}), state=st, cache={})
    ctx = SimpleNamespace(application=SimpleNamespace(bot_data={"deps": deps}), user_data={})
    if pending:
        ctx.user_data["pending"] = {"kind": "persona_file", "ts": time.monotonic(), "chat_id": 10}
    tg_file = SimpleNamespace(download_as_bytearray=AsyncMock(return_value=bytearray(doc_bytes)))
    doc = SimpleNamespace(file_size=size if size is not None else len(doc_bytes), get_file=AsyncMock(return_value=tg_file))
    msg = SimpleNamespace(document=doc, caption=caption, reply_text=AsyncMock())
    upd = SimpleNamespace(
        effective_message=msg, effective_user=SimpleNamespace(id=1 if admin else 2), effective_chat=SimpleNamespace(id=10)
    )
    return st, ctx, upd, msg


def run(coro):
    return asyncio.run(coro)


def test_admin_envia_json_apos_tocar_no_botao(tmp_path):
    st, ctx, upd, msg = fakes(tmp_path, doc_bytes=json.dumps(VH).encode())
    run(panel.on_document(upd, ctx))
    assert st.persona.name == "Nyx"
    assert "Nyx" in msg.reply_text.call_args.args[0]
    assert "pending" not in ctx.user_data


def test_legenda_persona_sem_pendencia(tmp_path):
    st, ctx, upd, msg = fakes(tmp_path, caption="/persona", pending=False, doc_bytes=json.dumps(AETHER | {"name": "Lia"}).encode())
    run(panel.on_document(upd, ctx))
    assert st.persona.name == "Lia"


def test_documento_qualquer_e_ignorado(tmp_path):
    st, ctx, upd, msg = fakes(tmp_path, pending=False, doc_bytes=json.dumps(VH).encode())
    run(panel.on_document(upd, ctx))
    assert st.persona.name == "Aether" and not msg.reply_text.called


def test_nao_admin_fica_em_silencio(tmp_path):
    st, ctx, upd, msg = fakes(tmp_path, admin=False, caption="/persona", doc_bytes=json.dumps(VH).encode())
    run(panel.on_document(upd, ctx))
    assert st.persona.name == "Aether" and not msg.reply_text.called


def test_arquivo_invalido_avisa_e_nao_troca(tmp_path):
    st, ctx, upd, msg = fakes(tmp_path, doc_bytes=b"{quebrado")
    run(panel.on_document(upd, ctx))
    assert st.persona.name == "Aether"
    assert "Não troquei" in msg.reply_text.call_args.args[0]


def test_arquivo_nao_utf8(tmp_path):
    st, ctx, upd, msg = fakes(tmp_path, doc_bytes="{\"nome\": \"Ç\"}".encode("latin-1"))
    run(panel.on_document(upd, ctx))
    assert st.persona.name == "Aether" and "UTF-8" in msg.reply_text.call_args.args[0]


def test_json_colado_como_texto(tmp_path):
    st, ctx, upd, msg = fakes(tmp_path)
    upd.effective_message.text = json.dumps(AETHER | {"name": "Lia"})
    with pytest.raises(Exception):  # ApplicationHandlerStop ao consumir a pendencia
        run(panel.on_pending_text(upd, ctx))
    assert st.persona.name == "Lia"


def test_telas_renderizam(tmp_path):
    st, ctx, upd, msg = fakes(tmp_path)
    deps = ctx.application.bot_data["deps"]
    st.set_persona_from_text(json.dumps(VH))
    text, kb = panel.screen_persona(deps)
    flat = [b.callback_data for row in kb.inline_keyboard for b in row]
    assert "Nyx" in text and {"a:pup", "a:prag", "a:pun", "a:prs"} <= set(flat)
    assert all(len(c.encode()) <= 64 for c in flat)
