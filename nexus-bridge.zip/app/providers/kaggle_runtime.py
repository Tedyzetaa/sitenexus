"""
Gerenciador do ComfyUI remoto no Kaggle.

A URL do ngrok e ALEATORIA a cada sessao. Quem a descobre e o proprio notebook: assim que o tunel sobe,
ele publica "NEXUS_URL <sessao> <url>" num topico do ntfy.sh, e o Nexus le esse topico.

Fluxo (ensure_online):
  1. Se ja ha uma URL conhecida (memoria ou .kaggle_state.json) e GET <url>/system_stats responde 200,
     esta no ar.
  2. Senao, consulta o status do kernel (`kaggle kernels status`). Se ja estiver QUEUED/RUNNING (subindo),
     so espera; caso contrario, faz `kaggle kernels push` de um script gerado a partir de
     app/kaggle/comfyui_server.py.tpl (tokens do .env injetados so numa pasta temporaria, apagada em seguida).
     Cada push gera uma "sessao" nova; so mensagens do ntfy com essa sessao sao aceitas.
  3. Le o topico do ntfy ate aparecer a URL da sessao e espera <url>/system_stats responder. Se o kernel
     morrer no meio, falha cedo com o final do log.

O notebook se desliga sozinho (ocioso, teto de sessao ou arquivo de parada), entao nao ha processo
para o Nexus "matar": stop() so deixa o arquivo de parada via /upload/image.

A CLI do Kaggle e chamada por subprocess (nao pelo import do pacote) porque ela cuida da
autenticacao (chave legada ou token KGAT_) e porque o import do pacote autentica na hora.
"""
import asyncio
import io
import json
import logging
import os
import re
import secrets
import shutil
import subprocess
import sys
import tempfile
import time
from pathlib import Path

import httpx

from app.config import settings
from app.providers.base import ProviderUnavailableError

logger = logging.getLogger("nexus.kaggle_runtime")

TEMPLATE_PATH = Path(__file__).resolve().parent.parent / "kaggle" / "comfyui_server.py.tpl"
STOP_FILE_NAME = "__nexus_stop__.png"
# ngrok (plano gratis) mostra uma pagina de aviso para navegadores; este header a dispensa em chamadas de API.
NGROK_HEADERS = {"ngrok-skip-browser-warning": "true"}

# Arquivo com topico/sessao/ultima URL (para o Nexus reencontrar um notebook ainda no ar apos reiniciar).
STATE_PATH = Path(__file__).resolve().parent.parent.parent / ".kaggle_state.json"
# O Nexus so aceita URLs de dominios do ngrok vindas do ntfy (o topico e publico para quem souber o nome).
_NGROK_SUFFIXES = (".ngrok-free.app", ".ngrok-free.dev", ".ngrok.app", ".ngrok.dev", ".ngrok.io")
_NTFY_RE = re.compile(r"^NEXUS_URL\s+(\S+)\s+(https://\S+)\s*$")
_TOPIC_RE = re.compile(r"^[A-Za-z0-9_-]{8,64}$")

_TERMINAL = {"COMPLETE", "ERROR", "CANCEL_REQUESTED", "CANCEL_ACKNOWLEDGED", "CANCELACKNOWLEDGED"}
# Logo depois do push o status ainda pode mostrar a execucao ANTERIOR (COMPLETE) por alguns segundos.
_STATUS_SETTLE_S = 90


def _parse_status(text: str) -> str | None:
    """'user/slug has status "KernelWorkerStatus.RUNNING"' -> 'RUNNING'."""
    m = re.search(r'status\s*"?([\w\.]+)"?', text, re.IGNORECASE)
    if not m:
        return None
    return m.group(1).split(".")[-1].upper()


def _valid_url(url: str) -> bool:
    m = re.match(r"^https://([a-z0-9.-]+)/?$", url.strip().lower())
    return bool(m and m.group(1).endswith(_NGROK_SUFFIXES))


class KaggleComfyUIManager:
    def __init__(self):
        self._lock = asyncio.Lock()
        self._started_at: float | None = None
        self._state: dict = self._load_state()
        self._url: str | None = self._state.get("url") or None
        self._session: str | None = self._state.get("session") or None

    # --- estado persistente ---------------------------------------------------------------------

    @staticmethod
    def _load_state() -> dict:
        try:
            data = json.loads(STATE_PATH.read_text(encoding="utf-8"))
            return data if isinstance(data, dict) else {}
        except (OSError, json.JSONDecodeError):
            return {}

    def _save_state(self) -> None:
        self._state.update({"url": self._url, "session": self._session})
        try:
            STATE_PATH.write_text(json.dumps(self._state), encoding="utf-8")
        except OSError as e:
            logger.warning("[Kaggle] nao consegui gravar %s: %s", STATE_PATH, e)

    @property
    def topic(self) -> str:
        """Topico do ntfy: o do .env, ou um aleatorio gerado uma vez e guardado no arquivo de estado."""
        if settings.NTFY_TOPIC:
            return settings.NTFY_TOPIC
        if not self._state.get("topic"):
            self._state["topic"] = "nexus-" + secrets.token_hex(10)
            self._save_state()
        return self._state["topic"]

    # --- propriedades ---------------------------------------------------------------------------

    @property
    def base_url(self) -> str:
        """URL publica atual do ComfyUI (vazia ate o notebook publicar a primeira)."""
        return (self._url or "").rstrip("/")

    @property
    def kernel_ref(self) -> str:
        return f"{settings.KAGGLE_USERNAME}/{settings.KAGGLE_KERNEL_SLUG}"

    def _require_config(self) -> None:
        missing = []
        if not settings.KAGGLE_USERNAME:
            missing.append("KAGGLE_USERNAME")
        if not (settings.KAGGLE_KEY or settings.KAGGLE_API_TOKEN):
            missing.append("KAGGLE_KEY (ou KAGGLE_API_TOKEN)")
        if not settings.NGROK_AUTHTOKEN:
            missing.append("NGROK_AUTHTOKEN")
        if missing:
            raise ProviderUnavailableError(
                "VIDEO_PROVIDER=kaggle_wan, mas faltam no .env: " + ", ".join(missing)
            )
        if settings.NTFY_TOPIC and not _TOPIC_RE.match(settings.NTFY_TOPIC):
            raise ProviderUnavailableError(
                "NTFY_TOPIC invalido: use 8 a 64 caracteres entre letras, numeros, - e _ "
                "(ou deixe vazio que o Nexus gera um)."
            )

    # --- CLI do Kaggle --------------------------------------------------------------------------

    def _cli_base(self) -> list[str]:
        exe = "kaggle.exe" if os.name == "nt" else "kaggle"
        venv_exe = Path(sys.executable).parent / exe
        if venv_exe.exists():
            return [str(venv_exe)]
        found = shutil.which("kaggle")
        if found:
            return [found]
        return [sys.executable, "-m", "kaggle.cli"]

    def _cli_env(self) -> dict[str, str]:
        env = dict(os.environ)
        env["KAGGLE_USERNAME"] = settings.KAGGLE_USERNAME
        key, token = settings.KAGGLE_KEY, settings.KAGGLE_API_TOKEN
        if key.startswith("KGAT_") and not token:   # token novo colado no campo antigo
            key, token = "", key
        if key:
            env["KAGGLE_KEY"] = key
        if token:
            env["KAGGLE_API_TOKEN"] = token
        env["PYTHONIOENCODING"] = "utf-8"
        return env

    def _run_cli_sync(self, *args: str, timeout: int = 180) -> tuple[int, str]:
        cmd = self._cli_base() + list(args)
        logger.debug("[Kaggle] %s", " ".join(cmd))
        try:
            p = subprocess.run(
                cmd, env=self._cli_env(), capture_output=True, timeout=timeout,
            )
        except FileNotFoundError as e:
            raise ProviderUnavailableError(
                "CLI do Kaggle nao encontrada. Instale com: pip install -U kaggle"
            ) from e
        except subprocess.TimeoutExpired as e:
            raise ProviderUnavailableError(f"CLI do Kaggle excedeu {timeout}s: {' '.join(args)}") from e
        out = (p.stdout or b"").decode("utf-8", "replace") + (p.stderr or b"").decode("utf-8", "replace")
        return p.returncode, out.strip()

    async def _cli(self, *args: str, timeout: int = 180) -> tuple[int, str]:
        return await asyncio.to_thread(self._run_cli_sync, *args, timeout=timeout)

    # --- estado ---------------------------------------------------------------------------------

    async def is_online(self) -> bool:
        if not self.base_url:
            return False
        try:
            async with httpx.AsyncClient(timeout=8, headers=NGROK_HEADERS) as c:
                r = await c.get(f"{self.base_url}/system_stats")
                return r.status_code == 200
        except httpx.HTTPError:
            return False

    async def kernel_status(self) -> str | None:
        """QUEUED | RUNNING | COMPLETE | ERROR | CANCEL... ou None (nunca enviado / falha de consulta)."""
        code, out = await self._cli("kernels", "status", self.kernel_ref, timeout=60)
        if code != 0 and "status" not in out.lower():
            logger.info("[Kaggle] status indisponivel: %s", out[:200])
            return None
        return _parse_status(out)

    async def status(self) -> dict:
        online = await self.is_online()
        try:
            ks = await self.kernel_status()
        except ProviderUnavailableError as e:
            ks = f"indisponivel ({e})"
        return {"online": online, "kernel_status": ks, "url": self.base_url or None,
                "kernel": self.kernel_ref, "ntfy_topic": self.topic}

    # --- push -----------------------------------------------------------------------------------

    def _render_kernel_dir(self) -> str:
        if not TEMPLATE_PATH.exists():
            raise ProviderUnavailableError(f"Template do notebook nao encontrado: {TEMPLATE_PATH}")
        cfg = {
            "ngrok_token": settings.NGROK_AUTHTOKEN,
            "ntfy_topic": self.topic,
            "ntfy_server": settings.NTFY_SERVER.rstrip("/"),
            "session": self._session,
            "hf_token": settings.HF_TOKEN,
            "profile": settings.WAN_PROFILE,
            "hunyuan_unet": settings.HUNYUAN_UNET,
            "r2v_unet": settings.R2V_UNET,
            "minimax_unet": settings.MINIMAX_UNET,
            "minimax_text_encoder": settings.MINIMAX_TEXT_ENCODER,
            "minimax_turbo": settings.MINIMAX_TURBO,
            "minimax_turbo_lora": settings.MINIMAX_TURBO_LORA,
            "idle_timeout_min": settings.KAGGLE_IDLE_TIMEOUT_MIN,
            "max_session_min": settings.KAGGLE_MAX_SESSION_MIN,
        }
        code = TEMPLATE_PATH.read_text(encoding="utf-8").replace("__NEXUS_CONFIG__", json.dumps(cfg))
        d = tempfile.mkdtemp(prefix="nexus_kaggle_")
        Path(d, "comfyui_server.py").write_text(code, encoding="utf-8")
        meta = {
            "id": self.kernel_ref,
            "title": settings.KAGGLE_KERNEL_SLUG,
            "code_file": "comfyui_server.py",
            "language": "python",
            "kernel_type": "script",
            "is_private": "true",
            "enable_gpu": "true",
            "enable_tpu": "false",
            "enable_internet": "true",
            "dataset_sources": [],
            "competition_sources": [],
            "kernel_sources": [],
            "model_sources": [],
        }
        Path(d, "kernel-metadata.json").write_text(json.dumps(meta, indent=2), encoding="utf-8")
        return d

    async def start(self) -> None:
        self._require_config()
        # sessao nova a cada push: so a URL publicada por ESTE notebook sera aceita
        self._session = secrets.token_hex(8)
        self._url = None
        self._state["profile"] = settings.WAN_PROFILE
        self._state["hunyuan_unet"] = settings.HUNYUAN_UNET
        self._state["r2v_unet"] = settings.R2V_UNET
        self._state["minimax_unet"] = settings.MINIMAX_UNET
        self._save_state()
        d = await asyncio.to_thread(self._render_kernel_dir)
        try:
            args = ["kernels", "push", "-p", d]
            if settings.KAGGLE_ACCELERATOR:
                args += ["--accelerator", settings.KAGGLE_ACCELERATOR]
            logger.info("[Kaggle] Enviando notebook %s (GPU)...", self.kernel_ref)
            code, out = await self._cli(*args, timeout=300)
        finally:
            # a pasta contem os tokens renderizados: apaga sempre
            shutil.rmtree(d, ignore_errors=True)
        low = out.lower()
        if code != 0 or ("error" in low and "success" not in low):
            raise ProviderUnavailableError(f"kaggle kernels push falhou: {out[:800]}")
        self._started_at = time.monotonic()
        logger.info("[Kaggle] %s", out.splitlines()[-1] if out else "push ok")

    # --- espera ---------------------------------------------------------------------------------

    async def _log_tail(self, max_chars: int = 1500) -> str:
        """Melhor esforco: baixa o log final do kernel para explicar uma falha."""
        d = tempfile.mkdtemp(prefix="nexus_kaggle_out_")
        try:
            await self._cli("kernels", "output", self.kernel_ref, "-p", d, timeout=120)
            for f in Path(d).glob("*.log"):
                raw = f.read_text(encoding="utf-8", errors="replace")
                try:
                    items = json.loads(raw)
                    raw = "".join(i.get("data", "") for i in items)
                except (json.JSONDecodeError, AttributeError, TypeError):
                    pass
                return raw[-max_chars:]
        except Exception as e:  # noqa: BLE001
            return f"(nao foi possivel obter o log: {e})"
        finally:
            shutil.rmtree(d, ignore_errors=True)
        return "(log vazio)"

    async def _poll_ntfy(self) -> str | None:
        """URL mais recente publicada no topico (da sessao atual, se ela for conhecida)."""
        try:
            async with httpx.AsyncClient(timeout=15) as c:
                r = await c.get(f"{settings.NTFY_SERVER.rstrip('/')}/{self.topic}/json",
                                params={"poll": "1", "since": "all"})
            if r.status_code != 200:
                logger.info("[Kaggle] ntfy respondeu HTTP %s", r.status_code)
                return None
        except httpx.HTTPError as e:
            logger.info("[Kaggle] ntfy indisponivel: %s", e)
            return None
        best = None
        for line in r.text.splitlines():
            try:
                msg = json.loads(line)
            except json.JSONDecodeError:
                continue
            if msg.get("event") != "message":
                continue
            m = _NTFY_RE.match(str(msg.get("message", "")))
            if not m:
                continue
            session, url = m.group(1), m.group(2).rstrip("/")
            if self._session and session != self._session:
                continue
            if not _valid_url(url):
                logger.warning("[Kaggle] URL ignorada (dominio nao e do ngrok): %s", url[:80])
                continue
            best = url      # as mensagens vem em ordem cronologica: a ultima vence
        return best

    async def _wait_until_online(self) -> None:
        # minimax baixa ~40 GB (o repo e gated e o disco do Kaggle e lento em horario de pico)
        startup_s = max(settings.KAGGLE_STARTUP_TIMEOUT_S, 3000) if settings.WAN_PROFILE == "minimax" \
            else settings.KAGGLE_STARTUP_TIMEOUT_S
        deadline = time.monotonic() + startup_s
        last_status_check = 0.0
        t_start = self._started_at or time.monotonic()
        logger.info("[Kaggle] Aguardando o notebook publicar a URL (ntfy: %s, ate %ss)...",
                    self.topic, startup_s)
        while time.monotonic() < deadline:
            url = await self._poll_ntfy()
            if url and url != self._url:
                logger.info("[Kaggle] URL recebida: %s", url)
                self._url = url
                self._save_state()
            if self._url and await self.is_online():
                logger.info("[Kaggle] ComfyUI online apos %ds.", int(time.monotonic() - t_start))
                return
            now = time.monotonic()
            if now - last_status_check > 45:
                last_status_check = now
                st = await self.kernel_status()
                logger.info("[Kaggle] kernel=%s (%ds)", st, int(now - t_start))
                if st in _TERMINAL and now - t_start > _STATUS_SETTLE_S:
                    tail = await self._log_tail()
                    raise ProviderUnavailableError(
                        f"O notebook do Kaggle terminou ({st}) antes de o ComfyUI ficar online.\n"
                        f"--- final do log ---\n{tail}"
                    )
            await asyncio.sleep(10)
        raise ProviderUnavailableError(
            f"Timeout ({startup_s}s) esperando o ComfyUI no Kaggle. "
            f"Veja o log em https://www.kaggle.com/code/{self.kernel_ref}"
        )

    def _check_profile(self) -> None:
        """O notebook ligado so tem os modelos do perfil com que foi iniciado."""
        started = self._state.get("profile")
        if started and started != settings.WAN_PROFILE:
            raise ProviderUnavailableError(
                f"O notebook ligado no Kaggle foi iniciado com WAN_PROFILE={started}, mas o .env agora diz "
                f"{settings.WAN_PROFILE}. Rode `python tools/kaggle_smoke_test.py stop`, espere uns 30 s e "
                "tente de novo."
            )
        if started == "minimax" and settings.WAN_PROFILE == "minimax":
            unet = self._state.get("minimax_unet")
            if unet and unet != settings.MINIMAX_UNET:
                raise ProviderUnavailableError(
                    f"O notebook ligado no Kaggle baixou o modelo {unet}, mas o .env agora diz MINIMAX_UNET="
                    f"{settings.MINIMAX_UNET}. Rode `python tools/kaggle_smoke_test.py stop`, espere uns 30 s "
                    "e tente de novo."
                )
        if started == "r2v" and settings.WAN_PROFILE == "r2v":
            unet = self._state.get("r2v_unet")
            if unet and unet != settings.R2V_UNET:
                raise ProviderUnavailableError(
                    f"O notebook ligado no Kaggle baixou o modelo {unet}, mas o .env agora diz R2V_UNET="
                    f"{settings.R2V_UNET}. Rode `python tools/kaggle_smoke_test.py stop`, espere uns 30 s "
                    "e tente de novo."
                )
        if started == "hunyuan" and settings.WAN_PROFILE == "hunyuan":
            unet = self._state.get("hunyuan_unet")
            if unet and unet != settings.HUNYUAN_UNET:
                raise ProviderUnavailableError(
                    f"O notebook ligado no Kaggle baixou o modelo {unet}, mas o .env agora diz HUNYUAN_UNET="
                    f"{settings.HUNYUAN_UNET}. Rode `python tools/kaggle_smoke_test.py stop`, espere uns 30 s "
                    "e tente de novo."
                )

    async def ensure_online(self) -> None:
        self._require_config()
        if await self.is_online():
            self._check_profile()
            return
        async with self._lock:          # varios jobs na fila nao disparam varios pushes
            if await self.is_online():
                return
            st = await self.kernel_status()
            if st in ("QUEUED", "RUNNING"):
                logger.info("[Kaggle] Notebook ja esta %s; so aguardando.", st)
                self._started_at = self._started_at or time.monotonic()
                if not self._session:
                    logger.warning("[Kaggle] sessao do notebook desconhecida; aceitando a URL mais recente do ntfy.")
            else:
                await self.start()
            await self._wait_until_online()

    # --- desligar -------------------------------------------------------------------------------

    async def stop(self) -> bool:
        """Pede ao notebook para se desligar (arquivo de parada). Retorna True se o pedido foi aceito."""
        if not await self.is_online():
            return False
        png = (b"\x89PNG\r\n\x1a\n\x00\x00\x00\rIHDR\x00\x00\x00\x01\x00\x00\x00\x01\x08\x06\x00\x00\x00"
               b"\x1f\x15\xc4\x89\x00\x00\x00\rIDATx\x9cc\xf8\xff\xff?\x00\x05\xfe\x02\xfe\xa7\x9a\xa0\xa0"
               b"\x00\x00\x00\x00IEND\xaeB`\x82")
        try:
            async with httpx.AsyncClient(timeout=15, headers=NGROK_HEADERS) as c:
                r = await c.post(
                    f"{self.base_url}/upload/image",
                    files={"image": (STOP_FILE_NAME, io.BytesIO(png), "image/png")},
                    data={"type": "input", "overwrite": "true"},
                )
                return r.status_code == 200
        except httpx.HTTPError:
            return False


kaggle_manager = KaggleComfyUIManager()
