@echo off
setlocal EnableExtensions
chcp 65001 >nul
title Nexus-Bridge v8.0
cd /d "%~dp0"

rem ============================================================
rem  Nexus-Bridge v8.0 - launcher (perfil LITE: notebook sem GPU, 8 GB de RAM)
rem  Uso:  start.bat           (interativo)
rem        start.bat silent    (sem perguntas e sem pause; use no start.vbs)
rem ============================================================

rem ---- Configuracao ----
rem Padrao: SO esta maquina enxerga o Nexus. Para abrir na rede: set NEXUS_HOST=0.0.0.0
rem E configure API_REQUIRE_TOKEN=true + TOOLS_API_TOKEN no .env.
if not defined NEXUS_HOST set "NEXUS_HOST=127.0.0.1"
set "HOST=%NEXUS_HOST%"
set "PORT=666"
set "REQ_FILE=requirements.lite.txt"
set "MAX_RESTARTS=5"
rem Python usado so para CRIAR a venv, caso ela nao exista (ex.: py -3.11)
set "PY_NEW=py -3"

set "SILENT="
if /i "%~1"=="silent" set "SILENT=1"

set "PYTHONUTF8=1"
set "PYTHONUNBUFFERED=1"

rem ---- Ajustes para i3-3110M (2 nucleos / 4 threads) ----
rem 2 threads de calculo = nucleos fisicos; mais que isso so disputa CPU com o Windows.
if not defined OMP_NUM_THREADS set "OMP_NUM_THREADS=2"
if not defined MKL_NUM_THREADS set "MKL_NUM_THREADS=2"
if not defined OPENBLAS_NUM_THREADS set "OPENBLAS_NUM_THREADS=2"
set "TOKENIZERS_PARALLELISM=false"
rem Ollama (herdado se este script o iniciar): 1 modelo por vez, 1 requisicao por vez, descarrega rapido.
if not defined OLLAMA_MAX_LOADED_MODELS set "OLLAMA_MAX_LOADED_MODELS=1"
if not defined OLLAMA_NUM_PARALLEL set "OLLAMA_NUM_PARALLEL=1"
if not defined OLLAMA_KEEP_ALIVE set "OLLAMA_KEEP_ALIVE=2m"

rem ---- 1. venv ----
set "NEED_INSTALL="
if not exist "venv\Scripts\python.exe" (
    echo [*] venv nao encontrada. Criando...
    %PY_NEW% -m venv venv || goto :erro
    set "NEED_INSTALL=1"
)
set "PY=venv\Scripts\python.exe"
set "VIRTUAL_ENV=%CD%\venv"
set "PATH=%CD%\venv\Scripts;%PATH%"

rem ---- 2. dependencias (so instala se faltar algo essencial) ----
if not defined NEED_INSTALL (
    "%PY%" -c "import fastapi, uvicorn, pydantic_settings, httpx" >nul 2>&1
    if errorlevel 1 set "NEED_INSTALL=1"
)
if defined NEED_INSTALL (
    echo [*] Instalando dependencias - pode demorar bastante na primeira vez...
    "%PY%" -m pip install --upgrade pip >nul 2>&1
    echo [*] torch CPU...
    "%PY%" -m pip install torch==2.5.1 torchaudio==2.5.1 --index-url https://download.pytorch.org/whl/cpu || goto :erro
    "%PY%" -m pip install -r "%REQ_FILE%" || goto :erro
)

rem ---- 3. .env ----
if not exist ".env" (
    if exist ".env.example" (
        copy /y ".env.example" ".env" >nul
        echo [!] .env criado a partir do .env.example - revise as chaves.
    ) else (
        echo [!] .env nao encontrado - usando valores padrao.
    )
)

rem ---- 4. Ollama (le OLLAMA_HOST do .env; sobe sozinho se for local) ----
set "OLLAMA_URL=http://localhost:11434"
if exist ".env" for /f "usebackq tokens=1,* delims==" %%A in (`findstr /b /i /c:"OLLAMA_HOST=" ".env"`) do set "OLLAMA_URL=%%B"
set "OLLAMA_URL=%OLLAMA_URL:"=%"

curl.exe -s -f -m 3 -o NUL "%OLLAMA_URL%/api/tags" >nul 2>&1
if not errorlevel 1 goto :ollama_ok

echo %OLLAMA_URL% | findstr /i "localhost 127.0.0.1" >nul
if errorlevel 1 (
    echo [!] Ollama remoto sem resposta: %OLLAMA_URL%
    goto :ollama_ok
)
where ollama >nul 2>&1
if errorlevel 1 (
    echo [!] Ollama offline e nao esta no PATH - o chat nao vai funcionar.
    goto :ollama_ok
)
echo [*] Ollama offline. Iniciando...
start "Ollama" /min ollama serve
for /l %%i in (1,1,30) do (
    ping -n 2 127.0.0.1 >nul
    curl.exe -s -f -m 2 -o NUL "%OLLAMA_URL%/api/tags" >nul 2>&1 && goto :ollama_ok
)
echo [!] Ollama nao respondeu em 30s - seguindo mesmo assim.
:ollama_ok

rem ---- 5. ffmpeg (usado por anuncios/dublagem) ----
where ffmpeg >nul 2>&1 || echo [!] ffmpeg nao esta no PATH - anuncios e dublagem podem falhar.

rem ---- 6. porta ocupada? ----
set "PID="
for /f "tokens=5" %%P in ('netstat -ano ^| findstr /r /c:":%PORT% .*LISTENING"') do set "PID=%%P"
if defined PID (
    echo [!] A porta %PORT% ja esta em uso pelo PID %PID%:
    tasklist /fi "PID eq %PID%" /fo table /nh
    if defined SILENT exit /b 1
    choice /c SN /m "Encerrar esse processo e continuar"
    if errorlevel 2 exit /b 1
    taskkill /f /pid %PID% >nul 2>&1
    ping -n 3 127.0.0.1 >nul
)

rem ---- 7. servidor, com reinicio automatico se cair ----
rem --no-access-log: o front consulta /api/status e os jobs a cada poucos segundos; logar cada GET
rem custa I/O e enche o console. Os logs de verdade ficam em logs\nexus.log (e crashes em logs\faulthandler.log).
set /a TRIES=0
:run
echo.
echo [*] Nexus-Bridge v8.0 em http://%HOST%:%PORT%  -  docs em /docs  -  Ctrl+C para parar
"%PY%" -m uvicorn app.main:app --host %HOST% --port %PORT% --no-access-log
set "RC=%errorlevel%"

if "%RC%"=="0" goto :fim
rem -1073741510 = Ctrl+C no Windows
if "%RC%"=="-1073741510" goto :fim

set /a TRIES+=1
if %TRIES% GTR %MAX_RESTARTS% (
    echo [X] O servidor caiu %MAX_RESTARTS% vezes seguidas. Abortando. Veja logs\nexus.log e logs\faulthandler.log
    goto :erro
)
echo.
echo [!] Servidor caiu - codigo %RC%. Reiniciando em 5s - tentativa %TRIES% de %MAX_RESTARTS%...
ping -n 6 127.0.0.1 >nul
goto :run

:erro
echo.
echo [X] Falha ao iniciar. Veja as mensagens acima.
if not defined SILENT pause
exit /b 1

:fim
echo.
echo Nexus-Bridge encerrado.
if not defined SILENT pause
exit /b 0
