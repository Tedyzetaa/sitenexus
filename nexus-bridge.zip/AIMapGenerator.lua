-- AI Map Generator / Assistente de código (Plugin do Roblox Studio)
--  * Analisa seus scripts ARQUIVO POR ARQUIVO (estilo Copilot)
--  * Chat sobre o código (contexto = scripts selecionados ou o script aberto no editor)
--  * Sugere correções com diff e aplica com Ctrl+Z
--  * Gera mapas a partir de um prompt (botão "Gerar mapa")
--
-- Instalação: cole em um Script > botão direito > "Save as Local Plugin..." (pasta padrão).
-- Requer: Game Settings > Security > "Allow HTTP Requests".

local HttpService = game:GetService("HttpService")
local ChangeHistoryService = game:GetService("ChangeHistoryService")
local Selection = game:GetService("Selection")
local Workspace = game:GetService("Workspace")
local ScriptEditorService = game:GetService("ScriptEditorService")
local StudioService = game:GetService("StudioService")

local BASE_URL = "http://localhost:666/api/roblox"
local POLL_INTERVAL = 3          -- segundos entre consultas ao backend
local POLL_TIMEOUT = 900         -- desiste de um job após 15 minutos
local YIELD_EVERY = 50           -- peças criadas antes de ceder o frame (gerar mapa)
local MAX_FILES_PER_RUN = 25     -- arquivos por rodada de "Analisar arquivos"
local INDEX_LIMIT = 80           -- nomes de arquivos enviados como contexto
local MAX_CONTEXT_FILES = 6      -- arquivos enviados ao chat
local MAX_SOURCE_CHARS = 200000  -- limite do backend por arquivo

local SCAN_SERVICES = {
	"Workspace", "ServerScriptService", "ServerStorage", "ReplicatedStorage", "ReplicatedFirst",
	"StarterGui", "StarterPack", "StarterPlayer", "Lighting", "SoundService",
}

----------------------------------------------------------------------
-- Utilidades
----------------------------------------------------------------------
local function esc(s)
	s = tostring(s)
	s = string.gsub(s, "&", "&amp;")
	s = string.gsub(s, "<", "&lt;")
	s = string.gsub(s, ">", "&gt;")
	return s
end

local function getPath(inst)
	local parts = {}
	local cur = inst
	while cur and cur ~= game do
		table.insert(parts, 1, cur.Name)
		cur = cur.Parent
	end
	return table.concat(parts, ".")
end

local function readSource(inst)
	local ok, src = pcall(function()
		return ScriptEditorService:GetEditorSource(inst)
	end)
	if ok and type(src) == "string" then
		return src
	end
	local ok2, src2 = pcall(function()
		return inst.Source
	end)
	if ok2 and type(src2) == "string" then
		return src2
	end
	return nil
end

local function isBlank(s)
	return #string.gsub(s, "%s", "") == 0
end

----------------------------------------------------------------------
-- UI
----------------------------------------------------------------------
local toolbar = plugin:CreateToolbar("AI Map Generator")
local toggleButton = toolbar:CreateButton("AI Map", "Abrir assistente de código e gerador de mapas", "")
toggleButton.ClickableWhenViewportHidden = true

local widgetInfo = DockWidgetPluginGuiInfo.new(Enum.InitialDockState.Float, false, false, 460, 680, 340, 460)
local widget = plugin:CreateDockWidgetPluginGui("AIMapGeneratorWidget", widgetInfo)
widget.Title = "AI Assistant"

local root = Instance.new("Frame")
root.Size = UDim2.fromScale(1, 1)
root.BackgroundColor3 = Color3.fromRGB(40, 40, 40)
root.BorderSizePixel = 0
root.Parent = widget

local rootPadding = Instance.new("UIPadding")
rootPadding.PaddingTop = UDim.new(0, 8)
rootPadding.PaddingBottom = UDim.new(0, 8)
rootPadding.PaddingLeft = UDim.new(0, 8)
rootPadding.PaddingRight = UDim.new(0, 8)
rootPadding.Parent = root

local function makeButton(parent, text, color, index, count)
	local b = Instance.new("TextButton")
	b.Position = UDim2.new((index - 1) / count, if index == 1 then 0 else 3, 0, 0)
	b.Size = UDim2.new(1 / count, if index == 1 or index == count then -3 else -6, 1, 0)
	b.BackgroundColor3 = color
	b.TextColor3 = Color3.new(1, 1, 1)
	b.Text = text
	b.Font = Enum.Font.GothamBold
	b.TextSize = 12
	b.AutoButtonColor = true
	b.Parent = parent
	return b
end

local topRow = Instance.new("Frame")
topRow.Size = UDim2.new(1, 0, 0, 32)
topRow.BackgroundTransparency = 1
topRow.Parent = root

local analyzeAllButton = makeButton(topRow, "Analisar arquivos", Color3.fromRGB(0, 120, 215), 1, 4)
local generateButton = makeButton(topRow, "Gerar mapa", Color3.fromRGB(46, 139, 87), 2, 4)
local stopButton = makeButton(topRow, "Parar", Color3.fromRGB(170, 70, 60), 3, 4)
local clearButton = makeButton(topRow, "Limpar", Color3.fromRGB(80, 80, 80), 4, 4)

local statusLabel = Instance.new("TextLabel")
statusLabel.Position = UDim2.new(0, 0, 0, 38)
statusLabel.Size = UDim2.new(1, 0, 0, 30)
statusLabel.BackgroundTransparency = 1
statusLabel.TextColor3 = Color3.fromRGB(200, 200, 200)
statusLabel.Text = "Pronto."
statusLabel.TextWrapped = true
statusLabel.TextXAlignment = Enum.TextXAlignment.Left
statusLabel.TextYAlignment = Enum.TextYAlignment.Top
statusLabel.Font = Enum.Font.Gotham
statusLabel.TextSize = 12
statusLabel.Parent = root

local feed = Instance.new("ScrollingFrame")
feed.Position = UDim2.new(0, 0, 0, 72)
feed.Size = UDim2.new(1, 0, 1, -180)
feed.BackgroundColor3 = Color3.fromRGB(28, 28, 28)
feed.BorderSizePixel = 0
feed.ScrollBarThickness = 6
feed.CanvasSize = UDim2.new(0, 0, 0, 0)
feed.AutomaticCanvasSize = Enum.AutomaticSize.Y
feed.Parent = root

local feedLayout = Instance.new("UIListLayout")
feedLayout.SortOrder = Enum.SortOrder.LayoutOrder
feedLayout.Padding = UDim.new(0, 8)
feedLayout.Parent = feed

local feedPadding = Instance.new("UIPadding")
feedPadding.PaddingTop = UDim.new(0, 6)
feedPadding.PaddingBottom = UDim.new(0, 6)
feedPadding.PaddingLeft = UDim.new(0, 6)
feedPadding.PaddingRight = UDim.new(0, 10)
feedPadding.Parent = feed

local inputArea = Instance.new("Frame")
inputArea.AnchorPoint = Vector2.new(0, 1)
inputArea.Position = UDim2.new(0, 0, 1, 0)
inputArea.Size = UDim2.new(1, 0, 0, 100)
inputArea.BackgroundTransparency = 1
inputArea.Parent = root

local promptBox = Instance.new("TextBox")
promptBox.Size = UDim2.new(1, -88, 0, 70)
promptBox.BackgroundColor3 = Color3.fromRGB(25, 25, 25)
promptBox.TextColor3 = Color3.new(1, 1, 1)
promptBox.PlaceholderText = "Pergunte sobre o código (ex: por que o DanceFloor não troca de cor?)\nOu descreva um mapa e clique em Gerar mapa."
promptBox.PlaceholderColor3 = Color3.fromRGB(140, 140, 140)
promptBox.Text = ""
promptBox.TextWrapped = true
promptBox.MultiLine = true
promptBox.ClearTextOnFocus = false
promptBox.TextXAlignment = Enum.TextXAlignment.Left
promptBox.TextYAlignment = Enum.TextYAlignment.Top
promptBox.Font = Enum.Font.Gotham
promptBox.TextSize = 12
promptBox.Parent = inputArea

local sendButton = Instance.new("TextButton")
sendButton.Position = UDim2.new(1, -82, 0, 0)
sendButton.Size = UDim2.new(0, 82, 0, 70)
sendButton.BackgroundColor3 = Color3.fromRGB(0, 120, 215)
sendButton.TextColor3 = Color3.new(1, 1, 1)
sendButton.Text = "Perguntar"
sendButton.Font = Enum.Font.GothamBold
sendButton.TextSize = 13
sendButton.Parent = inputArea

local contextLabel = Instance.new("TextLabel")
contextLabel.Position = UDim2.new(0, 0, 0, 74)
contextLabel.Size = UDim2.new(1, 0, 0, 24)
contextLabel.BackgroundTransparency = 1
contextLabel.TextColor3 = Color3.fromRGB(130, 130, 130)
contextLabel.Text = "Contexto do chat: scripts selecionados ou o script aberto no editor."
contextLabel.TextWrapped = true
contextLabel.TextXAlignment = Enum.TextXAlignment.Left
contextLabel.TextYAlignment = Enum.TextYAlignment.Top
contextLabel.Font = Enum.Font.Gotham
contextLabel.TextSize = 11
contextLabel.Parent = inputArea

toggleButton.Click:Connect(function()
	widget.Enabled = not widget.Enabled
end)
widget:GetPropertyChangedSignal("Enabled"):Connect(function()
	toggleButton:SetActive(widget.Enabled)
end)

local function setStatus(text, isError)
	statusLabel.Text = text
	statusLabel.TextColor3 = if isError then Color3.fromRGB(255, 110, 110) else Color3.fromRGB(200, 200, 200)
end

----------------------------------------------------------------------
-- Cartões (mensagens do "chat")
----------------------------------------------------------------------
local cardCounter = 0

local function scrollToBottom()
	task.defer(function()
		feed.CanvasPosition = Vector2.new(0, math.max(0, feed.AbsoluteCanvasSize.Y))
	end)
end

-- Cria um cartão. opts: color, mono (fonte monoespaçada no corpo), rich (padrão true)
local function addCard(titleText, bodyText, opts)
	opts = opts or {}
	cardCounter += 1

	local frame = Instance.new("Frame")
	frame.LayoutOrder = cardCounter
	frame.Size = UDim2.new(1, 0, 0, 0)
	frame.AutomaticSize = Enum.AutomaticSize.Y
	frame.BackgroundColor3 = opts.color or Color3.fromRGB(38, 38, 38)
	frame.BorderSizePixel = 0
	frame.Parent = feed

	local pad = Instance.new("UIPadding")
	pad.PaddingTop = UDim.new(0, 8)
	pad.PaddingBottom = UDim.new(0, 8)
	pad.PaddingLeft = UDim.new(0, 8)
	pad.PaddingRight = UDim.new(0, 8)
	pad.Parent = frame

	local list = Instance.new("UIListLayout")
	list.SortOrder = Enum.SortOrder.LayoutOrder
	list.Padding = UDim.new(0, 6)
	list.Parent = frame

	local title = Instance.new("TextLabel")
	title.LayoutOrder = 1
	title.Size = UDim2.new(1, 0, 0, 0)
	title.AutomaticSize = Enum.AutomaticSize.Y
	title.BackgroundTransparency = 1
	title.TextColor3 = Color3.fromRGB(255, 255, 255)
	title.Text = titleText
	title.TextWrapped = true
	title.TextXAlignment = Enum.TextXAlignment.Left
	title.Font = Enum.Font.GothamBold
	title.TextSize = 13
	title.Parent = frame

	local body = Instance.new("TextLabel")
	body.LayoutOrder = 2
	body.Size = UDim2.new(1, 0, 0, 0)
	body.AutomaticSize = Enum.AutomaticSize.Y
	body.BackgroundTransparency = 1
	body.TextColor3 = Color3.fromRGB(220, 220, 220)
	body.RichText = opts.rich ~= false
	body.Text = string.sub(bodyText, 1, 15000)
	body.TextWrapped = true
	body.TextXAlignment = Enum.TextXAlignment.Left
	body.TextYAlignment = Enum.TextYAlignment.Top
	body.Font = if opts.mono then Enum.Font.Code else Enum.Font.Gotham
	body.TextSize = if opts.mono then 12 else 12
	body.Parent = frame

	scrollToBottom()
	return { frame = frame, body = body, row = nil }
end

local function addCardButton(card, text, callback)
	if not card.row then
		local row = Instance.new("Frame")
		row.LayoutOrder = 3
		row.Size = UDim2.new(1, 0, 0, 26)
		row.BackgroundTransparency = 1
		row.Parent = card.frame
		local layout = Instance.new("UIListLayout")
		layout.FillDirection = Enum.FillDirection.Horizontal
		layout.SortOrder = Enum.SortOrder.LayoutOrder
		layout.Padding = UDim.new(0, 6)
		layout.Parent = row
		card.row = row
	end
	local b = Instance.new("TextButton")
	b.Size = UDim2.new(0, 0, 1, 0)
	b.AutomaticSize = Enum.AutomaticSize.X
	b.BackgroundColor3 = Color3.fromRGB(70, 70, 70)
	b.TextColor3 = Color3.new(1, 1, 1)
	b.Text = text
	b.Font = Enum.Font.GothamBold
	b.TextSize = 12
	b.Parent = card.row
	local bpad = Instance.new("UIPadding")
	bpad.PaddingLeft = UDim.new(0, 10)
	bpad.PaddingRight = UDim.new(0, 10)
	bpad.Parent = b
	b.MouseButton1Click:Connect(function()
		callback(b)
	end)
	return b
end

----------------------------------------------------------------------
-- HTTP (sempre dentro de pcall) + polling a cada 3 s
----------------------------------------------------------------------
local cancelRequested = false

local function startJob(endpoint, bodyTable)
	local okEnc, body = pcall(function()
		return HttpService:JSONEncode(bodyTable)
	end)
	if not okEnc then
		return nil, "Não consegui converter os dados para JSON: " .. tostring(body)
	end

	local ok, response = pcall(function()
		return HttpService:PostAsync(BASE_URL .. endpoint, body, Enum.HttpContentType.ApplicationJson)
	end)
	if not ok then
		return nil, "Falha na requisição POST: " .. tostring(response)
	end

	local decoded
	local okJson = pcall(function()
		decoded = HttpService:JSONDecode(response)
	end)
	if not okJson or type(decoded) ~= "table" or type(decoded.job_id) ~= "string" then
		return nil, "Resposta inesperada do backend ao iniciar o job."
	end
	return decoded.job_id, nil
end

local function fetchJob(jobId)
	local ok, response = pcall(function()
		return HttpService:GetAsync(BASE_URL .. "/jobs/" .. jobId, true) -- true = nocache
	end)
	if not ok then
		return nil, "Falha na requisição GET: " .. tostring(response)
	end

	local decoded
	local okJson = pcall(function()
		decoded = HttpService:JSONDecode(response)
	end)
	if not okJson or type(decoded) ~= "table" then
		return nil, "JSON inválido recebido no polling."
	end
	return decoded, nil
end

-- Retorna (result, nil) ou (nil, mensagemDeErro). "Cancelado." quando o usuário clica em Parar.
local function waitForJob(jobId, progressPrefix)
	local startedAt = os.clock()
	local consecutiveFailures = 0

	while true do
		if cancelRequested then
			return nil, "Cancelado."
		end
		if os.clock() - startedAt > POLL_TIMEOUT then
			return nil, "Tempo esgotado aguardando a IA."
		end

		task.wait(POLL_INTERVAL)

		local job, pollErr = fetchJob(jobId)
		if not job then
			consecutiveFailures += 1
			warn("[AI Map] " .. tostring(pollErr))
			if consecutiveFailures >= 3 then
				return nil, pollErr or "Falha repetida no polling."
			end
		else
			consecutiveFailures = 0
			if job.status == "done" then
				return job.result, nil
			elseif job.status == "error" then
				local msg = tostring(job.error)
				warn("[AI Map] " .. msg)
				return nil, msg
			else
				setStatus(("%sIA trabalhando... (%ds)"):format(progressPrefix or "", math.floor(os.clock() - startedAt)))
			end
		end
	end
end

----------------------------------------------------------------------
-- Estado ocupado
----------------------------------------------------------------------
local busy = false

local function setBusy(value)
	busy = value
	analyzeAllButton.Active = not value
	generateButton.Active = not value
	sendButton.Active = not value
	clearButton.Active = not value
	stopButton.Active = value
end
setBusy(false)

----------------------------------------------------------------------
-- Coleta de scripts
----------------------------------------------------------------------
local function scanProject()
	local found, seen = {}, {}
	for _, name in ipairs(SCAN_SERVICES) do
		local ok, svc = pcall(game.GetService, game, name)
		if ok and svc then
			for _, d in ipairs(svc:GetDescendants()) do
				if not seen[d] and d:IsA("LuaSourceContainer") then
					seen[d] = true
					table.insert(found, d)
				end
			end
		end
	end
	table.sort(found, function(a, b)
		return getPath(a) < getPath(b)
	end)
	return found
end

-- Scripts da seleção (incluindo descendentes); se nada selecionado, o projeto inteiro.
local function collectScripts()
	local selection = Selection:Get()
	if #selection == 0 then
		return scanProject(), "projeto inteiro"
	end
	local found, seen = {}, {}
	local function add(inst)
		if not seen[inst] and inst:IsA("LuaSourceContainer") then
			seen[inst] = true
			table.insert(found, inst)
		end
	end
	for _, rootInst in ipairs(selection) do
		add(rootInst)
		for _, d in ipairs(rootInst:GetDescendants()) do
			add(d)
		end
	end
	table.sort(found, function(a, b)
		return getPath(a) < getPath(b)
	end)
	return found, ("%d item(ns) selecionado(s)"):format(#selection)
end

local function projectIndex()
	local index = {}
	for _, inst in ipairs(scanProject()) do
		if #index >= INDEX_LIMIT then
			break
		end
		table.insert(index, getPath(inst))
	end
	return index
end

local function makeFile(inst)
	local src = readSource(inst)
	if not src or isBlank(src) then
		return nil
	end
	if #src > MAX_SOURCE_CHARS then
		src = string.sub(src, 1, MAX_SOURCE_CHARS)
	end
	return { inst = inst, path = getPath(inst), class_name = inst.ClassName, source = src }
end

-- Contexto do chat: seleção; se não houver, o script aberto no editor.
local function chatContextFiles()
	local files = {}
	local selection = Selection:Get()
	if #selection > 0 then
		local function add(inst)
			if #files < MAX_CONTEXT_FILES and inst:IsA("LuaSourceContainer") then
				local f = makeFile(inst)
				if f then
					table.insert(files, f)
				end
			end
		end
		for _, rootInst in ipairs(selection) do
			add(rootInst)
			for _, d in ipairs(rootInst:GetDescendants()) do
				add(d)
			end
		end
	end
	if #files == 0 then
		local okActive, active = pcall(function()
			return StudioService.ActiveScript
		end)
		if okActive and active and active:IsA("LuaSourceContainer") then
			local f = makeFile(active)
			if f then
				table.insert(files, f)
			end
		end
	end
	return files
end

----------------------------------------------------------------------
-- Formatação dos resultados
----------------------------------------------------------------------
local SEVERITY_COLOR = { alta = "#ff6b6b", media = "#ffb347", baixa = "#9ecbff" }

local function formatScriptAnalysis(res)
	local a = res.analysis or {}
	local out = {}
	table.insert(out, "<b>Resumo</b>\n" .. esc(a.summary or "-"))

	local issues = a.issues or {}
	table.insert(out, "")
	table.insert(out, "<b>Problemas</b>")
	if #issues == 0 then
		table.insert(out, "Nenhum problema encontrado.")
	else
		for _, it in ipairs(issues) do
			local sev = tostring(it.severity or "media")
			local color = SEVERITY_COLOR[sev] or "#ffffff"
			local line = math.floor(tonumber(it.line) or 0)
			local where = if line > 0 then ("L%d: "):format(line) else ""
			table.insert(out, ('<font color="%s">[%s]</font> %s%s'):format(color, esc(sev), where, esc(it.message or "")))
		end
	end

	local sugg = a.suggestions or {}
	if #sugg > 0 then
		table.insert(out, "")
		table.insert(out, "<b>Sugestões</b>")
		for _, s in ipairs(sugg) do
			table.insert(out, "• " .. esc(s))
		end
	end

	if res.truncated then
		table.insert(out, "")
		table.insert(out, "<i>Arquivo longo: só o início foi analisado.</i>")
	end
	return table.concat(out, "\n")
end

local function formatDiff(diff, maxLines)
	local out, n = {}, 0
	for line in string.gmatch(diff, "[^\n]+") do
		if not (string.sub(line, 1, 3) == "---" or string.sub(line, 1, 3) == "+++") then
			n += 1
			if n > maxLines then
				table.insert(out, "…")
				break
			end
			local first = string.sub(line, 1, 1)
			local color = "#c8c8c8"
			if first == "+" then
				color = "#7ee787"
			elseif first == "-" then
				color = "#ff7b72"
			elseif first == "@" then
				color = "#79c0ff"
			end
			table.insert(out, ('<font color="%s">%s</font>'):format(color, esc(line)))
		end
	end
	return table.concat(out, "\n")
end

----------------------------------------------------------------------
-- Correção: sugerir + aplicar
----------------------------------------------------------------------
local function applyFix(file, newSource, applyButton)
	if not file.inst or not file.inst.Parent then
		setStatus("O script não existe mais.", true)
		return
	end
	if readSource(file.inst) ~= file.source then
		setStatus("O arquivo mudou desde a sugestão. Rode a análise de novo antes de aplicar.", true)
		return
	end

	local recording = ChangeHistoryService:TryBeginRecording("AI: corrigir " .. file.inst.Name)
	local ok = pcall(function()
		ScriptEditorService:UpdateSourceAsync(file.inst, function(_old)
			return newSource
		end)
	end)
	if not ok then
		ok = pcall(function()
			file.inst.Source = newSource
		end)
	end
	if recording then
		ChangeHistoryService:FinishRecording(
			recording,
			if ok then Enum.FinishRecordingOperation.Commit else Enum.FinishRecordingOperation.Cancel
		)
	end

	if ok then
		file.source = newSource
		applyButton.Text = "Aplicado ✓"
		applyButton.Active = false
		setStatus(("Correção aplicada em %s. Ctrl+Z desfaz."):format(file.inst.Name))
	else
		setStatus("Não consegui escrever no script.", true)
	end
end

local function suggestFix(file, issueTexts, instruction)
	if busy then
		setStatus("Aguarde a tarefa atual terminar.", true)
		return
	end
	cancelRequested = false
	setBusy(true)
	setStatus(("Pedindo correção de %s..."):format(file.inst.Name))

	local jobId, startErr = startJob("/fix-script", {
		file = { path = file.path, class_name = file.class_name, source = file.source },
		instruction = instruction or "",
		issues = issueTexts or {},
	})
	if not jobId then
		warn("[AI Map] " .. tostring(startErr))
		setBusy(false)
		setStatus(startErr or "Erro ao iniciar a correção.", true)
		return
	end

	local result, waitErr = waitForJob(jobId, file.inst.Name .. ": ")
	setBusy(false)
	if not result then
		addCard("Correção: " .. file.path, "<font color=\"#ff6b6b\">" .. esc(waitErr or "Erro desconhecido") .. "</font>")
		setStatus(waitErr or "Erro desconhecido.", true)
		return
	end

	local warnText = ""
	for _, w in ipairs(result.warnings or {}) do
		warnText ..= ('<font color="#ffb347">⚠ %s</font>\n'):format(esc(w))
	end
	local header = ("%s\n<b>+%d  −%d linhas</b>\n%s"):format(
		esc(result.explanation or ""),
		math.floor(tonumber(result.added) or 0),
		math.floor(tonumber(result.removed) or 0),
		warnText
	)
	local card = addCard("Correção sugerida: " .. file.path, header .. "\n" .. formatDiff(result.diff or "", 80), { mono = true })
	local newSource = tostring(result.new_source or "")
	if newSource ~= "" and newSource ~= file.source then
		addCardButton(card, "Aplicar", function(btn)
			applyFix(file, newSource, btn)
		end)
	end
	addCardButton(card, "Abrir script", function()
		pcall(function()
			ScriptEditorService:OpenScriptDocumentAsync(file.inst)
		end)
	end)
	setStatus("Correção pronta. Revise o diff e clique em Aplicar.")
end

----------------------------------------------------------------------
-- Analisar arquivos (um por vez)
----------------------------------------------------------------------
local function showScriptResult(file, result)
	local card = addCard(("%s  (%s)"):format(file.path, file.class_name), formatScriptAnalysis(result))

	local issueTexts = {}
	local issues = (result.analysis and result.analysis.issues) or {}
	for _, it in ipairs(issues) do
		local line = math.floor(tonumber(it.line) or 0)
		table.insert(issueTexts, (if line > 0 then ("L%d: "):format(line) else "") .. tostring(it.message))
	end

	addCardButton(card, "Abrir", function()
		pcall(function()
			ScriptEditorService:OpenScriptDocumentAsync(file.inst)
		end)
	end)
	if #issueTexts > 0 then
		addCardButton(card, "Sugerir correção", function()
			suggestFix(file, issueTexts, "")
		end)
	end
end

local function analyzeAll()
	if busy then
		return
	end
	cancelRequested = false
	setBusy(true)
	setStatus("Procurando scripts...")

	local scripts, scope = collectScripts()
	local files = {}
	for _, inst in ipairs(scripts) do
		local f = makeFile(inst)
		if f then
			table.insert(files, f)
		end
	end
	if #files == 0 then
		setBusy(false)
		setStatus("Nenhum script com código encontrado.", true)
		return
	end

	local index = {}
	for i = 1, math.min(#scripts, INDEX_LIMIT) do
		table.insert(index, getPath(scripts[i]))
	end

	local total = math.min(#files, MAX_FILES_PER_RUN)
	local intro = ("Escopo: %s\n%d arquivo(s) com código."):format(scope, #files)
	if #files > total then
		intro ..= (" Analisando os %d primeiros; selecione outros no Explorer para continuar."):format(total)
	end
	addCard("Análise arquivo por arquivo", esc(intro))

	local okCount = 0
	for i = 1, total do
		if cancelRequested then
			break
		end
		local file = files[i]
		local prefix = ("(%d/%d) %s: "):format(i, total, file.inst.Name)
		setStatus(prefix .. "enviando...")

		local jobId, startErr = startJob("/analyze-script", {
			file = { path = file.path, class_name = file.class_name, source = file.source },
			question = "",
			project_index = index,
		})
		if not jobId then
			warn("[AI Map] " .. tostring(startErr))
			addCard("Erro", '<font color="#ff6b6b">' .. esc(startErr) .. "</font>")
			setStatus(startErr or "Erro ao iniciar.", true)
			break -- sem conexão: não adianta tentar os próximos
		end

		local result, waitErr = waitForJob(jobId, prefix)
		if result then
			okCount += 1
			showScriptResult(file, result)
		elseif waitErr == "Cancelado." then
			break
		else
			addCard(file.path, '<font color="#ff6b6b">' .. esc(waitErr or "Erro desconhecido") .. "</font>")
		end
	end

	setBusy(false)
	if cancelRequested then
		setStatus(("Interrompido. %d arquivo(s) analisado(s)."):format(okCount))
	else
		setStatus(("Concluído: %d de %d arquivo(s) analisado(s)."):format(okCount, total))
	end
end

----------------------------------------------------------------------
-- Chat
----------------------------------------------------------------------
local history = {} -- { {role=, content=} }

local function askQuestion()
	if busy then
		return
	end
	local question = promptBox.Text
	if #string.gsub(question, "%s", "") < 2 then
		setStatus("Digite uma pergunta.", true)
		return
	end
	cancelRequested = false
	setBusy(true)
	promptBox.Text = ""
	addCard("Você", esc(question), { color = Color3.fromRGB(32, 52, 78) })
	setStatus("Lendo o contexto...")

	local files = chatContextFiles()
	local payloadFiles = {}
	local names = {}
	for _, f in ipairs(files) do
		table.insert(payloadFiles, { path = f.path, class_name = f.class_name, source = f.source })
		table.insert(names, f.inst.Name)
	end

	local jobId, startErr = startJob("/ask", {
		question = question,
		files = payloadFiles,
		project_index = projectIndex(),
		history = history,
	})
	if not jobId then
		warn("[AI Map] " .. tostring(startErr))
		addCard("Erro", '<font color="#ff6b6b">' .. esc(startErr) .. "</font>")
		setBusy(false)
		setStatus(startErr or "Erro ao iniciar.", true)
		return
	end

	local result, waitErr = waitForJob(jobId, "")
	setBusy(false)
	if not result then
		addCard("Erro", '<font color="#ff6b6b">' .. esc(waitErr or "Erro desconhecido") .. "</font>")
		setStatus(waitErr or "Erro desconhecido.", true)
		return
	end

	local answer = tostring(result.answer or "")
	local ctxText = if #names > 0 then ("Assistente  (contexto: %s)"):format(table.concat(names, ", ")) else "Assistente  (sem script em contexto)"
	addCard(ctxText, esc(answer), { mono = false })

	table.insert(history, { role = "user", content = string.sub(question, 1, 3900) })
	table.insert(history, { role = "assistant", content = string.sub(answer, 1, 3900) })
	while #history > 8 do
		table.remove(history, 1)
	end
	setStatus("Pronto.")
end

----------------------------------------------------------------------
-- Gerar mapa (usa o texto da caixa como prompt)
----------------------------------------------------------------------
local function toMaterial(name)
	local ok, mat = pcall(function()
		return Enum.Material[tostring(name)]
	end)
	if ok and mat then
		return mat
	end
	return Enum.Material.Plastic
end

local function toBrickColor(name)
	local ok, color = pcall(function()
		return BrickColor.new(tostring(name))
	end)
	if ok and color then
		return color
	end
	return BrickColor.new("Medium stone grey")
end

local function buildMap(result, prompt)
	if type(result) ~= "table" or type(result.parts) ~= "table" then
		return nil, "Resultado sem a lista 'parts'."
	end

	local model = Instance.new("Model")
	model.Name = "AIMap_" .. string.gsub(string.sub(prompt, 1, 24), "[^%w_]", "_")

	local created = 0
	for i, data in ipairs(result.parts) do
		local ok, err = pcall(function()
			local pos, size = data.position, data.size
			local part = Instance.new("Part")
			part.Name = tostring(data.name or ("Part" .. i))
			part.Anchored = true
			part.Size = Vector3.new(size.x, size.y, size.z)
			part.CFrame = CFrame.new(pos.x, pos.y, pos.z)
				* CFrame.Angles(0, math.rad(tonumber(data.rotation_y) or 0), 0)
			part.Material = toMaterial(data.material)
			part.BrickColor = toBrickColor(data.brick_color)
			part.TopSurface = Enum.SurfaceType.Smooth
			part.BottomSurface = Enum.SurfaceType.Smooth
			part.Parent = model
		end)
		if ok then
			created += 1
		else
			warn(("[AI Map] Peça %d ignorada: %s"):format(i, tostring(err)))
		end
		if i % YIELD_EVERY == 0 then
			task.wait()
		end
	end

	if created == 0 then
		model:Destroy()
		return nil, "Nenhuma peça válida foi criada."
	end

	model.Parent = Workspace
	return model, nil
end

local function generateMap()
	if busy then
		return
	end
	local prompt = promptBox.Text
	if #string.gsub(prompt, "%s", "") < 3 then
		setStatus("Descreva o mapa na caixa de texto antes de gerar.", true)
		return
	end
	cancelRequested = false
	setBusy(true)
	addCard("Gerar mapa", esc(prompt), { color = Color3.fromRGB(32, 52, 78) })
	setStatus("Enviando prompt ao backend...")

	local jobId, startErr = startJob("/generate-map", { prompt = prompt })
	if not jobId then
		warn("[AI Map] " .. tostring(startErr))
		setBusy(false)
		setStatus(startErr or "Erro ao iniciar o job.", true)
		return
	end

	local result, waitErr = waitForJob(jobId, "")
	if not result then
		setBusy(false)
		addCard("Erro", '<font color="#ff6b6b">' .. esc(waitErr or "Erro desconhecido") .. "</font>")
		setStatus(waitErr or "Erro desconhecido.", true)
		return
	end

	setStatus("Construindo o mapa no Workspace...")
	local recording = ChangeHistoryService:TryBeginRecording("AI Map Generator")
	local model, buildErr = buildMap(result, prompt)
	if recording then
		ChangeHistoryService:FinishRecording(
			recording,
			if model then Enum.FinishRecordingOperation.Commit else Enum.FinishRecordingOperation.Cancel
		)
	end

	setBusy(false)
	if model then
		local msg = ("Mapa criado: %d peças em Workspace.%s"):format(#model:GetChildren(), model.Name)
		addCard("Mapa criado", esc(msg))
		setStatus(msg)
	else
		setStatus(buildErr or "Erro ao construir o mapa.", true)
	end
end

----------------------------------------------------------------------
-- Ligações
----------------------------------------------------------------------
analyzeAllButton.MouseButton1Click:Connect(analyzeAll)
generateButton.MouseButton1Click:Connect(generateMap)
sendButton.MouseButton1Click:Connect(askQuestion)
stopButton.MouseButton1Click:Connect(function()
	if busy then
		cancelRequested = true
		setStatus("Parando... (o job atual termina em segundo plano)")
	end
end)
clearButton.MouseButton1Click:Connect(function()
	if busy then
		return
	end
	for _, c in ipairs(feed:GetChildren()) do
		if c:IsA("Frame") then
			c:Destroy()
		end
	end
	history = {}
	setStatus("Pronto.")
end)

addCard(
	"Como usar",
	"<b>Analisar arquivos</b>: lê seus scripts um por um (os selecionados no Explorer, ou o projeto inteiro) "
		.. "e mostra problemas por linha.\n"
		.. "<b>Perguntar</b>: chat sobre o script aberto no editor ou os selecionados.\n"
		.. "<b>Sugerir correção</b> (em cada arquivo): mostra o diff e só altera o código quando você clica em Aplicar (Ctrl+Z desfaz).\n"
		.. "<b>Gerar mapa</b>: usa o texto da caixa como prompt e cria as peças no Workspace."
)
