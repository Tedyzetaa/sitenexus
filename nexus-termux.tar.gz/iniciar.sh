#!/usr/bin/env bash
# ============================================================
#  Inicia o Nexus-Bridge (confere se ha atualizacao antes)
#
#    ./iniciar.sh                 primeiro plano (Ctrl+C para parar)
#    ./iniciar.sh bg              segundo plano
#    ./iniciar.sh --sem-atualizar nao consulta o GitHub
# ============================================================
main() {
    local here mode="iniciar" check=1 a r rc
    here="$(cd "$(dirname "$(readlink -f "${BASH_SOURCE[0]}")")" && pwd)"
    export NEXUS_HOME="$here"
    for a in "$@"; do
        case "$a" in
            bg|fundo|background) mode="bg" ;;
            --sem-atualizar|-n)  check=0 ;;
            -h|--help|ajuda) sed -n '2,8p' "$here/iniciar.sh" | sed 's/^# \{0,1\}//'; return 0 ;;
            *) echo "Opcao desconhecida: $a"; return 1 ;;
        esac
    done

    if [ "$check" -eq 1 ]; then
        bash "$here/termux/nexus.sh" verificar -q; rc=$?
        if [ "$rc" -eq 10 ]; then
            echo "[!] Ha uma versao nova do Nexus-Bridge no GitHub."
            if [ -t 0 ] && [ -t 1 ]; then
                read -r -p "    Atualizar agora? [S/n] " r || r="n"
                case "${r:-s}" in
                    s|S|y|Y|sim|Sim) bash "$here/atualizar.sh" || echo "[!] A atualizacao falhou - iniciando a versao atual." ;;
                esac
            else
                echo "    Atualize com:  nexus atualizar"
            fi
        fi
    fi
    exec bash "$here/termux/nexus.sh" "$mode"
}
main "$@"
exit $?
