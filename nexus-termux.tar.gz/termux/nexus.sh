#!/usr/bin/env bash
# ============================================================
#  nexus - controle do Nexus-Bridge no Termux
#  Uso: nexus <comando>        (nexus ajuda  lista tudo)
# ============================================================
set -u
NEXUS_HOME="${NEXUS_HOME:-$(cd "$(dirname "$(readlink -f "${BASH_SOURCE[0]}")")/.." && pwd)}"
cd "$NEXUS_HOME" || { echo "[X] Pasta nao encontrada: $NEXUS_HOME"; exit 1; }

PY="$NEXUS_HOME/venv/bin/python"
ENV_FILE="$NEXUS_HOME/.env"
RUN_DIR="$NEXUS_HOME/.run"
PID_FILE="$RUN_DIR/nexus.pid"
OLLAMA_PID_FILE="$RUN_DIR/ollama.pid"
LOG_FILE="$NEXUS_HOME/logs/nexus-console.log"
mkdir -p "$RUN_DIR" "$NEXUS_HOME/logs"

# valores do instalador (porta/host); o ambiente tem prioridade
[ -f "$NEXUS_HOME/.nexus-install" ] && . "$NEXUS_HOME/.nexus-install"
HOST="${NEXUS_HOST:-${INSTALL_HOST:-127.0.0.1}}"
PORT="${NEXUS_PORT:-${INSTALL_PORT:-8666}}"
MAX_RESTARTS="${MAX_RESTARTS:-5}"

export PYTHONUTF8=1 PYTHONUNBUFFERED=1 TOKENIZERS_PARALLELISM=false
export OMP_NUM_THREADS="${OMP_NUM_THREADS:-2}" OPENBLAS_NUM_THREADS="${OPENBLAS_NUM_THREADS:-2}" MKL_NUM_THREADS="${MKL_NUM_THREADS:-2}"
export OLLAMA_MAX_LOADED_MODELS="${OLLAMA_MAX_LOADED_MODELS:-1}" OLLAMA_NUM_PARALLEL="${OLLAMA_NUM_PARALLEL:-1}" OLLAMA_KEEP_ALIVE="${OLLAMA_KEEP_ALIVE:-2m}"

env_get() { # env_get CHAVE  -> valor do .env (sem aspas)
    [ -f "$ENV_FILE" ] || return 0
    grep -E "^$1=" "$ENV_FILE" | tail -n1 | cut -d= -f2- | sed -e 's/\r$//' -e 's/^"//' -e 's/"$//'
}

is_running() { [ -f "$PID_FILE" ] && kill -0 "$(cat "$PID_FILE" 2>/dev/null)" 2>/dev/null; }

# /api/health responde 503 quando algum servico opcional (Ollama etc.) esta offline, entao
# "no ar" = qualquer resposta HTTP (000 = sem conexao).
alive() { local c; c="$(curl -s -m 3 -o /dev/null -w '%{http_code}' "http://127.0.0.1:$PORT/api/health" 2>/dev/null)"; [ -n "$c" ] && [ "$c" != "000" ]; }

health() { # corpo do /api/health (manda o token se houver)
    local tok; tok="$(env_get TOOLS_API_TOKEN)"
    if [ -n "$tok" ]; then curl -s -m 3 -H "X-Nexus-Token: $tok" "http://127.0.0.1:$PORT/api/health" 2>/dev/null
    else curl -s -m 3 "http://127.0.0.1:$PORT/api/health" 2>/dev/null; fi
}

ollama_local() { # 0 se o OLLAMA_HOST do .env e local e o binario existe
    local h; h="$(env_get OLLAMA_HOST)"; h="${h:-http://localhost:11434}"
    case "$h" in *localhost*|*127.0.0.1*) command -v ollama >/dev/null 2>&1 ;; *) return 1 ;; esac
}

start_ollama() {
    ollama_local || return 0
    local h; h="$(env_get OLLAMA_HOST)"; h="${h:-http://localhost:11434}"
    curl -s -f -m 3 -o /dev/null "$h/api/tags" 2>/dev/null && return 0
    echo "[*] Iniciando o Ollama..."
    nohup ollama serve >"$NEXUS_HOME/logs/ollama.log" 2>&1 &
    echo $! >"$OLLAMA_PID_FILE"
    local i
    for i in $(seq 1 30); do
        sleep 1
        curl -s -f -m 2 -o /dev/null "$h/api/tags" 2>/dev/null && return 0
    done
    echo "[!] Ollama nao respondeu em 30s - seguindo mesmo assim."
}

stop_ollama() {
    [ -f "$OLLAMA_PID_FILE" ] || return 0
    kill "$(cat "$OLLAMA_PID_FILE")" 2>/dev/null; rm -f "$OLLAMA_PID_FILE"
}

wake_on()  { command -v termux-wake-lock   >/dev/null 2>&1 && termux-wake-lock   2>/dev/null; return 0; }
wake_off() { command -v termux-wake-unlock >/dev/null 2>&1 && termux-wake-unlock 2>/dev/null; return 0; }

serve_loop() { # servidor com reinicio automatico (igual ao start.bat)
    local tries=0 rc
    while :; do
        echo "[*] Nexus-Bridge em http://$HOST:$PORT  -  docs em /docs  -  Ctrl+C para parar"
        "$PY" -m uvicorn app.main:app --host "$HOST" --port "$PORT" --no-access-log
        rc=$?
        [ "$rc" -eq 0 ] && break
        [ "$rc" -eq 130 ] || [ "$rc" -eq 143 ] && break   # Ctrl+C / SIGTERM
        tries=$((tries + 1))
        if [ "$tries" -gt "$MAX_RESTARTS" ]; then
            echo "[X] O servidor caiu $MAX_RESTARTS vezes seguidas. Veja logs/nexus.log e logs/faulthandler.log"
            return 1
        fi
        echo "[!] Servidor caiu (codigo $rc). Reiniciando em 5s - tentativa $tries de $MAX_RESTARTS..."
        sleep 5
    done
}

port_busy() { (exec 3<>"/dev/tcp/127.0.0.1/$PORT") 2>/dev/null; }

cmd_start() { # primeiro plano
    [ -x "$PY" ] || { echo "[X] venv nao encontrada. Rode o instalador de novo."; exit 1; }
    if is_running; then echo "[!] Ja esta rodando em segundo plano (PID $(cat "$PID_FILE")). Use: nexus parar"; exit 1; fi
    if port_busy; then echo "[X] A porta $PORT ja esta em uso. Use: nexus parar  (ou troque a porta com NEXUS_PORT=...)"; exit 1; fi
    command -v ffmpeg >/dev/null 2>&1 || echo "[!] ffmpeg nao encontrado - anuncios podem falhar (pkg install ffmpeg)."
    wake_on; start_ollama
    trap 'stop_ollama; wake_off' EXIT
    serve_loop
}

cmd_bg() { # segundo plano
    [ -x "$PY" ] || { echo "[X] venv nao encontrada. Rode o instalador de novo."; exit 1; }
    if is_running; then echo "[=] Ja esta rodando (PID $(cat "$PID_FILE"))."; return 0; fi
    if port_busy; then echo "[X] A porta $PORT ja esta em uso."; exit 1; fi
    wake_on; start_ollama
    nohup bash "$0" _loop >>"$LOG_FILE" 2>&1 &
    echo $! >"$PID_FILE"
    local i
    for i in $(seq 1 40); do
        sleep 1
        if alive; then echo "[OK] Nexus-Bridge no ar em http://$HOST:$PORT  (PID $(cat "$PID_FILE"))"; return 0; fi
        is_running || break
    done
    if is_running; then echo "[!] Subiu mas /api/health ainda nao respondeu. Veja: nexus logs"; else echo "[X] Caiu ao iniciar. Veja: nexus logs"; return 1; fi
}

cmd_stop() {
    if is_running; then
        local pid; pid="$(cat "$PID_FILE")"
        pkill -TERM -P "$pid" 2>/dev/null; kill "$pid" 2>/dev/null
        sleep 1; pkill -KILL -P "$pid" 2>/dev/null; kill -KILL "$pid" 2>/dev/null
        echo "[OK] Nexus-Bridge parado."
    else
        echo "[=] Nao estava rodando em segundo plano."
    fi
    rm -f "$PID_FILE"; stop_ollama; wake_off
}

cmd_status() {
    if is_running; then echo "Processo : rodando (PID $(cat "$PID_FILE"))"; else echo "Processo : parado (em segundo plano)"; fi
    echo "Endereco : http://$HOST:$PORT"
    if alive; then echo "Health   : $(health)"; else echo "Health   : sem resposta"; fi
}

cmd_logs() { tail -n "${2:-80}" -F "$NEXUS_HOME/logs/nexus.log" "$LOG_FILE" 2>/dev/null; }

cmd_edit() {
    local ed="${EDITOR:-}"
    [ -z "$ed" ] && for ed in nano vim vi; do command -v "$ed" >/dev/null 2>&1 && break; done
    command -v "$ed" >/dev/null 2>&1 || { echo "[X] Nenhum editor. Instale: pkg install nano"; exit 1; }
    "$ed" "$ENV_FILE"
    echo "Reinicie para aplicar: nexus reiniciar"
}

cmd_kaggle() { # nexus kaggle check|start|stop|t2v|i2v ...
    [ -x "$PY" ] || { echo "[X] venv nao encontrada."; exit 1; }
    shift
    "$PY" tools/kaggle_smoke_test.py "${@:-check}"
}

RAW_BASE="${NEXUS_RAW:-${INSTALL_RAW:-https://raw.githubusercontent.com/Tedyzetaa/sitenexus/main}}"
VER_FILE="$NEXUS_HOME/.nexus-version"

ver_field() { # ver_field ARQUIVO CAMPO
    grep -E "^$2=" "$1" 2>/dev/null | head -n1 | cut -d= -f2- | tr -d '\r '
}

# 0 = em dia | 10 = ha versao nova | 2 = nao deu para checar (sem internet etc.)
cmd_check() {
    local quiet=0 tmp rsha lsha
    [ "${1:-}" = "-q" ] && quiet=1
    tmp="$(mktemp 2>/dev/null || echo "$RUN_DIR/ver.tmp")"
    if ! curl -fsS -m 6 "$RAW_BASE/nexus-termux.version" -o "$tmp" 2>/dev/null; then
        rm -f "$tmp"; [ "$quiet" -eq 1 ] || echo "[!] Nao consegui consultar o GitHub (sem internet?)."; return 2
    fi
    rsha="$(ver_field "$tmp" SHA256)"; lsha="$(ver_field "$VER_FILE" SHA256)"
    if [ "${#rsha}" -ne 64 ]; then rm -f "$tmp"; [ "$quiet" -eq 1 ] || echo "[!] Resposta invalida do GitHub."; return 2; fi
    if [ "$rsha" = "$lsha" ]; then
        [ "$quiet" -eq 1 ] || echo "[OK] Voce esta na ultima versao ($(ver_field "$VER_FILE" VERSION))."
        rm -f "$tmp"; return 0
    fi
    [ "$quiet" -eq 1 ] || echo "[!] Ha versao nova: $(ver_field "$tmp" VERSION)  (instalada: $(ver_field "$VER_FILE" VERSION)). Rode: nexus atualizar"
    rm -f "$tmp"; return 10
}

cmd_update() { bash "$NEXUS_HOME/atualizar.sh" "${@:2}"; }

cmd_help() {
    cat <<'TXT'
nexus - Nexus-Bridge no Termux

  nexus iniciar      roda em primeiro plano (Ctrl+C para parar)
  nexus bg           roda em segundo plano (mantem o celular acordado)
  nexus parar        para o servidor (e o Ollama, se foi o nexus que subiu)
  nexus reiniciar    parar + bg
  nexus status       processo + /api/health
  nexus logs         acompanha logs/nexus.log
  nexus verificar    confere se ha versao nova no GitHub
  nexus atualizar    baixa e instala a versao nova (reinicia se estiver em segundo plano)
  nexus env          edita o .env
  nexus kaggle X     testa o video remoto (X = check | start | stop | t2v "prompt" | i2v foto "prompt")
  nexus teste        roda a suite de testes (precisa de: pip install pytest pytest-asyncio)
TXT
}

case "${1:-ajuda}" in
    iniciar|start|run)     cmd_start ;;
    _loop)                 serve_loop ;;
    bg|fundo|background)   cmd_bg ;;
    parar|stop)            cmd_stop ;;
    reiniciar|restart)     cmd_stop; sleep 1; cmd_bg ;;
    status)                cmd_status ;;
    logs|log)              cmd_logs "$@" ;;
    env|config)            cmd_edit ;;
    verificar|check)       cmd_check "${2:-}" ;;
    atualizar|update)      cmd_update "$@" ;;
    kaggle)                cmd_kaggle "$@" ;;
    teste|test)            "$PY" -m pytest tests -q ;;
    ajuda|help|-h|--help)  cmd_help ;;
    *) echo "Comando desconhecido: $1"; cmd_help; exit 1 ;;
esac
