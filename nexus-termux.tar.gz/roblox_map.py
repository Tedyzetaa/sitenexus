"""
Router FastAPI: geração de mapas Roblox via Ollama, com polling.

Uso no seu app principal:
    from roblox_map import router as roblox_router
    app.include_router(roblox_router)

Dependências: pip install fastapi uvicorn httpx pydantic
"""
import asyncio
import difflib
import json
import math
import re
import time
import uuid
from collections import Counter
from enum import Enum
from typing import Any, Literal, Optional

import httpx
from fastapi import APIRouter, BackgroundTasks, HTTPException
from pydantic import BaseModel, Field, ValidationError, field_validator

from app.config import settings
from app.gpu_lock import gpu_vram_lock

# ----------------------------------------------------------------------------
# Configuração
# ----------------------------------------------------------------------------
# Reaproveita o Ollama já configurado no .env do Nexus-Bridge.
# Para usar outro modelo só para mapas (o "jarvis" é um persona e pode não seguir JSON bem),
# defina ROBLOX_OLLAMA_MODEL no .env / ambiente.
OLLAMA_URL = f"{settings.OLLAMA_HOST.rstrip('/')}/api/chat"
# v8.0: estas variaveis agora vivem em Settings. Antes eram lidas com os.getenv, que NAO enxerga o .env
# (o pydantic-settings so le o .env para os campos declarados) -- ROBLOX_* no .env eram ignoradas.
OLLAMA_MODEL = settings.ROBLOX_OLLAMA_MODEL or settings.OLLAMA_MODEL
OLLAMA_TIMEOUT = 1800.0 if settings.is_lite else 600.0   # segundos (CPU lenta gera ~2-5 tokens/s)
OLLAMA_NUM_CTX = settings.roblox_num_ctx           # o padrão do projeto (2048) é pequeno demais para mapas
OLLAMA_NUM_PREDICT = settings.roblox_num_predict
MAX_ATTEMPTS = 3                  # tentativas se o LLM devolver JSON inválido
MAX_PARTS = 150                   # ~40 tokens por peça; mais que isso estoura o limite de saída
JOB_TTL_SECONDS = 3600            # jobs são apagados após 1h

# Padrão de cores do seu jogo (nomes válidos de BrickColor no Roblox)
RARITY_TO_BRICKCOLOR = {
    "common": "Medium stone grey",   # cinza
    "uncommon": "Bright green",      # verde
}

router = APIRouter(prefix="/api/roblox", tags=["roblox"])


# ----------------------------------------------------------------------------
# Modelos (também usados como JSON Schema para o Ollama)
# ----------------------------------------------------------------------------
class MaterialName(str, Enum):
    Wood = "Wood"
    WoodPlanks = "WoodPlanks"
    Stone = "Stone"
    Cobblestone = "Cobblestone"
    Brick = "Brick"
    Concrete = "Concrete"
    Slate = "Slate"
    Granite = "Granite"
    Grass = "Grass"
    Sand = "Sand"
    Metal = "Metal"
    Plastic = "Plastic"


class PartSpec(BaseModel):
    name: str = Field(description="Nome curto da peça, ex: 'Casa1_Parede'")
    position: list[float] = Field(min_length=3, max_length=3, description="[X, Y, Z] em studs (centro da peça)")
    size: list[float] = Field(min_length=3, max_length=3, description="[largura, altura, profundidade] em studs")
    rotation_y: float = Field(default=0, description="Rotação em graus no eixo Y")
    rarity: Literal["common", "uncommon"] = "common"
    material: MaterialName = MaterialName.Plastic

    @field_validator("size")
    @classmethod
    def clamp_size(cls, v: list[float]) -> list[float]:
        return [min(max(x, 0.2), 2048.0) for x in v]

    @field_validator("position")
    @classmethod
    def clamp_pos(cls, v: list[float]) -> list[float]:
        return [min(max(x, -10000.0), 10000.0) for x in v]


class MapSpec(BaseModel):
    parts: list[PartSpec] = Field(min_length=1)


class GenerateRequest(BaseModel):
    prompt: str = Field(min_length=3, max_length=2000)


# ----------------------------------------------------------------------------
# Armazenamento de jobs (em memória)
# ----------------------------------------------------------------------------
JOBS: dict[str, dict[str, Any]] = {}


def _cleanup_jobs() -> None:
    now = time.time()
    for jid in [j for j, d in JOBS.items() if now - d["created_at"] > JOB_TTL_SECONDS]:
        JOBS.pop(jid, None)


# ----------------------------------------------------------------------------
# Lógica do LLM
# ----------------------------------------------------------------------------
SYSTEM_PROMPT = f"""Você é um gerador de mapas para Roblox. Converta o pedido do usuário em um JSON
com a chave "parts": uma lista de blocos (Parts) que compõem o mapa.

REGRAS:
- Responda SOMENTE com JSON puro. Nada de texto, comentários ou Markdown.
- Unidade: studs. O chão fica em Y=0; uma peça apoiada no chão tem position.y = size.y / 2.
- "position" é o CENTRO da peça: [x, y, z]. "size" é [largura, altura, profundidade].
- "rarity": "common" (cinza, peças comuns) ou "uncommon" (verde, peças especiais/destaque).
- "material" deve ser um de: {", ".join(m.value for m in MaterialName)}.
- Comece sempre com uma peça de chão grande (Grass) e depois adicione as estruturas.
- Monte estruturas com várias peças (paredes, telhado, base). Evite peças sobrepostas sem motivo.
- Espalhe as construções sem colidirem. Use no máximo {MAX_PARTS} peças (menos é melhor).

Formato:
{{"parts":[{{"name":"Chao","position":[0,-0.5,0],"size":[200,1,200],"rotation_y":0,"rarity":"common","material":"Grass"}}]}}"""


def clean_llm_json(raw: str) -> str:
    """Remove crases/markdown e texto ao redor, devolvendo só o objeto JSON."""
    text = raw.strip()
    text = re.sub(r"```(?:json|JSON)?", "", text)  # remove ```json e ```
    text = text.replace("`", "").strip()
    start, end = text.find("{"), text.rfind("}")
    if start == -1 or end == -1 or end < start:
        raise ValueError("Nenhum objeto JSON encontrado na resposta do modelo.")
    return text[start : end + 1]


async def call_ollama(
    client: httpx.AsyncClient,
    prompt: str,
    system: str = SYSTEM_PROMPT,
    schema: Optional[dict] = None,
) -> str:
    payload = {
        "model": OLLAMA_MODEL,
        "stream": False,
        "format": schema or MapSpec.model_json_schema(),  # saída estruturada
        "keep_alive": settings.OLLAMA_KEEP_ALIVE_ACTIVE,
        "options": settings.ollama_options(temperature=0.4, num_ctx=OLLAMA_NUM_CTX, num_predict=OLLAMA_NUM_PREDICT),
        "messages": [
            {"role": "system", "content": system},
            {"role": "user", "content": prompt},
        ],
    }
    async with gpu_vram_lock:
        resp = await client.post(OLLAMA_URL, json=payload)
    if resp.status_code == 404:
        raise RuntimeError(
            f"Modelo '{OLLAMA_MODEL}' não encontrado no Ollama. Rode 'ollama list' e ajuste "
            "OLLAMA_MODEL ou ROBLOX_OLLAMA_MODEL no .env."
        )
    resp.raise_for_status()
    return resp.json()["message"]["content"]


def build_result(spec: MapSpec) -> dict[str, Any]:
    parts = []
    for p in spec.parts[:MAX_PARTS]:
        parts.append(
            {
                "name": p.name,
                "position": {"x": p.position[0], "y": p.position[1], "z": p.position[2]},
                "size": {"x": p.size[0], "y": p.size[1], "z": p.size[2]},
                "rotation_y": p.rotation_y,
                "rarity": p.rarity,
                "brick_color": RARITY_TO_BRICKCOLOR[p.rarity],
                "material": p.material.value,
            }
        )
    return {"kind": "map", "part_count": len(parts), "parts": parts}


async def run_job(job_id: str, prompt: str) -> None:
    job = JOBS[job_id]
    job["status"] = "running"
    last_error = "erro desconhecido"
    try:
        async with httpx.AsyncClient(timeout=OLLAMA_TIMEOUT) as client:
            for attempt in range(1, MAX_ATTEMPTS + 1):
                job["attempt"] = attempt
                try:
                    raw = await call_ollama(client, prompt)
                    data = json.loads(clean_llm_json(raw))
                    spec = MapSpec.model_validate(data)
                    job["result"] = build_result(spec)
                    job["status"] = "done"
                    return
                except RuntimeError as e:
                    job["status"] = "error"
                    job["error"] = str(e)
                    return
                except (ValueError, ValidationError, KeyError) as e:
                    last_error = f"Resposta inválida do modelo (tentativa {attempt}): {e}"
                    await asyncio.sleep(0.5)
        job["status"] = "error"
        job["error"] = last_error
    except httpx.HTTPError as e:
        job["status"] = "error"
        job["error"] = f"Falha ao falar com o Ollama: {e}"
    except Exception as e:  # noqa: BLE001
        job["status"] = "error"
        job["error"] = f"Erro inesperado: {e}"
    finally:
        job["finished_at"] = time.time()


# ----------------------------------------------------------------------------
# Endpoints
# ----------------------------------------------------------------------------
@router.post("/generate-map", status_code=202)
async def generate_map(req: GenerateRequest, background_tasks: BackgroundTasks):
    """Inicia a geração e retorna imediatamente um job_id."""
    _cleanup_jobs()
    job_id = uuid.uuid4().hex
    JOBS[job_id] = {
        "status": "queued",
        "created_at": time.time(),
        "result": None,
        "error": None,
        "attempt": 0,
    }
    background_tasks.add_task(run_job, job_id, req.prompt)
    return {"job_id": job_id, "status": "queued"}


@router.get("/jobs/{job_id}")
async def get_job(job_id: str):
    """Consulta o status. Quando status == 'done', 'result' contém o mapa."""
    job: Optional[dict] = JOBS.get(job_id)
    if job is None:
        raise HTTPException(status_code=404, detail="job_id não encontrado ou expirado.")
    return {
        "job_id": job_id,
        "status": job["status"],      # queued | running | done | error
        "attempt": job["attempt"],
        "result": job["result"],
        "error": job["error"],
    }


# ============================================================================
# Análise de mapas já existentes (enviados pelo plugin)
# ============================================================================
MAX_ANALYZE_PARTS = 1500   # a checagem de sobreposição é O(n^2)
ANALYSIS_SAMPLE = 80       # quantas peças vão como amostra para o LLM


class ExistingPart(BaseModel):
    name: str = ""
    class_name: str = "Part"
    position: list[float] = Field(min_length=3, max_length=3)
    size: list[float] = Field(min_length=3, max_length=3)
    rotation_y: float = 0
    material: str = "Plastic"
    color_name: str = ""


class AnalyzeRequest(BaseModel):
    question: str = Field(default="", max_length=1000)
    parts: list[ExistingPart] = Field(min_length=1, max_length=MAX_ANALYZE_PARTS)


class AnalysisOut(BaseModel):
    summary: str
    issues: list[str]
    suggestions: list[str]


ANALYSIS_SYSTEM_PROMPT = """Você é um analista de mapas do Roblox. Receberá estatísticas calculadas
automaticamente e uma amostra das peças (Parts) de um mapa. Responda em português do Brasil.

Responda SOMENTE com JSON puro (sem Markdown) neste formato:
{"summary": "...", "issues": ["..."], "suggestions": ["..."]}

- summary: 2 a 4 frases dizendo o que o mapa parece ser (tema, layout, escala).
- issues: problemas concretos apoiados nas estatísticas (peças flutuando, sobreposições, pouca
  variedade de materiais ou cores...). Não invente problemas que os dados não mostram.
- suggestions: melhorias práticas e curtas.
- No máximo 6 itens por lista. Se não houver problemas, deixe "issues" vazio.
- Se houver uma PERGUNTA DO USUÁRIO, responda a ela dentro do summary."""


def _extents(p: ExistingPart) -> tuple[float, float, float, float, float, float]:
    """Caixa alinhada aos eixos (min_x, min_y, min_z, max_x, max_y, max_z), considerando rotação em Y."""
    r = math.radians(p.rotation_y)
    c, s = abs(math.cos(r)), abs(math.sin(r))
    hx = (c * p.size[0] + s * p.size[2]) / 2
    hz = (s * p.size[0] + c * p.size[2]) / 2
    hy = p.size[1] / 2
    x, y, z = p.position
    return (x - hx, y - hy, z - hz, x + hx, y + hy, z + hz)


def compute_stats(parts: list[ExistingPart]) -> dict[str, Any]:
    n = len(parts)
    boxes = [_extents(p) for p in parts]
    mins = [min(b[k] for b in boxes) for k in range(3)]
    maxs = [max(b[k + 3] for b in boxes) for k in range(3)]

    footprint = [(b[3] - b[0]) * (b[5] - b[2]) for b in boxes]
    volumes = [(b[3] - b[0]) * (b[4] - b[1]) * (b[5] - b[2]) for b in boxes]
    ground_idx = max(range(n), key=footprint.__getitem__)  # maior área em planta = chão
    ground_top = boxes[ground_idx][4]

    floating: list[str] = []
    overlaps: list[str] = []
    floating_count = 0
    overlap_count = 0

    for i in range(n):
        if i == ground_idx:
            continue
        bi = boxes[i]
        supported = bi[1] <= ground_top + 0.5  # encostada no chão
        for j in range(n):
            if j == i or j == ground_idx:
                continue
            bj = boxes[j]
            ox = min(bi[3], bj[3]) - max(bi[0], bj[0])
            if ox <= 0:
                continue
            oz = min(bi[5], bj[5]) - max(bi[2], bj[2])
            if oz <= 0:
                continue
            # apoiada por outra peça que passa pela base dela
            if not supported and bj[4] >= bi[1] - 0.5 and bj[1] <= bi[1] + 0.5:
                supported = True
            if j > i:
                oy = min(bi[4], bj[4]) - max(bi[1], bj[1])
                if oy > 0:
                    small = min(volumes[i], volumes[j])
                    if small > 0 and (ox * oz * oy) / small > 0.5:
                        overlap_count += 1
                        if len(overlaps) < 10:
                            overlaps.append(f"{parts[i].name} x {parts[j].name}")
        if not supported:
            floating_count += 1
            if len(floating) < 10:
                floating.append(f"{parts[i].name} (y={parts[i].position[1]:.1f})")

    def top(counter: Counter) -> list[dict[str, Any]]:
        return [{"name": k, "count": v} for k, v in counter.most_common(8)]

    return {
        "part_count": n,
        "bounds_size": {
            "x": round(maxs[0] - mins[0], 1),
            "y": round(maxs[1] - mins[1], 1),
            "z": round(maxs[2] - mins[2], 1),
        },
        "ground": {"name": parts[ground_idx].name, "top_y": round(ground_top, 2)},
        "materials": top(Counter(p.material for p in parts)),
        "colors": top(Counter(p.color_name or "?" for p in parts)),
        "floating_count": floating_count,
        "floating_examples": floating,
        "overlap_count": overlap_count,
        "overlap_examples": overlaps,
    }


def build_analysis_prompt(req: AnalyzeRequest, stats: dict[str, Any]) -> str:
    n = len(req.parts)
    step = max(1, math.ceil(n / ANALYSIS_SAMPLE))
    sample = req.parts[::step]
    lines = [
        f"{p.name}|{p.class_name}|pos({p.position[0]:.0f},{p.position[1]:.0f},{p.position[2]:.0f})"
        f"|size({p.size[0]:.0f},{p.size[1]:.0f},{p.size[2]:.0f})|{p.material}|{p.color_name}"
        for p in sample
    ]
    text = (
        "ESTATÍSTICAS (calculadas automaticamente):\n"
        + json.dumps(stats, ensure_ascii=False)
        + f"\n\nAMOSTRA DE PEÇAS ({len(sample)} de {n}), formato nome|classe|posição|tamanho|material|cor:\n"
        + "\n".join(lines)
    )
    if req.question.strip():
        text += f"\n\nPERGUNTA DO USUÁRIO: {req.question.strip()}"
    return text


async def run_analysis_job(job_id: str, req: AnalyzeRequest) -> None:
    job = JOBS[job_id]
    job["status"] = "running"
    try:
        stats = await asyncio.to_thread(compute_stats, req.parts)
        analysis: Optional[dict[str, Any]] = None
        llm_error: Optional[str] = None
        prompt = build_analysis_prompt(req, stats)
        schema = AnalysisOut.model_json_schema()

        async with httpx.AsyncClient(timeout=OLLAMA_TIMEOUT) as client:
            for attempt in range(1, MAX_ATTEMPTS + 1):
                job["attempt"] = attempt
                try:
                    raw = await call_ollama(client, prompt, ANALYSIS_SYSTEM_PROMPT, schema)
                    analysis = AnalysisOut.model_validate(json.loads(clean_llm_json(raw))).model_dump()
                    llm_error = None
                    break
                except RuntimeError as e:
                    llm_error = str(e)
                    break
                except (ValueError, ValidationError, KeyError) as e:
                    llm_error = f"Resposta inválida do modelo (tentativa {attempt}): {e}"
                    await asyncio.sleep(0.5)
                except httpx.HTTPError as e:
                    llm_error = f"Falha ao falar com o Ollama: {e}"
                    break

        # as estatísticas são úteis mesmo se o LLM falhar
        job["result"] = {"kind": "analysis", "stats": stats, "analysis": analysis, "llm_error": llm_error}
        job["status"] = "done"
    except Exception as e:  # noqa: BLE001
        job["status"] = "error"
        job["error"] = f"Erro inesperado na análise: {e}"
    finally:
        job["finished_at"] = time.time()


@router.post("/analyze-map", status_code=202)
async def analyze_map(req: AnalyzeRequest, background_tasks: BackgroundTasks):
    """Recebe as peças de um mapa existente e inicia a análise. Use GET /jobs/{job_id} para o resultado."""
    _cleanup_jobs()
    job_id = uuid.uuid4().hex
    JOBS[job_id] = {
        "status": "queued",
        "created_at": time.time(),
        "result": None,
        "error": None,
        "attempt": 0,
    }
    background_tasks.add_task(run_analysis_job, job_id, req)
    return {"job_id": job_id, "status": "queued"}


# ============================================================================
# Assistente de código (estilo Copilot): análise por arquivo, correção e chat
# ============================================================================
# Modelo de código separado (opcional): defina ROBLOX_CODE_MODEL=qwen2.5-coder:7b no .env.
CODE_MODEL = settings.ROBLOX_CODE_MODEL or OLLAMA_MODEL
CODE_NUM_CTX = settings.roblox_code_num_ctx
CODE_NUM_PREDICT = settings.ROBLOX_CODE_NUM_PREDICT
MAX_ANALYZE_CHARS = 14000   # trecho do arquivo enviado ao LLM na análise
MAX_FIX_CHARS = 7000        # a correção reescreve o arquivo inteiro: precisa caber na saída
MAX_ASK_CHARS = 12000       # contexto total (todos os arquivos) no chat


class ScriptFile(BaseModel):
    path: str = Field(max_length=300)
    class_name: str = "Script"          # Script | LocalScript | ModuleScript
    source: str = Field(max_length=200000)


class ScriptIssue(BaseModel):
    line: int = Field(default=0, description="Número da linha, 0 se for geral")
    severity: Literal["alta", "media", "baixa"] = "media"
    message: str


class ScriptAnalysisOut(BaseModel):
    summary: str
    issues: list[ScriptIssue]
    suggestions: list[str]


class AnalyzeScriptRequest(BaseModel):
    file: ScriptFile
    question: str = Field(default="", max_length=1000)
    project_index: list[str] = Field(default_factory=list, max_length=80)


class FixScriptRequest(BaseModel):
    file: ScriptFile
    instruction: str = Field(default="", max_length=1000)
    issues: list[str] = Field(default_factory=list, max_length=12)


class ChatTurn(BaseModel):
    role: Literal["user", "assistant"]
    content: str = Field(max_length=4000)


class AskRequest(BaseModel):
    question: str = Field(min_length=2, max_length=2000)
    files: list[ScriptFile] = Field(default_factory=list, max_length=6)
    project_index: list[str] = Field(default_factory=list, max_length=80)
    history: list[ChatTurn] = Field(default_factory=list, max_length=8)


SCRIPT_SYSTEM_PROMPT = """Você é um revisor sênior de código Luau para Roblox (estilo GitHub Copilot).
Você analisa UM arquivo por vez. Responda em português do Brasil.

Responda SOMENTE com JSON puro (sem Markdown) neste formato:
{"summary": "...", "issues": [{"line": 12, "severity": "alta", "message": "..."}], "suggestions": ["..."]}

Regras:
- summary: 1 a 3 frases dizendo o que o arquivo faz e como se encaixa no projeto.
- issues: bugs reais e riscos que você ENXERGA no código: APIs obsoletas (wait/spawn/delay -> task.wait/task.spawn/task.delay,
  Instance.new com Parent no 2º argumento, BodyVelocity e similares), conexões que vazam, loops sem yield,
  RemoteEvents sem validação no servidor, variáveis globais acidentais, erros de lógica, nil não tratado.
- "line" é o número mostrado à esquerda de cada linha (0 se for um problema geral).
- "severity": "alta" (quebra/exploit), "media" (bug provável ou desempenho), "baixa" (estilo).
- Não invente problemas. Se o código está bom, devolva "issues": [].
- No máximo 8 issues e 5 suggestions; mensagens curtas e objetivas.
- Se houver PERGUNTA DO USUÁRIO, responda a ela dentro do summary."""

FIX_SYSTEM_PROMPT = """Você corrige scripts Luau do Roblox. Faça o MÍNIMO de mudanças necessárias.

Formato da resposta (obrigatório):
RESUMO: 1 a 3 frases explicando o que foi alterado.
Depois, o arquivo COMPLETO corrigido dentro de UM único bloco ```lua ... ```.

Regras:
- Devolva o arquivo inteiro. NUNCA abrevie nem escreva comentários como "-- resto igual" ou "-- ...".
- Preserve nomes, estrutura, comentários e estilo que não precisam mudar.
- Não adicione dependências nem serviços que o arquivo não usava."""

ASK_SYSTEM_PROMPT = """Você é um assistente de programação para Roblox/Luau, no estilo do GitHub Copilot Chat.
Responda em português do Brasil, em TEXTO SIMPLES: sem Markdown, sem asteriscos, sem crases.
Para trechos de código, indente cada linha com 4 espaços. Ao apontar algo, cite o arquivo e a linha.
Use apenas o código e a lista de arquivos fornecidos. Se faltar contexto, diga qual arquivo precisa ver."""


def _new_job() -> str:
    _cleanup_jobs()
    job_id = uuid.uuid4().hex
    JOBS[job_id] = {
        "status": "queued",
        "created_at": time.time(),
        "result": None,
        "error": None,
        "attempt": 0,
    }
    return job_id


def _fail(job: dict[str, Any], message: str) -> None:
    job["status"] = "error"
    job["error"] = message


async def _ollama(
    client: httpx.AsyncClient,
    messages: list[dict[str, str]],
    *,
    schema: Optional[dict] = None,
    num_predict: Optional[int] = None,
    temperature: float = 0.2,
) -> str:
    payload: dict[str, Any] = {
        "model": CODE_MODEL,
        "stream": False,
        "keep_alive": settings.OLLAMA_KEEP_ALIVE_ACTIVE,
        "options": settings.ollama_options(
            temperature=temperature, num_ctx=CODE_NUM_CTX, num_predict=num_predict or CODE_NUM_PREDICT),
        "messages": messages,
    }
    if schema:
        payload["format"] = schema
    async with gpu_vram_lock:
        resp = await client.post(OLLAMA_URL, json=payload)
    if resp.status_code == 404:
        raise RuntimeError(
            f"Modelo '{CODE_MODEL}' não encontrado no Ollama. Rode 'ollama list' e ajuste "
            "ROBLOX_CODE_MODEL (ou OLLAMA_MODEL) no .env."
        )
    resp.raise_for_status()
    return resp.json()["message"]["content"]


def _numbered(source: str, limit: int) -> tuple[str, bool]:
    """Numera as linhas ('12| código') e corta no limite de caracteres, sempre em fim de linha."""
    out: list[str] = []
    total = 0
    for i, line in enumerate(source.splitlines(), 1):
        row = f"{i}| {line}"
        if total + len(row) + 1 > limit:
            return "\n".join(out), True
        out.append(row)
        total += len(row) + 1
    return "\n".join(out), False


def _index_text(index: list[str], current: str = "") -> str:
    others = [p for p in index if p != current][:80]
    return "\n".join(f"- {p}" for p in others) if others else "(nenhum)"


# --- análise de um arquivo -------------------------------------------------
async def run_script_analysis(job_id: str, req: AnalyzeScriptRequest) -> None:
    job = JOBS[job_id]
    job["status"] = "running"
    try:
        f = req.file
        numbered, truncated = _numbered(f.source, MAX_ANALYZE_CHARS)
        line_count = len(f.source.splitlines())
        user = (
            f"Arquivo: {f.path} ({f.class_name}, {line_count} linhas)\n"
            f"Outros arquivos do projeto:\n{_index_text(req.project_index, f.path)}\n\n"
            f"CÓDIGO (formato 'linha| código'):\n{numbered}"
        )
        if truncated:
            user += "\n\n[AVISO: arquivo longo, apenas o início foi enviado.]"
        if req.question.strip():
            user += f"\n\nPERGUNTA DO USUÁRIO: {req.question.strip()}"

        messages = [
            {"role": "system", "content": SCRIPT_SYSTEM_PROMPT},
            {"role": "user", "content": user},
        ]
        schema = ScriptAnalysisOut.model_json_schema()
        last_error = "erro desconhecido"
        async with httpx.AsyncClient(timeout=OLLAMA_TIMEOUT) as client:
            for attempt in range(1, MAX_ATTEMPTS + 1):
                job["attempt"] = attempt
                try:
                    raw = await _ollama(client, messages, schema=schema)
                    analysis = ScriptAnalysisOut.model_validate(json.loads(clean_llm_json(raw)))
                    job["result"] = {
                        "kind": "script_analysis",
                        "path": f.path,
                        "line_count": line_count,
                        "truncated": truncated,
                        "analysis": analysis.model_dump(),
                    }
                    job["status"] = "done"
                    return
                except RuntimeError as e:
                    _fail(job, str(e))
                    return
                except (ValueError, ValidationError, KeyError) as e:
                    last_error = f"Resposta inválida do modelo (tentativa {attempt}): {e}"
                    await asyncio.sleep(0.5)
        _fail(job, last_error)
    except httpx.HTTPError as e:
        _fail(job, f"Falha ao falar com o Ollama: {e}")
    except Exception as e:  # noqa: BLE001
        _fail(job, f"Erro inesperado na análise: {e}")
    finally:
        job["finished_at"] = time.time()


@router.post("/analyze-script", status_code=202)
async def analyze_script(req: AnalyzeScriptRequest, background_tasks: BackgroundTasks):
    """Analisa UM script. O plugin chama uma vez por arquivo e faz polling em /jobs/{job_id}."""
    job_id = _new_job()
    background_tasks.add_task(run_script_analysis, job_id, req)
    return {"job_id": job_id, "status": "queued"}


# --- correção de um arquivo ------------------------------------------------
_FENCE = re.compile(r"```[a-zA-Z]*\n(.*?)(?:```|\Z)", re.DOTALL)
_PLACEHOLDER = re.compile(r"--\s*(\.\.\.|…|resto|restante|rest of|unchanged|igual|sem altera)", re.IGNORECASE)


def _parse_fix(raw: str, original: str) -> tuple[str, str]:
    blocks = _FENCE.findall(raw)
    if not blocks:
        raise ValueError("O modelo não devolveu o código dentro de um bloco ```lua.")
    code = max(blocks, key=len).strip("\n")
    if not code.strip():
        raise ValueError("O código devolvido veio vazio.")
    if _PLACEHOLDER.search(code) and not _PLACEHOLDER.search(original):
        raise ValueError("O modelo omitiu trechos do arquivo (placeholders).")
    explanation = raw[: raw.find("```")].strip()
    explanation = re.sub(r"^\s*RESUMO:\s*", "", explanation, flags=re.IGNORECASE) or "Correção sugerida."
    return explanation, code


async def run_fix(job_id: str, req: FixScriptRequest) -> None:
    job = JOBS[job_id]
    job["status"] = "running"
    try:
        f = req.file
        if len(f.source) > MAX_FIX_CHARS:
            _fail(
                job,
                f"Arquivo grande demais para correção automática ({len(f.source)} caracteres, "
                f"limite {MAX_FIX_CHARS}). Use o chat para pedir orientações pontuais.",
            )
            return

        user = f"Arquivo: {f.path} ({f.class_name})\n"
        if req.issues:
            user += "Problemas a corrigir:\n" + "\n".join(f"- {i}" for i in req.issues) + "\n"
        if req.instruction.strip():
            user += f"Instrução do usuário: {req.instruction.strip()}\n"
        user += f"\nCÓDIGO ATUAL:\n```lua\n{f.source}\n```"

        messages = [
            {"role": "system", "content": FIX_SYSTEM_PROMPT},
            {"role": "user", "content": user},
        ]
        last_error = "erro desconhecido"
        async with httpx.AsyncClient(timeout=OLLAMA_TIMEOUT) as client:
            for attempt in range(1, MAX_ATTEMPTS + 1):
                job["attempt"] = attempt
                try:
                    raw = await _ollama(client, messages, num_predict=4096, temperature=0.1)
                    explanation, code = _parse_fix(raw, f.source)

                    diff_lines = list(
                        difflib.unified_diff(
                            f.source.splitlines(), code.splitlines(), "antes", "depois", lineterm="", n=1
                        )
                    )
                    added = sum(1 for l in diff_lines if l.startswith("+") and not l.startswith("+++"))
                    removed = sum(1 for l in diff_lines if l.startswith("-") and not l.startswith("---"))
                    warnings: list[str] = []
                    if code.strip() == f.source.strip():
                        warnings.append("O modelo não alterou nada no arquivo.")
                    elif len(code) < 0.6 * len(f.source):
                        warnings.append("O arquivo novo ficou bem menor que o original; confira o diff antes de aplicar.")

                    job["result"] = {
                        "kind": "fix",
                        "path": f.path,
                        "explanation": explanation,
                        "new_source": code,
                        "diff": "\n".join(diff_lines[:400]),
                        "added": added,
                        "removed": removed,
                        "warnings": warnings,
                    }
                    job["status"] = "done"
                    return
                except RuntimeError as e:
                    _fail(job, str(e))
                    return
                except (ValueError, KeyError) as e:
                    last_error = f"Resposta inválida do modelo (tentativa {attempt}): {e}"
                    await asyncio.sleep(0.5)
        _fail(job, last_error)
    except httpx.HTTPError as e:
        _fail(job, f"Falha ao falar com o Ollama: {e}")
    except Exception as e:  # noqa: BLE001
        _fail(job, f"Erro inesperado na correção: {e}")
    finally:
        job["finished_at"] = time.time()


@router.post("/fix-script", status_code=202)
async def fix_script(req: FixScriptRequest, background_tasks: BackgroundTasks):
    """Gera uma versão corrigida do script (com diff). Quem aplica é o plugin, com Ctrl+Z."""
    job_id = _new_job()
    background_tasks.add_task(run_fix, job_id, req)
    return {"job_id": job_id, "status": "queued"}


# --- chat ------------------------------------------------------------------
async def run_ask(job_id: str, req: AskRequest) -> None:
    job = JOBS[job_id]
    job["status"] = "running"
    try:
        budget = MAX_ASK_CHARS // max(1, len(req.files))
        parts: list[str] = []
        for f in req.files:
            numbered, truncated = _numbered(f.source, budget)
            note = "\n[arquivo cortado por tamanho]" if truncated else ""
            parts.append(f"=== {f.path} ({f.class_name}) ===\n{numbered}{note}")

        context = "ARQUIVOS DO PROJETO:\n" + _index_text(req.project_index)
        if parts:
            context += "\n\nCÓDIGO EM CONTEXTO (formato 'linha| código'):\n" + "\n\n".join(parts)
        else:
            context += "\n\n(Nenhum script selecionado ou aberto no editor.)"

        messages: list[dict[str, str]] = [{"role": "system", "content": ASK_SYSTEM_PROMPT}]
        for turn in req.history[-6:]:
            messages.append({"role": turn.role, "content": turn.content})
        messages.append({"role": "user", "content": f"{context}\n\nPERGUNTA: {req.question.strip()}"})

        async with httpx.AsyncClient(timeout=OLLAMA_TIMEOUT) as client:
            answer = (await _ollama(client, messages, temperature=0.3)).strip()
        answer = answer.replace("```", "").strip()  # o plugin mostra texto simples
        if not answer:
            _fail(job, "O modelo devolveu uma resposta vazia.")
            return
        job["result"] = {"kind": "answer", "answer": answer}
        job["status"] = "done"
    except RuntimeError as e:
        _fail(job, str(e))
    except httpx.HTTPError as e:
        _fail(job, f"Falha ao falar com o Ollama: {e}")
    except Exception as e:  # noqa: BLE001
        _fail(job, f"Erro inesperado no chat: {e}")
    finally:
        job["finished_at"] = time.time()


@router.post("/ask", status_code=202)
async def ask(req: AskRequest, background_tasks: BackgroundTasks):
    """Chat sobre o código (contexto = scripts selecionados/abertos + índice do projeto)."""
    job_id = _new_job()
    background_tasks.add_task(run_ask, job_id, req)
    return {"job_id": job_id, "status": "queued"}
