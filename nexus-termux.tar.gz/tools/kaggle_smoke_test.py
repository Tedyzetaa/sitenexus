"""
Teste por etapas da ligacao Nexus <-> Kaggle <-> ComfyUI (Wan 2.2 / HunyuanVideo 1.5; perfil em WAN_PROFILE).
Rode na raiz do projeto, com o .env preenchido e VIDEO_PROVIDER=kaggle_wan:

  python tools/kaggle_smoke_test.py check          # 1) valida .env e a autenticacao no Kaggle
  python tools/kaggle_smoke_test.py start          # 2) sobe o notebook e espera o ComfyUI ficar online
  python tools/kaggle_smoke_test.py i2v foto.png "the camera slowly pushes in"   # 3) imagem -> video (qualquer perfil)
  python tools/kaggle_smoke_test.py r2v ref.png "the subject walks through a forest"  # 3b) referencia -> video (perfil r2v)
  python tools/kaggle_smoke_test.py t2v "a red fox running in snow"   # texto -> video (so WAN_PROFILE=draft)
  python tools/kaggle_smoke_test.py status         # estado atual
  python tools/kaggle_smoke_test.py stop           # desliga o notebook agora
"""
import asyncio
import logging
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent.parent))

from app.config import settings  # noqa: E402
from app.providers.base import ProviderUnavailableError  # noqa: E402
from app.providers.kaggle_runtime import kaggle_manager  # noqa: E402
from app.providers.kaggle_wan_provider import KaggleWanVideoProvider  # noqa: E402

logging.basicConfig(level=logging.INFO, format="%(asctime)s %(name)s: %(message)s")


async def main(argv):
    cmd = argv[0] if argv else "check"
    if cmd == "check":
        kaggle_manager._require_config()
        code, out = await kaggle_manager._cli("kernels", "list", "--mine", "--page-size", "1", timeout=90)
        print("Kaggle CLI (codigo %s):\n%s" % (code, out[:600]))
        print("OK: autenticou." if code == 0 else "FALHOU: confira KAGGLE_USERNAME/KEY e a versao da CLI.")
        print("Topico ntfy:", kaggle_manager.topic, "(a URL do ngrok chega por ele a cada start)")
    elif cmd == "start":
        await kaggle_manager.ensure_online()
        print("ONLINE em", kaggle_manager.base_url)   # URL aleatoria, lida do ntfy
    elif cmd == "status":
        print(await kaggle_manager.status())
    elif cmd == "stop":
        print("pedido de parada aceito:", await kaggle_manager.stop())
    elif cmd in ("t2v", "i2v", "r2v"):
        prov = KaggleWanVideoProvider()
        if cmd == "t2v":
            prompt, img = " ".join(argv[1:]) or "a red fox running through snow, cinematic", b""
        else:
            img = Path(argv[1]).read_bytes()
            prompt = " ".join(argv[2:]) or (
                "the subject from the reference image walks slowly through a sunny forest, gentle push-in"
                if cmd == "r2v" else "the camera slowly zooms in, subtle motion")
        out = await prov.generate(prompt, "blurry, low quality, watermark", img,
                                  settings.LTX_WIDTH, settings.LTX_HEIGHT, settings.LTX_LENGTH, 1.0, None)
        print("VIDEO SALVO EM:", out)
    else:
        print(__doc__)


try:
    asyncio.run(main(sys.argv[1:]))
except ProviderUnavailableError as e:
    print("\nERRO:", e)
    sys.exit(1)
