"""Verificacao dos patches SEM dependencias externas (stubs minimos de httpx/telegram/pydantic).
Rode:  python verify_patches.py <pasta com nexus-bridge/ e jarvis-bot/>"""
import asyncio, importlib.util, json, os, sys, tempfile, types
from pathlib import Path

ROOT = Path(sys.argv[1] if len(sys.argv) > 1 else "fixed").resolve()
NEX, JAR = ROOT / "nexus-bridge", ROOT / "jarvis-bot"
passed = failed = 0

def check(name, cond, extra=""):
    global passed, failed
    if cond: passed += 1; print(f"  ok   {name}")
    else: failed += 1; print(f"  FAIL {name} {extra}")

def load(modname, path):
    spec = importlib.util.spec_from_file_location(modname, path)
    m = importlib.util.module_from_spec(spec); sys.modules[modname] = m
    spec.loader.exec_module(m); return m

def pkg(name):
    m = types.ModuleType(name); m.__path__ = []; sys.modules[name] = m; return m

# ============================================================ 1. net_safety (SSRF)
print("net_safety")
pkg("app"); ns = load("app.net_safety", NEX / "app/net_safety.py")
async def t_ssrf():
    bad = ["http://127.0.0.1/", "http://localhost/", "http://10.0.0.5/", "http://192.168.1.10/", "http://172.16.0.1/",
           "http://169.254.169.254/latest/meta-data", "http://[::1]/", "http://[::ffff:127.0.0.1]/", "http://0.0.0.0/",
           "http://100.64.0.1/", "file:///etc/passwd", "ftp://8.8.8.8/", "http:///x", "", "javascript:alert(1)",
           "http://[fe80::1]/", "http://224.0.0.1/"]
    for u in bad:
        try: await ns.assert_public_url(u); check(f"bloqueia {u!r}", False)
        except ns.UnsafeURLError: check(f"bloqueia {u!r}", True)
    for u in ["http://8.8.8.8/x", "https://1.1.1.1:8443/a?b=1", "http://[2606:4700:4700::1111]/"]:
        try: await ns.assert_public_url(u); check(f"permite {u!r}", True)
        except ns.UnsafeURLError as e: check(f"permite {u!r}", False, str(e))

    class FakeResp:
        def __init__(self, status, headers, chunks): self.status_code, self.headers, self._c, self.encoding = status, headers, chunks, "utf-8"
        async def __aenter__(self): return self
        async def __aexit__(self, *a): return False
        async def aiter_bytes(self):
            for c in self._c: yield c
    class FakeClient:
        def __init__(self, routes): self.routes, self.calls = routes, []
        def stream(self, method, url, headers=None, follow_redirects=None):
            assert follow_redirects is False, "safe_get nao pode deixar o httpx seguir redirects"
            self.calls.append(url); return self.routes[url]
    # redirect publico -> loopback e barrado no 2o salto
    c = FakeClient({"http://8.8.8.8/a": FakeResp(302, {"location": "http://127.0.0.1:11434/api/tags"}, [])})
    try: await ns.safe_get(c, "http://8.8.8.8/a"); check("redirect para loopback bloqueado", False)
    except ns.UnsafeURLError: check("redirect para loopback bloqueado", c.calls == ["http://8.8.8.8/a"])
    # redirect relativo valido + corpo
    c = FakeClient({"http://8.8.8.8/a": FakeResp(301, {"location": "/b"}, []), "http://8.8.8.8/b": FakeResp(200, {}, [b"<html>", b"ok"])})
    r = await ns.safe_get(c, "http://8.8.8.8/a")
    check("segue redirect relativo e devolve corpo", r.status_code == 200 and r.text == "<html>ok" and r.url == "http://8.8.8.8/b")
    # content-length acima do teto / stream acima do teto / loop de redirect
    c = FakeClient({"http://8.8.8.8/big": FakeResp(200, {"content-length": str(10 * 1024 * 1024)}, [b"x"])})
    try: await ns.safe_get(c, "http://8.8.8.8/big", max_bytes=1024 * 1024); check("content-length gigante recusado", False)
    except ns.UnsafeURLError: check("content-length gigante recusado", True)
    c = FakeClient({"http://8.8.8.8/s": FakeResp(200, {}, [b"a" * 600_000, b"b" * 600_000])})
    try: await ns.safe_get(c, "http://8.8.8.8/s", max_bytes=1_000_000); check("stream acima do teto recusado", False)
    except ns.UnsafeURLError: check("stream acima do teto recusado", True)
    c = FakeClient({"http://8.8.8.8/l": FakeResp(302, {"location": "http://8.8.8.8/l"}, [])})
    try: await ns.safe_get(c, "http://8.8.8.8/l"); check("loop de redirect interrompido", False)
    except ns.UnsafeURLError as e: check("loop de redirect interrompido", "demais" in str(e))
asyncio.run(t_ssrf())

# ============================================================ 2. gpu_lock
print("gpu_lock")
gl = load("app.gpu_lock", NEX / "app/gpu_lock.py")
async def t_gpu():
    async with gl.gpu_slot(0.2): check("slot livre adquire", gl.gpu_vram_lock.locked())
    check("slot libera ao sair", not gl.gpu_vram_lock.locked())
    await gl.gpu_vram_lock.acquire()
    try:
        async with gl.gpu_slot(0.1): check("slot ocupado deve falhar", False)
    except gl.GpuBusyError: check("slot ocupado -> GpuBusyError", True)
    gl.gpu_vram_lock.release()
    try:
        async with gl.gpu_slot(0.2): raise KeyError("x")
    except KeyError: pass
    check("lock liberado mesmo com excecao no corpo", not gl.gpu_vram_lock.locked())
asyncio.run(t_gpu())

# ============================================================ 3. queue_manager (com stubs de models/config/orchestrator/status)
print("queue_manager")
from enum import Enum
class JobStatus(str, Enum):
    QUEUED="queued"; RUNNING="generating_image"; COMPLETED="completed"; FAILED="failed"
class Job:
    _n = 0
    def __init__(self, status=JobStatus.QUEUED): Job._n += 1; self.id=f"j{Job._n}"; self.status=status; self.error=None
m = types.ModuleType("app.models"); m.Job, m.JobStatus = Job, JobStatus; sys.modules["app.models"] = m
m = types.ModuleType("app.config"); m.settings = types.SimpleNamespace(JOB_HISTORY_LIMIT=3, max_queued_jobs=1000); sys.modules["app.config"] = m
m = types.ModuleType("app.services"); m.__path__=[]; sys.modules["app.services"] = m
m = types.ModuleType("app.services.orchestrator"); m.NexusOrchestrator = object; sys.modules["app.services.orchestrator"] = m
class SM:
    async def set_queue_length(self, n): pass
m = types.ModuleType("app.status_manager"); m.status_manager = SM(); sys.modules["app.status_manager"] = m
qm_mod = load("app.queue_manager", NEX / "app/queue_manager.py")

async def t_queue():
    order, concurrent = [], {"now": 0, "max": 0}
    class Orch:
        async def run(self, job):
            concurrent["now"] += 1; concurrent["max"] = max(concurrent["max"], concurrent["now"])
            assert gl.gpu_vram_lock.locked(), "worker deve segurar gpu_vram_lock"
            order.append(job.id)
            if getattr(job, "boom", False): raise RuntimeError("kaboom")
            if getattr(job, "slow", False): await asyncio.sleep(30)
            await asyncio.sleep(0.01); job.status = JobStatus.COMPLETED; concurrent["now"] -= 1
    q = qm_mod.QueueManager(Orch()); q.start()
    # historico (limite 3): jobs na fila NAO podem ser expulsos
    jobs = [Job() for _ in range(6)]
    for j in jobs: await q.enqueue(j)
    check("fila mantem 6 jobs pendentes acima do limite 3", all(q.get_job(j.id) is j for j in jobs))
    await asyncio.wait_for(q._queue.join(), 5)
    check("todos rodaram, em ordem, um por vez", order == [j.id for j in jobs] and concurrent["max"] == 1)
    extra = Job(); await q.enqueue(extra); await q._queue.join()
    check("apos concluir, historico e aparado para o limite", len(q._jobs) <= 3, str(len(q._jobs)))
    check("job mais novo permanece", q.get_job(extra.id) is extra)
    # excecao no orchestrator => job marcado failed e worker continua vivo
    bad = Job(); bad.boom = True; ok = Job()
    await q.enqueue(bad); await q.enqueue(ok); await asyncio.wait_for(q._queue.join(), 5)
    check("excecao -> job failed com erro", bad.status == JobStatus.FAILED and "kaboom" in (bad.error or ""))
    check("worker sobrevive e roda o proximo", ok.status == JobStatus.COMPLETED)
    check("lock da GPU liberado", not gl.gpu_vram_lock.locked())
    # stop() durante um job lento => failed + sem task pendurada
    slow = Job(); slow.slow = True; await q.enqueue(slow); await asyncio.sleep(0.1)
    await q.stop()
    check("stop() marca job em andamento como failed", slow.status == JobStatus.FAILED and "encerrado" in (slow.error or ""))
    check("stop() libera o lock", not gl.gpu_vram_lock.locked())
    check("list_jobs(0) vazio", q.list_jobs(0) == [] and len(q.list_jobs(2)) == 2)
asyncio.run(t_queue())

# ============================================================ 4. tools/commands._uint
print("commands")
pkg("app.tools")
class ToolSpec:
    def __init__(self, name, params=()): self.name, self.params = name, list(params)
reg = types.ModuleType("app.tools.registry"); reg.TOOLS, reg.ToolSpec, reg.get_spec = [], ToolSpec, (lambda n: None); sys.modules["app.tools.registry"] = reg
cm = load("app.tools.commands", NEX / "app/tools/commands.py")
check("_uint('12') == 12", cm._uint("12") == 12)
check("_uint('²') is None (isdigit() daria True)", cm._uint("²") is None and "²".isdigit())
check("_uint('٣') is None", cm._uint("٣") is None)
check("_uint de 5000 digitos is None (sem ValueError)", cm._uint("9" * 5000) is None)
a = cm._args_for(ToolSpec("check_seismic_activity"), "² 3 strong")
check("/sismo ² 3 strong nao levanta e usa limit=3", a == {"limit": 3, "level": "strong"}, str(a))
a = cm._args_for(ToolSpec("scan_radio_stations"), "am ²")
check("scan_radio_stations com digito unicode nao levanta", a == {"mode": "am"}, str(a))

# ============================================================ 5. openhands_provider
print("openhands_provider")
hx = types.ModuleType("httpx")
class _E(Exception): pass
hx.AsyncBaseTransport = object; hx.RequestError = _E; hx.AsyncClient = object
sys.modules["httpx"] = hx
oh = load("oh_provider", NEX / "app/providers/openhands_provider.py")
check("paused e terminal", "paused" in oh.TERMINAL)
async def t_oh():
    p = oh.OpenHandsProvider("http://x", tempfile.gettempdir())
    async def fake_req(method, path, **kw):
        return {"execution_status": "paused"} if "events" not in path else {"items": []}
    p._req = fake_req
    r = await p.get_task("a" * 32)
    check("get_task(paused) -> done=True com erro legivel", r["done"] is True and "interrompida" in r["error"], str(r))
    async def fake_fin(method, path, **kw):
        return {"execution_status": "finished"} if "events" not in path else {"items": [{"action": {"kind": "FinishAction", "message": "feito"}}]}
    p._req = fake_fin
    r = await p.get_task("a" * 32)
    check("get_task(finished) continua devolvendo resultado", r["done"] and r["result"] == "feito" and r["error"] == "")
asyncio.run(t_oh())

# ============================================================ 6. jarvis: utils / config / persona
print("jarvis utils/config/persona")
pk = pkg("jarvis")
ut = load("jarvis.utils", JAR / "jarvis/utils.py")
for s in ["\x00999\x00", "oi \x000\x00 tchau **negrito** `x`", "```py\nprint(1)\n``` fim \x00"]:
    try: out = ut.format_html(s); check(f"format_html({s!r}) nao levanta", "\x00" not in out)
    except Exception as e: check(f"format_html({s!r}) nao levanta", False, repr(e))
check("format_html mantem negrito/codigo", ut.format_html("**a** `b<c>`") == "<b>a</b> <code>b&lt;c&gt;</code>")
check("format_html escapa HTML", ut.format_html("<script>&") == "&lt;script&gt;&amp;")
dot = types.ModuleType("dotenv"); dot.load_dotenv = lambda *a, **k: None; sys.modules["dotenv"] = dot
cf = load("jarvis.config", JAR / "jarvis/config.py")
check("parse_ids normal", cf.parse_ids("1, 2;3", "X") == frozenset({1, 2, 3}))
for bad in ["²", "12,٣", "abc", "-5", "1.5"]:
    try: cf.parse_ids(bad, "X"); check(f"parse_ids({bad!r}) -> ConfigError", False)
    except cf.ConfigError: check(f"parse_ids({bad!r}) -> ConfigError", True)
    except Exception as e: check(f"parse_ids({bad!r}) -> ConfigError", False, repr(e))
for bad in ["nan", "inf", "-1", "0", "abc"]:
    try: cf._pos(bad, 5, "V"); check(f"_pos({bad!r}) rejeitado", False)
    except cf.ConfigError: check(f"_pos({bad!r}) rejeitado", True)
check("_pos('2.5') == 2.5 e default", cf._pos("2.5", 1, "V") == 2.5 and cf._pos("", 7, "V") == 7.0)
ps = load("jarvis.persona", JAR / "jarvis/persona.py")
d = Path(tempfile.mkdtemp())
for payload, label in [("[1,2,3]", "lista"), ('{"directives": "texto"}', "directives string"), ("null", "null"), ('{"directives":["a","b"],"model":"m","temperature":0.3}', "valido")]:
    (d / "r.json").write_text(payload)
    try:
        st = ps.RuntimeState(d / "r.json", "def", 0.8)
        ok = (st.directives == ["a", "b"] and st.model == "m") if label == "valido" else (st.directives == [] and st.model == "def")
        check(f"RuntimeState com runtime.json {label}", ok, str((st.directives, st.model)))
    except Exception as e: check(f"RuntimeState com runtime.json {label}", False, repr(e))

# ============================================================ 7. jarvis nexus.py (httpx/telegram stubs)
print("jarvis nexus gateway")
class TransportError(_E): pass
class TimeoutException(TransportError): pass
class ConnectError(TransportError): pass
class ConnectTimeout(TimeoutException): pass
hx.HTTPError = _E; hx.TransportError, hx.TimeoutException, hx.ConnectError, hx.ConnectTimeout = TransportError, TimeoutException, ConnectError, ConnectTimeout
hx.Response = object; hx.Timeout = lambda **k: None; hx.Limits = lambda **k: None
class _AC:
    def __init__(self, **k): pass
hx.AsyncClient = _AC
tg = pkg("telegram"); tge = types.ModuleType("telegram.error"); sys.modules["telegram.error"] = tge
class NetworkError(Exception): pass
tge.NetworkError, tge.TimedOut, tge.BadRequest = NetworkError, type("TimedOut", (NetworkError,), {}), type("BadRequest", (NetworkError,), {})
load("jarvis.net", JAR / "jarvis/net.py")
nx = load("jarvis.nexus", JAR / "jarvis/nexus.py")
class SResp:
    def __init__(self, status, headers, chunks, body=b"{}"): self.status_code, self.headers, self._c, self._b = status, headers, chunks, body
    async def __aenter__(self): return self
    async def __aexit__(self, *a): return False
    async def aread(self): return self._b
    def json(self): return json.loads(self._b)
    async def aiter_bytes(self):
        for c in self._c: yield c
class SHttp:
    def __init__(self, resp): self.resp = resp; self.paths = []
    def stream(self, method, path, **kw): self.paths.append(path); return self.resp
async def t_nexus():
    gw = nx.NexusGateway("http://x", "", 5.0)
    gw._http = SHttp(SResp(200, {"content-type": "video/mp4; codecs=x"}, [b"abc", b"def"]))
    f = await gw.fetch_media("http://evil.example/videos/v.mp4?z=1")
    check("fetch_media usa so o PATH e junta os chunks", f.data == b"abcdef" and gw._http.paths == ["/videos/v.mp4?z=1"] and f.content_type == "video/mp4" and f.filename == "v.mp4")
    gw._http = SHttp(SResp(200, {"content-length": str(nx.MAX_MEDIA_BYTES + 1)}, [b"x"]))
    try: await gw.fetch_media("/videos/big.mp4"); check("content-length > 50MB recusado sem baixar", False)
    except nx.NexusError as e: check("content-length > 50MB recusado sem baixar", "50 MB" in str(e))
    orig = nx.MAX_MEDIA_BYTES; nx.MAX_MEDIA_BYTES = 10
    gw._http = SHttp(SResp(200, {}, [b"a" * 6, b"b" * 6]))
    try: await gw.fetch_media("/videos/big.mp4"); check("stream > teto recusado no meio", False)
    except nx.NexusError: check("stream > teto recusado no meio", True)
    nx.MAX_MEDIA_BYTES = orig
    gw._http = SHttp(SResp(404, {}, [], body=b'{"detail":"Arquivo nao encontrado"}'))
    try: await gw.fetch_media("/videos/nope.mp4"); check("404 -> NexusError(status_code=404)", False)
    except nx.NexusError as e: check("404 -> NexusError(status_code=404)", e.status_code == 404 and "Arquivo nao encontrado" in str(e), str(e))
    # wait_*: 404 aborta imediatamente por status_code, sem depender de texto
    async def get404(_id): raise nx.NexusError("qualquer mensagem", 404)
    gw.get_video_job = get404
    try: await gw.wait_video_job("1", poll_s=0.01); check("wait_video_job aborta em 404 (status_code)", False)
    except nx.NexusError as e: check("wait_video_job aborta em 404 (status_code)", "nao conhece" in str(e))
    async def get404s(_id): raise nx.NexusError("Nexus respondeu HTTP 404: x")
    gw.get_code_task = get404s
    try: await gw.wait_code_task("1", poll_s=0.01); check("wait_code_task ainda reconhece texto legado 'HTTP 404'", False)
    except nx.NexusError as e: check("wait_code_task ainda reconhece texto legado 'HTTP 404'", "nao conhece" in str(e))
    check("NexusError('x') continua valido (compat.)", str(nx.NexusError("x")) == "x" and nx.NexusError("x").status_code is None)
asyncio.run(t_nexus())

print(f"\n{passed} ok, {failed} falhas")
sys.exit(1 if failed else 0)
