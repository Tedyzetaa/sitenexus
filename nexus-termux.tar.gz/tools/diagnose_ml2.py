"""
Diagnostico 2 da API do Mercado Livre: testa as rotas que o diagnostico 1 deixou em aberto
(campos do item, user-products e catalogo). Nao imprime token nem dados da sua conta.

Uso (na raiz do projeto):
    & "C:\\Program Files\\Python311\\python.exe" tools\\diagnose_ml2.py MLB5026881325 MLBU4668038018 "dispenser detergente pia cozinha"
"""
import sys
import httpx

sys.path.insert(0, ".")
from app.config import settings  # noqa: E402

API = "https://api.mercadolibre.com"
item = sys.argv[1] if len(sys.argv) > 1 else "MLB5026881325"
mlbu = sys.argv[2] if len(sys.argv) > 2 else ""
query = sys.argv[3] if len(sys.argv) > 3 else "dispenser detergente pia cozinha"


def show(label, r):
    print(f"[{r.status_code}] {label}\n      {(r.text or '')[:260]!r}\n")


def main():
    with httpx.Client(timeout=20.0) as c:
        r = c.post(f"{API}/oauth/token", data={"grant_type": "client_credentials",
                   "client_id": settings.ML_CLIENT_ID, "client_secret": settings.ML_CLIENT_SECRET})
        if r.status_code != 200:
            print("Falha no token:", r.status_code); return
        h = {"Authorization": f"Bearer {r.json()['access_token']}"}

        show(f"GET /items/{item}?attributes=title,price,pictures,permalink", c.get(f"{API}/items/{item}?attributes=title,price,pictures,permalink", headers=h))
        if mlbu:
            show(f"GET /user-products/{mlbu}", c.get(f"{API}/user-products/{mlbu}", headers=h))

        rs = c.get(f"{API}/products/search", params={"site_id": "MLB", "q": query, "status": "active"}, headers=h)
        print(f"[{rs.status_code}] GET /products/search q={query!r}")
        if rs.status_code == 200:
            results = rs.json().get("results", [])[:3]
            for p in results:
                pid = p.get("id")
                rp = c.get(f"{API}/products/{pid}", headers=h)
                if rp.status_code == 200:
                    d = rp.json()
                    print(f"      {pid}: '{d.get('name')}' | fotos: {len(d.get('pictures') or [])} | "
                          f"descricao: {bool(d.get('short_description'))} | buy_box: {bool(d.get('buy_box_winner'))}")
                else:
                    print(f"      {pid}: GET /products/{pid} -> {rp.status_code} {rp.text[:120]!r}")
        print()


if __name__ == "__main__":
    main()
