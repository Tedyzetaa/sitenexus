"""
Diagnostico da API do Mercado Livre: mostra, para cada endpoint, o status HTTP e o corpo da
resposta (o corpo diz POR QUE deu 403). Nao imprime o token nem o secret.

Uso (na raiz do projeto, com a venv ativa):
    python tools\\diagnose_ml.py MLB5026881325
"""
import sys
import httpx

sys.path.insert(0, ".")
from app.config import settings  # noqa: E402

API = "https://api.mercadolibre.com"
item = sys.argv[1] if len(sys.argv) > 1 else "MLB5026881325"


def show(label: str, r: httpx.Response) -> None:
    body = (r.text or "").replace("\n", " ")[:350]
    print(f"[{r.status_code}] {label}\n      {body}\n")


def main() -> None:
    cid, secret = settings.ML_CLIENT_ID, settings.ML_CLIENT_SECRET
    print(f"ML_CLIENT_ID lido: {'sim (' + cid + ')' if cid else 'NAO'} | ML_CLIENT_SECRET lido: {'sim' if secret else 'NAO'}\n")
    with httpx.Client(timeout=20.0) as c:
        r = c.post(f"{API}/oauth/token", data={"grant_type": "client_credentials", "client_id": cid, "client_secret": secret})
        tok = r.json().get("access_token") if r.status_code == 200 else None
        print(f"[{r.status_code}] POST /oauth/token (token obtido: {'sim' if tok else 'NAO'})")
        if tok:
            info = {k: v for k, v in r.json().items() if k != "access_token"}
            print(f"      resposta (sem o token): {info}\n")
        h = {"Authorization": f"Bearer {tok}"} if tok else {}
        tests = [
            (f"GET /items/{item}  (COM token)", f"/items/{item}", h),
            (f"GET /items/{item}  (SEM token)", f"/items/{item}", {}),
            (f"GET /items?ids={item}  (COM token)", f"/items?ids={item}", h),
            (f"GET /items/{item}/description  (COM token)", f"/items/{item}/description", h),
            ("GET /users/me  (COM token)", "/users/me", h),
            ("GET /sites/MLB/search?q=dispenser&limit=1  (COM token)", "/sites/MLB/search?q=dispenser&limit=1", h),
            ("GET /products/search?site_id=MLB&q=dispenser&status=active  (COM token)", "/products/search?site_id=MLB&q=dispenser&status=active", h),
        ]
        for label, path, headers in tests:
            try:
                show(label, c.get(f"{API}{path}", headers=headers))
            except httpx.HTTPError as exc:
                print(f"[erro de rede] {label}: {exc}\n")


if __name__ == "__main__":
    main()
