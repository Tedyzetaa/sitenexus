# Ferramentas do J.A.R.V.I.S. (`app/tools`)

Subsistemas legados de monitoramento (pasta `features/`) reescritos como ferramentas
**assíncronas**, com falha isolada, e expostos de 3 formas: **API Python**, **rota HTTP** e **comandos de chat**.

## Arquitetura

```
app/tools/
├── base.py         ToolResult, @safe_tool, HTTP async c/ retry, cache TTL, arquivos gerados
├── browser.py      Playwright async + allowlist de hosts (opt-in)
├── feeds.py        RSS/Atom seguro (defusedxml)
├── antibot.py      detecta páginas de verificação anti-robô (só detecta; não contorna)
├── orbit.py        mecânica kepleriana (órbita 3D)
├── space.py        asteroides NASA · ISS · órbita 3D (JPL SBDB)
├── geophysics.py   sismos USGS · vulcões Smithsonian
├── weather.py      OpenWeatherMap
├── noaa.py         clima espacial NOAA/SWPC (dados + mídia)
├── solar.py        status solar consolidado
├── traffic.py      radar aéreo OpenSky · rádios online
├── tactical.py     frente de conflito · painel · PIZZINT · sentinela (webcam)
├── hub.py          ★ API pública limpa (check_seismic_activity, get_solar_status, ...)
├── registry.py     catálogo + validação de args + manifesto p/ function-calling
├── commands.py     parser de "/comandos" e linguagem natural
└── router.py       rotas FastAPI (/api/v1/tools)
```

## Uso em Python

```python
from app.tools import hub, registry
res = await hub.check_seismic_activity(level="strong")   # nunca levanta exceção
res.ok, res.text, res.data, res.media, res.cached, res.elapsed_ms
await registry.invoke("get_weather", {"city": "Dourados MS"})   # com validação de args
```

## Comandos de chat

`POST /api/v1/tools/chat {"message": "/sismo forte 3"}` → `{"handled": true, "reply": "...", "media": [...]}`.
Se `handled=false`, o front segue para `/api/chat` (Langflow) como hoje.

| Comando | Ferramenta | O que faz |
|---|---|---|
| `/sismo` | `check_seismic_activity` | Terremotos recentes no mundo (USGS, últimas 24h).  |
| `/vulcao` | `get_volcano_report` | Atividade vulcânica global (Smithsonian GVP, semanal).  |
| `/asteroides` | `get_asteroid_report` | Asteroides próximos da Terra hoje (NASA NeoWs).  |
| `/iss` | `track_iss` | Posição atual da ISS com mapa; avisa se está sobre o Brasil.  |
| `/trajetoria` | `get_asteroid_trajectory` | Gráfico 3D da órbita de um asteroide (JPL SBDB, cálculo local kepleriano). |
| `/clima` | `get_weather` | Clima atual de uma cidade (OpenWeatherMap).  |
| `/noaa` | `fetch_noaa_data` | Clima espacial NOAA: raios-X, Kp, vento solar, prótons, alertas, previsão.  |
| `/noaamidia` | `get_noaa_media` | Imagens/vídeos solares: D-RAP, SDO, coronógrafo SOHO, ENLIL. ⚙️ |
| `/solar` | `get_solar_status` | Resumo da atividade solar: flares, CME, Kp e tendência.  |
| `/radar` | `scan_radar_feeds` | Radar aéreo: aeronaves ao redor de uma cidade (OpenSky) + mapa.  |
| `/radio` | `scan_radio_stations` | Rádios online mais ouvidas (Radio-Browser). Não é varredura de RF.  |
| `/frente` | `get_frontline_report` | Manchetes de conflitos (Liveuamap / Google News).  |
| `/guerra` | `get_war_snapshot` | Print do painel/mapa + manchetes. Exige navegador ⚙️; se o site mostrar verificação anti-robô, devolve o relatório em texto. |
| `/pizzint` | `get_pizzint_status` | Leitura do PIZZINT / DEFCON watch.  |
| `/sentinela` | `capture_sentinel` | Foto da webcam local (Sentinela). Opt-in + token obrigatório. 🔒 |
| `/relatorio` | `get_situation_report` | Painel geral: sismos, vulcões, sol, asteroides e ISS de uma vez.  |

⚙️ exige recurso extra (navegador/ffmpeg) · 🔒 exige opt-in + token. `/ferramentas` lista tudo.
Exemplos: `/radar Campo Grande 200` · `/clima Dourados MS` · `/noaa kp` · `/sdo` · `/frente israel 8` · `/radio news`.

**Modo autônomo** (linguagem natural): `POST /api/v1/tools/dispatch {"text": "teve terremoto hoje?"}`
ou `/chat` com `"auto_intent": true`. É heurístico e conservador: ferramentas pesadas e a câmera
**só** disparam por comando explícito. Para o próprio LLM escolher ferramentas (function-calling):
`GET /api/v1/tools/manifest?format=ollama` (a câmera nunca aparece no manifesto).

## Rotas

`GET /api/v1/tools` · `GET /help` · `GET /manifest` · `POST /chat` · `POST /dispatch` ·
`POST /{nome}` (body `{"args": {...}}`) · `GET /media/{arquivo}` · `GET /private/{arquivo}` (token).

## Segurança e robustez

- **Isolamento de falhas:** `@safe_tool` converte qualquer erro (rede, timeout, JSON ruim, bug) em `ToolResult(ok=False)`;
  bug inesperado vai pro log, não pro chat. Teto duro por chamada (`TOOLS_CALL_TIMEOUT_S`).
- **Rate limit de terceiros:** cache TTL + single-flight (várias perguntas iguais = 1 chamada externa).
- **Sem bloqueio do loop:** HTTP async; matplotlib/OpenCV em `to_thread`; ffmpeg via `create_subprocess_exec`; Playwright async.
- **Auth:** com `TOOLS_API_TOKEN` definido, todas as rotas exigem `X-Nexus-Token`. **Sem token configurado as rotas ficam abertas**
  (comportamento igual ao resto da API atual) — defina um se o Nexus for acessível fora do seu PC.
- **Câmera (sentinela):** desligada; `TOOLS_ENABLE_SENTINEL=true` **exige** token (o app não sobe sem ele); foto em pasta privada.
- **Navegador:** opt-in, só HTTPS e só hosts da allowlist (inclusive após redirect), um Chromium por vez.
- **Entradas:** modo do rádio/cidade/args validados (sem injeção no path da URL), arquivos gerados com nome único + expiração
  (`TOOLS_MEDIA_TTL_H`) e proteção contra path traversal/symlink.

## Mudanças em relação aos scripts legados

| Legado | Decisão |
|---|---|
| `solar_monitor.py` (Tkinter, 1350 linhas) | **Não portado como GUI.** Dependia de `NOAAService.register_alert_callback`/`SpaceWeatherData`, que **não existem** no `noaa_service.py` v3.0 enviado. Portada só a lógica (índices, tendência) em `solar.py`. |
| `simple_solar_monitor.py` | Descartado (stubs/"dummy" de compatibilidade para o GUI). |
| `air_traffic.py` + `radar_api.py` | Unificados em `scan_radar_feeds` (geopy → Nominatim via httpx). |
| `liveuamap_intel.py` | `webbrowser.open` (abria navegador **no servidor**) e `cloudscraper` (burla de anti-bot) removidos; fallback Google News RSS mantido. |
| `radio_scanner.py` | Mantido, mas descrito como o que é: diretório de **rádios online**, não varredura de RF. |
| NOAA | Corrigidos: banda 0.1–0.8 nm do raio-X, filtro ≥10 MeV nos prótons, escala S1–S5 (legado marcava S5 com 1000 pfu), formatos atuais de vento solar/Kp (lista-de-listas), teto de 3 pts por avisos de rotina no score. |
| Asteroides/ISS/sismos | `KeyError` quando o dia não vem no feed, `mag` nulo, `callsign` nulo, horários agora em UTC. |
| Arquivos fixos (`radar_final.png`...) | Nomes únicos (sem corrida entre chamadas simultâneas). |

## Dependências

`matplotlib`, `defusedxml` (já em `requirements*.txt`). Opcionais: `playwright` (+ `playwright install chromium`), `opencv-python`, `ffmpeg` no PATH.

## Testes

`pytest tests/test_tools_parsers.py tests/test_tools_integration.py` — sem rede (`httpx.MockTransport`).
**Não** cobrem as APIs reais (USGS, NOAA, OpenSky...) nem Playwright/câmera: valide numa máquina com internet.
