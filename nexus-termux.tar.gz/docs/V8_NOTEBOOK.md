# Nexus-Bridge v8.0 — guia para o notebook (i3-3110M · 8 GB · Intel HD 4000)

## O que o seu hardware permite (e o que não)
| Item | Seu notebook | Consequência |
|---|---|---|
| CPU | i3-3110M, 2 núcleos / 4 threads, sem AVX2 | tudo roda em CPU; usamos **2 threads** de cálculo (núcleos físicos) |
| RAM | 8 GB DDR3 (≈5 GB úteis com o Windows) | **um modelo pesado por vez**; guardas de RAM antes de carregar |
| Vídeo | Intel HD 4000 (32 MB) | **não acelera nada** (nem torch nem Ollama): ignore a GPU |

Por isso a v8.0 tem o **perfil `lite`** (`NEXUS_PROFILE=lite`, também escolhido sozinho se não houver driver NVIDIA).

## Orçamento de RAM (valores aproximados, não medidos neste notebook)
- Windows + navegador leve: 2,5–3,5 GB
- Ollama `qwen2.5:3b-instruct-q4_K_M`: ~2–2,5 GB · `qwen2.5:1.5b-instruct-q4_0`: ~1–1,3 GB
- Whisper `base` int8: ~0,3–0,5 GB
- XTTS v2: ~2–3 GB (**não cabe junto com o LLM** — por isso o pipeline descarrega um antes de carregar o outro)

## Instalação
1. Python 3.11 ou 3.12 de 64 bits, ffmpeg no PATH, Ollama instalado.
2. `ollama pull qwen2.5:3b-instruct-q4_K_M` e `ollama pull qwen2.5:1.5b-instruct-q4_0`
3. Execute `start.bat` (cria a venv, instala torch CPU + `requirements.lite.txt`, cria `.env` a partir do `.env.example`, sobe o Ollama e o Nexus).
4. Confira `http://127.0.0.1:666/api/system` (perfil, RAM, threads) e `http://127.0.0.1:666/api/health`.

## O que roda onde
| Recurso | No notebook | Observação |
|---|---|---|
| Chat / ferramentas JARVIS / RAG | ✅ | modelos pequenos |
| Dublagem (Whisper → Ollama → XTTS) | ✅ **lenta** | só pela fila para áudios > ~15 s; veja os tempos por etapa no log |
| Modo ligação | ✅ com limites | prefira `piper`; recusa iniciar se há job pesado rodando (HTTP 409) |
| Vídeo | ☁️ Kaggle | `VIDEO_PROVIDER=kaggle_wan` |
| Imagem (ComfyUI/Fooocus) e 3D (Hunyuan3D) | ❌ | exigem GPU; o job falha **na hora** com mensagem clara |

## Diagnóstico de falhas
- `logs/nexus.log`: tudo que aparece no console (rotativo, 2 MB × 3).
- `logs/faulthandler.log`: pilha de crashes **nativos** (ctranslate2/torch) — resolve o "o processo fechou sem traceback" de `docs/need-fix.md`.
- `/api/system`: RAM livre, modelos residentes, job pesado em execução.

## Ajustes finos (`.env`)
`CPU_THREADS` (2), `WHISPER_MODEL_SIZE` (base/tiny/small), `MIN_FREE_RAM_XTTS_MB`, `XTTS_IDLE_UNLOAD_S`, `MAX_QUEUED_JOBS`, `ROBLOX_NUM_CTX`, `CALL_TTS_ENGINE=piper`.
