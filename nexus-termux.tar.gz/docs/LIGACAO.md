# Modo ligação — Nexus-Bridge

Conversa por voz: **fala → Whisper → Ollama (stream) → frases → XTTS v2 → áudio**, com interrupção.
Endpoints em `/api/v1/call/*` (código em `app/call/`).

## Instalar (PC sem GPU)
```bash
pip install torch==2.5.1 torchaudio==2.5.1 --index-url https://download.pytorch.org/whl/cpu
pip install -r requirements.cpu.txt
ollama pull qwen2.5:1.5b-instruct-q4_0
```

## `.env` sugerido (8 GB de RAM, CPU)
```
XTTS_DEVICE=cpu
CALL_OLLAMA_MODEL=qwen2.5:1.5b-instruct-q4_0
CALL_OLLAMA_NUM_CTX=2048
CALL_OLLAMA_NUM_PREDICT=120
CALL_WHISPER_MODEL=base
CALL_WHISPER_DEVICE=cpu
CALL_TTS_ENGINE=xtts
```
No terminal que roda o Ollama: `OLLAMA_KEEP_ALIVE=-1`, `OLLAMA_NUM_PARALLEL=1`, `OLLAMA_MAX_LOADED_MODELS=1`.
O bridge força Whisper, Ollama e XTTS a usar CPU, independentemente dos
valores de device no `.env`. `IMAGE_PROVIDER=fooocus` ou `comfyui` seleciona
o servidor externo para geração de imagens; vídeo, 3D e propaganda continuam
usando o ComfyUI configurado em `COMFYUI_HOST`.

## O que esperar em CPU
- A 1ª ligação carrega 3 modelos de um HDD: o app mostra "Preparando…" até ficar pronto.
- O gargalo é o **XTTS** (cada frase pode levar bem mais do que a duração do áudio). Por isso a resposta é
  quebrada em frases e tocada conforme fica pronta, e o prompt força respostas curtas.
- Se ficar lento demais: `CALL_TTS_ENGINE=piper` (+ `pip install piper-tts` e `CALL_PIPER_MODEL_PATH=...onnx`).
- Sem ligações ativas por `CALL_IDLE_UNLOAD_S` (10 min), Whisper e XTTS são descarregados da RAM.

## Testes
`python -m pytest tests -q` (usam motores falsos; não precisam de modelos).
