# Módulo "Criar Propaganda"

Link do produto → dados + fotos reais → roteiro (voz única) + prompts de cena → clipes LTX-Video
(retrato) → narração XTTS v2 → montagem ffmpeg (cortes, legendas, marca d'água, música com ducking).

## Fluxo (2 jobs na MESMA fila; um por vez, sem disputa de VRAM)

1. `POST /api/v1/ads/plan` `{url | manual, target_duration_s, scenes_count}` → job `ad_plan`.
   `GET /api/jobs/{id}` → `result = {product, plan}` (o usuário revisa/edita no front).
2. `POST /api/v1/ads/render` (multipart): `payload` = JSON `{product, plan, options}` + arquivos
   opcionais `music`, `watermark`, `voice` → job `ad_render`. `progress` traz a etapa; ao concluir,
   `file_path` = mp4 servido em `/videos/ad_<id>.mp4`.
3. `GET /api/v1/ads/{assets_id}/refs/ref_N.jpg` serve só as fotos de referência.

Ordem de VRAM no render: Ollama (unload) → ComfyUI/LTX → `POST /free` no ComfyUI → XTTS (unload) → ffmpeg (CPU).

## Fidelidade ao produto
- Primeiro quadro de cada clipe = FOTO REAL do anúncio (não uma imagem gerada do zero).
- A foto é encaixada em 2:3 com fundo desfocado (nada do produto é cortado).
- Prompt de cena: só o produto + 1 movimento de câmera + sufixo fixo "produto rígido, sem pessoas/mãos/texto".
- O roteiro só pode usar fatos dos dados do produto; números que não aparecem neles geram aviso na UI.

## Sem fotos reais
Se nenhuma foto do produto puder ser achada/baixada, o job de plano cria `AD_GENERATED_IMAGES_COUNT`
imagens de referência por IA (Ollama escreve o prompt a partir da descrição → ComfyUI T2I, em retrato)
e marca `product.images_generated = true` + aviso. São imagens inventadas a partir do TEXTO: o produto
mostrado pode diferir do real. Desligue com `AD_GENERATE_IMAGES_WHEN_MISSING=false`.

## Configuração (.env) — ver `.env.example`
`AD_OLLAMA_MODEL`, `AD_VIDEO_WIDTH/HEIGHT`, `AD_VOICE_REFERENCE_PATH`, `FFMPEG_BINARY`, `FFPROBE_BINARY`,
`ML_CLIENT_ID`, `ML_CLIENT_SECRET` (leitura de links do Mercado Livre pela API oficial; sem elas o job cai no preenchimento manual).
Requer `ffmpeg`/`ffprobe` no PATH. Sem dependências Python novas.

## Testes
`pytest tests/test_ads.py` (27 testes; os de ffmpeg pulam se ele não estiver instalado).
