# Video remoto: Kaggle + ComfyUI + Wan 2.2 5B (T2V e I2V)

O Nexus liga sozinho um notebook no Kaggle (GPU gratis) quando chega um job de video, espera o ComfyUI
ficar online (a URL do ngrok e aleatoria e o notebook a publica no ntfy.sh), gera o video e o notebook se desliga sozinho quando fica ocioso.

## Configuracao unica (faca uma vez)

1. **ngrok**: so o *Authtoken* (dashboard.ngrok.com). Nao precisa de dominio fixo.
2. **Kaggle**: telefone verificado (feito) e chave de API (feita).
3. **.env** (copie as linhas de `.env.example`):
   ```
   VIDEO_PROVIDER=kaggle_wan
   KAGGLE_USERNAME=seu_usuario_kaggle
   KAGGLE_KEY=...            # chave legada; se comecar com KGAT_ pode colar aqui mesmo
   NGROK_AUTHTOKEN=...
   # NTFY_TOPIC=...          # opcional; vazio = o Nexus gera um e guarda em .kaggle_state.json
   ```
   (`NGROK_DOMAIN` nao e mais usado; pode apagar do `.env`.)
4. `pip install -U kaggle six` (ja estao no requirements.txt; a CLI 2.x importa o `six` sem declarar).

## Como o Nexus descobre a URL

O notebook abre o ngrok (URL aleatoria) e publica `NEXUS_URL <sessao> <url>` num topico do **ntfy.sh**
(servico gratis, sem conta). O Nexus le esse topico depois do push e testa `<url>/system_stats`.

- A `<sessao>` e gerada pelo Nexus a cada push; mensagens de outra sessao sao ignoradas.
- So URLs `https://*.ngrok-free.app|dev`, `*.ngrok.app|dev|io` sao aceitas.
- O topico fica em `.kaggle_state.json` (junto com a ultima URL e sessao). Quem souber o topico le a URL
  do ComfyUI, entao nao o compartilhe. Para trocar, apague o arquivo ou defina `NTFY_TOPIC`.
- Se o Nexus reiniciar com o notebook ainda no ar, ele reaproveita a URL guardada.
- O notebook republica a URL a cada 5 min.

## Teste por etapas (nessa ordem)

```
python tools/kaggle_smoke_test.py check     # autentica no Kaggle?
python tools/kaggle_smoke_test.py start     # sobe o notebook (5 a 15 min na 1a vez)
python tools/kaggle_smoke_test.py t2v "a red fox running in snow"
python tools/kaggle_smoke_test.py i2v foto.png "the camera slowly zooms in"
python tools/kaggle_smoke_test.py stop
```
Acompanhe o notebook em `https://www.kaggle.com/code/<usuario>/nexus-comfyui-wan` (aba *Logs*).

## Uso normal

- `POST /api/generate-video` funciona como antes. **Sem `input_image_base64` vira T2V**; com imagem, I2V.
- `GET /api/kaggle/status` mostra se esta online; `POST /api/kaggle/stop` desliga na hora.
- Desliga sozinho: ocioso por `KAGGLE_IDLE_TIMEOUT_MIN` (10), ou ao passar de `KAGGLE_MAX_SESSION_MIN` (180).

## Limites e cuidados

- Cota do Kaggle: ~30 h de GPU por semana, sessao de ate ~9 h. O teto de 180 min protege a cota.
- A cada sessao o notebook baixa ~18 GB de modelos (alguns minutos). Evolucao futura: guardar os
  modelos em um Kaggle Dataset para montar instantaneamente.
- O notebook e **privado**, mas contem o authtoken do ngrok no codigo-fonte dele. Nao compartilhe o
  notebook; se vazar, gere outro token no ngrok.
- O prompt negativo continua sendo o de `app/constants.py` (feito para produtos, exclui pessoas). Para
  T2V com gente, ajuste esse arquivo.
- A GPU padrao do Kaggle (P100 ou T4) e bem mais lenta que uma 4090: ~832x480, 81 frames, 20 steps
  pode levar varios minutos por video. Ajuste `WAN_STEPS`/`WAN_LENGTH` se precisar.
- Nao testado contra o Kaggle/ngrok/ntfy reais (a sandbox nao os alcanca): a logica foi testada com uma CLI
  falsa, um ntfy falso e um ComfyUI simulado. O primeiro `start` real pode revelar ajustes (ver Logs do notebook).


## Perfis de video (`WAN_PROFILE`)

| Perfil | Modelos baixados no inicio | Faz | Obs. |
|---|---|---|---|
| `draft` (padrao) | Wan 2.2 5B fp16 (~18 GB) | texto->video e imagem->video, 5 s @ 24 fps | rapido; qualidade de teste |
| `quality` | Wan 2.2 A14B I2V em GGUF Q4_K_M (2 x 9,65 GB) + LoRAs Lightning de 4 passos + VAE do Wan 2.1 + umt5 (~30 GB) | so imagem->video, 5 s @ 16 fps | bem melhor em movimento e fidelidade; mais lento |

| `hunyuan` | HunyuanVideo 1.5 I2V 480p (`HUNYUAN_UNET`, padrao step-distilled fp8) + Qwen2.5-VL 7B fp8 + ByT5 + VAE + SigLIP (~20 GB, estimativa) | so imagem->video, 5 s @ 24 fps | nos nativos do ComfyUI (sem custom nodes); nao testado na T4 |
| `r2v` (**padrao**) | Wan 2.1 VACE 1.3B (`R2V_UNET`, fp16 ~6,5 GB) + VAE do Wan 2.1 + umt5 (~14 GB) | **referencia -> video**, 5 s @ 16 fps, ~480p | nos nativos do ComfyUI (`WanVaceToVideo` + `TrimVideoLatent`), sem custom nodes; nao testado na T4 |
| `minimax` (experimental) | MiniMax H3 Ref2VA podado fp8 (~20 GB) + Qwen3-VL-32B NVFP4-AWQ (~15 GB) + VAEs de video e audio (~5,5 GB) + LoRA turbo opcional | **referencia -> video com audio**, ~1,6 s @ 24 fps, ~0,25 MP | ComfyUI >= 0.30 (no nativo `MiniMaxH3ReferenceToVideo`), `--lowvram`; repo gated; nao testado na T4 |

- O `hunyuan` usa 8 passos e cfg 1 no checkpoint step-distilled, entao o **prompt negativo nao tem efeito**. O refinador do Ollama tem prompt proprio (so movimento, sem objetos/maos novos). O log do Kaggle mostra `no HunyuanVideo15ImageToVideo: ok` quando o ComfyUI clonado tem o no.
- Resolucao do `hunyuan`: ~480p seguindo a foto dentro de `HUNYUAN_MAX_PIXELS` (1:1 -> 640x640, 9:16 -> 480x864). Se estourar a memoria, o Nexus repete com 60% dos pixels e 81 frames.
- O `quality` instala o no ComfyUI-GGUF no notebook. O log do Kaggle mostra `no UnetLoaderGGUF: ok` quando carregou.
- Com Lightning o `cfg` e 1, entao o **prompt negativo nao tem efeito**: escreva o que quer no prompt positivo.
- A resolucao segue a proporcao da foto dentro de `WAN14B_MAX_PIXELS` (9:16 -> 576x1024, 1:1 -> 768x768).
- O A14B gera a 16 fps. Para 24/30/60 fps interpole no editor (ex.: RIFE ou o recurso de interpolacao do CapCut).
- Se a T4 estourar a memoria, o Nexus repete com 60% dos pixels e 57 frames. Se ainda faltar: baixe `WAN14B_MAX_PIXELS`.
- Trocou o perfil com o notebook ligado? `python tools/kaggle_smoke_test.py stop`, espere ~30 s e gere de novo.

### Fluxo para poucos clipes (ex.: 5 clipes de 5 s)
1. Gere a **foto inicial** de cada clipe na IA de imagem que voce usa (9:16, cena nova com o produto de referencia).
2. Mande a foto no Jarvis com a legenda `/video ! <prompt so de movimento, em ingles>` (o `!` pula o Ollama).
3. Audio, legenda, musica e marca d'agua ficam no seu editor.

## Perfil `r2v` (reference-to-video)

- No `r2v` a imagem enviada em `input_image_base64` **nao e o primeiro frame**: e uma **referencia** do sujeito (produto, personagem, objeto). O modelo coloca esse sujeito numa cena nova descrita pelo prompt. No `draft`, `quality` e `hunyuan` a imagem continua sendo o 1o frame (I2V).
- O contrato da API nao muda: `POST /api/generate-video` com `input_image_base64` continua igual. Sem imagem, o `r2v` recusa o job (a referencia e obrigatoria); para texto -> video use `WAN_PROFILE=draft`.
- O refinador do Ollama tem prompt proprio: descreve a **cena nova** e a acao do sujeito ("the subject from the reference image ..."), nao o conteudo da foto.
- Dicas de entrada: sujeito inteiro, centralizado e nitido, de preferencia sobre fundo liso/branco. Se o sujeito nao ficar parecido, suba `R2V_STRENGTH` (ate ~1.3); se ficar "colado"/rigido, baixe para ~0.8.
- O `r2v` usa 30 passos e cfg 6, entao o **prompt negativo funciona** (`R2V_NEGATIVE_PROMPT`). Resolucao: ~480p seguindo a foto dentro de `R2V_MAX_PIXELS`. Se estourar a memoria, o Nexus repete com 60% dos pixels e 49 frames.
- O log do Kaggle mostra `no WanVaceToVideo: ok` quando o ComfyUI clonado tem o no.
- Teste: `python tools/kaggle_smoke_test.py r2v ref.png "the subject walks slowly through a sunny forest"`.

## Perfil `minimax` (MiniMax H3, experimental no Kaggle)

Gambiarra para rodar o MiniMax H3 Ref2VA na GPU gratis do Kaggle (T4/P100 de 16 GB). **Nada disso foi testado numa T4 de verdade.**

- **Antes de ligar:** (1) aceite a licenca em huggingface.co/Comfy-Org/MiniMax-H3 com a conta do `HF_TOKEN`, (2) `WAN_PROFILE=minimax` no `.env`, (3) `python tools/kaggle_smoke_test.py stop` se o notebook estiver ligado. Confira tambem os termos da licenca (a licenca aberta nao cobre alguns territorios, incluindo os EUA, onde ficam os servidores do Kaggle).
- **O que o notebook faz:** baixa ~40 GB, sobe o ComfyUI com `--lowvram` (os pesos ficam na RAM e passam pela GPU em streaming) e confere o no `MiniMaxH3ReferenceToVideo`. O log mostra `no MiniMaxH3ReferenceToVideo: ok` e `turbo_lora: ok` ou `AUSENTE`.
- **LoRA turbo (4 passos):** o caminho dele no repo e um palpite. Se o download falhar, o Nexus detecta e roda com 20 passos (`MINIMAX_STEPS`), bem mais lento.
- **Audio:** o H3 gera som junto; o MP4 sai com audio.
- **Prompt:** a foto entra como `<Picture 1>`. O refinador do Ollama escreve nesse formato (e o provider acrescenta a tag se faltar).
- **Limites realistas:** frames 17n+5, ~0,25 MP, ~1,6 s por padrao. Se estourar a memoria, o Nexus repete com 60% dos pixels e 22 frames. O job tem teto de `MINIMAX_JOB_TIMEOUT_S` (90 min) e a sessao do Kaggle, `KAGGLE_MAX_SESSION_MIN` (180 min): na T4 um clipe pode levar bem mais que no Wan.
- **Riscos conhecidos:** a T4 nao tem bf16 nem fp8 nativos; se o video sair preto/ruidoso, e provavel overflow em fp16. Plano B: `WAN_PROFILE=r2v` (Wan VACE).
