# Integração OpenHands (bot + Nexus)

Copie cada arquivo para o mesmo caminho no seu projeto (sobrescreva os existentes):

nexus-bridge/app/providers/openhands_provider.py   (NOVO)
nexus-bridge/app/openhands_router.py                (NOVO)
nexus-bridge/app/config.py                          (+ 6 variáveis OPENHANDS_*)
nexus-bridge/app/main.py                            (+ 2 linhas: include_router)
jarvis-bot/jarvis/nexus.py                          (+ submit_code / wait_code_task / stop)
jarvis-bot/jarvis/config.py                         (+ CODE_POLL_INTERVAL_S / CODE_MAX_WAIT_S)
jarvis-bot/jarvis/handlers.py                       (+ /code)
jarvis-bot/jarvis/app.py                            (+ registro do /code, só admins)
jarvis-bot/.env.example                             (+ 2 linhas)

## .env do Nexus
TOOLS_API_TOKEN=um-segredo-longo            # OBRIGATÓRIO: sem ele /api/v1/openhands responde 403
OPENHANDS_AGENT_PROFILE_ID=1025f182-d52b-44d6-9edb-0ba817e6b9fb
OPENHANDS_WORKSPACE=C:\Cyberverse\workspace

## .env do bot
NEXUS_TOKEN=um-segredo-longo                # mesmo valor do TOOLS_API_TOKEN

## Uso no Telegram
/code projeto:site crie um index.html com uma landing page
/code parar
