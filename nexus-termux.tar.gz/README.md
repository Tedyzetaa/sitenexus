> **v8.0** — perfil `lite` para notebook sem GPU (i3 / 8 GB). Comece por [docs/V8_NOTEBOOK.md](docs/V8_NOTEBOOK.md). Mudanças em `RELATORIO_V8.md`.

**README.md**

Bem-vindo ao Nexus: Um Projeto de Inteligência Artificial Avançado para Tradução e Dublagem!

### Introdução

O Nexus é um projeto de software que utiliza técnicas de inteligência artificial para realizar traduções e dublagens de alta qualidade. O objetivo do projeto é fornecer uma plataforma escalável e eficiente para realizar tarefas de tradução e dublagem, com foco em precisão e velocidade.

### Características

- **Tradução e Dublagem**: O Nexus pode realizar traduções e dublagens em vários idiomas, incluindo inglês, espanhol, francês, alemão, japonês e chinês.
- **Técnicas de IA**: O projeto utiliza técnicas de processamento de linguagem natural (NLP) e aprendizado de máquina para realizar traduções e dublagens.
- **Plataforma Escalável**: O Nexus é projetado para ser escalável, permitindo que ele seja executado em ambientes com grande demanda de recursos.
- **Integração com APIs**: O projeto pode integrar-se com várias APIs de tradução e dublagem, incluindo Google Translate, Microsoft Translator e Amazon Translate.

### Componentes

O Nexus é composto por vários componentes, incluindo:

- **App**: É o núcleo do projeto, responsável por gerenciar as tarefas de tradução e dublagem.
- **Providers**: São os provedores de serviços que realizam as tarefas de tradução e dublagem. Exemplos incluem Google Translate, Microsoft Translator e Amazon Translate.
- **Queue Manager**: É o componente responsável por gerenciar a fila de tarefas de tradução e dublagem.
- **Status Manager**: É o componente responsável por gerenciar o status das tarefas de tradução e dublagem.

### Funções

O Nexus oferece várias funções, incluindo:

- **Traduzir texto**: O usuário pode inserir um texto para ser traduzido em outro idioma.
- **Dublar áudio**: O usuário pode inserir um arquivo de áudio para ser dublado em outro idioma.
- **Gerenciar fila**: O usuário pode gerenciar a fila de tarefas de tradução e dublagem.
- **Verificar status**: O usuário pode verificar o status das tarefas de tradução e dublagem.

### Requisitos

O Nexus requer os seguintes requisitos:

- Python 3.7 ou superior
- Bibliotecas necessárias: Flask, PyJWT, Boto3, Google Cloud Client Library
- Ambiente de desenvolvimento: PyCharm, Visual Studio Code

### Instalação

Para instalar o Nexus, siga os passos abaixo:

1. Clonar o repositório do GitHub.
2. Criar um ambiente virtual com Python 3.7 ou superior.
3. Instalar as bibliotecas necessárias.
4. Executar o aplicativo com o comando `python app/main.py`.

### Chat com RAG (Langflow)

Configure no `.env` o endereço do Langflow, o ID do flow e o ID interno do nó
Knowledge (o valor `knowledge` é substituído a cada chamada):

```env
LANGFLOW_HOST=http://127.0.0.1:7860
LANGFLOW_FLOW_ID=seu-flow-id
LANGFLOW_KNOWLEDGE_NODE_ID=Knowledge-ID-Do-Seu-No
LANGFLOW_TIMEOUT_S=60
```

O backend recebe `POST /api/chat` com `{"message":"...","selectedRag":"..."}`.
Timeout do Langflow retorna HTTP 504; falhas de conexão ou respostas HTTP de
erro retornam HTTP 502.

### Documentação

Para obter mais informações sobre a documentação do Nexus, clique [aqui](SUMMARY.md).

### Contribuição

O Nexus é um projeto aberto e você pode contribuir para ele! Para fazer isso, siga os passos abaixo:

1. Clonar o repositório do GitHub.
2. Crie uma nova branch com seu nome.
3. Faça suas alterações e commits.
4. Abra uma solicitação de pull.

### Licença

O Nexus é licenciado sob a licença MIT. Você pode ler mais sobre a licença [aqui](LICENSE.md).

**Fim da Documentação**

Espero que você tenha gostado do README do Nexus! Se tiver alguma dúvida ou precisar de ajuda, não hesite em contatar-me.