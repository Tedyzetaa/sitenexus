from app.call.text import SentenceSplitter, clean_for_speech


def feed_all(chunks, **kw):
    sp = SentenceSplitter(**kw)
    out = []
    for c in chunks:
        out += sp.feed(c)
    out += sp.flush()
    return out


def test_clean_removes_markdown_code_links_emoji():
    raw = "# Titulo\n**Oi** tudo bem 😀? Veja [aqui](http://x.com) e https://y.com\n```py\nprint(1)\n```\n- item"
    assert clean_for_speech(raw) == "Titulo Oi tudo bem ? Veja aqui e item"


def test_splits_on_sentence_boundaries_in_stream():
    out = feed_all(["Ola! Tudo be", "m com voce? Eu es", "tou otimo. Obrigado"])
    assert out == ["Ola! Tudo bem com voce?", "Eu estou otimo.", "Obrigado"]


def test_does_not_split_decimals():
    assert feed_all(["O valor e 3.5 reais e cabe no bolso."]) == ["O valor e 3.5 reais e cabe no bolso."]


def test_short_sentences_are_merged():
    assert feed_all(["Oi. Tudo bem por ai hoje?"]) == ["Oi. Tudo bem por ai hoje?"]


def test_long_text_without_punctuation_is_cut():
    out = feed_all(["palavra " * 60], max_chars=100)
    assert len(out) >= 3
    assert all(len(s) <= 100 for s in out)


def test_flush_returns_rest_and_empty_is_ignored():
    assert feed_all(["   ", "\n"]) == []
