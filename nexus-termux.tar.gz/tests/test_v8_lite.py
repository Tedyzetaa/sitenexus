"""Testes da v8.0 (perfil lite: notebook sem GPU, 8 GB de RAM)."""
import asyncio
import threading
import time

import pytest

from app import hardware
from app.config import Settings
from app.providers import xtts_provider
from app.providers.base import ResourceExhaustedError
from app.providers.ollama_provider import lang_label, split_for_translation


# ---------------------------------------------------------------- config / perfil
def test_lite_defaults_apply_only_when_not_explicit(monkeypatch):
    monkeypatch.setenv("NEXUS_PROFILE", "lite")
    monkeypatch.setenv("WHISPER_MODEL_SIZE", "small")
    s = Settings(_env_file=None)
    assert s.is_lite
    assert s.WHISPER_MODEL_SIZE == "small"          # explicito ganha
    assert s.VIDEO_PROVIDER == "kaggle_wan"         # padrao do lite
    assert s.JOB_HISTORY_LIMIT == 50
    assert s.max_queued_jobs == 10
    assert s.whisper_beam_size == 1


def test_gpu_profile_keeps_original_defaults(monkeypatch):
    monkeypatch.setenv("NEXUS_PROFILE", "gpu")
    s = Settings(_env_file=None)
    assert not s.is_lite
    assert s.WHISPER_MODEL_SIZE == "small" and s.VIDEO_PROVIDER == "local_ltx"
    assert s.whisper_beam_size == 5 and s.max_queued_jobs == 30
    assert s.ollama_options(num_ctx=1)["num_gpu"] == 0 and "num_thread" not in s.ollama_options()


def test_invalid_profile_rejected(monkeypatch):
    monkeypatch.setenv("NEXUS_PROFILE", "turbo")
    with pytest.raises(ValueError):
        Settings(_env_file=None)


def test_ollama_options_lite_sets_threads(monkeypatch):
    monkeypatch.setenv("NEXUS_PROFILE", "lite")
    monkeypatch.setenv("CPU_THREADS", "2")
    s = Settings(_env_file=None)
    assert s.ollama_options(temperature=0.2) == {"num_gpu": 0, "num_thread": 2, "temperature": 0.2}


def test_roblox_settings_come_from_dotenv(tmp_path):
    env = tmp_path / ".env"
    env.write_text("NEXUS_PROFILE=lite\nROBLOX_NUM_CTX=3000\nROBLOX_OLLAMA_MODEL=qwen2.5:3b\n", encoding="utf-8")
    s = Settings(_env_file=str(env))
    assert s.roblox_num_ctx == 3000 and s.ROBLOX_OLLAMA_MODEL == "qwen2.5:3b"


# ---------------------------------------------------------------- hardware
def test_ensure_ram_blocks_when_low(monkeypatch):
    monkeypatch.setattr(hardware, "available_ram_mb", lambda: 500)
    with pytest.raises(ResourceExhaustedError):
        hardware.ensure_ram(2500, "o XTTS v2")
    hardware.ensure_ram(0, "x")  # 0 desliga


def test_ensure_ram_unknown_does_not_block(monkeypatch):
    monkeypatch.setattr(hardware, "available_ram_mb", lambda: None)
    hardware.ensure_ram(99999, "x")


def test_auto_threads_is_physical_cores(monkeypatch):
    monkeypatch.setattr(hardware, "logical_cpus", lambda: 4)
    assert hardware.auto_cpu_threads() == 2
    monkeypatch.setattr(hardware, "logical_cpus", lambda: 2)
    assert hardware.auto_cpu_threads() == 2


# ---------------------------------------------------------------- traducao em trechos
def test_split_for_translation_respects_limit_and_keeps_text():
    text = "Hello there. " * 300
    chunks = split_for_translation(text, 900)
    assert len(chunks) >= 4 and all(len(c) <= 900 for c in chunks)
    assert " ".join(chunks).replace(" ", "") == text.replace(" ", "")


def test_split_handles_giant_sentence_and_empty():
    assert [len(c) for c in split_for_translation("a" * 2000, 900)] == [900, 900, 200]
    assert split_for_translation("   ") == []


def test_lang_label():
    assert lang_label("pt-BR") == "Brazilian Portuguese (pt-BR)"
    assert lang_label("en") == "English"


# ---------------------------------------------------------------- XTTS: descarregar so se ocioso
def test_xtts_idle_unload_never_blocks_on_busy_lock():
    xtts_provider._model = object()
    xtts_provider._last_activity_ts = time.monotonic() - 10_000
    xtts_provider._pinned = False
    with xtts_provider._model_lock:           # simula sintese longa segurando o lock
        t0 = time.monotonic()
        assert xtts_provider._unload_if_idle() is False   # nao espera o lock
        assert time.monotonic() - t0 < 1
        assert xtts_provider.unload(blocking=False) is False
    assert xtts_provider._model is not None
    assert xtts_provider._unload_if_idle() is True        # lock livre + ocioso: descarrega
    assert xtts_provider._model is None


def test_xtts_pinned_model_survives_idle():
    xtts_provider._model = object()
    xtts_provider._last_activity_ts = 0.0
    xtts_provider._pinned = True
    try:
        xtts_provider._unload_if_idle()
        assert xtts_provider._model is not None
    finally:
        xtts_provider.unload()


# ---------------------------------------------------------------- fila cheia
async def test_queue_rejects_when_full(monkeypatch):
    from app.models import GenerateRequest, Job
    from app.queue_manager import QueueFullError, QueueManager

    class Orch:
        async def run(self, job):
            return job

    monkeypatch.setattr("app.queue_manager.settings", type("S", (), {"max_queued_jobs": 2, "JOB_HISTORY_LIMIT": 50})())
    q = QueueManager(Orch())  # worker NAO iniciado: jobs ficam aguardando
    for _ in range(2):
        await q.enqueue(Job(user_prompt="gato", request=GenerateRequest(user_prompt="gato")))
    with pytest.raises(QueueFullError):
        await q.enqueue(Job(user_prompt="gato", request=GenerateRequest(user_prompt="gato")))


# ---------------------------------------------------------------- orchestrator
async def test_release_payloads_keeps_job_valid():
    from app.models import Job, ThreeDGenerateRequest
    from app.services.orchestrator import _release_payloads

    req = ThreeDGenerateRequest(input_image_base64="A" * 5000)
    job = Job(user_prompt="x", kind="3d", request=req)
    _release_payloads(job)
    assert len(req.input_image_base64) >= 10 and "AAAA" not in req.input_image_base64
    Job.model_validate(job.model_dump())  # o GET /api/jobs/{id} re-valida o job


async def test_preflight_fails_fast_when_generator_offline():
    from app.providers.base import ProviderUnavailableError
    from app.services.orchestrator import NexusOrchestrator

    class Off:
        async def health_check(self):
            return False

    class OnDemand(Off):
        on_demand = True

    with pytest.raises(ProviderUnavailableError):
        await NexusOrchestrator._preflight(Off(), "Gerador", "dica")
    await NexusOrchestrator._preflight(OnDemand(), "Gerador", "dica")  # Kaggle: nao bloqueia
    await NexusOrchestrator._preflight(None, "Gerador", "dica")


# ---------------------------------------------------------------- API
def test_system_and_health_lite(monkeypatch):
    monkeypatch.setenv("NEXUS_PROFILE", "lite")
    from fastapi.testclient import TestClient
    import app.main as m

    with TestClient(m.app) as c:
        r = c.get("/api/system")
        assert r.status_code == 200 and r.json()["version"] == "8.0.0"
        assert "ram_total_mb" in r.json()["hardware"]
        assert c.get("/api/health").json()["profile"] in ("lite", "gpu")


def test_health_check_is_cached():
    import app.main as m

    calls = {"n": 0}

    class P:
        async def health_check(self):
            calls["n"] += 1
            return True

    p = P()
    loop = asyncio.new_event_loop()
    try:
        assert loop.run_until_complete(m._safe_health(p.health_check, fresh=True))
        assert loop.run_until_complete(m._safe_health(p.health_check))
        assert calls["n"] == 1
        assert loop.run_until_complete(m._safe_health(p.health_check, fresh=True))
        assert calls["n"] == 2
    finally:
        loop.close()
