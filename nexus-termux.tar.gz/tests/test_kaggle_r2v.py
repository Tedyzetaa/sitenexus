"""Perfil WAN_PROFILE=r2v (Wan 2.1 VACE reference-to-video no Kaggle): workflow, provider, config e refinador."""
import asyncio
import json
from pathlib import Path

import pytest

from app.config import settings
from app.providers.base import ProviderUnavailableError
from app.providers.kaggle_wan_provider import KaggleWanVideoProvider

WF_PATH = Path("app/workflows/wan21_r2v_vace_api.json")


class _FakeManager:
    base_url = "https://x.ngrok-free.app"


def _provider() -> KaggleWanVideoProvider:
    return KaggleWanVideoProvider(manager=_FakeManager())


def _wf() -> dict:
    wf = json.loads(WF_PATH.read_text(encoding="utf-8"))
    wf.pop("_comment", None)
    return wf


def test_workflow_links_apontam_para_nos_existentes():
    wf = _wf()
    for nid, node in wf.items():
        for k, v in node["inputs"].items():
            if isinstance(v, list):
                assert str(v[0]) in wf, f"no {nid}.{k} aponta para no inexistente {v}"


def test_workflow_usa_imagem_como_referencia_e_nao_como_primeiro_frame():
    wf = _wf()
    vace = next(n for n in wf.values() if n["class_type"] == "WanVaceToVideo")
    assert "reference_image" in vace["inputs"] and "start_image" not in vace["inputs"]
    assert any(n["class_type"] == "TrimVideoLatent" for n in wf.values())


def test_build_r2v_prompt(monkeypatch):
    monkeypatch.setattr(settings, "WAN_PROFILE", "r2v")
    monkeypatch.setattr(settings, "R2V_STEPS", 12)
    monkeypatch.setattr(settings, "R2V_CFG", 5.0)
    monkeypatch.setattr(settings, "R2V_SHIFT", 6.0)
    monkeypatch.setattr(settings, "R2V_STRENGTH", 0.8)
    p = _provider()
    wf = p._build_wan_prompt("r2v", "pos", "neg", "ref.png", 640, 640, 81, 123)
    f = p._find_node_by_title
    assert wf[f(wf, "positive_prompt")]["inputs"]["text"] == "pos"
    assert wf[f(wf, "negative_prompt")]["inputs"]["text"] == "neg"
    assert wf[f(wf, "input_image")]["inputs"]["image"] == "ref.png"
    lat = wf[f(wf, "video_latent")]["inputs"]
    assert (lat["width"], lat["height"], lat["length"], lat["strength"]) == (640, 640, 81, 0.8)
    assert wf[f(wf, "model_shift")]["inputs"]["shift"] == 6.0
    ks = wf[f(wf, "ksampler")]["inputs"]
    assert (ks["steps"], ks["cfg"], ks["seed"]) == (12, 5.0, 123)
    assert wf[f(wf, "create_video")]["inputs"]["fps"] == settings.R2V_FPS


def test_template_original_nao_e_alterado(monkeypatch):
    monkeypatch.setattr(settings, "WAN_PROFILE", "r2v")
    p = _provider()
    p._build_wan_prompt("r2v", "um", "", "a.png", 640, 640, 81, 1)
    wf2 = p._build_wan_prompt("r2v", "dois", "", "b.png", 640, 640, 81, 2)
    assert wf2[p._find_node_by_title(wf2, "positive_prompt")]["inputs"]["text"] == "dois"


def test_negativo_do_r2v_ignora_o_do_app(monkeypatch):
    monkeypatch.setattr(settings, "WAN_PROFILE", "r2v")
    monkeypatch.setattr(settings, "R2V_NEGATIVE_PROMPT", "blurry")
    assert _provider()._negative("human, person, hand") == "blurry"


@pytest.mark.parametrize("profile", ["draft", "quality", "hunyuan"])
def test_outros_perfis_continuam_montando(monkeypatch, profile):
    monkeypatch.setattr(settings, "WAN_PROFILE", profile)
    p = _provider()
    wf = p._build_wan_prompt("i2v", "pos", "neg", "foto.png", 576, 1024, 81, 7)
    assert wf[p._find_node_by_title(wf, "positive_prompt")]["inputs"]["text"] == "pos"


def test_r2v_exige_imagem_de_referencia(monkeypatch):
    monkeypatch.setattr(settings, "WAN_PROFILE", "r2v")
    p = _provider()
    assert p.supports_t2v is False

    class _M(_FakeManager):
        async def ensure_online(self):
            return None

    p.manager = _M()
    with pytest.raises(ProviderUnavailableError, match="REFERENCIA"):
        asyncio.run(p.generate("x", "", b"", 640, 640, 81, 1.0, None))


def test_refinador_usa_prompt_de_r2v(monkeypatch):
    from app.providers import ollama_provider as op
    monkeypatch.setattr(settings, "VIDEO_PROVIDER", "kaggle_wan")
    monkeypatch.setattr(settings, "WAN_PROFILE", "r2v")
    seen = {}

    class _Resp:
        status_code = 200
        def raise_for_status(self): pass
        def json(self): return {"message": {"content": "ok"}}

    class _Client:
        def __init__(self, *a, **k): pass
        async def __aenter__(self): return self
        async def __aexit__(self, *a): return False
        async def post(self, url, json=None, **k):
            seen["system"] = json["messages"][0]["content"]
            return _Resp()

    monkeypatch.setattr(op.httpx, "AsyncClient", _Client)
    out = asyncio.run(op.OllamaProvider().refine_prompt("o tenis andando na praia", mode="video", has_image=True))
    assert out == "ok" and seen["system"] == op.REFINEMENT_SYSTEM_PROMPT_WAN_R2V


def test_config_aceita_perfil_r2v_e_valida_length(monkeypatch):
    from app.config import Settings
    Settings(WAN_PROFILE="r2v")  # nao levanta
    with pytest.raises(Exception, match="R2V_LENGTH"):
        Settings(WAN_PROFILE="r2v", R2V_LENGTH=80)
