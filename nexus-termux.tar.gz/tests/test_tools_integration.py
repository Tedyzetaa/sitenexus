"""Ferramentas ponta a ponta com HTTP simulado (httpx.MockTransport) + rotas FastAPI.
Nenhum teste toca a rede."""
import asyncio
import json

import httpx
import pytest
from fastapi import FastAPI
from fastapi.testclient import TestClient

from app.config import Settings, settings
from app.tools import base, hub, registry
from app.tools.router import router as tools_router


@pytest.fixture(autouse=True)
def isolated(tmp_path, monkeypatch):
    monkeypatch.setattr(settings, "OUTPUT_DIR_TOOLS", tmp_path / "tools")
    monkeypatch.setattr(settings, "TOOLS_HTTP_RETRIES", 1)
    monkeypatch.setattr(settings, "TOOLS_API_TOKEN", "")
    monkeypatch.setattr(settings, "TOOLS_ENABLED", True)
    base.clear_cache()
    base._client = None
    yield
    base._client = None
    base.clear_cache()


def mock_http(handler):
    base._client = httpx.AsyncClient(transport=httpx.MockTransport(handler), follow_redirects=True)


@pytest.fixture(autouse=True)
def no_sleep(monkeypatch):
    real = asyncio.sleep

    async def fast(_):  # backoff do retry sem esperar de verdade
        await real(0)

    monkeypatch.setattr(base.asyncio, "sleep", fast)


QUAKES = {"metadata": {"count": 2}, "features": [
    {"properties": {"mag": 6.7, "place": "Japan", "time": 1700000000000, "tsunami": 1}},
    {"properties": {"mag": 2.6, "place": "Alaska", "time": 1700000100000}}]}


async def test_seismic_ok_and_cached():
    calls = []

    def h(req):
        calls.append(str(req.url))
        return httpx.Response(200, json=QUAKES)

    mock_http(h)
    r1 = await hub.check_seismic_activity()
    r2 = await hub.check_seismic_activity()
    assert r1.ok and "M6.7" in r1.text and "tsunami" in r1.text and not r1.cached
    assert r2.cached and len(calls) == 1  # single-flight/TTL: 1 chamada externa


async def test_external_failure_never_raises():
    mock_http(lambda req: httpx.Response(503))
    r = await hub.check_seismic_activity()
    assert not r.ok and "USGS indisponivel" in r.error and r.text.startswith("⚠️")


async def test_network_error_and_bad_json_are_contained():
    def boom(req):
        raise httpx.ConnectError("dns")

    mock_http(boom)
    assert not (await hub.get_asteroid_report()).ok
    mock_http(lambda req: httpx.Response(200, content=b"<html>not json</html>"))
    r = await hub.check_seismic_activity()
    assert not r.ok and "JSON" in r.error


async def test_retry_recovers_from_transient_500():
    n = {"i": 0}

    def h(req):
        n["i"] += 1
        return httpx.Response(500) if n["i"] == 1 else httpx.Response(200, json=QUAKES)

    mock_http(h)
    assert (await hub.check_seismic_activity()).ok and n["i"] == 2


async def test_4xx_does_not_retry():
    n = {"i": 0}

    def h(req):
        n["i"] += 1
        return httpx.Response(403)

    mock_http(h)
    r = await hub.check_seismic_activity()
    assert not r.ok and n["i"] == 1


async def test_unexpected_bug_is_contained(monkeypatch):
    @base.safe_tool("explode")
    async def explode():
        raise KeyError("segredo-interno")

    r = await explode()
    assert not r.ok and "segredo-interno" not in r.text  # nao vaza detalhes internos


async def test_timeout_is_contained():
    @base.safe_tool("slow", timeout=0.05)
    async def slow():
        await asyncio.Event().wait()  # nunca termina

    r = await slow()
    assert not r.ok and "excedeu" in r.error


async def test_tools_disabled(monkeypatch):
    monkeypatch.setattr(settings, "TOOLS_ENABLED", False)
    assert not (await hub.check_seismic_activity()).ok


async def test_weather_fallback_queries_and_missing_key(monkeypatch):
    monkeypatch.setattr(settings, "OPENWEATHER_API_KEY", "")
    assert "OPENWEATHER_API_KEY" in (await hub.get_weather("x")).error

    monkeypatch.setattr(settings, "OPENWEATHER_API_KEY", "SECRETKEY123")
    seen = []

    def h(req):
        q = req.url.params["q"]
        seen.append(q)
        if q == "ivinhema,ms,BR":
            return httpx.Response(200, json={"name": "Ivinhema", "sys": {"country": "BR"},
                                             "main": {"temp": 31.2, "feels_like": 33.0, "humidity": 40},
                                             "weather": [{"description": "céu limpo"}], "wind": {"speed": 3.0}})
        return httpx.Response(404, json={"cod": "404"})

    mock_http(h)
    r = await hub.get_weather("Ivinhema MS")
    assert r.ok and seen == ["ivinhema,Mato Grosso do Sul,BR", "ivinhema,ms,BR"]
    assert "31.2" in r.text and r.data["wind_kmh"] == 10.8
    assert "SECRETKEY123" not in r.text and "SECRETKEY123" not in json.dumps(r.to_dict())  # chave nunca vaza

    mock_http(lambda req: httpx.Response(404))
    r = await hub.get_weather("Cidade Fantasma")
    assert not r.ok and "não localizado" in r.error

    mock_http(lambda req: httpx.Response(401))
    assert not (await hub.get_weather("Qualquer")).ok  # chave invalida: erro limpo, sem excecao


async def test_radar_end_to_end_with_image(monkeypatch):
    def h(req):
        assert "opensky" in str(req.url)
        return httpx.Response(200, json={"states": [
            ["a1", "GLO1234 ", "Brazil", 0, 0, -53.9, -22.2, 9500.0, False, 240.0],
            ["a2", None, "Brazil", 0, 0, -53.7, -22.4, 3000.0, False, 100.0]]})

    mock_http(h)
    r = await hub.scan_radar_feeds()  # sem geocoding: cidade base (Ivinhema)
    assert r.ok and r.data["count"] == 2 and "GLO1234" in r.text
    assert r.media and r.media[0].startswith("/api/v1/tools/media/")
    files = list((settings.OUTPUT_DIR_TOOLS / "public").glob("radar_*.png"))
    assert files and files[0].stat().st_size > 1000

    mock_http(lambda req: httpx.Response(200, json={"states": None}))
    base.clear_cache()
    assert (await hub.scan_radar_feeds()).data["count"] == 0  # sem trafego != erro


async def test_noaa_full_partial_failure_and_total_failure():
    plasma = [["time_tag", "density", "speed", "temperature"], ["t", "4", "700", "1e5"]]

    def h(req):
        u = str(req.url)
        if "plasma" in u:
            return httpx.Response(200, json=plasma)
        if "xrays" in u:
            return httpx.Response(200, json=[{"energy": "0.1-0.8nm", "flux": 2e-5, "time_tag": "t"}])
        if "text/" in u:
            return httpx.Response(200, text="forecast")
        return httpx.Response(500)  # kp, mag, protons, alerts fora do ar

    mock_http(h)
    r = await hub.fetch_noaa_data()
    assert r.ok and "classe **M**" in r.text and "700" in r.text and r.data["fontes_ok"] == 2

    s = await hub.get_solar_status()
    assert s.ok and s.cached and s.data["flare_class"] == "M"  # reaproveita o cache do NOAA

    base.clear_cache()
    mock_http(lambda req: httpx.Response(500))
    t = await hub.fetch_noaa_data()
    assert not t.ok and "NOAA" in t.error
    assert not (await hub.fetch_noaa_data("inexistente")).ok


async def test_situation_report_degrades_gracefully():
    def h(req):
        u = str(req.url)
        if "earthquake" in u:
            return httpx.Response(200, json=QUAKES)
        return httpx.Response(500)

    mock_http(h)
    r = await hub.get_situation_report()
    assert r.ok and "M6.7" in r.text and "indisponível" in r.error
    assert r.data["check_seismic_activity"]["total"] == 2


async def test_sentinel_and_browser_are_opt_in(monkeypatch):
    r = await hub.capture_sentinel()
    assert not r.ok and "TOOLS_ENABLE_SENTINEL" in r.error
    r = await hub.get_war_snapshot()
    assert not r.ok and "TOOLS_ENABLE_BROWSER" in r.error
    assert not (await hub.get_asteroid_trajectory("2340 Hathor")).ok


def test_config_blocks_sentinel_without_token():
    with pytest.raises(ValueError, match="TOOLS_API_TOKEN"):
        Settings(TOOLS_ENABLE_SENTINEL=True, TOOLS_API_TOKEN="", _env_file=None)
    Settings(TOOLS_ENABLE_SENTINEL=True, TOOLS_API_TOKEN="t", _env_file=None)


# --------------------------------------------------------------------------- #
# Registro / validacao de argumentos
# --------------------------------------------------------------------------- #
def test_coerce_args():
    spec = registry.get_spec("check_seismic_activity")
    assert registry.coerce_args(spec, {"limit": "99", "level": "strong"}) == {"limit": 15, "level": "strong"}
    assert registry.coerce_args(spec, {}) == {"level": "all", "limit": 5}
    with pytest.raises(ValueError):
        registry.coerce_args(spec, {"level": "xx"})
    with pytest.raises(ValueError):
        registry.coerce_args(spec, {"evil": 1})
    with pytest.raises(ValueError):
        registry.coerce_args(registry.get_spec("get_weather"), {"city": "a" * 200})


def test_manifest_hides_sensitive_and_is_wellformed():
    names = [t["function"]["name"] for t in registry.manifest("ollama")]
    assert "capture_sentinel" not in names and "check_seismic_activity" in names
    assert "capture_sentinel" in [t["name"] for t in registry.manifest("anthropic", include_sensitive=True)]
    json.dumps(registry.manifest("ollama"))


def test_every_registered_tool_is_exposed_and_unique():
    assert len({t.name for t in registry.TOOLS}) == len(registry.TOOLS)
    cmds = [c for t in registry.TOOLS for c in t.commands]
    assert len(cmds) == len(set(cmds)), "comando duplicado entre ferramentas"
    for t in registry.TOOLS:
        assert hasattr(hub, t.name), t.name


# --------------------------------------------------------------------------- #
# Rotas HTTP
# --------------------------------------------------------------------------- #
@pytest.fixture
def client():
    app = FastAPI()
    app.include_router(tools_router)
    with TestClient(app) as c:
        yield c


def test_route_chat_command_and_fallthrough(client):
    mock_http(lambda req: httpx.Response(200, json=QUAKES))
    r = client.post("/api/v1/tools/chat", json={"message": "/sismo"}).json()
    assert r["handled"] and r["tool"] == "check_seismic_activity" and "M6.7" in r["reply"]
    assert client.post("/api/v1/tools/chat", json={"message": "oi, tudo bem?"}).json() == {"handled": False}
    # linguagem natural so com auto_intent
    assert client.post("/api/v1/tools/chat", json={"message": "teve terremoto?"}).json()["handled"] is False
    base.clear_cache()
    assert client.post("/api/v1/tools/chat", json={"message": "teve terremoto?", "auto_intent": True}).json()["handled"]
    assert "radar" in client.post("/api/v1/tools/chat", json={"message": "/ferramentas"}).json()["reply"]


def test_route_invoke_validation_and_unknown(client):
    assert client.post("/api/v1/tools/naoexiste").status_code == 404
    r = client.post("/api/v1/tools/check_seismic_activity", json={"args": {"level": "bad"}})
    assert r.status_code == 200 and r.json()["ok"] is False  # erro de argumento vira resultado, nao 500
    mock_http(lambda req: httpx.Response(200, json=QUAKES))
    assert client.post("/api/v1/tools/check_seismic_activity", json={"args": {"limit": 1}}).json()["ok"]


def test_route_dispatch_dry_run(client):
    r = client.post("/api/v1/tools/dispatch", json={"text": "como está o clima em Dourados MS", "run": False}).json()
    assert r["matched"] and r["tool"] == "get_weather" and r["args"]["city"].startswith("Dourados")
    assert client.post("/api/v1/tools/dispatch", json={"text": "bom dia"}).json() == {"matched": False}


def test_route_auth_when_token_set(client, monkeypatch):
    monkeypatch.setattr(settings, "TOOLS_API_TOKEN", "segredo")
    assert client.get("/api/v1/tools").status_code == 401
    assert client.get("/api/v1/tools", headers={"X-Nexus-Token": "errado"}).status_code == 401
    ok = client.get("/api/v1/tools", headers={"X-Nexus-Token": "segredo"})
    assert ok.status_code == 200 and any(t["name"] == "capture_sentinel" for t in ok.json()["tools"])


def test_route_sensitive_needs_token(client):
    assert client.post("/api/v1/tools/capture_sentinel").status_code == 403
    assert client.post("/api/v1/tools/chat", json={"message": "/sentinela"}).status_code == 403
    assert all(t["name"] != "capture_sentinel" for t in client.get("/api/v1/tools").json()["tools"])


def test_media_serving_and_traversal(client, monkeypatch):
    pub, _ = base.new_media_file("t", "png")
    pub.write_bytes(b"\x89PNG")
    priv, purl = base.new_media_file("s", "png", private=True)
    priv.write_bytes(b"secret")

    assert client.get(f"/api/v1/tools/media/{pub.name}").status_code == 200
    assert client.get("/api/v1/tools/media/..%2F..%2Fetc%2Fpasswd").status_code == 404
    assert client.get("/api/v1/tools/media/%2e%2e").status_code == 404
    assert client.get(f"/api/v1/tools/media/{priv.name}").status_code == 404  # privado nao vaza no publico

    monkeypatch.setattr(settings, "TOOLS_API_TOKEN", "segredo")
    assert client.get(f"/api/v1/tools/private/{priv.name}").status_code == 401
    r = client.get(f"/api/v1/tools/private/{priv.name}", headers={"X-Nexus-Token": "segredo"})
    assert r.status_code == 200 and r.content == b"secret" and r.headers["cache-control"] == "no-store"


def test_media_prune_removes_expired(monkeypatch):
    old, _ = base.new_media_file("old", "png")
    old.write_bytes(b"x")
    import os, time
    os.utime(old, (time.time() - 3 * 86400, time.time() - 3 * 86400))
    base.new_media_file("new", "png")  # dispara a limpeza
    assert not old.exists()


def test_resolve_media_blocks_escape_at_function_level(tmp_path):
    """Testa a guarda de verdade (sem depender do roteamento do Starlette)."""
    outside = settings.OUTPUT_DIR_TOOLS / "segredo.txt"
    outside.parent.mkdir(parents=True, exist_ok=True)
    outside.write_text("nao pode sair")
    base.media_dir()  # cria public/
    # 1) traversal por nome
    for name in ("../segredo.txt", "..\\segredo.txt", str(outside), ".hidden", "a/b.png", ""):
        assert base.resolve_media(name) is None, name
    # 2) symlink dentro de public/ apontando para fora (nome valido, destino fora)
    link = base.media_dir() / "link.txt"
    try:
        link.symlink_to(outside)
    except (OSError, NotImplementedError):
        pytest.skip("symlink indisponivel nesta plataforma")
    assert base.resolve_media("link.txt") is None
    # 3) arquivo legitimo continua acessivel
    ok, _ = base.new_media_file("legit", "png")
    ok.write_bytes(b"1")
    assert base.resolve_media(ok.name) == ok.resolve()
    # 4) publico e privado nao se misturam
    priv, _ = base.new_media_file("p", "png", private=True)
    priv.write_bytes(b"1")
    assert base.resolve_media(priv.name) is None and base.resolve_media(priv.name, private=True) is not None
