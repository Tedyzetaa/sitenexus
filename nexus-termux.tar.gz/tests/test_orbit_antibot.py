import math
import re
from datetime import datetime, timezone

import pytest

from app.tools import orbit
from app.tools.antibot import is_challenge_page


def _jd(y, m, d):
    return orbit.unix_to_jd(datetime(y, m, d, 12, tzinfo=timezone.utc).timestamp())


def test_antibot_detection():
    assert is_challenge_page("", "theskylive.com Performing security verification This website uses a security service")
    assert is_challenge_page("Just a moment...", "")
    assert not is_challenge_page("3D Solar System", "Orbit of asteroid 2012 PP28")


def test_earth_longitude_in_november():
    # Em 6/nov o Sol esta ~224 graus de longitude eclíptica -> a Terra, ~44 graus.
    x, y, z = orbit.position_at(orbit.EARTH, _jd(2026, 11, 6))
    lon = math.degrees(math.atan2(y, x)) % 360
    assert 40 <= lon <= 48
    assert 0.98 <= math.hypot(x, y) <= 1.02 and abs(z) < 1e-9


def test_radius_bounds_and_inclination():
    el = orbit.Elements(a=1.458, e=0.2229, i=10.83, om=304.3, w=178.9, ma=100.0, epoch=orbit.J2000, n=0.5598)
    for k in range(0, 4000, 97):
        x, y, z = orbit.position_at(el, orbit.J2000 + k)
        r = math.sqrt(x * x + y * y + z * z)
        assert el.perihelion - 1e-9 <= r <= el.aphelion + 1e-9
        assert abs(z) <= r * math.sin(math.radians(el.i)) + 1e-9
    path = orbit.orbit_path(el)
    assert math.isclose(math.dist(path[0], (0, 0, 0)), el.perihelion, rel_tol=1e-9)


def test_kepler_solver():
    for e in (0.0, 0.3, 0.9):
        for m in (0, 30, 179, 250):
            big_e = orbit.solve_kepler(m, e)
            mm = math.degrees(big_e - e * math.sin(big_e)) % 360
            assert math.isclose(mm, m, abs_tol=1e-6)


def test_parse_sbdb():
    data = {"orbit": {"epoch": "2461000.5", "elements": [
        {"name": "e", "value": "0.2"}, {"name": "a", "value": "1.5"}, {"name": "i", "value": "5"},
        {"name": "om", "value": "10"}, {"name": "w", "value": "20"}, {"name": "ma", "value": "30"}]}}
    el = orbit.parse_sbdb(data)
    assert math.isclose(el.n, 0.9856076686014 / 1.5 ** 1.5)
    data["orbit"]["elements"][0]["value"] = "1.3"
    with pytest.raises(ValueError):
        orbit.parse_sbdb(data)
    with pytest.raises(ValueError):
        orbit.parse_sbdb({})
