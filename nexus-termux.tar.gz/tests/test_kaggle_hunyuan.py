"""Perfil WAN_PROFILE=hunyuan (HunyuanVideo 1.5 I2V no Kaggle): workflow, provider, config e refinador."""
import asyncio
import json
from pathlib import Path

import pytest

from app.config import settings
from app.providers.base import ProviderUnavailableError
from app.providers.kaggle_wan_provider import KaggleWanVideoProvider, _wan_size

WF_PATH = Path("app/workflows/hunyuan15_i2v_api.json")


class _FakeManager:
    base_url = "https://x.ngrok-free.app"


def _provider() -> KaggleWanVideoProvider:
    return KaggleWanVideoProvider(manager=_FakeManager())


def _wf() -> dict:
    wf = json.loads(WF_PATH.read_text(encoding="utf-8"))
    wf.pop("_comment", None)
    return wf


def test_workflow_links_apontam_para_nos_existentes():
    wf = _wf()
    for nid, node in wf.items():
        for k, v in node["inputs"].items():
            if isinstance(v, list):
                assert str(v[0]) in wf, f"no {nid}.{k} aponta para no inexistente {v}"


def test_build_hunyuan_prompt(monkeypatch):
    monkeypatch.setattr(settings, "WAN_PROFILE", "hunyuan")
    monkeypatch.setattr(settings, "HUNYUAN_STEPS", 12)
    monkeypatch.setattr(settings, "HUNYUAN_CFG", 6.0)
    monkeypatch.setattr(settings, "HUNYUAN_SHIFT", 5.0)
    p = _provider()
    wf = p._build_wan_prompt("i2v", "pos", "neg", "foto.png", 640, 640, 121, 123)
    f = p._find_node_by_title
    assert wf[f(wf, "unet")]["inputs"]["unet_name"] == settings.HUNYUAN_UNET
    assert wf[f(wf, "positive_prompt")]["inputs"]["text"] == "pos"
    assert wf[f(wf, "negative_prompt")]["inputs"]["text"] == "neg"
    assert wf[f(wf, "input_image")]["inputs"]["image"] == "foto.png"
    lat = wf[f(wf, "video_latent")]["inputs"]
    assert (lat["width"], lat["height"], lat["length"]) == (640, 640, 121)
    assert wf[f(wf, "model_shift")]["inputs"]["shift"] == 5.0
    assert wf[f(wf, "guider")]["inputs"]["cfg"] == 6.0
    assert wf[f(wf, "scheduler")]["inputs"]["steps"] == 12
    assert wf[f(wf, "noise")]["inputs"]["noise_seed"] == 123
    assert wf[f(wf, "create_video")]["inputs"]["fps"] == settings.HUNYUAN_FPS


def test_template_original_nao_e_alterado(monkeypatch):
    monkeypatch.setattr(settings, "WAN_PROFILE", "hunyuan")
    p = _provider()
    p._build_wan_prompt("i2v", "um", "", "a.png", 640, 640, 121, 1)
    wf2 = p._build_wan_prompt("i2v", "dois", "", "b.png", 640, 640, 121, 2)
    assert wf2[p._find_node_by_title(wf2, "positive_prompt")]["inputs"]["text"] == "dois"


def test_negativo_do_hunyuan_ignora_o_do_app(monkeypatch):
    monkeypatch.setattr(settings, "WAN_PROFILE", "hunyuan")
    monkeypatch.setattr(settings, "HUNYUAN_NEGATIVE_PROMPT", "")
    assert _provider()._negative("human, person, hand") == ""


@pytest.mark.parametrize("profile", ["draft", "quality"])
def test_outros_perfis_continuam_montando(monkeypatch, profile):
    monkeypatch.setattr(settings, "WAN_PROFILE", profile)
    p = _provider()
    wf = p._build_wan_prompt("i2v", "pos", "neg", "foto.png", 576, 1024, 81, 7)
    assert wf[p._find_node_by_title(wf, "positive_prompt")]["inputs"]["text"] == "pos"


def test_hunyuan_so_faz_i2v(monkeypatch):
    monkeypatch.setattr(settings, "WAN_PROFILE", "hunyuan")
    p = _provider()
    assert p.supports_t2v is False

    class _M(_FakeManager):
        async def ensure_online(self):
            return None

    p.manager = _M()
    with pytest.raises(ProviderUnavailableError, match="so faz imagem"):
        asyncio.run(p.generate("x", "", b"", 640, 640, 81, 1.0, None))


def test_tamanho_480p_segue_a_foto():
    from PIL import Image
    import io

    def png(w, h):
        b = io.BytesIO(); Image.new("RGB", (w, h)).save(b, "PNG"); return b.getvalue()

    px = settings.HUNYUAN_MAX_PIXELS
    assert _wan_size(png(1000, 1000), 0, 0, px) == (640, 640)
    w, h = _wan_size(png(1080, 1920), 0, 0, px)
    assert w < h and w % 32 == 0 and h % 32 == 0 and w * h <= px * 1.08


@pytest.mark.parametrize("bad", ["../x.safetensors", "wan.safetensors", "hunyuanvideo1.5_x.gguf"])
def test_config_rejeita_unet_invalido(bad):
    from app.config import Settings
    with pytest.raises(Exception):
        Settings(HUNYUAN_UNET=bad)


def test_config_aceita_perfil_hunyuan():
    from app.config import Settings
    assert Settings(WAN_PROFILE="hunyuan").WAN_PROFILE == "hunyuan"
    with pytest.raises(Exception):
        Settings(WAN_PROFILE="outro")


def test_refinador_usa_prompt_hunyuan(monkeypatch):
    import httpx
    from app.providers import ollama_provider as op
    monkeypatch.setattr(settings, "VIDEO_PROVIDER", "kaggle_wan")
    monkeypatch.setattr(settings, "WAN_PROFILE", "hunyuan")
    seen = {}

    class _Resp:
        def raise_for_status(self): pass
        def json(self): return {"message": {"content": "ok"}}

    class _Client:
        def __init__(self, *a, **k): pass
        async def __aenter__(self): return self
        async def __aexit__(self, *a): return False
        async def post(self, url, json=None):
            seen["system"] = json["messages"][0]["content"]
            return _Resp()

    monkeypatch.setattr(httpx, "AsyncClient", _Client)
    out = asyncio.run(op.OllamaProvider().refine_prompt("camera lenta", mode="video", has_image=True))
    assert out == "ok" and seen["system"] == op.REFINEMENT_SYSTEM_PROMPT_HUNYUAN_I2V
    assert "Never add a person, a hand" in seen["system"]


def test_template_do_notebook_lista_os_modelos_do_hunyuan():
    src = Path("app/kaggle/comfyui_server.py.tpl").read_text(encoding="utf-8")
    for nome in ("qwen_2.5_vl_7b_fp8_scaled.safetensors", "byt5_small_glyphxl_fp16.safetensors",
                 "hunyuanvideo15_vae_fp16.safetensors", "sigclip_vision_patch14_384.safetensors"):
        assert nome in src
    compile(src.replace("__NEXUS_CONFIG__", '{"profile": "hunyuan"}'), "tpl", "exec")
