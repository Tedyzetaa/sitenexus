"""Parsers e logica pura das ferramentas (sem rede)."""
import pytest

from app.tools import commands, feeds, noaa, solar
from app.tools.geophysics import magnitude_icon, parse_quakes
from app.tools.space import make_slug, over_brazil, parse_neo_feed
from app.tools.tactical import resolve_sector, resolve_theater
from app.tools.traffic import bounding_box, parse_states, parse_stations, radio_endpoint
from app.tools.base import ToolError
from app.tools.weather import build_queries


def test_neo_feed_tolerant_and_sorted():
    data = {"element_count": 2, "near_earth_objects": {"2026-11-06": [
        {"id": "1", "name": "small", "estimated_diameter": {"meters": {"estimated_diameter_max": 10}},
         "is_potentially_hazardous_asteroid": False, "close_approach_data": []},
        {"id": "2", "name": "big", "estimated_diameter": {"meters": {"estimated_diameter_max": 500}},
         "is_potentially_hazardous_asteroid": True,
         "close_approach_data": [{"relative_velocity": {"kilometers_per_hour": "70000"},
                                  "miss_distance": {"kilometers": "1000000"}}]},
    ]}}
    info = parse_neo_feed(data, "2026-11-06")
    assert [a["name"] for a in info["top"]] == ["big", "small"]
    assert info["top"][0]["hazardous"] and info["top"][0]["velocity_kmh"] == 70000.0
    assert info["top"][1]["velocity_kmh"] == 0.0 and info["top"][1]["miss_distance_km"] == 0.0  # sem close_approach_data
    # dia ausente no feed (o legado dava KeyError)
    assert parse_neo_feed({"element_count": 0, "near_earth_objects": {}}, "2026-11-06")["top"] == []


def test_quakes_skip_null_magnitude():
    g = {"features": [{"properties": {"mag": None, "place": "x", "time": 0}},
                      {"properties": {"mag": 5.6, "place": "Chile", "time": 1700000000000}}]}
    q = parse_quakes(g, 5)
    assert len(q) == 1 and q[0]["place"] == "Chile" and "UTC" in q[0]["time_utc"]
    assert magnitude_icon(6.6) == "🔴" and magnitude_icon(2.6) == "🟢"


def test_open_states_none_callsign_and_null():
    assert parse_states(None) == []
    st = [["abc", None, "Brazil", 0, 0, -53.8, -22.3, 9000.0, False, 250.0], ["x", "G3 1", "BR", 0, 0, None, None, 0]]
    out = parse_states(st)
    assert len(out) == 1 and out[0]["callsign"] == "UNK" and out[0]["speed_kmh"] == 900


def test_bounding_box_symmetry():
    b = bounding_box(-22.0, -53.0, 111.0)
    assert b["lamax"] - b["lamin"] == pytest.approx(2.0)
    assert b["lomax"] - b["lomin"] > 2.0  # longitude se alarga longe do equador


def test_radio_endpoint_blocks_path_injection():
    for bad in ("../admin", "news/../../x", "a?b=1", "x" * 40, "ro ck;ls"):
        with pytest.raises(ToolError):
            radio_endpoint(bad, 5)
    path, _ = radio_endpoint("News", 5)
    assert path == "stations/bytag/news"
    assert radio_endpoint("global", 3)[0] == "stations/topclick/3"


def test_stations_filter_unsafe_schemes():
    raw = [{"name": "ok", "url_resolved": "https://a/b"}, {"name": "bad", "url_resolved": "javascript:alert(1)"},
           {"name": "file", "url_resolved": "file:///etc/passwd"}, {"name": "none"}]
    assert [s["name"] for s in parse_stations(raw)] == ["ok"]


def test_slug_sanitized():
    assert make_slug("2340 Hathor (1976 UA)") == "2340-hathor"
    assert make_slug("(2022 SU)") == "2022-su"
    assert make_slug("../../etc?x=1") == "etcx1"


def test_brazil_box():
    assert over_brazil(-22, -53) and not over_brazil(40, 10)


# ----- NOAA ---------------------------------------------------------------
def test_xray_uses_long_band_only():
    data = [{"time_tag": "t1", "energy": "0.1-0.8nm", "flux": 2e-6},
            {"time_tag": "t1", "energy": "0.05-0.4nm", "flux": 9e-4},   # nao pode virar classe X
            {"time_tag": "t2", "energy": "0.1-0.8nm", "flux": 3e-5}]
    r = noaa.parse_xray(data)
    assert r["classe_flare"] == "M" and r["alerta"] and r["classe_pico_6h"] == "M" and r["amostras"] == 2


def test_kp_both_formats():
    old = [["time_tag", "Kp", "a_running", "station_count"], ["t1", "2.33", "9", "8"], ["t2", "5.0", "48", "8"]]
    new = [{"time_tag": "t1", "Kp": 3.0}, {"time_tag": "t2", "Kp": 7.0}]
    assert noaa.parse_kp(old)["kp_atual"] == 5.0 and noaa.parse_kp(old)["tempestade"]
    assert noaa.parse_kp(new)["nivel"].startswith("G3")
    assert noaa.parse_kp([])["kp_atual"] is None


def test_wind_list_of_lists_and_alert():
    plasma = [["time_tag", "density", "speed", "temperature"], ["t", "5.1", "650", "1e5"]]
    mag = [["time_tag", "bx_gsm", "by_gsm", "bz_gsm"], ["t", "1", "2", "-12.5"]]
    w = noaa.parse_wind(plasma, mag)
    assert w["velocidade_km_s"] == 650 and w["campo_Bz_nT"] == -12.5 and w["alerta"]
    assert noaa.parse_wind(None, None)["alerta"] is False


def test_proton_scale_and_energy_filter():
    assert noaa.proton_level(5).startswith("Normal")
    assert noaa.proton_level(10).startswith("S1") and noaa.proton_level(150).startswith("S2")
    assert noaa.proton_level(2000).startswith("S3")  # o legado dizia S5 aqui
    data = [{"energy": ">=100 MeV", "flux": 500, "time_tag": "a"}, {"energy": ">=10 MeV", "flux": 12, "time_tag": "b"}]
    assert noaa.parse_protons(data)["fluxo_pfu"] == 12


def test_alert_score_caps_routine_alerts():
    intel = {"goes_xray": {}, "kp_index": {}, "proton_flux": {}, "solar_wind": {},
             "alertas": [{}] * 10}
    score, state = noaa.alert_score(intel)
    assert score == 3 and "MODERADO" in state


def test_solar_heuristics():
    assert solar.flare_probability(None) == 0
    assert solar.flare_probability(1e-4) == pytest.approx(80)
    assert solar.cme_probability(800, "M") == 60 and solar.cme_probability(400, "C") == 0
    assert solar.kp_trend([2, 3, 4]) == "subindo" and solar.kp_trend([5, 3]) == "caindo" and solar.kp_trend([3]) == "estável"
    assert solar.overall(10, 10) == "BAIXA" and solar.overall(50, 0) == "MODERADA" and solar.overall(0, 90) == "ALTA"


# ----- feeds / clima / comandos ------------------------------------------
RSS = b"""<?xml version="1.0"?><rss><channel>
<item><title>Etna (Italy) - New Activity</title><link>http://x/1</link><description>&lt;b&gt;Eruption&lt;/b&gt; seen. More.</description></item>
<item><title></title></item></channel></rss>"""


def test_feed_parse_and_strip_html():
    items = feeds.parse_feed(RSS)
    assert len(items) == 1 and items[0]["description"].startswith("Eruption seen")


def test_feed_rejects_garbage():
    with pytest.raises(ValueError):
        feeds.parse_feed(b"<not xml")


def test_feed_blocks_entity_bomb():
    bomb = b'<?xml version="1.0"?><!DOCTYPE l [<!ENTITY a "aaaaaaaaaa"><!ENTITY b "&a;&a;&a;&a;&a;&a;&a;&a;">]><rss><channel><item><title>&b;</title></item></channel></rss>'
    try:
        items = feeds.parse_feed(bomb)
        assert all(len(i["title"]) < 1000 for i in items)  # stdlib expande pouco; defusedxml recusa
    except ValueError:
        pass


def test_weather_queries():
    q = build_queries("Ivinhema MS")
    assert q[0] == "ivinhema,Mato Grosso do Sul,BR" and q[1] == "ivinhema,ms,BR" and q[-1] == "Ivinhema MS"
    assert len(set(q)) == len(q)


def test_theater_sector_aliases():
    assert resolve_theater("Ucrânia") == "ukraine" and resolve_theater("???") == "global"
    assert resolve_sector("gaza") == "israel" and resolve_sector("") == "global"


def test_parse_command_variants():
    inv = commands.parse_command("/sismo forte 3")
    assert inv.tool == "check_seismic_activity" and inv.args == {"level": "strong", "limit": 3}
    inv = commands.parse_command("/clima Dourados MS")
    assert inv.tool == "get_weather" and inv.args == {"city": "Dourados MS"}
    inv = commands.parse_command("/radar Campo Grande 200")
    assert inv.args == {"location": "Campo Grande", "radius_km": "200"}
    assert commands.parse_command("/SDO").args == {"kind": "sdo"}
    assert commands.parse_command("/solar@jarvis_bot").tool == "get_solar_status"
    assert commands.parse_command("/vulcão").tool == "get_volcano_report"
    assert commands.parse_command("/naoexiste") is None and commands.parse_command("oi tudo bem") is None


def test_intent_matching_is_conservative():
    assert commands.match_intent("teve algum terremoto hoje?").tool == "check_seismic_activity"
    inv = commands.match_intent("como está o clima em Ivinhema MS?")
    assert inv.tool == "get_weather" and inv.args["city"] == "Ivinhema Ms"
    assert commands.match_intent("me conta uma piada") is None
    assert commands.match_intent("tire uma foto com a sentinela") is None   # sensivel: so por comando
    inv = commands.match_intent("mostre a trajetoria do asteroide")
    assert inv is None or inv.tool != "get_asteroid_trajectory"  # pesado (navegador): so por comando


def test_browser_allowlist():
    from app.tools.browser import assert_allowed
    hosts = ["liveuamap.com"]
    assert_allowed("https://ukraine.liveuamap.com/x", hosts)
    assert_allowed("https://liveuamap.com/", hosts)
    for bad in ("http://liveuamap.com/", "https://evil.com/?liveuamap.com", "https://liveuamap.com.evil.com/",
                "https://127.0.0.1/", "http://localhost:8188/", "file:///etc/passwd", "https://notliveuamap.com/"):
        with pytest.raises(ToolError):
            assert_allowed(bad, hosts)
