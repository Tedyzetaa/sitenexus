"""Perfil WAN_PROFILE=minimax (MiniMax H3 Ref2VA no Kaggle): workflow, provider, config e refinador."""
import asyncio
import json
from pathlib import Path

import pytest

from app.config import settings
from app.providers.base import ProviderUnavailableError
from app.providers.kaggle_wan_provider import KaggleWanVideoProvider, _frames_17n5

WF_PATH = Path("app/workflows/minimax_h3_r2v_api.json")


class _FakeManager:
    base_url = "https://x.ngrok-free.app"


def _provider() -> KaggleWanVideoProvider:
    return KaggleWanVideoProvider(manager=_FakeManager())


def _wf() -> dict:
    wf = json.loads(WF_PATH.read_text(encoding="utf-8"))
    wf.pop("_comment", None)
    return wf


def test_workflow_links_apontam_para_nos_existentes():
    wf = _wf()
    for nid, node in wf.items():
        for k, v in node["inputs"].items():
            if isinstance(v, list):
                assert str(v[0]) in wf, f"no {nid}.{k} aponta para no inexistente {v}"


def test_workflow_tem_o_no_nativo_de_referencia():
    wf = _wf()
    ref = next(n for n in wf.values() if n["class_type"] == "MiniMaxH3ReferenceToVideo")
    assert "ref_images.ref_image_0" in ref["inputs"] and ref["inputs"]["audio_vae"]


@pytest.mark.parametrize("n,esperado", [(5, 5), (21, 5), (22, 22), (40, 39), (100, 90), (124, 124), (1, 5)])
def test_frames_17n_mais_5(n, esperado):
    assert _frames_17n5(n) == esperado
    assert (_frames_17n5(n) - 5) % 17 == 0


def test_build_minimax_com_turbo(monkeypatch):
    monkeypatch.setattr(settings, "WAN_PROFILE", "minimax")
    monkeypatch.setattr(settings, "MINIMAX_TURBO", True)
    p = _provider()
    wf = p._build_wan_prompt("r2v", "o tenis na praia", "", "ref.png", 640, 384, 39, 5)
    f = p._find_node_by_title
    assert wf[f(wf, "positive_prompt")]["inputs"]["value"].startswith("<Picture 1> is the reference subject.")
    assert wf[f(wf, "input_image")]["inputs"]["image"] == "ref.png"
    lat = wf[f(wf, "video_latent")]["inputs"]
    assert (lat["width"], lat["height"], lat["length"]) == (640, 384, 39)
    assert wf[f(wf, "noise")]["inputs"]["noise_seed"] == 5
    assert wf[f(wf, "scheduler")]["inputs"]["steps"] == settings.MINIMAX_TURBO_STEPS
    lora_id = f(wf, "turbo_lora")
    assert wf[lora_id]["class_type"] == "LoraLoaderModelOnly"
    assert wf[f(wf, "guider")]["inputs"]["model"] == [lora_id, 0]
    # o scheduler continua no modelo base
    assert wf[f(wf, "scheduler")]["inputs"]["model"] == [f(wf, "unet"), 0]
    for nid, node in wf.items():
        for v in node["inputs"].values():
            if isinstance(v, list):
                assert str(v[0]) in wf


def test_build_minimax_sem_turbo_nao_injeta_lora(monkeypatch):
    monkeypatch.setattr(settings, "WAN_PROFILE", "minimax")
    monkeypatch.setattr(settings, "MINIMAX_TURBO", True)
    p = _provider()
    p._turbo_ok = False   # notebook sem o LoRA
    wf = p._build_wan_prompt("r2v", "<Picture 1> corre", "", "ref.png", 640, 384, 39, 5)
    assert not any(n["class_type"] == "LoraLoaderModelOnly" for n in wf.values())
    assert wf[p._find_node_by_title(wf, "scheduler")]["inputs"]["steps"] == settings.MINIMAX_STEPS
    # prompt que ja cita <Picture 1> nao e alterado
    assert wf[p._find_node_by_title(wf, "positive_prompt")]["inputs"]["value"] == "<Picture 1> corre"


def test_template_original_nao_e_alterado(monkeypatch):
    monkeypatch.setattr(settings, "WAN_PROFILE", "minimax")
    monkeypatch.setattr(settings, "MINIMAX_TURBO", True)
    p = _provider()
    p._build_wan_prompt("r2v", "um", "", "a.png", 640, 384, 39, 1)
    wf2 = p._build_wan_prompt("r2v", "dois", "", "b.png", 640, 384, 39, 2)
    assert sum(n["class_type"] == "LoraLoaderModelOnly" for n in wf2.values()) == 1


def test_minimax_exige_imagem_e_nao_usa_negativo(monkeypatch):
    monkeypatch.setattr(settings, "WAN_PROFILE", "minimax")
    p = _provider()
    assert p.supports_t2v is False
    assert p._negative("human, hand") == ""

    class _M(_FakeManager):
        async def ensure_online(self):
            return None

    p.manager = _M()
    with pytest.raises(ProviderUnavailableError, match="REFERENCIA"):
        asyncio.run(p.generate("x", "", b"", 640, 640, 81, 1.0, None))


def test_refinador_usa_prompt_do_minimax(monkeypatch):
    from app.providers import ollama_provider as op
    monkeypatch.setattr(settings, "VIDEO_PROVIDER", "kaggle_wan")
    monkeypatch.setattr(settings, "WAN_PROFILE", "minimax")
    seen = {}

    class _Resp:
        status_code = 200
        def raise_for_status(self): pass
        def json(self): return {"message": {"content": "ok"}}

    class _Client:
        def __init__(self, *a, **k): pass
        async def __aenter__(self): return self
        async def __aexit__(self, *a): return False
        async def post(self, url, json=None, **k):
            seen["system"] = json["messages"][0]["content"]
            return _Resp()

    monkeypatch.setattr(op.httpx, "AsyncClient", _Client)
    out = asyncio.run(op.OllamaProvider().refine_prompt("o tenis andando", mode="video", has_image=True))
    assert out == "ok" and seen["system"] == op.REFINEMENT_SYSTEM_PROMPT_MINIMAX_R2V


def test_config_valida_minimax():
    from app.config import Settings
    Settings(WAN_PROFILE="minimax")
    with pytest.raises(Exception, match="MINIMAX_LENGTH"):
        Settings(WAN_PROFILE="minimax", MINIMAX_LENGTH=40)
    with pytest.raises(Exception, match="MINIMAX_UNET"):
        Settings(WAN_PROFILE="minimax", MINIMAX_UNET="outro.safetensors")
