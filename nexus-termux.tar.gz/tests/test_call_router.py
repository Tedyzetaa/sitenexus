import json
import time

import pytest
from fastapi import FastAPI
from fastapi.testclient import TestClient

from app.call import router as call_router
from app.call.session import CallManager
from tests.test_call_session import FakeLlm, FakeStt, FakeTts


@pytest.fixture
def client(tmp_path):
    call_router.set_manager(CallManager(FakeStt(), FakeLlm(), FakeTts(), tmp_path))
    app = FastAPI()
    app.include_router(call_router.router)
    with TestClient(app) as c:
        yield c
    call_router.set_manager(None)


def poll(client, sid, want, after=0, timeout=5):
    end = time.time() + timeout
    seen = []
    while time.time() < end:
        data = client.get(f"/api/v1/call/{sid}/events", params={"after": after}).json()
        seen += data["events"]
        after = data["next"]
        if any(e["type"] == want for e in seen):
            return seen
        time.sleep(0.02)
    raise AssertionError(f"evento {want} nao chegou: {seen}")


def test_full_flow(client):
    r = client.post("/api/v1/call/start", data={"language": "pt-BR", "history": json.dumps([{"role": "user", "content": "oi"}])})
    assert r.status_code == 200
    sid = r.json()["session_id"]
    assert r.json()["engine"] == "fake"
    poll(client, sid, "ready")

    t = client.post(f"/api/v1/call/{sid}/turn", files={"audio": ("fala.webm", b"abc", "audio/webm")})
    assert t.status_code == 202 and t.json()["turn"] == 1
    evs = poll(client, sid, "done")
    assert [e["text"] for e in evs if e["type"] == "sentence"][0].startswith("Ola!")
    assert any(e["type"] == "audio" for e in evs)

    assert client.post(f"/api/v1/call/{sid}/interrupt").json() == {"interrupted": False}
    assert client.delete(f"/api/v1/call/{sid}").json() == {"ok": True}
    assert client.get(f"/api/v1/call/{sid}/events").status_code == 404


def test_validation_errors(client):
    sid = client.post("/api/v1/call/start").json()["session_id"]
    bad = client.post(f"/api/v1/call/{sid}/turn", files={"audio": ("x.txt", b"abc", "text/plain")})
    assert bad.status_code == 400
    empty = client.post(f"/api/v1/call/{sid}/turn", files={"audio": ("x.webm", b"", "audio/webm")})
    assert empty.status_code == 400
    assert client.post("/api/v1/call/start", data={"history": "nao-json"}).status_code == 400
    assert client.post("/api/v1/call/naoexiste/turn", files={"audio": ("x.webm", b"a", "audio/webm")}).status_code == 404


def test_suffix_from_content_type_when_filename_missing(client):
    sid = client.post("/api/v1/call/start").json()["session_id"]
    ok = client.post(f"/api/v1/call/{sid}/turn", files={"audio": ("blob", b"abc", "audio/webm;codecs=opus")})
    assert ok.status_code == 202


def test_health(client):
    h = client.get("/api/v1/call/health").json()
    assert h["ollama"] is True and h["tts_engine"] == "fake"
