import asyncio
import wave
from pathlib import Path

import pytest

from app.call.llm import LlmError
from app.call.session import CallManager
from app.call.stt import SttError
from app.call.tts import TtsError


class FakeStt:
    def __init__(self, transcript="oi, tudo bem?"):
        self.transcript = transcript
        self.closed = False

    async def warmup(self): pass
    async def transcribe(self, path, language):
        assert Path(path).exists()
        return self.transcript
    def close(self): self.closed = True


class FakeLlm:
    model = "fake"
    def __init__(self, chunks=("Ola! ", "Tudo bem ", "com voce? ", "Estou aqui."), delay=0.0, error=None):
        self.chunks, self.delay, self.error = chunks, delay, error
        self.seen = []

    async def warmup(self): pass
    async def health(self): return True, None
    async def stream(self, messages):
        self.seen.append(messages)
        for c in self.chunks:
            if self.delay:
                await asyncio.sleep(self.delay)
            yield c
        if self.error:
            raise self.error


class FakeTts:
    name = "fake"
    def __init__(self, fail_on=None, delay=0.0):
        self.fail_on, self.delay, self.unloaded = fail_on, delay, False
        self.calls = []

    async def warmup(self, language): pass
    async def synthesize(self, text, language, voice, out_dir):
        self.calls.append(text)
        if self.delay:
            await asyncio.sleep(self.delay)
        if self.fail_on and self.fail_on in text:
            raise TtsError("falhou")
        p = Path(out_dir) / f"fake_{len(self.calls)}.wav"
        with wave.open(str(p), "wb") as w:
            w.setnchannels(1); w.setsampwidth(2); w.setframerate(8000); w.writeframes(b"\0\0" * 80)
        return p
    def unload(self): self.unloaded = True


def make(tmp_path, stt=None, llm=None, tts=None):
    return CallManager(stt or FakeStt(), llm or FakeLlm(), tts or FakeTts(), tmp_path)


async def wait_done(m, sid, turn, timeout=3.0):
    loop = asyncio.get_running_loop()
    end = loop.time() + timeout
    while loop.time() < end:
        evs = m.events_after(sid, 0)["events"]
        if any(e["type"] == "done" and e.get("turn") == turn for e in evs):
            return evs
        await asyncio.sleep(0.01)
    raise AssertionError("turno nao terminou")


async def test_warmup_sets_ready(tmp_path):
    m = make(tmp_path)
    s = await m.create(language="pt-BR")
    await s.warm_task
    assert s.ready and any(e["type"] == "ready" for e in s.events)
    assert "portugues do Brasil" in s.system_prompt


async def test_full_turn_event_order_and_history(tmp_path):
    m = make(tmp_path)
    s = await m.create(language="pt-BR")
    await s.warm_task
    turn = await m.start_turn(s.id, b"x", "webm")
    evs = await wait_done(m, s.id, turn)
    types = [e["type"] for e in evs if e.get("turn") == turn]
    assert types[:2] == ["stage", "transcript"]
    assert types[-1] == "done"
    sentences = [e["text"] for e in evs if e["type"] == "sentence"]
    audios = [e for e in evs if e["type"] == "audio"]
    assert sentences == ["Ola! Tudo bem com voce?", "Estou aqui."]
    assert [a["index"] for a in audios] == [0, 1]
    assert all(a["url"].startswith("/audio/call_") for a in audios)
    for a in audios:
        assert (tmp_path / a["url"].split("/")[-1]).exists()
    assert [h["role"] for h in s.history] == ["user", "assistant"]
    assert s.history[1]["content"] == "Ola! Tudo bem com voce? Estou aqui."


async def test_empty_transcript_ends_quietly(tmp_path):
    m = make(tmp_path, stt=FakeStt(transcript="  . "))
    s = await m.create()
    turn = await m.start_turn(s.id, b"x", "wav")
    evs = await wait_done(m, s.id, turn)
    assert next(e for e in evs if e["type"] == "done")["empty"] is True
    assert not any(e["type"] == "sentence" for e in evs)
    assert s.history == []


async def test_interrupt_stops_further_audio(tmp_path):
    tts = FakeTts(delay=0.15)
    m = make(tmp_path, tts=tts, llm=FakeLlm(chunks=("Primeira frase longa aqui. ", "Segunda frase longa aqui. ", "Terceira frase longa aqui.")))
    s = await m.create()
    turn = await m.start_turn(s.id, b"x", "webm")
    await asyncio.sleep(0.25)
    assert m.interrupt(s.id) is True
    n_audio = sum(1 for e in s.events if e["type"] == "audio")
    await asyncio.sleep(0.6)
    assert sum(1 for e in s.events if e["type"] == "audio") == n_audio
    assert any(e["type"] == "interrupted" for e in s.events)
    assert not s.turn_active
    assert turn == 1


async def test_new_turn_cancels_previous(tmp_path):
    m = make(tmp_path, llm=FakeLlm(delay=0.2))
    s = await m.create()
    await m.start_turn(s.id, b"x", "webm")
    await asyncio.sleep(0.1)
    t2 = await m.start_turn(s.id, b"y", "webm")
    assert t2 == 2
    assert sum(1 for e in s.events if e["type"] == "interrupted") == 1
    await wait_done(m, s.id, 2, timeout=5)


async def test_llm_error_reports_and_cleans_history(tmp_path):
    m = make(tmp_path, llm=FakeLlm(chunks=(), error=LlmError("ollama fora")))
    s = await m.create()
    turn = await m.start_turn(s.id, b"x", "webm")
    evs = await wait_done(m, s.id, turn)
    assert any(e["type"] == "error" and "ollama fora" in e["message"] for e in evs)
    assert s.history == []


async def test_tts_failure_on_one_sentence_keeps_going(tmp_path):
    m = make(tmp_path, tts=FakeTts(fail_on="Estou"))
    s = await m.create()
    turn = await m.start_turn(s.id, b"x", "webm")
    evs = await wait_done(m, s.id, turn)
    assert [e["index"] for e in evs if e["type"] == "audio"] == [0]
    assert [e["index"] for e in evs if e["type"] == "audio_error"] == [1]


async def test_history_is_sent_to_llm_and_capped(tmp_path):
    llm = FakeLlm()
    m = make(tmp_path, llm=llm)
    hist = [{"role": "user" if i % 2 == 0 else "assistant", "content": f"msg {i}"} for i in range(40)]
    s = await m.create(history=hist + [{"role": "system", "content": "ignorar"}, {"role": "user", "content": " "}])
    turn = await m.start_turn(s.id, b"x", "webm")
    await wait_done(m, s.id, turn)
    sent = llm.seen[0]
    assert sent[0]["role"] == "system"
    assert sent[-1] == {"role": "user", "content": "oi, tudo bem?"}
    assert len(sent) <= 1 + 12
    assert all(x["role"] != "system" for x in sent[1:])


async def test_events_after_and_close_cleans_files(tmp_path):
    m = make(tmp_path)
    s = await m.create()
    turn = await m.start_turn(s.id, b"x", "webm")
    await wait_done(m, s.id, turn)
    first = m.events_after(s.id, 0)
    assert m.events_after(s.id, first["next"])["events"] == []
    assert list(tmp_path.glob("call_*.wav"))
    await m.close(s.id)
    assert not list(tmp_path.glob("call_*.wav"))
    with pytest.raises(KeyError):
        m.get(s.id)


async def test_janitor_unloads_when_idle(tmp_path, monkeypatch):
    from app.config import settings
    monkeypatch.setattr(settings, "CALL_IDLE_UNLOAD_S", 0)
    stt, tts = FakeStt(), FakeTts()
    m = make(tmp_path, stt=stt, tts=tts)
    s = await m.create()
    await m.close(s.id)
    m.janitor_tick()
    assert stt.closed and tts.unloaded


async def test_stt_error_is_reported(tmp_path):
    class BadStt(FakeStt):
        async def transcribe(self, path, language):
            raise SttError("whisper caiu")
    m = make(tmp_path, stt=BadStt())
    s = await m.create()
    turn = await m.start_turn(s.id, b"x", "webm")
    evs = await wait_done(m, s.id, turn)
    assert any(e["type"] == "error" and "whisper caiu" in e["message"] for e in evs)
