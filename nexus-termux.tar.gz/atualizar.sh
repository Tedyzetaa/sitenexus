#!/usr/bin/env bash
# ============================================================
#  Atualiza o Nexus-Bridge: baixa o instalador atual do GitHub e roda com --atualizar
#  (mantem .env, venv, logs e arquivos gerados). Aceita --forcar.
# ============================================================
main() {
    local here raw tmp rc
    here="$(cd "$(dirname "$(readlink -f "${BASH_SOURCE[0]}")")" && pwd)"
    raw="${NEXUS_RAW:-}"
    if [ -z "$raw" ] && [ -f "$here/.nexus-install" ]; then
        raw="$(grep -E '^INSTALL_RAW=' "$here/.nexus-install" | head -n1 | cut -d= -f2- | tr -d '"\r')"
    fi
    raw="${raw:-https://raw.githubusercontent.com/Tedyzetaa/sitenexus/main}"
    tmp="$(mktemp 2>/dev/null || echo "${TMPDIR:-/tmp}/nexus-install.$$")"
    echo "[*] Baixando o instalador de $raw ..."
    if ! curl -fsSL --retry 3 --connect-timeout 15 -m 60 "$raw/install-nexus.sh" -o "$tmp"; then
        rm -f "$tmp"; echo "[X] Nao consegui baixar o instalador (sem internet?)."; return 1
    fi
    NEXUS_RAW="$raw" bash "$tmp" --dir "$here" --atualizar "$@"
    rc=$?
    rm -f "$tmp"
    return $rc
}
main "$@"
exit $?
