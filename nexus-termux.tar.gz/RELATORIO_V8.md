# Nexus-Bridge v8.0 — relatório (otimização para i3-3110M · 8 GB · sem GPU)

## Verificação
- `pytest`: **105 testes passam** (87 originais — incluindo `test_intent_matching_is_conservative`, que já falhava antes — + 18 novos em `tests/test_v8_lite.py`). Rodado em Python 3.12/Linux com fastapi, httpx, pydantic, scipy, matplotlib reais.
- `tools/verify_patches.py` (auditoria anterior): 69 checagens do Nexus sem falhas. A parte do bot **não rodou**: ela precisa de `jarvis/net.py`, que não veio nos zips.
- **NÃO validado (exige o seu notebook):** inferência real de Whisper/XTTS/Ollama, tempos, uso de RAM, `start.bat` no Windows, `pip install` do `requirements.lite.txt`, execução do Kaggle. Nenhum número de desempenho neste relatório foi medido.

## Premissa que muda tudo
O Intel HD 4000 (32 MB) não acelera torch nem Ollama. Todo o pipeline vira CPU (2 núcleos), e o gargalo é a **RAM** (XTTS ~2–3 GB + LLM + Windows ≈ 8 GB). Por isso o foco foi: um modelo pesado por vez, falhar cedo com mensagem clara e economizar RAM/CPU.

## Mudanças da v8.0
| # | Onde | O que mudou |
|---|---|---|
| 1 | `app/hardware.py` (novo), `config.py` | Perfil `lite`/`gpu`/`auto` (auto = `nvidia-smi` presente). Padrões do lite só valem para campos **não** definidos no `.env`: Whisper `base`, vídeo `kaggle_wan`, histórico 50 jobs, upload 50 MB, XTTS descarrega em 90 s, fila máx. 10. |
| 2 | Whisper (`whisper_stt.py`, `whisper_server.py`) | `cpu_threads` = núcleos físicos (padrão do ctranslate2 era 4), `num_workers=1`, `beam_size=1` no lite, guarda de RAM antes de carregar. |
| 3 | XTTS (`xtts_provider.py`) | Guarda de RAM (`MIN_FREE_RAM_XTTS_MB`), `torch.set_num_threads`. O descarregamento por ociosidade era **código morto** (agendava com `asyncio.get_running_loop()` dentro de threads, onde falha) e, se rodasse, bloquearia o event loop esperando o lock de uma síntese longa; agora usa `threading.Timer` + try-lock, nunca no loop, e não derruba o modelo durante a ligação. |
| 4 | Ollama (`ollama_provider.py`, `call/llm.py`, `roblox_map.py`) | `num_thread` no lite; timeouts realistas (600 s); **tradução em trechos de ~900 caracteres** (antes o Ollama truncava o início em silêncio com `num_ctx=2048`), temperatura 0,2, nomes de idioma por extenso. |
| 5 | `roblox_map.py` | `ROBLOX_*` eram lidas com `os.getenv`, que **não enxerga o `.env`** (ignoradas). Agora são campos do `Settings`; contexto 4096 no lite (era 8192). |
| 6 | `orchestrator.py` | **Preflight**: verifica o gerador (ComfyUI) antes de gastar minutos de CPU refinando o prompt. Libera da RAM imagens base64/áudios/música de jobs encerrados (mantendo o job válido para `GET /api/jobs`). |
| 7 | `main.py` | Cache de health checks (10 s); `/api/health` não fica 503 permanente sem GPU; novo `/api/system`; `lifespan` no lugar de `on_event`; HTTP 429 com fila cheia; 503 para falta de RAM; 500 sem `repr` por padrão (`DEBUG_ERRORS`). |
| 8 | Logs | `logs/nexus.log` rotativo + `logs/faulthandler.log` (pilha de crashes nativos) — responde ao "processo fecha sem traceback" de `docs/need-fix.md`. |
| 9 | Modo ligação | `/turn` agora lê com teto (o patch anterior só corrigiu o `/start`); recusa iniciar (409) se há job pesado; Piper automático no lite se houver modelo; nome de arquivo do Piper sem colisão; janitor não trava o loop. |
| 10 | `tools/registry.py` | `get_asteroid_trajectory` marcado `heavy` (só por comando). Corrige o teste que já falhava. |
| 11 | `start.bat`, `.env.example`, `requirements.lite.txt` | Threads=2, Ollama com 1 modelo/1 requisição, `--no-access-log`, torch CPU, host 127.0.0.1. Removidas dependências não importadas por `app/`. |
| 12 | Jarvis bot (`config.py`) | Padrões leves: contexto 2048, histórico 8, timeouts 600 s, consultas de job menos frequentes. Só os 5 arquivos que vieram no zip; o restante do bot não foi fornecido e não foi tocado. |

## Limitações honestas
- **XTTS v2 em i3 de 2 núcleos será lento** (minutos por frase longa). Para voz rápida use Piper; XTTS fica para clipes curtos pela fila.
- LLM: `qwen2.5:3b-instruct-q4_K_M` ou `1.5b`. Modelos 7B não são recomendados (o startup avisa se o modelo passar de 3,5 GB).
- Imagem local (ComfyUI/Fooocus) e 3D não existem sem GPU; falham rápido com mensagem clara.
- As guardas de RAM usam o valor livre no momento; não substituem fechar o navegador.
- Mudanças de comportamento: host padrão 127.0.0.1; dublagem > ~256 KB vai para a fila (resposta com `job_id`, como já acontecia para arquivos grandes); `ROBLOX_*` do `.env` passam a valer.
- Continua valendo da auditoria anterior: rotas abertas por padrão (use `API_REQUIRE_TOKEN`), DNS rebinding residual, `.kaggle_state.json` removido do pacote (gere novo `NTFY_TOPIC` se já compartilhou o zip antigo).
