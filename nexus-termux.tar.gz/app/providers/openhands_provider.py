"""Cliente assincrono do agent-server do OpenHands (http://127.0.0.1:18000).

Fluxo (conferido no codigo do openhands-agent-server 1.60.1):
  1. POST /api/conversations            -> cria a conversa; com `initial_message` o servidor JA inicia
                                           a execucao (chamar /run em seguida da 409 "already running")
  2. GET  /api/conversations/{id}       -> `execution_status` (idle|running|finished|error|stuck|paused|...)
  3. GET  /api/conversations/{id}/events/search -> eventos (resposta final = FinishAction / MessageEvent)
"""
from __future__ import annotations

import re
from pathlib import Path

import httpx

# "paused" tambem e terminal: stop_task() usa /pause; sem isso o bot ficava consultando ate o timeout
# (30 min) e o chat travado em "ja existe uma tarefa de codigo".
TERMINAL = {"finished", "error", "stuck", "paused"}


class OpenHandsError(Exception):
    pass


class OpenHandsOfflineError(OpenHandsError):
    pass


class OpenHandsNotFoundError(OpenHandsError):
    pass


def _text_of(content) -> str:
    if isinstance(content, str):
        return content
    parts = []
    for c in content or []:
        if isinstance(c, dict) and c.get("type", "text") == "text" and c.get("text"):
            parts.append(str(c["text"]))
    return "\n".join(parts)


def extract_result(events: list[dict]) -> str:
    """`events` em ordem DECRESCENTE. Pega a mensagem final do agente (finish) ou a ultima fala dele."""
    for ev in events:
        action = ev.get("action")
        if isinstance(action, dict) and action.get("kind") == "FinishAction" and action.get("message"):
            return str(action["message"])
    for ev in events:
        if ev.get("kind") == "MessageEvent" and ev.get("source") == "agent":
            txt = _text_of((ev.get("llm_message") or {}).get("content"))
            if txt:
                return txt
    return ""


def extract_progress(events: list[dict]) -> str:
    """Ultima ferramenta usada pelo agente (para a mensagem de progresso)."""
    for ev in events:
        if ev.get("kind") == "ActionEvent":
            tool = ev.get("tool_name") or (ev.get("action") or {}).get("kind") or ""
            return str(tool)[:40]
    return ""


def extract_error(events: list[dict]) -> str:
    for ev in events:
        if "error" in str(ev.get("kind", "")).lower():
            return str(ev.get("detail") or ev.get("error") or ev.get("message") or ev.get("kind"))[:400]
    return ""


class OpenHandsProvider:
    def __init__(self, host: str, workspace_root: str, agent_profile_id: str = "",
                 session_api_key: str = "", timeout_s: float = 20.0, max_iterations: int = 60,
                 transport: httpx.AsyncBaseTransport | None = None):
        self.host = host.rstrip("/")
        self.root = Path(workspace_root)
        self.agent_profile_id = agent_profile_id.strip()
        self.timeout_s = timeout_s
        self.max_iterations = max_iterations
        self.transport = transport
        self.headers = {"X-Session-API-Key": session_api_key} if session_api_key else {}

    async def _req(self, method: str, path: str, **kw):
        try:
            async with httpx.AsyncClient(timeout=self.timeout_s, transport=self.transport,
                                         headers=self.headers, trust_env=False) as c:
                r = await c.request(method, f"{self.host}{path}", **kw)
        except httpx.RequestError as exc:
            raise OpenHandsOfflineError(f"OpenHands offline em {self.host}") from exc
        if r.status_code == 404:
            raise OpenHandsNotFoundError("conversa nao encontrada")
        if r.status_code >= 400:
            detail = ""
            try:
                detail = str(r.json().get("detail"))[:300]
            except Exception:
                detail = r.text[:200]
            raise OpenHandsError(f"OpenHands HTTP {r.status_code}: {detail}")
        try:
            return r.json()
        except ValueError:
            return {}

    async def health_check(self) -> bool:
        try:
            await self._req("GET", "/server_info")
            return True
        except OpenHandsError:
            return False

    async def _resolve_profile(self) -> str:
        """Usa OPENHANDS_AGENT_PROFILE_ID; senao tenta o perfil ativo via GET /api/agent-profiles."""
        if self.agent_profile_id:
            return self.agent_profile_id
        data = await self._req("GET", "/api/agent-profiles")
        for key in ("active_agent_profile_id", "active_id", "active"):
            if isinstance(data, dict) and isinstance(data.get(key), str):
                return data[key]
        raise OpenHandsError("Defina OPENHANDS_AGENT_PROFILE_ID no .env do Nexus (id do perfil de agente).")

    def workdir(self, project: str = "") -> Path:
        slug = re.sub(r"[^A-Za-z0-9_-]", "", project)[:40] or "default"
        d = (self.root / slug).resolve()
        if self.root.resolve() not in d.parents and d != self.root.resolve():
            raise OpenHandsError("projeto invalido")
        d.mkdir(parents=True, exist_ok=True)
        return d

    async def start_task(self, prompt: str, project: str = "") -> str:
        profile = await self._resolve_profile()
        payload = {
            "agent_profile_id": profile,
            "workspace": {"working_dir": str(self.workdir(project))},
            "initial_message": {"role": "user", "content": [{"type": "text", "text": prompt[:8000]}]},
            "max_iterations": self.max_iterations,
            "autotitle": False,  # evita a chamada extra de LLM so para dar titulo
        }
        info = await self._req("POST", "/api/conversations", json=payload)
        cid = str(info.get("id") or "")
        if not cid:
            raise OpenHandsError("OpenHands nao devolveu o id da conversa")
        return cid

    async def get_task(self, cid: str) -> dict:
        info = await self._req("GET", f"/api/conversations/{cid}")
        status = str(info.get("execution_status") or "").lower()
        page = await self._req("GET", f"/api/conversations/{cid}/events/search",
                               params={"limit": 40, "sort_order": "TIMESTAMP_DESC"})
        events = page.get("items") or []
        done = status in TERMINAL
        out = {"id": cid, "status": status, "done": done,
               "progress": extract_progress(events), "result": "", "error": ""}
        if done:
            out["result"] = extract_result(events)
            if status != "finished":
                out["error"] = extract_error(events) or (
                    "tarefa interrompida pelo usuario" if status == "paused"
                    else f"agente terminou com status '{status}'")
        return out

    async def stop_task(self, cid: str) -> None:
        await self._req("POST", f"/api/conversations/{cid}/pause")
