"""
Provider de video Wan no ComfyUI remoto (Kaggle): T2V, I2V e R2V (reference-to-video, Wan 2.1 VACE).

Reaproveita do ComfyUIVideoProvider (LTX local) o upload, o enfileiramento, o polling do /history e o
download do video. O que muda aqui:
  - antes de gerar, `kaggle_manager.ensure_online()` sobe o notebook do Kaggle se estiver desligado;
  - o host e a URL aleatoria do ngrok (descoberta via ntfy pelo manager) e toda chamada leva o header
    que dispensa a pagina de aviso;
  - dois workflows (app/workflows/wan22_i2v_api.json e wan22_t2v_api.json), editados pelo _meta.title;
  - sem imagem de entrada (image_bytes vazio) usa o workflow de texto-para-video (so perfil draft);
  - perfil r2v (padrao): a imagem NAO e o primeiro frame, e uma referencia do sujeito (WanVaceToVideo).

Parametros: largura/altura vem do orchestrator (arredondadas para multiplo de 32); frames, steps, cfg e
fps vem de settings.WAN_*. Se o guard de OOM reduzir `length` (valor menor que settings.LTX_LENGTH),
essa reducao e respeitada.
"""
import io
import json
import logging
import random
from pathlib import Path
from typing import Any

import httpx

from app.config import settings
from app.providers.base import ProviderUnavailableError, ResourceExhaustedError
from app.providers.comfyui_video_provider import ComfyUIVideoProvider
from app.providers.kaggle_runtime import NGROK_HEADERS, KaggleComfyUIManager, kaggle_manager

logger = logging.getLogger("nexus.kaggle_wan_provider")

_TITLES_14B = {
    "positive": "positive_prompt",
    "negative": "negative_prompt",
    "image": "input_image",
    "video_latent": "video_latent",
    "ksampler_high": "ksampler_high",
    "ksampler_low": "ksampler_low",
    "create_video": "create_video",
}
_TITLES = {
    "positive": "positive_prompt",
    "negative": "negative_prompt",
    "image": "input_image",
    "video_latent": "video_latent",
    "ksampler": "ksampler",
    "create_video": "create_video",
}


_TITLES_R2V = {
    "positive": "positive_prompt",
    "negative": "negative_prompt",
    "image": "input_image",
    "video_latent": "video_latent",
    "shift": "model_shift",
    "ksampler": "ksampler",
    "create_video": "create_video",
}

_TITLES_MM = {
    "unet": "unet",
    "positive": "positive_prompt",
    "image": "input_image",
    "video_latent": "video_latent",
    "guider": "guider",
    "scheduler": "scheduler",
    "noise": "noise",
    "create_video": "create_video",
}

_TITLES_HY = {
    "unet": "unet",
    "positive": "positive_prompt",
    "negative": "negative_prompt",
    "image": "input_image",
    "video_latent": "video_latent",
    "shift": "model_shift",
    "guider": "guider",
    "scheduler": "scheduler",
    "noise": "noise",
    "create_video": "create_video",
}


def _round32(v: int) -> int:
    return max(256, int(round(v / 32.0)) * 32)


def _wan_size(image_bytes: bytes, fallback_w: int, fallback_h: int, pixels: int) -> tuple[int, int]:
    """Largura/altura (multiplos de 32) com a PROPORCAO da imagem e area <= pixels.

    O Wan22ImageToVideoLatent recorta a imagem no centro para a proporcao do latente: com um latente 3:2
    e uma foto quadrada, o topo e a base da foto eram cortados (e o modelo inventava o resto).
    Sem imagem (T2V) usa 16:9."""
    iw, ih = 16, 9
    if image_bytes:
        try:
            from PIL import Image
            with Image.open(io.BytesIO(image_bytes)) as im:
                iw, ih = im.size
        except Exception:  # noqa: BLE001
            iw, ih = fallback_w, fallback_h
    aspect = max(iw, 1) / max(ih, 1)
    h = (pixels / aspect) ** 0.5
    w = h * aspect
    # arredonda ao multiplo de 32 mais proximo (preserva a proporcao: 480x854 -> 576x1024, sem corte);
    # se estourar o orcamento de pixels em mais de 8%, cai para o multiplo de baixo
    rw, rh = max(256, int(round(w / 32)) * 32), max(256, int(round(h / 32)) * 32)
    if rw * rh > pixels * 1.08:
        rw, rh = max(256, int(w // 32) * 32), max(256, int(h // 32) * 32)
    return rw, rh


def _frames_17n5(n: int) -> int:
    """MiniMax H3 so aceita 17n+5 frames (22, 39, 56, 73, ... 124)."""
    n = max(5, int(n))
    return ((n - 5) // 17) * 17 + 5


def _frames_4n1(n: int) -> int:
    n = max(5, int(n))
    return ((n - 1) // 4) * 4 + 1


class KaggleWanVideoProvider(ComfyUIVideoProvider):
    # O notebook do Kaggle e ligado sob demanda no 1o job: "offline" aqui e o estado normal, nao uma falha.
    on_demand = True

    @property
    def supports_t2v(self) -> bool:
        # o perfil quality (A14B) so tem o workflow imagem->video
        return settings.WAN_PROFILE == "draft"

    @property
    def input_image_max_side(self) -> int:
        return 1024   # o Wan remoto usa resolucao maior que o LTX local: nao reduza demais a foto

    def __init__(self, manager: KaggleComfyUIManager | None = None):
        self.manager = manager or kaggle_manager
        super().__init__(host=self.manager.base_url or "https://dominio-nao-configurado.invalid",
                         workflow_path=settings.WAN_I2V_WORKFLOW_PATH)
        self.timeout_s = (settings.MINIMAX_JOB_TIMEOUT_S if settings.WAN_PROFILE == "minimax"
                          else settings.WAN_JOB_TIMEOUT_S)
        self._templates: dict[str, dict[str, Any]] = {}
        # o guard do resource_manager olha a VRAM LOCAL (irrelevante para o Kaggle) e reduz `length`.
        # Aqui so reduzimos depois de um OOM REMOTO de verdade.
        self._oom_recent = False
        # None = ainda nao checado; False = o notebook nao tem o LoRA turbo do MiniMax (cai para 20 passos)
        self._turbo_ok: bool | None = None

    async def _check_turbo(self, client: httpx.AsyncClient) -> None:
        """Pergunta ao ComfyUI remoto se o LoRA turbo do MiniMax existe (o download dele e opcional)."""
        if not settings.MINIMAX_TURBO or self._turbo_ok is not None:
            return
        try:
            r = await client.get(f"{self.host}/object_info/LoraLoaderModelOnly")
            names = r.json()["LoraLoaderModelOnly"]["input"]["required"]["lora_name"][0]
            self._turbo_ok = settings.MINIMAX_TURBO_LORA in names
        except Exception as e:  # noqa: BLE001
            logger.warning("[Wan/Kaggle] nao consegui checar o LoRA turbo (%s); tentando com turbo.", e)
            return   # tenta de novo no proximo job; por ora assume que existe
        if not self._turbo_ok:
            logger.warning("[Wan/Kaggle] LoRA turbo do MiniMax ausente no notebook: rodando com %s passos.",
                           settings.MINIMAX_STEPS)

    def _negative(self, app_negative: str) -> str:
        if settings.WAN_PROFILE == "minimax":
            return ""   # BasicGuider: o H3 nao usa prompt negativo
        if settings.WAN_PROFILE == "r2v":
            # cfg > 1: o negativo funciona. O do app (constants.py) bloqueia mao/pessoa, entao nao entra.
            return settings.R2V_NEGATIVE_PROMPT.strip()
        if settings.WAN_PROFILE == "hunyuan":
            # o negativo do app (constants.py) e do LTX/produtos e bloqueia mao/pessoa; aqui so vale o do .env
            return settings.HUNYUAN_NEGATIVE_PROMPT.strip()
        neg = settings.WAN_NEGATIVE_PROMPT.strip()
        if settings.WAN_APPEND_NEGATIVE and app_negative:
            neg = f"{neg}, {app_negative}" if neg else app_negative
        return neg or app_negative

    # --- templates ------------------------------------------------------------------------------

    def _template(self, kind: str) -> dict[str, Any]:
        if kind not in self._templates:
            if settings.WAN_PROFILE == "minimax":
                path = Path(settings.MINIMAX_WORKFLOW_PATH)
            elif settings.WAN_PROFILE == "r2v":
                path = Path(settings.R2V_WORKFLOW_PATH)
            elif settings.WAN_PROFILE == "quality":
                path = Path(settings.WAN14B_I2V_WORKFLOW_PATH)
            elif settings.WAN_PROFILE == "hunyuan":
                path = Path(settings.HUNYUAN_I2V_WORKFLOW_PATH)
            else:
                path = Path(settings.WAN_I2V_WORKFLOW_PATH if kind == "i2v" else settings.WAN_T2V_WORKFLOW_PATH)
            if not path.exists():
                raise ProviderUnavailableError(f"Workflow do Wan nao encontrado: '{path}'.")
            try:
                raw = json.loads(path.read_text(encoding="utf-8"))
            except (OSError, json.JSONDecodeError) as e:
                raise ProviderUnavailableError(f"Nao foi possivel ler o workflow '{path}': {e}") from e
            raw.pop("_comment", None)
            self._templates[kind] = raw
        return json.loads(json.dumps(self._templates[kind]))

    def _build_wan_prompt(self, kind: str, positive: str, negative: str, image_filename: str | None,
                          width: int, height: int, length: int, seed: int | None) -> dict[str, Any]:
        wf = self._template(kind)
        if settings.WAN_PROFILE == "minimax":
            return self._build_minimax_prompt(wf, positive, negative, image_filename, width, height, length, seed)
        if settings.WAN_PROFILE == "r2v":
            return self._build_r2v_prompt(wf, positive, negative, image_filename, width, height, length, seed)
        if settings.WAN_PROFILE == "quality":
            return self._build_a14b_prompt(wf, positive, negative, image_filename, width, height, length, seed)
        if settings.WAN_PROFILE == "hunyuan":
            return self._build_hunyuan_prompt(wf, positive, negative, image_filename, width, height, length, seed)
        wf[self._find_node_by_title(wf, _TITLES["positive"])]["inputs"]["text"] = positive
        wf[self._find_node_by_title(wf, _TITLES["negative"])]["inputs"]["text"] = negative
        if kind == "i2v":
            wf[self._find_node_by_title(wf, _TITLES["image"])]["inputs"]["image"] = image_filename
        lat = wf[self._find_node_by_title(wf, _TITLES["video_latent"])]["inputs"]
        lat["width"], lat["height"], lat["length"] = width, height, length
        ks = wf[self._find_node_by_title(wf, _TITLES["ksampler"])]["inputs"]
        ks["steps"] = settings.WAN_STEPS
        ks["cfg"] = settings.WAN_CFG
        ks["seed"] = seed if seed is not None else random.randint(0, 2**53 - 1)
        wf[self._find_node_by_title(wf, _TITLES["create_video"])]["inputs"]["fps"] = settings.WAN_FPS
        return wf

    def _build_minimax_prompt(self, wf: dict[str, Any], positive: str, negative: str, image_filename: str | None,
                              width: int, height: int, length: int, seed: int | None) -> dict[str, Any]:
        t = _TITLES_MM
        find = self._find_node_by_title
        if "<Picture 1>" not in positive:
            # o H3 so enxerga a referencia se o prompt a citar como <Picture 1>
            positive = f"<Picture 1> is the reference subject. {positive}"
        unet_id = find(wf, t["unet"])
        wf[unet_id]["inputs"]["unet_name"] = settings.MINIMAX_UNET
        wf[find(wf, t["positive"])]["inputs"]["value"] = positive
        wf[find(wf, t["image"])]["inputs"]["image"] = image_filename
        lat = wf[find(wf, t["video_latent"])]["inputs"]
        lat["width"], lat["height"], lat["length"] = width, height, length
        wf[find(wf, t["noise"])]["inputs"]["noise_seed"] = seed if seed is not None else random.randint(0, 2**53 - 1)
        wf[find(wf, t["create_video"])]["inputs"]["fps"] = settings.MINIMAX_FPS
        steps = settings.MINIMAX_STEPS
        if settings.MINIMAX_TURBO and self._turbo_ok is not False:
            # LoRA turbo de 4 passos: so o modelo do GUIDER passa por ele; o BasicScheduler usa o modelo base
            lora_id = str(max(int(k) for k in wf if k.isdigit()) + 1)
            wf[lora_id] = {
                "class_type": "LoraLoaderModelOnly",
                "_meta": {"title": "turbo_lora"},
                "inputs": {"lora_name": settings.MINIMAX_TURBO_LORA, "strength_model": 1, "model": [unet_id, 0]},
            }
            wf[find(wf, t["guider"])]["inputs"]["model"] = [lora_id, 0]
            steps = settings.MINIMAX_TURBO_STEPS
        wf[find(wf, t["scheduler"])]["inputs"]["steps"] = steps
        return wf

    def _build_r2v_prompt(self, wf: dict[str, Any], positive: str, negative: str, image_filename: str | None,
                          width: int, height: int, length: int, seed: int | None) -> dict[str, Any]:
        t = _TITLES_R2V
        find = self._find_node_by_title
        wf[find(wf, t["positive"])]["inputs"]["text"] = positive
        wf[find(wf, t["negative"])]["inputs"]["text"] = negative
        # a imagem entra como reference_image do WanVaceToVideo (nao como start_image)
        wf[find(wf, t["image"])]["inputs"]["image"] = image_filename
        lat = wf[find(wf, t["video_latent"])]["inputs"]
        lat["width"], lat["height"], lat["length"] = width, height, length
        lat["strength"] = settings.R2V_STRENGTH
        wf[find(wf, t["shift"])]["inputs"]["shift"] = settings.R2V_SHIFT
        ks = wf[find(wf, t["ksampler"])]["inputs"]
        ks["steps"] = settings.R2V_STEPS
        ks["cfg"] = settings.R2V_CFG
        ks["seed"] = seed if seed is not None else random.randint(0, 2**53 - 1)
        wf[find(wf, t["create_video"])]["inputs"]["fps"] = settings.R2V_FPS
        return wf

    def _build_hunyuan_prompt(self, wf: dict[str, Any], positive: str, negative: str, image_filename: str | None,
                              width: int, height: int, length: int, seed: int | None) -> dict[str, Any]:
        t = _TITLES_HY
        find = self._find_node_by_title
        wf[find(wf, t["unet"])]["inputs"]["unet_name"] = settings.HUNYUAN_UNET
        wf[find(wf, t["positive"])]["inputs"]["text"] = positive
        wf[find(wf, t["negative"])]["inputs"]["text"] = negative
        wf[find(wf, t["image"])]["inputs"]["image"] = image_filename
        lat = wf[find(wf, t["video_latent"])]["inputs"]
        lat["width"], lat["height"], lat["length"] = width, height, length
        wf[find(wf, t["shift"])]["inputs"]["shift"] = settings.HUNYUAN_SHIFT
        wf[find(wf, t["guider"])]["inputs"]["cfg"] = settings.HUNYUAN_CFG
        wf[find(wf, t["scheduler"])]["inputs"]["steps"] = settings.HUNYUAN_STEPS
        wf[find(wf, t["noise"])]["inputs"]["noise_seed"] = seed if seed is not None else random.randint(0, 2**53 - 1)
        wf[find(wf, t["create_video"])]["inputs"]["fps"] = settings.HUNYUAN_FPS
        return wf

    def _build_a14b_prompt(self, wf: dict[str, Any], positive: str, negative: str, image_filename: str | None,
                           width: int, height: int, length: int, seed: int | None) -> dict[str, Any]:
        t = _TITLES_14B
        wf[self._find_node_by_title(wf, t["positive"])]["inputs"]["text"] = positive
        wf[self._find_node_by_title(wf, t["negative"])]["inputs"]["text"] = negative
        wf[self._find_node_by_title(wf, t["image"])]["inputs"]["image"] = image_filename
        lat = wf[self._find_node_by_title(wf, t["video_latent"])]["inputs"]
        lat["width"], lat["height"], lat["length"] = width, height, length
        steps = settings.WAN14B_STEPS
        s = seed if seed is not None else random.randint(0, 2**53 - 1)
        hi = wf[self._find_node_by_title(wf, t["ksampler_high"])]["inputs"]
        lo = wf[self._find_node_by_title(wf, t["ksampler_low"])]["inputs"]
        for ks in (hi, lo):
            ks["steps"], ks["cfg"], ks["noise_seed"] = steps, settings.WAN14B_CFG, s
        hi["start_at_step"], hi["end_at_step"] = 0, steps // 2      # ruido alto: primeira metade
        lo["start_at_step"], lo["end_at_step"] = steps // 2, steps  # ruido baixo: segunda metade
        wf[self._find_node_by_title(wf, t["create_video"])]["inputs"]["fps"] = settings.WAN14B_FPS
        return wf

    # --- interface publica ----------------------------------------------------------------------

    async def generate(self, positive_prompt: str, negative_prompt: str, image_bytes: bytes,
                       width: int, height: int, length: int, denoise: float,
                       seed: int | None) -> str:
        # `denoise` do orchestrator e especifico do LTX (LTXVImgToVideo) e nao se aplica ao Wan.
        await self.manager.ensure_online()
        self.host = self.manager.base_url   # garante o dominio mesmo se o .env mudou com o app aberto

        profile = settings.WAN_PROFILE
        kind = ("r2v" if profile in ("r2v", "minimax") else "i2v") if image_bytes else "t2v"
        if profile in ("quality", "hunyuan", "r2v", "minimax") and kind == "t2v":
            if profile in ("r2v", "minimax"):
                raise ProviderUnavailableError(
                    f"O perfil WAN_PROFILE={profile} precisa de uma imagem de REFERENCIA do sujeito. "
                    "Envie uma foto ou use WAN_PROFILE=draft para texto -> video."
                )
            nome = "Wan A14B" if profile == "quality" else "HunyuanVideo 1.5"
            raise ProviderUnavailableError(
                f"O perfil WAN_PROFILE={profile} ({nome}) so faz imagem -> video. Envie uma foto "
                "ou use WAN_PROFILE=draft para texto -> video."
            )
        base_pixels, base_frames, fallback_frames, steps = {
            "minimax": (settings.MINIMAX_MAX_PIXELS, settings.MINIMAX_LENGTH, settings.MINIMAX_LENGTH_FALLBACK,
                        settings.MINIMAX_TURBO_STEPS if settings.MINIMAX_TURBO else settings.MINIMAX_STEPS),
            "r2v": (settings.R2V_MAX_PIXELS, settings.R2V_LENGTH,
                    settings.R2V_LENGTH_FALLBACK, settings.R2V_STEPS),
            "quality": (settings.WAN14B_MAX_PIXELS, settings.WAN14B_LENGTH,
                        settings.WAN14B_LENGTH_FALLBACK, settings.WAN14B_STEPS),
            "hunyuan": (settings.HUNYUAN_MAX_PIXELS, settings.HUNYUAN_LENGTH,
                        settings.HUNYUAN_LENGTH_FALLBACK, settings.HUNYUAN_STEPS),
        }.get(profile, (settings.WAN_MAX_PIXELS, settings.WAN_LENGTH,
                        settings.WAN_LENGTH_FALLBACK, settings.WAN_STEPS))
        pixels = int(base_pixels * (0.6 if self._oom_recent else 1.0))
        w, h = _wan_size(image_bytes, width, height, pixels)
        frames = min(base_frames, fallback_frames) if self._oom_recent else base_frames
        frames = _frames_17n5(frames) if profile == "minimax" else _frames_4n1(frames)
        negative_prompt = self._negative(negative_prompt)
        logger.info("[Wan/Kaggle] perfil=%s %s %sx%s, %s frames, steps=%s, seed=%s",
                    profile, kind.upper(), w, h, frames, steps, seed)

        try:
            async with httpx.AsyncClient(timeout=60, headers=NGROK_HEADERS) as client:
                if profile == "minimax":
                    await self._check_turbo(client)
                image_filename = await self._upload_image(client, image_bytes) if kind in ("i2v", "r2v") else None
                wf = self._build_wan_prompt(kind, positive_prompt, negative_prompt, image_filename,
                                            w, h, frames, seed)
                prompt_id = await self._queue_prompt(client, wf)
                logger.info("[Wan/Kaggle] Prompt enfileirado (prompt_id=%s), aguardando...", prompt_id)
                entry = await self._poll_history(client, prompt_id)
                out = await self._download_output_video(client, entry)
        except ResourceExhaustedError:
            self._oom_recent = True
            raise
        self._oom_recent = False
        return out

    async def health_check(self) -> bool:
        # Nunca dispara o notebook: so informa se o ComfyUI remoto esta no ar agora.
        return await self.manager.is_online()
