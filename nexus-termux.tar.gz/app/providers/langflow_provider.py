"""Cliente HTTP assíncrono para execução de flows Langflow com RAG dinâmico."""
from urllib.parse import quote

import httpx


class LangflowError(Exception):
    """Falha ao configurar ou executar um flow do Langflow."""


class LangflowNotConfiguredError(LangflowError):
    pass


class LangflowTimeoutError(LangflowError):
    pass


class LangflowConnectionError(LangflowError):
    pass


class LangflowResponseError(LangflowError):
    pass


class LangflowProvider:
    def __init__(self, host: str, flow_id: str, knowledge_node_id: str,
                 timeout_s: float = 60.0,
                 transport: httpx.AsyncBaseTransport | None = None,
                 api_key: str = "",
                 knowledge_field: str = "knowledge_base"):
        self.host = host.rstrip("/")
        self.flow_id = flow_id.strip()
        self.knowledge_node_id = knowledge_node_id.strip()
        self.timeout_s = timeout_s
        self.transport = transport
        # Chave criada em Langflow > Settings > Langflow API Keys. Sem ela a
        # maioria dos endpoints /api/v1 responde 401/403.
        self.api_key = api_key.strip()
        # Nome INTERNO do campo no JSON do flow ("name"), nao o rotulo da tela.
        self.knowledge_field = knowledge_field.strip() or "knowledge_base"

    async def health_check(self) -> bool:
        try:
            async with httpx.AsyncClient(timeout=3.0, transport=self.transport) as client:
                response = await client.get(f"{self.host}/api/v1/version")
                return response.status_code < 400
        except Exception:
            return False

    async def list_knowledge_bases(self) -> list[dict]:
        """Lista as bases de conhecimento do Langflow (GET /api/v1/knowledge_bases/)."""
        url = f"{self.host}/api/v1/knowledge_bases/"
        headers = {"x-api-key": self.api_key} if self.api_key else {}
        try:
            async with httpx.AsyncClient(timeout=10.0, transport=self.transport) as client:
                response = await client.get(url, headers=headers, follow_redirects=True)
                response.raise_for_status()
                data = response.json()
        except httpx.TimeoutException as exc:
            raise LangflowTimeoutError("Langflow excedeu o tempo limite ao listar bases.") from exc
        except httpx.HTTPStatusError as exc:
            status = exc.response.status_code
            hint = (
                " Verifique LANGFLOW_API_KEY."
                if status in (401, 403)
                else " Esta versão do Langflow pode não expor a listagem; use LANGFLOW_RAGS no .env."
                if status == 404
                else ""
            )
            raise LangflowResponseError(f"Langflow respondeu com HTTP {status} ao listar bases.{hint}") from exc
        except httpx.RequestError as exc:
            raise LangflowConnectionError("Não foi possível conectar ao servidor Langflow.") from exc
        except ValueError as exc:
            raise LangflowResponseError("Langflow retornou JSON inválido ao listar bases.") from exc
        if not isinstance(data, list):
            raise LangflowResponseError("Formato inesperado na listagem de bases do Langflow.")
        return [item for item in data if isinstance(item, dict)]

    async def run_chat(self, message: str, selected_rag: str) -> dict:
        if not self.flow_id or not self.knowledge_node_id:
            raise LangflowNotConfiguredError(
                "Configure LANGFLOW_FLOW_ID e LANGFLOW_KNOWLEDGE_NODE_ID no ambiente."
            )

        payload = {
            "input_value": message,
            "output_type": "chat",
            "input_type": "chat",
            "tweaks": {
                self.knowledge_node_id: {self.knowledge_field: selected_rag},
            },
        }
        url = f"{self.host}/api/v1/run/{quote(self.flow_id, safe='')}"
        headers = {"x-api-key": self.api_key} if self.api_key else {}

        try:
            async with httpx.AsyncClient(
                timeout=self.timeout_s, transport=self.transport
            ) as client:
                response = await client.post(url, json=payload, headers=headers)
                response.raise_for_status()
                return response.json()
        except httpx.TimeoutException as exc:
            raise LangflowTimeoutError("Langflow excedeu o tempo limite de resposta.") from exc
        except httpx.HTTPStatusError as exc:
            status = exc.response.status_code
            hint = (
                " Verifique LANGFLOW_API_KEY (Settings > Langflow API Keys)."
                if status in (401, 403) else ""
            )
            raise LangflowResponseError(
                f"Langflow respondeu com HTTP {status}.{hint}"
            ) from exc
        except httpx.RequestError as exc:
            raise LangflowConnectionError("Não foi possível conectar ao servidor Langflow.") from exc
        except ValueError as exc:
            raise LangflowResponseError("Langflow retornou uma resposta JSON inválida.") from exc