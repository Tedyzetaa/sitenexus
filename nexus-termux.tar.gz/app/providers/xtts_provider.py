"""
Sintese de voz local com XTTS v2 (pacote "coqui-tts"), usada pelo pipeline de
translation_dubbing como ULTIMO estagio: recebe o texto ja traduzido (Ollama)
e um arquivo de audio de referencia (o audio original enviado pelo usuario) e
sintetiza a fala no idioma alvo CLONANDO a voz do falante original.

Requer Python < 3.14 (limite atual do pacote "coqui-tts") e torch instalado.
O XTTS e sempre executado em CPU, independentemente do valor de XTTS_DEVICE.

Mesma disciplina de VRAM do whisper_stt.py: carrega sob demanda, expoe
unload(). NAO e assincrono -- envolver em asyncio.to_thread(...).
"""
import gc
import logging
import threading
import time
import uuid
from pathlib import Path

from app import hardware
from app.config import settings

logger = logging.getLogger("nexus.xtts_provider")

_model = None
_model_lock = threading.Lock()
_loaded_config: tuple[str, str] | None = None  # (model_name, device) atualmente carregado
_idle_timer: threading.Timer | None = None
_last_activity_ts = 0.0
_pinned = False  # modo ligacao: o modelo FICA carregado entre as frases (quem libera e o CallManager)


def _idle_seconds() -> float:
    """Tempo sem uso apos o qual o XTTS e descarregado (settings.XTTS_IDLE_UNLOAD_S; minimo 10 s)."""
    return float(max(10, settings.XTTS_IDLE_UNLOAD_S))

# Idiomas suportados pelo XTTS v2 (codigos curtos, SEM variante regional --
# "pt-BR" deve ser normalizado para "pt" antes de chegar aqui).
SUPPORTED_LANGUAGES = {
    "en", "es", "fr", "de", "it", "pt", "pl", "tr", "ru",
    "nl", "cs", "ar", "zh-cn", "ja", "hu", "ko",
}


class SynthesisError(Exception):
    """Levantada quando a sintese falha ou o idioma nao e suportado."""


def normalize_language(lang: str) -> str:
    """'pt-BR'/'pt_br' -> 'pt'. Levanta SynthesisError se o idioma nao for suportado."""
    short = (lang or "").strip().lower().replace("_", "-").split("-")[0]
    if short not in SUPPORTED_LANGUAGES:
        raise SynthesisError(
            f"Idioma alvo '{lang}' nao suportado pelo XTTS v2. "
            f"Suportados: {sorted(SUPPORTED_LANGUAGES)}"
        )
    return short


def _resolve_device(device: str) -> str:
    """XTTS fica sempre em CPU, mesmo se XTTS_DEVICE estiver definido como cuda."""
    return "cpu"


def schedule_idle_unload() -> None:
    """(Re)agenda o descarregamento do XTTS apos XTTS_IDLE_UNLOAD_S segundos sem uso.

    v8.0: usa threading.Timer em vez de asyncio.Task. O XTTS e carregado/usado sempre em threads
    (asyncio.to_thread), onde `asyncio.get_running_loop()` levanta RuntimeError -- a versao anterior
    simplesmente nao agendava nada nesse caso (codigo morto). Timer funciona de qualquer thread e o
    descarregamento nunca roda no event loop (a versao antiga, se tivesse rodado, travaria o servidor
    inteiro esperando o _model_lock enquanto uma sintese longa de CPU o segurava).
    """
    global _idle_timer
    if _idle_timer is not None:
        _idle_timer.cancel()
    timer = threading.Timer(_idle_seconds(), _idle_fire)
    timer.daemon = True
    timer.start()
    _idle_timer = timer


def _idle_fire() -> None:
    if _model is None or _pinned:
        return
    if not _unload_if_idle() and _model is not None:
        # sintese em andamento ou atividade recente: confere de novo em breve
        global _idle_timer
        timer = threading.Timer(min(30.0, _idle_seconds()), _idle_fire)
        timer.daemon = True
        timer.start()
        _idle_timer = timer


def _unload_if_idle() -> bool:
    """Descarrega SE ninguem esta sintetizando e o tempo ocioso venceu. True = nada mais a vigiar."""
    if not _model_lock.acquire(blocking=False):
        return False  # sintese em andamento: tenta de novo na proxima volta
    try:
        if _model is None or _pinned:
            return True
        if time.monotonic() - _last_activity_ts < _idle_seconds():
            return False
        _unload_locked()
        return True
    finally:
        _model_lock.release()


def _load_model(model_name: str, device: str):
    global _model, _loaded_config, _last_activity_ts
    try:
        from TTS.api import TTS
    except ImportError as exc:
        raise SynthesisError(
            "Pacote 'coqui-tts' nao instalado (ou Python >= 3.14, que nao e suportado "
            "pelo coqui-tts). Rode 'pip install coqui-tts' numa venv com Python < 3.14."
        ) from exc

    resolved_device = _resolve_device(device)
    # v8.0: o XTTS v2 ocupa ~2-3 GB de RAM. Com 8 GB no total, carregar sem espaco faz o Windows paginar
    # no HDD (maquina trava) ou matar o processo sem traceback -- melhor recusar com mensagem clara.
    hardware.ensure_ram(settings.MIN_FREE_RAM_XTTS_MB, "o XTTS v2")
    logger.info("Carregando XTTS v2 (%s, device=%s, threads=%d)...", model_name, resolved_device, settings.cpu_threads)
    model = TTS(model_name).to(resolved_device)
    try:  # nucleos fisicos apenas: mais threads que nucleos so aumenta a disputa de CPU
        import torch

        torch.set_num_threads(settings.cpu_threads)
    except Exception:  # noqa: BLE001 - ajuste de desempenho, nunca fatal
        logger.debug("Nao consegui ajustar torch.set_num_threads", exc_info=True)
    _model = model
    _loaded_config = (model_name, resolved_device)
    _last_activity_ts = time.monotonic()
    schedule_idle_unload()
    return _model


def _synthesize_impl(
    text: str,
    speaker_wav_path: str,
    language: str,
    model_name: str,
    device: str,
    output_dir: Path,
) -> str:
    if not text or not text.strip():
        raise SynthesisError("Texto vazio para sintese.")
    lang = normalize_language(language)

    with _model_lock:
        model = _model
        if model is None or _loaded_config != (model_name, _resolve_device(device)):
            model = _load_model(model_name, device)

        output_dir.mkdir(parents=True, exist_ok=True)
        out_path = output_dir / f"{uuid.uuid4()}.wav"
        try:
            model.tts_to_file(
                text=text,
                speaker_wav=speaker_wav_path,
                language=lang,
                file_path=str(out_path),
            )
            global _last_activity_ts
            _last_activity_ts = time.monotonic()
            schedule_idle_unload()
        except Exception as exc:
            raise SynthesisError(f"Falha ao sintetizar audio com XTTS v2: {exc!r}") from exc

    if not out_path.exists() or out_path.stat().st_size == 0:
        raise SynthesisError("XTTS v2 nao gerou um arquivo de audio valido.")
    return str(out_path)


def synthesize(
    text: str,
    speaker_wav_path: str,
    language: str,
    model_name: str,
    device: str,
    output_dir: Path,
) -> str:
    """Sintetiza `text` clonando a voz de speaker_wav_path. BLOQUEANTE -- usar asyncio.to_thread."""

    return _synthesize_impl(
        text=text,
        speaker_wav_path=speaker_wav_path,
        language=language,
        model_name=model_name,
        device=device,
        output_dir=output_dir,
    )


def _unload_locked() -> None:
    """Descarrega o modelo. O CHAMADOR precisa estar segurando _model_lock."""
    global _model, _loaded_config, _idle_timer, _last_activity_ts, _pinned
    if _model is None:
        return
    del _model
    _model = None
    _loaded_config = None
    _last_activity_ts = 0.0
    _pinned = False
    gc.collect()
    timer, _idle_timer = _idle_timer, None
    if timer is not None:
        timer.cancel()
    logger.info("Modelo XTTS v2 descarregado.")


def unload(blocking: bool = True) -> bool:
    """Libera o modelo XTTS da RAM. Chamar apos o job terminar (sucesso ou falha).

    blocking=False: se uma sintese estiver em andamento, NAO espera (devolve False) -- use quando quem
    chama esta no event loop (ex.: manutencao do modo ligacao).
    """
    if not _model_lock.acquire(blocking=blocking):
        return False
    try:
        _unload_locked()
        return True
    finally:
        _model_lock.release()


# ----------------------------------------------------------------------
# Modo ligacao: o modelo FICA carregado entre as frases (carregar o XTTS de um
# HDD a cada frase seria inviavel). Sem gpu_vram_lock: em CPU nao ha disputa
# de VRAM, e o _model_lock ja serializa o acesso ao modelo.
# ----------------------------------------------------------------------

def _write_wav(path: Path, wav, sample_rate: int = 24000) -> None:
    import numpy as np
    from scipy.io import wavfile

    if hasattr(wav, "detach"):  # tensor do torch
        wav = wav.detach().cpu().numpy()
    arr = np.asarray(wav, dtype=np.float32).reshape(-1)
    wavfile.write(str(path), sample_rate, (np.clip(arr, -1.0, 1.0) * 32767).astype(np.int16))


def warmup(model_name: str, device: str) -> None:
    """Carrega o XTTS (se ainda nao estiver) para a primeira frase da ligacao nao pagar o load."""
    global _last_activity_ts, _pinned
    with _model_lock:
        if _model is None or _loaded_config != (model_name, _resolve_device(device)):
            _load_model(model_name, device)
        _last_activity_ts = time.monotonic()
        _pinned = True  # ligacao em andamento: o idle-unload nao pode derrubar o modelo entre as frases


def compute_latents(speaker_wav_path: str, model_name: str, device: str):
    """Calcula UMA vez os latentes da voz de referencia (caro em CPU) para reutilizar em todas as frases."""
    with _model_lock:
        model = _model
        if model is None or _loaded_config != (model_name, _resolve_device(device)):
            model = _load_model(model_name, device)
        try:
            return model.synthesizer.tts_model.get_conditioning_latents(audio_path=[speaker_wav_path])
        except Exception as exc:
            raise SynthesisError(f"Falha ao calcular a voz de referencia: {exc!r}") from exc


def synthesize_call(
    text: str,
    language: str,
    model_name: str,
    device: str,
    output_dir: Path,
    *,
    speaker: str | None = None,
    speaker_wav_path: str | None = None,
    latents=None,
) -> str:
    """Sintetiza uma frase da ligacao. BLOQUEANTE -- usar asyncio.to_thread.

    Prioridade da voz: latents (referencia ja processada) > speaker_wav_path > speaker embutido.
    """
    global _last_activity_ts, _pinned
    if not text or not text.strip():
        raise SynthesisError("Texto vazio para sintese.")
    lang = normalize_language(language)

    with _model_lock:
        model = _model
        if model is None or _loaded_config != (model_name, _resolve_device(device)):
            model = _load_model(model_name, device)
        _pinned = True

        output_dir.mkdir(parents=True, exist_ok=True)
        out_path = output_dir / f"{uuid.uuid4()}.wav"
        try:
            if latents is not None:
                gpt_cond_latent, speaker_embedding = latents
                result = model.synthesizer.tts_model.inference(
                    text, lang, gpt_cond_latent, speaker_embedding, enable_text_splitting=True
                )
                _write_wav(out_path, result["wav"])
            elif speaker_wav_path:
                model.tts_to_file(text=text, speaker_wav=speaker_wav_path, language=lang, file_path=str(out_path))
            else:
                names = list(getattr(model, "speakers", None) or [])
                chosen = speaker if speaker in names else (names[0] if names else None)
                if chosen is None:
                    raise SynthesisError("Este XTTS nao tem vozes embutidas; envie um audio de referencia.")
                model.tts_to_file(text=text, speaker=chosen, language=lang, file_path=str(out_path))
        except SynthesisError:
            raise
        except Exception as exc:
            raise SynthesisError(f"Falha ao sintetizar a frase com XTTS v2: {exc!r}") from exc
        _last_activity_ts = time.monotonic()

    if not out_path.exists() or out_path.stat().st_size == 0:
        raise SynthesisError("XTTS v2 nao gerou um arquivo de audio valido.")
    return str(out_path)
