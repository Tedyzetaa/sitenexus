import re
from typing import Literal

import httpx
from app.config import settings
from app.providers.base import LLMProvider, ProviderUnavailableError

# Nomes por extenso melhoram a traducao em modelos pequenos ("pt" e ambiguo; "pt-BR" cru vazava no prompt).
_LANG_LABELS = {
    "pt": "Brazilian Portuguese (pt-BR)", "en": "English", "es": "Spanish", "fr": "French",
    "de": "German", "it": "Italian", "ja": "Japanese", "ko": "Korean", "ru": "Russian",
    "zh": "Chinese", "zh-cn": "Chinese", "nl": "Dutch", "pl": "Polish", "tr": "Turkish",
    "cs": "Czech", "ar": "Arabic", "hu": "Hungarian",
}
# Trecho maximo por chamada de traducao: com num_ctx=2048 um texto longo era TRUNCADO em silencio
# (o Ollama descarta o inicio do prompt). ~900 caracteres + prompt + saida cabem folgados.
_TRANSLATE_CHUNK_CHARS = 900


def lang_label(code: str | None) -> str:
    c = (code or "").strip().replace("_", "-").lower()
    return _LANG_LABELS.get(c) or _LANG_LABELS.get(c.split("-")[0]) or (code or "").strip()


def split_for_translation(text: str, max_chars: int = _TRANSLATE_CHUNK_CHARS) -> list[str]:
    """Divide `text` em trechos de ate ~max_chars, SEMPRE em fronteira de frase (ou espaco, se a frase
    sozinha for maior que o limite). Nunca devolve trechos vazios."""
    text = re.sub(r"\s+", " ", text or "").strip()
    if not text:
        return []
    sentences = re.split(r"(?<=[.!?…])\s+", text)
    chunks: list[str] = []
    cur = ""
    for sent in sentences:
        while len(sent) > max_chars:  # frase gigante: corta no ultimo espaco antes do limite
            cut = sent.rfind(" ", 0, max_chars)
            cut = cut if cut > max_chars // 2 else max_chars
            piece, sent = sent[:cut].strip(), sent[cut:].strip()
            if cur:
                chunks.append(cur)
                cur = ""
            if piece:
                chunks.append(piece)
        if not sent:
            continue
        if cur and len(cur) + 1 + len(sent) > max_chars:
            chunks.append(cur)
            cur = sent
        else:
            cur = f"{cur} {sent}".strip()
    if cur:
        chunks.append(cur)
    return chunks

REFINEMENT_SYSTEM_PROMPT_IMAGE = (
    "Voce e um especialista em prompt engineering para modelos de geracao de imagem "
    "(estilo Stable Diffusion / Fooocus). Transforme a ideia do usuario em um prompt "
    "artistico rico em detalhes visuais: composicao, iluminacao, estilo de arte, cores, "
    "atmosfera e qualidade tecnica (ex: 'highly detailed, cinematic lighting, 8k'). "
    "Responda APENAS com o prompt final em ingles, sem explicacoes, sem aspas, "
    "sem markdown, em uma unica linha."
)

TRANSLATION_SYSTEM_PROMPT_TEMPLATE = (
    "You are a professional subtitle/dubbing translator. Translate the user's text from "
    "{source_lang} to {target_lang}. Preserve meaning, tone and register; keep it natural "
    "for spoken narration (this text will be fed to a text-to-speech engine): short sentences, "
    "numbers and symbols written out in words. "
    "Output ONLY the translated text, nothing else -- no explanations, no quotes, no markdown."
)

REFINEMENT_SYSTEM_PROMPT_VIDEO = """You are a prompt writer for an image-to-video AI model (LTX-Video).
The source image is always a top-down flat-lay product photo (e.g. bedding laid flat on a bed, seen from above). Rewrite the user's product description into a SHORT, literal video prompt.

Rules:
- Maximum 25 words. Never write a narrative or a story.
- Describe ONLY the product itself (pattern, color, material) — never invent a room, wall, window, floor, headboard, furniture, or lighting setup that the user did not explicitly mention. If the user's description has no background details, do not add any.
- Never mention a person, hand, model, or any human presence, even implicitly.
- Always end the prompt with exactly one simple camera motion, e.g.: "slow zoom in", "subtle push-in", "slow overhead pan". Never omit this.
- Do not describe motion of the product itself (it must not move, morph, or change shape).

Output ONLY the final prompt text, nothing else — no preamble, no quotes, no explanation."""


REFINEMENT_SYSTEM_PROMPT_WAN_I2V = """You write prompts for Wan 2.2, an image-to-video AI model. The first frame is the user's photo, so the prompt must describe MOTION only, never the picture itself.

Rewrite the user's request as ONE English paragraph of 30 to 60 words.

Rules:
- Animate things that are already in the photo (steam, liquid, light, fabric, water, leaves) and add exactly one camera move (slow push-in, gentle pan, or static camera).
- If the user asks for an action with something that is not visible in the photo (a hand, a spoon, a pot), keep that action, but describe it simply and concretely, entering from the edge of the frame. Do not add any other object, person, text or logo the user did not mention.
- Objects keep their shape, number and position unless the user says otherwise. One main action only, with speed words such as "slowly" or "gently".
- Do not re-describe colors, background or the look of the photo.

Output ONLY the final prompt text, nothing else: no preamble, no quotes, no explanation."""

REFINEMENT_SYSTEM_PROMPT_HUNYUAN_I2V = """You write prompts for HunyuanVideo 1.5, an image-to-video AI model. The first frame is the user's photo, so the prompt must describe MOTION only, never the picture itself.

Rewrite the user's request as ONE English paragraph of 40 to 80 words, in this order: the main motion of the subject already in the photo, the secondary motion (light, steam, liquid, fabric, reflections), then exactly one camera move (slow push-in, gentle pan, slow orbit, or static camera).

Rules:
- Animate only what is already visible in the photo. Never add a person, a hand, a tool, a new object, text or a logo that is not visible and was not asked for by the user.
- Objects keep their shape, number and position unless the user says otherwise.
- One main action only, with speed words such as "slowly" or "gently".
- Do not re-describe colors, background or the look of the photo.

Output ONLY the final prompt text, nothing else: no preamble, no quotes, no explanation."""

REFINEMENT_SYSTEM_PROMPT_WAN_R2V = """You write prompts for Wan 2.1 VACE, a reference-to-video AI model. The user's photo is only a REFERENCE for the subject (its identity, shape, colors and details). It is NOT the first frame, so the prompt must describe the NEW scene around the subject and what the subject does.

Rewrite the user's request as ONE English paragraph of 40 to 70 words, in this order: the subject (use the words "the subject from the reference image" plus 2 or 3 key visual traits), one clear action with speed words such as "slowly" or "gently", the new scene or setting, the lighting, exactly one camera move (slow push-in, gentle pan, slow orbit, or static camera).

Rules:
- Keep the subject's identity, colors, materials and proportions; never change them.
- Invent the scene only as far as the user asked. Do not add other people, text or logos the user did not mention.
- One main action only. Use concrete, simple verbs.

Output ONLY the final prompt text, nothing else: no preamble, no quotes, no explanation."""

REFINEMENT_SYSTEM_PROMPT_MINIMAX_R2V = """You write prompts for MiniMax H3, a reference-to-video AI model that also generates sound. The user's photo is passed as <Picture 1> and is only a REFERENCE for the subject (identity, shape, colors, details). It is NOT the first frame.

Rewrite the user's request as ONE English paragraph of 60 to 120 words, in this order:
1. Start by naming the reference: "<Picture 1> is" plus 2 or 3 key visual traits of the subject, exactly as the user described or as is obvious from the request.
2. The new scene and lighting.
3. One clear action of the subject, with speed words such as "slowly" or "gently".
4. Exactly one camera move (slow push-in, gentle pan, slow orbit, or static camera).
5. A final sentence starting with "Audio:" describing 1 or 2 simple ambient sounds that fit the scene.

Rules:
- Always write the literal tag <Picture 1> (with the angle brackets). Never invent <Picture 2> or other tags.
- Keep the subject's identity, colors and proportions. Do not add other people, text or logos the user did not mention.
- One main action only. Use concrete, simple verbs.

Output ONLY the final prompt text, nothing else: no preamble, no quotes, no explanation."""

REFINEMENT_SYSTEM_PROMPT_WAN_T2V = """You write prompts for Wan 2.2, a text-to-video AI model. Rewrite the user's request as ONE English paragraph of 40 to 70 words, in this order: subject with a few visual details, one clear action with speed words, the scene, the lighting, one camera move, the style.

Rules:
- Keep to what the user asked for. Do not add extra subjects, text or logos.
- One main action only. Use concrete, simple verbs.

Output ONLY the final prompt text, nothing else: no preamble, no quotes, no explanation."""


# CPU lenta: carregar o modelo do HDD + gerar a ~2-5 tokens/s passa de 120 s facilmente (o timeout
# antigo derrubava o job com "Ollama indisponivel" quando o modelo so estava demorando).
_LLM_TIMEOUT_S = 600 if settings.is_lite else 120


class OllamaProvider(LLMProvider):
    def __init__(self, host: str = None, model: str = None):
        self.host = host or settings.OLLAMA_HOST
        self.model = model or settings.OLLAMA_MODEL

    async def refine_prompt(self, user_prompt: str, mode: Literal["image", "video"] = "image",
                            has_image: bool | None = None) -> str:
        if mode == "video" and settings.VIDEO_PROVIDER == "kaggle_wan":
            # o prompt de LTX abaixo assume foto plana de produto e proibe movimento; no Wan isso
            # atrapalha. has_image=None (chamador antigo) conta como imagem->video.
            if settings.WAN_PROFILE == "minimax":
                system_prompt = REFINEMENT_SYSTEM_PROMPT_MINIMAX_R2V
            elif settings.WAN_PROFILE == "r2v":
                system_prompt = REFINEMENT_SYSTEM_PROMPT_WAN_R2V
            elif settings.WAN_PROFILE == "hunyuan":
                system_prompt = REFINEMENT_SYSTEM_PROMPT_HUNYUAN_I2V
            else:
                system_prompt = (REFINEMENT_SYSTEM_PROMPT_WAN_T2V if has_image is False
                                 else REFINEMENT_SYSTEM_PROMPT_WAN_I2V)
        else:
            system_prompt = (
                REFINEMENT_SYSTEM_PROMPT_VIDEO if mode == "video" else REFINEMENT_SYSTEM_PROMPT_IMAGE
            )
        payload = {
            "model": self.model,
            "messages": [
                {"role": "system", "content": system_prompt},
                {"role": "user", "content": user_prompt},
            ],
            "stream": False,
            # mantem o modelo carregado so durante a chamada ativa
            "keep_alive": settings.OLLAMA_KEEP_ALIVE_ACTIVE,
            # Ollama roda em CPU para nao disputar GPU com o XTTS.
            "options": settings.ollama_options(num_ctx=settings.OLLAMA_NUM_CTX),
        }
        try:
            async with httpx.AsyncClient(timeout=_LLM_TIMEOUT_S) as client:
                resp = await client.post(f"{self.host}/api/chat", json=payload)
                resp.raise_for_status()
                data = resp.json()
                refined = data.get("message", {}).get("content", "").strip()
                return refined or user_prompt
        except (httpx.ConnectError, httpx.TimeoutException) as e:
            raise ProviderUnavailableError(f"Ollama indisponivel: {e}") from e
        except httpx.HTTPStatusError as e:
            # Caso mais comum: o modelo configurado em OLLAMA_MODEL (.env) nao
            # esta instalado/puxado no Ollama (404). Sem esse catch, o erro
            # cru do httpx ("Client error '404 Not Found' for url ...") vazava
            # ate o card de video na UI, sem dizer o que de fato faltava.
            if e.response.status_code == 404:
                raise ProviderUnavailableError(
                    f"Modelo '{self.model}' nao encontrado no Ollama ({self.host}). "
                    f"Rode 'ollama list' e confira o valor de OLLAMA_MODEL no .env."
                ) from e
            raise ProviderUnavailableError(
                f"Ollama respondeu com erro {e.response.status_code}: {e}"
            ) from e

    async def translate_text(self, text: str, source_lang: str, target_lang: str, model: str | None = None) -> str:
        """Traduz `text` de source_lang para target_lang reaproveitando o Ollama.

        Usado pelo pipeline de translation_dubbing (app/providers/translation_dubbing_provider.py)
        para traduzir a transcricao do whisper antes de sintetizar com XTTS v2.
        model permite sobrescrever settings.OLLAMA_MODEL (ex: settings.TRANSLATION_OLLAMA_MODEL).

        v8.0: textos longos sao traduzidos em trechos de ~900 caracteres (fronteira de frase), em ordem.
        Antes iam inteiros com num_ctx=2048 e o Ollama TRUNCAVA o inicio do texto sem avisar.
        """
        if not text or not text.strip():
            raise ValueError("Texto vazio para traducao.")
        system_prompt = TRANSLATION_SYSTEM_PROMPT_TEMPLATE.format(
            source_lang=lang_label(source_lang), target_lang=lang_label(target_lang)
        )
        parts = split_for_translation(text)
        out: list[str] = []
        for part in parts:
            out.append(await self._translate_chunk(part, system_prompt, model))
        return " ".join(out).strip()

    async def _translate_chunk(self, chunk: str, system_prompt: str, model: str | None) -> str:
        payload = {
            "model": model or self.model,
            "messages": [
                {"role": "system", "content": system_prompt},
                {"role": "user", "content": chunk},
            ],
            "stream": False,
            "keep_alive": settings.OLLAMA_KEEP_ALIVE_ACTIVE,
            # temperatura baixa: traducao fiel, sem "criatividade"; num_predict limita respostas fora de controle
            "options": settings.ollama_options(num_ctx=settings.OLLAMA_NUM_CTX, temperature=0.2, num_predict=768),
        }
        try:
            async with httpx.AsyncClient(timeout=_LLM_TIMEOUT_S) as client:
                resp = await client.post(f"{self.host}/api/chat", json=payload)
                resp.raise_for_status()
                data = resp.json()
                translated = data.get("message", {}).get("content", "").strip()
                if not translated:
                    raise ProviderUnavailableError("Ollama devolveu tradução vazia.")
                return translated
        except (httpx.ConnectError, httpx.TimeoutException) as e:
            raise ProviderUnavailableError(f"Ollama indisponivel para traducao: {e}") from e
        except httpx.HTTPStatusError as e:
            if e.response.status_code == 404:
                raise ProviderUnavailableError(
                    f"Modelo '{model or self.model}' nao encontrado no Ollama ({self.host}) "
                    f"para traducao. Rode 'ollama list' e confira TRANSLATION_OLLAMA_MODEL/OLLAMA_MODEL."
                ) from e
            raise ProviderUnavailableError(
                f"Ollama respondeu com erro {e.response.status_code} na traducao: {e}"
            ) from e

    async def generate_json(self, system_prompt: str, user_prompt: str, model: str | None = None,
                            temperature: float = 0.6, num_ctx: int = 4096, timeout_s: float | None = None) -> str:
        """Chamada generica em modo JSON (format="json" do Ollama). Devolve o texto bruto -- quem chama valida.

        Usada pelo modulo Criar Propaganda (roteiro/prompts). num_ctx >= 4096 porque o prompt
        carrega a descricao do produto; o contexto padrao (2048) truncaria silenciosamente.
        """
        payload = {
            "model": model or self.model,
            "messages": [
                {"role": "system", "content": system_prompt},
                {"role": "user", "content": user_prompt},
            ],
            "stream": False,
            "format": "json",
            "keep_alive": settings.OLLAMA_KEEP_ALIVE_ACTIVE,
            "options": settings.ollama_options(num_ctx=num_ctx, temperature=temperature),
        }
        try:
            async with httpx.AsyncClient(timeout=timeout_s or (900 if settings.is_lite else 240)) as client:
                resp = await client.post(f"{self.host}/api/chat", json=payload)
                resp.raise_for_status()
                content = resp.json().get("message", {}).get("content", "").strip()
                if not content:
                    raise ProviderUnavailableError("Ollama devolveu resposta vazia.")
                return content
        except (httpx.ConnectError, httpx.TimeoutException) as e:
            raise ProviderUnavailableError(f"Ollama indisponivel: {e}") from e
        except httpx.HTTPStatusError as e:
            if e.response.status_code == 404:
                raise ProviderUnavailableError(
                    f"Modelo '{model or self.model}' nao encontrado no Ollama ({self.host}). "
                    f"Rode 'ollama list' e confira AD_OLLAMA_MODEL/OLLAMA_MODEL."
                ) from e
            raise ProviderUnavailableError(f"Ollama respondeu com erro {e.response.status_code}: {e}") from e

    async def clear_context(self) -> None:
        """
        Nao mantemos historico de conversa entre chamadas (cada refine_prompt e
        stateless), e alem disso forcamos o descarregamento do modelo da VRAM
        enviando keep_alive=0, liberando memoria para o Fooocus.
        """
        payload = {
            "model": self.model,
            "messages": [],
            "stream": False,
            "keep_alive": settings.OLLAMA_KEEP_ALIVE_IDLE,
        }
        try:
            async with httpx.AsyncClient(timeout=30) as client:
                await client.post(f"{self.host}/api/chat", json=payload)
        except (httpx.ConnectError, httpx.TimeoutException):
            # Nao e critico se o unload falhar; o Ollama descarrega sozinho
            # apos o timeout padrao de 5 minutos.
            pass

    async def health_check(self) -> bool:
        try:
            async with httpx.AsyncClient(timeout=5) as client:
                resp = await client.get(f"{self.host}/api/tags")
                return resp.status_code == 200
        except (httpx.ConnectError, httpx.TimeoutException):
            return False

    async def model_ready(self) -> tuple[bool, str | None]:
        """
        Health check ativo de verdade: confere se o Ollama esta de pe NA PORTA
        configurada (OLLAMA_HOST) e se o modelo especifico (OLLAMA_MODEL) esta
        instalado -- nao basta o servico responder, o modelo errado/ausente
        tambem deve ser reportado como falha.
        Retorna (ready: bool, detail: str | None) -- detail so vem preenchido
        quando ready=False, para aparecer no /api/health.
        """
        try:
            async with httpx.AsyncClient(timeout=5) as client:
                resp = await client.get(f"{self.host}/api/tags")
                if resp.status_code != 200:
                    return False, f"Ollama respondeu com status {resp.status_code}"
                names = {m.get("name") for m in resp.json().get("models", [])}
                if self.model not in names:
                    return False, f"Modelo '{self.model}' nao encontrado (instalados: {sorted(names)})"
                return True, None
        except httpx.ConnectError:
            return False, f"Conexao recusada em {self.host} -- o Ollama esta rodando?"
        except httpx.TimeoutException:
            return False, f"Timeout ao consultar {self.host}/api/tags"

    async def model_size_mb(self, model: str | None = None) -> int | None:
        """Tamanho (MB) do modelo em disco segundo /api/tags -- aproxima a RAM que ele ocupa carregado.
        None se o Ollama estiver offline ou o modelo nao existir."""
        wanted = model or self.model
        names = {wanted, wanted if ":" in wanted else f"{wanted}:latest"}
        try:
            async with httpx.AsyncClient(timeout=5) as client:
                resp = await client.get(f"{self.host}/api/tags")
                if resp.status_code != 200:
                    return None
                for m in resp.json().get("models", []):
                    if m.get("name") in names or m.get("model") in names:
                        return int(m.get("size", 0) // (1024 * 1024)) or None
        except (httpx.HTTPError, ValueError):
            return None
        return None
