"""Leitura de uploads com teto de tamanho (nao carrega arquivos gigantes inteiros na RAM)."""
from __future__ import annotations

from fastapi import HTTPException, UploadFile

_CHUNK = 1024 * 1024


async def read_upload_limited(upload: UploadFile, max_mb: int, what: str = "arquivo") -> bytes:
    """Le o upload em blocos de 1 MB e responde 413 assim que passar de `max_mb` (sem ler o resto)."""
    limit = max_mb * 1024 * 1024
    buf = bytearray()
    while True:
        chunk = await upload.read(_CHUNK)
        if not chunk:
            break
        buf.extend(chunk)
        if len(buf) > limit:
            raise HTTPException(status_code=413, detail=f"{what} maior que {max_mb} MB.")
    return bytes(buf)
