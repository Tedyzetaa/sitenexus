"""Rotas /api/v1/openhands (ponte bot -> Nexus -> OpenHands).

O agente executa comandos e edita arquivos no PC, entao estas rotas EXIGEM TOOLS_API_TOKEN
configurado e enviado (header X-Nexus-Token), como as ferramentas `sensitive`.
"""
from __future__ import annotations

import re
from typing import Optional

from fastapi import APIRouter, Depends, HTTPException
from pydantic import BaseModel, Field

from pathlib import Path

from app.config import settings
from app.providers.openhands_provider import (
    OpenHandsError, OpenHandsNotFoundError, OpenHandsOfflineError, OpenHandsProvider,
)
from app.tools.router import require_auth

def _session_key() -> str:
    """OPENHANDS_SESSION_API_KEY do .env; senao a chave que o Agent Canvas persiste em
    ~/.openhands/agent-canvas/api-key.txt (a mesma que a interface web usa)."""
    if settings.OPENHANDS_SESSION_API_KEY.strip():
        return settings.OPENHANDS_SESSION_API_KEY.strip()
    try:
        return (Path.home() / ".openhands" / "agent-canvas" / "api-key.txt").read_text(encoding="utf-8").strip()
    except OSError:
        return ""


provider = OpenHandsProvider(
    host=settings.OPENHANDS_HOST,
    workspace_root=settings.OPENHANDS_WORKSPACE,
    agent_profile_id=settings.OPENHANDS_AGENT_PROFILE_ID,
    session_api_key=_session_key(),
    timeout_s=settings.OPENHANDS_TIMEOUT_S,
    max_iterations=settings.OPENHANDS_MAX_ITERATIONS,
)

_ID = re.compile(r"^[0-9a-fA-F-]{32,36}$")


async def require_token(authed: bool = Depends(require_auth)) -> None:
    if not authed:
        raise HTTPException(403, "OpenHands exige TOOLS_API_TOKEN configurado e enviado.")


router = APIRouter(prefix="/api/v1/openhands", tags=["openhands"], dependencies=[Depends(require_token)])


class TaskBody(BaseModel):
    prompt: str = Field(..., min_length=3, max_length=8000)
    project: Optional[str] = Field(default="", max_length=40)


def _wrap(exc: OpenHandsError) -> HTTPException:
    if isinstance(exc, OpenHandsOfflineError):
        return HTTPException(503, str(exc))
    if isinstance(exc, OpenHandsNotFoundError):
        return HTTPException(404, str(exc))
    return HTTPException(502, str(exc))


def _check_id(cid: str) -> None:
    if not _ID.match(cid):
        raise HTTPException(422, "id invalido")


@router.get("/health")
async def oh_health():
    return {"ok": await provider.health_check(), "host": settings.OPENHANDS_HOST}


@router.post("/tasks")
async def oh_start(body: TaskBody):
    try:
        return {"id": await provider.start_task(body.prompt, body.project or "")}
    except OpenHandsError as exc:
        raise _wrap(exc) from exc


@router.get("/tasks/{cid}")
async def oh_status(cid: str):
    _check_id(cid)
    try:
        return await provider.get_task(cid)
    except OpenHandsError as exc:
        raise _wrap(exc) from exc


@router.post("/tasks/{cid}/stop")
async def oh_stop(cid: str):
    _check_id(cid)
    try:
        await provider.stop_task(cid)
        return {"ok": True}
    except OpenHandsError as exc:
        raise _wrap(exc) from exc
