"""
Script executado DENTRO do Kaggle (kernel_type=script, GPU + internet ligados).

NAO rode este arquivo localmente: ele e um template. O Nexus-Bridge (app/providers/kaggle_runtime.py)
troca o marcador de configuracao (CFG, abaixo) pelos valores reais e envia o resultado com `kaggle kernels push`.

O que ele faz:
  1. instala o ComfyUI e baixa Wan 2.2 5B (pula o que ja existe);
  2. sobe o ComfyUI em 127.0.0.1:8188;
  3. abre o tunel ngrok (URL aleatoria) e PUBLICA a URL no ntfy.sh (e assim que o Nexus a descobre);
  4. vigia: se ficar ocioso (ou tiver arquivo de parada, ou estourar o teto), desliga tudo e sai,
     liberando a GPU e poupando a cota semanal.
"""
import json
import os
import pathlib
import shutil
import subprocess
import sys
import threading
import time
import urllib.request

CFG = json.loads(r'''__NEXUS_CONFIG__''')

PORT = 8188
T0 = time.time()
STOP_FILE_NAME = "__nexus_stop__.png"   # o Nexus envia este arquivo via /upload/image para desligar


def log(*a):
    print("[nexus-kaggle]", *a, flush=True)


def sh(cmd, check=True, **kw):
    log("$", cmd if isinstance(cmd, str) else " ".join(cmd))
    return subprocess.run(cmd, shell=isinstance(cmd, str), check=check, **kw)


# --- 1. pastas (disco grande: /kaggle/temp ou /tmp; /kaggle/working so tem ~20GB) -------------
def pick_base():
    for cand in ("/kaggle/temp", "/tmp"):
        try:
            os.makedirs(cand, exist_ok=True)
            if os.access(cand, os.W_OK):
                return cand
        except OSError:
            pass
    return "/tmp"


BASE = pick_base()
COMFY = os.path.join(BASE, "ComfyUI")
INPUT_DIR = os.path.join(BASE, "comfy_input")
OUTPUT_DIR = os.path.join(BASE, "comfy_output")
for d in (INPUT_DIR, OUTPUT_DIR):
    os.makedirs(d, exist_ok=True)
log("base:", BASE)
sh("df -h " + BASE + " | tail -n 2; nvidia-smi --query-gpu=name,memory.total --format=csv,noheader", check=False)

# --- 2. ComfyUI ---------------------------------------------------------------------------------
if not os.path.exists(os.path.join(COMFY, "main.py")):
    sh(["git", "clone", "--depth", "1", "https://github.com/comfyanonymous/ComfyUI", COMFY])
# torch ja vem instalado no Kaggle; o pip so completa o que falta.
sh([sys.executable, "-m", "pip", "install", "-q", "-r", os.path.join(COMFY, "requirements.txt")])
sh([sys.executable, "-m", "pip", "install", "-q", "pyngrok>=7"])

PROFILE = (CFG.get("profile") or "draft").lower()
log("perfil:", PROFILE)
if PROFILE == "quality":
    # Wan 2.2 A14B vem em GGUF: precisa do no UnetLoaderGGUF (ComfyUI-GGUF)
    gguf_node = os.path.join(COMFY, "custom_nodes", "ComfyUI-GGUF")
    if not os.path.exists(gguf_node):
        sh(["git", "clone", "--depth", "1", "https://github.com/city96/ComfyUI-GGUF", gguf_node])
    sh([sys.executable, "-m", "pip", "install", "-q", "-r", os.path.join(gguf_node, "requirements.txt")], check=False)
    sh([sys.executable, "-m", "pip", "install", "-q", "-U", "gguf"], check=False)

# --- 3. modelos ---------------------------------------------------------------------------------
MODELS_DRAFT = [
    ("diffusion_models", "wan2.2_ti2v_5B_fp16.safetensors",
     "https://huggingface.co/Comfy-Org/Wan_2.2_ComfyUI_Repackaged/resolve/main/split_files/diffusion_models/wan2.2_ti2v_5B_fp16.safetensors"),
    ("vae", "wan2.2_vae.safetensors",
     "https://huggingface.co/Comfy-Org/Wan_2.2_ComfyUI_Repackaged/resolve/main/split_files/vae/wan2.2_vae.safetensors"),
    ("text_encoders", "umt5_xxl_fp8_e4m3fn_scaled.safetensors",
     "https://huggingface.co/Comfy-Org/Wan_2.1_ComfyUI_repackaged/resolve/main/split_files/text_encoders/umt5_xxl_fp8_e4m3fn_scaled.safetensors"),
]
_GGUF = "https://huggingface.co/QuantStack/Wan2.2-I2V-A14B-GGUF/resolve/main"
_REPACK = "https://huggingface.co/Comfy-Org/Wan_2.2_ComfyUI_Repackaged/resolve/main/split_files"
MODELS_QUALITY = [
    # especialistas de ruido alto/baixo do A14B I2V em GGUF Q4_K_M (~9,65 GB cada)
    ("unet", "Wan2.2-I2V-A14B-HighNoise-Q4_K_M.gguf", f"{_GGUF}/HighNoise/Wan2.2-I2V-A14B-HighNoise-Q4_K_M.gguf"),
    ("unet", "Wan2.2-I2V-A14B-LowNoise-Q4_K_M.gguf", f"{_GGUF}/LowNoise/Wan2.2-I2V-A14B-LowNoise-Q4_K_M.gguf"),
    # LoRAs Lightning de 4 passos (um por especialista)
    ("loras", "wan2.2_i2v_lightx2v_4steps_lora_v1_high_noise.safetensors",
     f"{_REPACK}/loras/wan2.2_i2v_lightx2v_4steps_lora_v1_high_noise.safetensors"),
    ("loras", "wan2.2_i2v_lightx2v_4steps_lora_v1_low_noise.safetensors",
     f"{_REPACK}/loras/wan2.2_i2v_lightx2v_4steps_lora_v1_low_noise.safetensors"),
    # o A14B usa o VAE do Wan 2.1 (o wan2.2_vae e so do 5B)
    ("vae", "wan_2.1_vae.safetensors", f"{_REPACK}/vae/wan_2.1_vae.safetensors"),
    ("text_encoders", "umt5_xxl_fp8_e4m3fn_scaled.safetensors",
     "https://huggingface.co/Comfy-Org/Wan_2.1_ComfyUI_repackaged/resolve/main/split_files/text_encoders/umt5_xxl_fp8_e4m3fn_scaled.safetensors"),
]
# HunyuanVideo 1.5 I2V (480p) -- nos nativos do ComfyUI, sem custom nodes. O checkpoint vem do .env (HUNYUAN_UNET).
HY_UNET = CFG.get("hunyuan_unet") or "hunyuanvideo1.5_480p_i2v_step_distilled_fp8_scaled.safetensors"
_HY = "https://huggingface.co/Comfy-Org/HunyuanVideo_1.5_repackaged/resolve/main/split_files"
MODELS_HUNYUAN = [
    ("diffusion_models", HY_UNET, f"{_HY}/diffusion_models/{HY_UNET}"),
    ("text_encoders", "qwen_2.5_vl_7b_fp8_scaled.safetensors", f"{_HY}/text_encoders/qwen_2.5_vl_7b_fp8_scaled.safetensors"),
    ("text_encoders", "byt5_small_glyphxl_fp16.safetensors", f"{_HY}/text_encoders/byt5_small_glyphxl_fp16.safetensors"),
    ("vae", "hunyuanvideo15_vae_fp16.safetensors", f"{_HY}/vae/hunyuanvideo15_vae_fp16.safetensors"),
    ("clip_vision", "sigclip_vision_patch14_384.safetensors",
     "https://huggingface.co/Comfy-Org/sigclip_vision_384/resolve/main/sigclip_vision_patch14_384.safetensors"),
]
# Wan 2.1 VACE (reference-to-video) -- nos nativos do ComfyUI (WanVaceToVideo), sem custom nodes.
R2V_UNET = CFG.get("r2v_unet") or "wan2.1_vace_1.3B_fp16.safetensors"
_W21 = "https://huggingface.co/Comfy-Org/Wan_2.1_ComfyUI_repackaged/resolve/main/split_files"
MODELS_R2V = [
    ("diffusion_models", R2V_UNET, f"{_W21}/diffusion_models/{R2V_UNET}"),
    ("vae", "wan_2.1_vae.safetensors", f"{_W21}/vae/wan_2.1_vae.safetensors"),
    ("text_encoders", "umt5_xxl_fp8_e4m3fn_scaled.safetensors", f"{_W21}/text_encoders/umt5_xxl_fp8_e4m3fn_scaled.safetensors"),
]
# MiniMax H3 Ref2VA (EXPERIMENTAL no Kaggle): repo gated da Comfy-Org (precisa de HF_TOKEN de conta que aceitou a licenca).
MM_UNET = CFG.get("minimax_unet") or "minimax_h3_ref2va_pruned_fp8_scaled.safetensors"
MM_TE = CFG.get("minimax_text_encoder") or "qwen3vl_32b_minimax_h3_nvfp4_awq.safetensors"
MM_TURBO = bool(CFG.get("minimax_turbo"))
MM_TURBO_LORA = CFG.get("minimax_turbo_lora") or "minimax_h3_ref2v_turbo_4step_v0.1_comfyui_bf16.safetensors"
_MM = "https://huggingface.co/Comfy-Org/MiniMax-H3/resolve/main"
MODELS_MINIMAX = [
    ("diffusion_models", MM_UNET, f"{_MM}/diffusion_models/{MM_UNET}"),
    ("text_encoders", MM_TE, f"{_MM}/text_encoders/{MM_TE}"),
    ("vae", "minimax_h3_video_vae_fp16.safetensors", f"{_MM}/vae/minimax_h3_video_vae_fp16.safetensors"),
    ("vae", "minimax_h3_audio_vae_fp32.safetensors", f"{_MM}/vae/minimax_h3_audio_vae_fp32.safetensors"),
]
# o LoRA turbo e OPCIONAL: o caminho no repo e um palpite; se falhar o job cai para 20 passos (sem turbo)
MODELS_MINIMAX_OPTIONAL = [
    ("loras", MM_TURBO_LORA, f"{_MM}/loras/{MM_TURBO_LORA}"),
] if MM_TURBO else []
MODELS = {"quality": MODELS_QUALITY, "hunyuan": MODELS_HUNYUAN, "r2v": MODELS_R2V,
          "minimax": MODELS_MINIMAX}.get(PROFILE, MODELS_DRAFT)
NEED_GB = {"quality": 32, "hunyuan": 24, "r2v": 14, "minimax": 45}.get(PROFILE, 20)
free_gb = shutil.disk_usage(BASE).free / 1e9
log(f"disco livre em {BASE}: {free_gb:.0f} GB (o perfil {PROFILE} precisa de ~{NEED_GB} GB)")
if free_gb < NEED_GB:
    log("AVISO: pouco espaco em disco; os downloads podem falhar.")

if not shutil.which("aria2c"):
    sh("apt-get -qq update >/dev/null 2>&1; apt-get -qq install -y aria2 >/dev/null 2>&1", check=False)
HAS_ARIA = bool(shutil.which("aria2c"))
HF_TOKEN = CFG.get("hf_token") or ""


def download(folder, name, url):
    dest_dir = os.path.join(COMFY, "models", folder)
    os.makedirs(dest_dir, exist_ok=True)
    dest = os.path.join(dest_dir, name)
    if os.path.exists(dest) and os.path.getsize(dest) > 1_000_000 and not os.path.exists(dest + ".aria2"):
        log("ja existe:", name)
        return
    for attempt in (1, 2, 3):
        log(f"baixando {name} (tentativa {attempt})")
        if HAS_ARIA:
            cmd = ["aria2c", "-x", "16", "-s", "16", "-k", "1M", "-c", "--console-log-level=error",
                   "--summary-interval=0", "-d", dest_dir, "-o", name]
            if HF_TOKEN:
                cmd += ["--header", f"Authorization: Bearer {HF_TOKEN}"]
            cmd.append(url)
        else:
            cmd = ["wget", "-q", "-c", "-O", dest, url]
            if HF_TOKEN:
                cmd[1:1] = ["--header", f"Authorization: Bearer {HF_TOKEN}"]
        subprocess.run(cmd)
        if os.path.exists(dest) and os.path.getsize(dest) > 1_000_000:
            log("ok:", name, f"{os.path.getsize(dest) / 1e9:.2f} GB")
            return
        time.sleep(5)
    if PROFILE == "minimax" and not HF_TOKEN:
        log("DICA: o repo Comfy-Org/MiniMax-H3 e gated. Defina HF_TOKEN no .env (conta que aceitou a licenca no site).")
    raise RuntimeError(f"falha ao baixar {name}")


errors = []


def _dl(args):
    try:
        download(*args)
    except Exception as e:  # noqa: BLE001
        errors.append(str(e))


threads = [threading.Thread(target=_dl, args=(m,)) for m in MODELS]
[t.start() for t in threads]
[t.join() for t in threads]
if errors:
    log("ERRO nos downloads:", errors)
    sys.exit(2)
# opcionais (nao derrubam o notebook): o job detecta pelo log se o LoRA turbo existe
TURBO_OK = False
for _m in MODELS_MINIMAX_OPTIONAL:
    try:
        download(*_m)
        TURBO_OK = True
    except Exception as e:  # noqa: BLE001
        log("AVISO: LoRA turbo indisponivel (o MiniMax vai rodar sem turbo, 20 passos):", e)
if PROFILE == "minimax":
    log("turbo_lora:", "ok" if TURBO_OK else "AUSENTE")
log("modelos prontos em", round(time.time() - T0), "s")

# --- 4. sobe o ComfyUI -------------------------------------------------------------------------
env = dict(os.environ, CUDA_VISIBLE_DEVICES="0", PYTHONUNBUFFERED="1")
comfy = subprocess.Popen(
    [sys.executable, "-u", "main.py", "--listen", "127.0.0.1", "--port", str(PORT),
     "--enable-cors-header", "*", "--input-directory", INPUT_DIR, "--output-directory", OUTPUT_DIR,
     "--disable-auto-launch"] + (["--lowvram"] if PROFILE == "minimax" else []),
    cwd=COMFY, env=env,
)


def http_ok(path):
    try:
        with urllib.request.urlopen(f"http://127.0.0.1:{PORT}{path}", timeout=5) as r:
            return r.status == 200, r.read()
    except Exception:  # noqa: BLE001
        return False, b""


tunnel_proc = None   # processo do binario do ngrok (so no plano B da secao 5)


def shutdown(code=0, why=""):
    log("desligando:", why)
    try:
        from pyngrok import ngrok
        ngrok.kill()
    except Exception:  # noqa: BLE001
        pass
    try:
        if tunnel_proc is not None:
            tunnel_proc.kill()
    except Exception:  # noqa: BLE001
        pass
    try:
        comfy.terminate()
        comfy.wait(timeout=20)
    except Exception:  # noqa: BLE001
        try:
            comfy.kill()
        except Exception:  # noqa: BLE001
            pass
    sys.exit(code)


for _ in range(300):
    if comfy.poll() is not None:
        shutdown(3, "o ComfyUI morreu ao iniciar")
    if http_ok("/system_stats")[0]:
        break
    time.sleep(1)
else:
    shutdown(3, "o ComfyUI nao respondeu em 5 min")
log("ComfyUI pronto")
if PROFILE == "minimax":
    ok_mm, _ = http_ok("/object_info/MiniMaxH3ReferenceToVideo")
    log("no MiniMaxH3ReferenceToVideo:", "ok" if ok_mm else "NAO CARREGOU (precisa de ComfyUI >= 0.30; veja o log acima)")
if PROFILE == "r2v":
    ok_r2v, _ = http_ok("/object_info/WanVaceToVideo")
    log("no WanVaceToVideo:", "ok" if ok_r2v else "NAO CARREGOU (o ComfyUI clonado e antigo? veja o log acima)")
if PROFILE == "hunyuan":
    ok_hy, _ = http_ok("/object_info/HunyuanVideo15ImageToVideo")
    log("no HunyuanVideo15ImageToVideo:", "ok" if ok_hy else "NAO CARREGOU (o ComfyUI clonado e antigo? veja o log acima)")
if PROFILE == "quality":
    ok_gguf, _ = http_ok("/object_info/UnetLoaderGGUF")
    log("no UnetLoaderGGUF:", "ok" if ok_gguf else "NAO CARREGOU (veja os erros do ComfyUI acima)")

# --- 5. tunel ngrok (URL aleatoria) + publicacao da URL no ntfy.sh ---------------------------------
from pyngrok import conf, ngrok  # noqa: E402

conf.get_default().auth_token = CFG["ngrok_token"]


def open_tunnel_pyngrok():
    """Plano A: igual ao script original do Colab (ngrok.connect sem dominio)."""
    ngrok.kill()
    time.sleep(2)
    return ngrok.connect(PORT, "http").public_url


def open_tunnel_binary():
    """Plano B: roda o binario do ngrok direto e le a URL na API local (porta 4040)."""
    global tunnel_proc
    ngrok.kill()
    try:
        if tunnel_proc is not None:
            tunnel_proc.kill()
    except Exception:  # noqa: BLE001
        pass
    try:
        ngrok.install_ngrok()
    except Exception as e:  # noqa: BLE001
        log("install_ngrok:", e)
    exe = conf.get_default().ngrok_path
    tunnel_proc = subprocess.Popen(
        [exe, "http", str(PORT), "--log=stdout"],
        env=dict(os.environ, NGROK_AUTHTOKEN=CFG["ngrok_token"]),
        stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL,
    )
    for _ in range(30):
        if tunnel_proc.poll() is not None:
            raise RuntimeError("o binario do ngrok encerrou")
        try:
            with urllib.request.urlopen("http://127.0.0.1:4040/api/tunnels", timeout=3) as r:
                for t in json.loads(r.read()).get("tunnels", []):
                    if str(t.get("public_url", "")).startswith("https://"):
                        return t["public_url"]
        except Exception:  # noqa: BLE001
            pass
        time.sleep(2)
    raise RuntimeError("o ngrok nao expos nenhum tunel em 60 s")


url = None
last_err = None
for attempt in range(8):
    for opener in (open_tunnel_pyngrok, open_tunnel_binary):
        try:
            url = opener()
            break
        except Exception as e:  # noqa: BLE001
            last_err = e
            log(f"ngrok ({opener.__name__}) falhou ({attempt + 1}/8): {e}")
    if url:
        break
    time.sleep(15)
if not url:
    shutdown(4, f"ngrok nao conectou: {last_err}")
log("NEXUS_READY", url)

# O Nexus le a URL neste topico do ntfy.sh. Formato: "NEXUS_URL <sessao> <url>" (a sessao e gerada pelo
# Nexus a cada push; mensagens com outra sessao sao ignoradas la).
NTFY_SERVER = (CFG.get("ntfy_server") or "https://ntfy.sh").rstrip("/")
NTFY_TOPIC = CFG["ntfy_topic"]
NTFY_MSG = f"NEXUS_URL {CFG['session']} {url}"


def publish_url():
    for i in range(5):
        try:
            req = urllib.request.Request(f"{NTFY_SERVER}/{NTFY_TOPIC}", data=NTFY_MSG.encode("utf-8"),
                                         method="POST", headers={"Title": "nexus-url"})
            with urllib.request.urlopen(req, timeout=15) as r:
                if r.status == 200:
                    log("URL publicada no ntfy")
                    return True
        except Exception as e:  # noqa: BLE001
            log(f"falha ao publicar a URL ({i + 1}/5): {e}")
        time.sleep(5)
    return False


if not publish_url():
    log("AVISO: nao consegui publicar a URL; vou tentar de novo a cada 5 min")
last_publish = time.time()

# --- 6. vigia: ocioso / arquivo de parada / teto de sessao -------------------------------------
IDLE_S = int(CFG["idle_timeout_min"]) * 60
MAX_S = int(CFG["max_session_min"]) * 60
last_activity = time.time()
last_hist = -1
stop_path = os.path.join(INPUT_DIR, STOP_FILE_NAME)

while True:
    time.sleep(15)
    if comfy.poll() is not None:
        shutdown(5, "o ComfyUI encerrou")
    if os.path.exists(stop_path):
        shutdown(0, "pedido de parada do Nexus")
    if time.time() - T0 > MAX_S:
        shutdown(0, f"teto de sessao ({CFG['max_session_min']} min)")
    if time.time() - last_publish > 300:      # republica: cobre o Nexus ter reiniciado ou perdido a mensagem
        publish_url()
        last_publish = time.time()

    ok, body = http_ok("/queue")
    if ok:
        try:
            q = json.loads(body)
            if q.get("queue_running") or q.get("queue_pending"):
                last_activity = time.time()
        except Exception:  # noqa: BLE001
            pass
    ok, body = http_ok("/history?max_items=50")
    if ok:
        try:
            n = len(json.loads(body))
            if n != last_hist:
                if last_hist != -1:
                    last_activity = time.time()
                last_hist = n
        except Exception:  # noqa: BLE001
            pass

    idle = time.time() - last_activity
    if idle > IDLE_S:
        shutdown(0, f"ocioso ha {int(idle // 60)} min")
