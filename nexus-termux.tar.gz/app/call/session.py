"""Sessoes e turnos do modo ligacao.

Cada turno: fala (audio) -> Whisper -> Ollama (stream) -> frases -> TTS -> eventos.
O cliente (web/mobile) acompanha por polling em GET /events?after=N e toca os
audios na ordem. Interromper = cancelar o turno atual (a frase que o TTS ja
estiver sintetizando termina em segundo plano, mas e descartada).
"""
import asyncio
import logging
import os
import re
import shutil
import tempfile
import time
import uuid
from dataclasses import dataclass, field
from pathlib import Path

from app.call.llm import Llm, LlmError
from app.call.stt import Stt, SttError
from app.call.text import SentenceSplitter, clean_for_speech
from app.call.tts import Tts, TtsError, VoiceCtx
from app.config import settings

logger = logging.getLogger("nexus.call.session")

LANG_NAMES = {
    "pt": "portugues do Brasil",
    "en": "ingles",
    "es": "espanhol",
    "fr": "frances",
    "de": "alemao",
    "ja": "japones",
}
_MAX_EVENTS = 500
_MAX_HISTORY_CHARS = 600


def short_lang(lang: str | None) -> str:
    return (lang or "pt").strip().lower().replace("_", "-").split("-")[0] or "pt"


@dataclass
class CallSession:
    id: str
    language: str
    system_prompt: str
    voice: VoiceCtx
    work_dir: Path
    history: list[dict] = field(default_factory=list)
    events: list[dict] = field(default_factory=list)
    seq: int = 0
    turn_no: int = 0
    ready: bool = False
    warm_error: str | None = None
    turn_task: asyncio.Task | None = None
    warm_task: asyncio.Task | None = None
    last_active: float = field(default_factory=time.monotonic)

    def emit(self, type_: str, **data) -> dict:
        self.seq += 1
        event = {"seq": self.seq, "type": type_, **data}
        self.events.append(event)
        if len(self.events) > _MAX_EVENTS:
            del self.events[: len(self.events) - _MAX_EVENTS]
        return event

    def touch(self) -> None:
        self.last_active = time.monotonic()

    @property
    def turn_active(self) -> bool:
        return self.turn_task is not None and not self.turn_task.done()


class CallManager:
    def __init__(self, stt: Stt, llm: Llm, tts: Tts, audio_dir: Path):
        self.stt = stt
        self.llm = llm
        self.tts = tts
        self.audio_dir = Path(audio_dir)
        self.audio_dir.mkdir(parents=True, exist_ok=True)
        self.work_root = Path(tempfile.gettempdir()) / "nexus_bridge_call"
        self.sessions: dict[str, CallSession] = {}
        self._janitor: asyncio.Task | None = None
        self._empty_since: float | None = None

    # ------------------------------------------------------------ ciclo de vida

    def get(self, sid: str) -> CallSession:
        s = self.sessions.get(sid)
        if s is None:
            raise KeyError(sid)
        return s

    async def create(
        self,
        *,
        language: str = "pt-BR",
        system_prompt: str | None = None,
        history: list[dict] | None = None,
        reference_bytes: bytes | None = None,
        reference_suffix: str | None = None,
        speaker: str | None = None,
    ) -> CallSession:
        self.sweep_sessions()
        self._ensure_janitor()
        sid = uuid.uuid4().hex
        lang = short_lang(language)
        prompt = (system_prompt or settings.CALL_SYSTEM_PROMPT).replace("{language}", LANG_NAMES.get(lang, lang))

        work_dir = self.work_root / sid
        work_dir.mkdir(parents=True, exist_ok=True)
        voice = VoiceCtx(speaker=speaker or None)
        if reference_bytes:
            ref = work_dir / f"reference.{(reference_suffix or 'wav').lstrip('.').lower()}"
            ref.write_bytes(reference_bytes)
            voice = VoiceCtx(reference_path=ref)

        clean_history: list[dict] = []
        for m in history or []:
            role, content = m.get("role"), m.get("content")
            if role in ("user", "assistant") and isinstance(content, str) and content.strip():
                clean_history.append({"role": role, "content": content.strip()[:_MAX_HISTORY_CHARS]})

        s = CallSession(id=sid, language=lang, system_prompt=prompt, voice=voice, work_dir=work_dir,
                        history=clean_history[-settings.CALL_HISTORY_TURNS * 2:])
        self.sessions[sid] = s
        self._empty_since = None
        s.warm_task = asyncio.create_task(self._warmup(s))
        return s

    async def _warmup(self, s: CallSession) -> None:
        """Carrega LLM, Whisper e TTS em sequencia (em paralelo o HDD so atrapalharia)."""
        s.emit("stage", stage="warming")
        try:
            await self.llm.warmup()
            await self.stt.warmup()
            await self.tts.warmup(s.language)
            s.ready = True
            s.emit("ready")
        except asyncio.CancelledError:
            raise
        except (LlmError, SttError, TtsError) as exc:
            s.warm_error = str(exc)
            s.emit("error", message=str(exc), fatal=True)
        except Exception as exc:  # noqa: BLE001
            logger.exception("Falha ao preparar a ligacao")
            s.warm_error = repr(exc)
            s.emit("error", message=repr(exc), fatal=True)

    def events_after(self, sid: str, after: int = 0) -> dict:
        s = self.get(sid)
        s.touch()
        return {
            "events": [e for e in s.events if e["seq"] > after],
            "next": s.seq,
            "ready": s.ready,
            "turn_active": s.turn_active,
            "error": s.warm_error,
        }

    async def close(self, sid: str) -> None:
        s = self.sessions.pop(sid, None)
        if s is None:
            return
        for task in (s.turn_task, s.warm_task):
            if task is not None and not task.done():
                task.cancel()
        shutil.rmtree(s.work_dir, ignore_errors=True)
        self._delete_audio(prefix=f"call_{s.id[:8]}_")
        if not self.sessions:
            self._empty_since = time.monotonic()

    # ------------------------------------------------------------------ turnos

    def interrupt(self, sid: str) -> bool:
        s = self.get(sid)
        s.touch()
        return self._cancel_turn(s)

    def _cancel_turn(self, s: CallSession) -> bool:
        if s.turn_active:
            assert s.turn_task is not None
            s.turn_task.cancel()
            s.emit("interrupted", turn=s.turn_no)
            return True
        return False

    async def start_turn(self, sid: str, audio: bytes, suffix: str) -> int:
        s = self.get(sid)
        self._cancel_turn(s)  # falar por cima = interromper o turno anterior
        s.touch()
        s.turn_no += 1
        n = s.turn_no
        s.turn_task = asyncio.create_task(self._run_turn(s, n, audio, suffix))
        return n

    async def _run_turn(self, s: CallSession, n: int, audio: bytes, suffix: str) -> None:
        tmp = s.work_dir / f"turn_{n}.{suffix.lstrip('.').lower() or 'webm'}"
        try:
            s.emit("stage", stage="transcribing", turn=n)
            tmp.write_bytes(audio)
            transcript = (await self.stt.transcribe(str(tmp), s.language)).strip()
            if len(re.sub(r"\W", "", transcript)) < 2:
                s.emit("transcript", turn=n, text="")
                s.emit("done", turn=n, empty=True)
                return
            s.emit("transcript", turn=n, text=transcript)

            s.emit("stage", stage="thinking", turn=n)
            reply = await self._reply(s, n, transcript)
            s.emit("done", turn=n, reply=reply)
        except asyncio.CancelledError:
            raise
        except (SttError, LlmError, TtsError) as exc:
            s.emit("error", turn=n, message=str(exc))
            s.emit("done", turn=n, failed=True)
        except Exception as exc:  # noqa: BLE001
            logger.exception("Erro inesperado no turno %s da ligacao %s", n, s.id)
            s.emit("error", turn=n, message=repr(exc))
            s.emit("done", turn=n, failed=True)
        finally:
            tmp.unlink(missing_ok=True)
            s.touch()

    async def _reply(self, s: CallSession, n: int, user_text: str) -> str:
        s.history.append({"role": "user", "content": user_text})
        messages = [{"role": "system", "content": s.system_prompt}] + s.history[-settings.CALL_HISTORY_TURNS * 2:]

        queue: asyncio.Queue = asyncio.Queue()
        full: list[str] = []
        counter = 0

        def push(sentence: str) -> None:
            nonlocal counter
            s.emit("sentence", turn=n, index=counter, text=sentence)
            queue.put_nowait((counter, sentence))
            counter += 1

        async def produce() -> None:
            splitter = SentenceSplitter()
            try:
                async for delta in self.llm.stream(messages):
                    full.append(delta)
                    for sentence in splitter.feed(delta):
                        push(sentence)
                for sentence in splitter.flush():
                    push(sentence)
            finally:
                queue.put_nowait(None)

        producer = asyncio.create_task(produce())
        text = ""
        try:
            while True:
                item = await queue.get()
                if item is None:
                    break
                idx, sentence = item
                try:
                    path = await self.tts.synthesize(sentence, s.language, s.voice, self.audio_dir)
                    name = f"call_{s.id[:8]}_{n}_{idx}.wav"
                    os.replace(path, self.audio_dir / name)
                    s.emit("audio", turn=n, index=idx, url=f"/audio/{name}")
                except TtsError as exc:
                    s.emit("audio_error", turn=n, index=idx, message=str(exc))
            await producer  # propaga LlmError, se houve
            return clean_for_speech("".join(full))
        except BaseException:
            producer.cancel()
            raise
        finally:
            text = clean_for_speech("".join(full))
            if text:
                s.history.append({"role": "assistant", "content": text})
            elif s.history and s.history[-1]["role"] == "user" and s.history[-1]["content"] == user_text:
                s.history.pop()  # falhou sem resposta: nao deixa pergunta "pendurada"
            del s.history[: max(0, len(s.history) - settings.CALL_HISTORY_TURNS * 2)]

    # ------------------------------------------------------------- manutencao

    def sweep_sessions(self) -> None:
        now = time.monotonic()
        for sid in [k for k, v in self.sessions.items()
                    if not v.turn_active and now - v.last_active > settings.CALL_SESSION_TTL_S]:
            s = self.sessions.pop(sid)
            if s.warm_task and not s.warm_task.done():
                s.warm_task.cancel()
            shutil.rmtree(s.work_dir, ignore_errors=True)
            self._delete_audio(prefix=f"call_{s.id[:8]}_")
            logger.info("Ligacao %s expirou por inatividade.", sid)
        if not self.sessions and self._empty_since is None:
            self._empty_since = now

    def _delete_audio(self, prefix: str = "call_", older_than_s: float | None = None) -> None:
        now = time.time()
        for f in self.audio_dir.glob(f"{prefix}*.wav"):
            try:
                if older_than_s is None or now - f.stat().st_mtime > older_than_s:
                    f.unlink()
            except OSError:
                pass

    def janitor_tick(self) -> None:
        """Roda a cada ~30s: expira sessoes, apaga audios velhos e libera RAM se ninguem esta ligando."""
        self.sweep_sessions()
        self._delete_audio(older_than_s=settings.CALL_AUDIO_TTL_S)
        if not self.sessions and self._empty_since is not None:
            if time.monotonic() - self._empty_since >= settings.CALL_IDLE_UNLOAD_S:
                logger.info("Sem ligacoes ativas: liberando Whisper e TTS da RAM.")
                self.stt.close()
                # unload() devolve False quando o TTS ainda esta ocupado: nesse caso mantem _empty_since
                # para tentar de novo no proximo ciclo (None/True = liberado).
                if self.tts.unload() is not False:
                    self._empty_since = None

    def _ensure_janitor(self) -> None:
        if self._janitor is None or self._janitor.done():
            self._janitor = asyncio.create_task(self._janitor_loop())

    async def _janitor_loop(self) -> None:
        try:
            while True:
                await asyncio.sleep(30)
                try:
                    self.janitor_tick()
                except Exception:  # noqa: BLE001
                    logger.exception("Falha na manutencao das ligacoes")
        except asyncio.CancelledError:
            pass

    def shutdown(self) -> None:
        for s in list(self.sessions.values()):
            for task in (s.turn_task, s.warm_task):
                if task is not None and not task.done():
                    task.cancel()
        if self._janitor is not None:
            self._janitor.cancel()
        self.stt.close()
