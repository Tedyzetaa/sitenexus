"""Endpoints do modo ligacao (prefixo /api/v1/call).

Fluxo do cliente:
  POST   /start                 -> session_id (o servidor comeca a carregar os modelos)
  GET    /{sid}/events?after=N  -> poll: stage/ready/transcript/sentence/audio/done/error
  POST   /{sid}/turn            -> envia a fala gravada (multipart "audio"); falar por cima interrompe o turno anterior
  POST   /{sid}/interrupt       -> para a resposta atual
  DELETE /{sid}                 -> desliga
  GET    /health                -> diagnostico (Ollama, modelo, pacotes)
"""
import importlib.util
import json
import logging
from pathlib import Path
from typing import Optional

from fastapi import APIRouter, File, Form, HTTPException, UploadFile

from app.call.session import CallManager
from app.config import settings
from app.gpu_lock import gpu_vram_lock
from app.uploads import read_upload_limited

logger = logging.getLogger("nexus.call.router")
router = APIRouter(prefix="/api/v1/call", tags=["call"])

_ALLOWED_SUFFIXES = {"wav", "mp3", "m4a", "mp4", "webm", "ogg", "opus", "aac", "3gp"}
_CONTENT_TYPE_SUFFIX = {
    "audio/webm": "webm", "video/webm": "webm", "audio/ogg": "ogg", "audio/mp4": "m4a", "audio/x-m4a": "m4a",
    "audio/mpeg": "mp3", "audio/wav": "wav", "audio/x-wav": "wav", "audio/aac": "aac", "audio/3gpp": "3gp",
}

_manager: CallManager | None = None


def get_manager() -> CallManager:
    global _manager
    if _manager is None:
        from app.call.llm import OllamaCallLlm
        from app.call.stt import PersistentWhisper
        from app.call.tts import make_tts_engine

        _manager = CallManager(PersistentWhisper(), OllamaCallLlm(), make_tts_engine(), settings.OUTPUT_DIR_AUDIO)
    return _manager


def set_manager(manager: CallManager | None) -> None:
    """Para testes (injeta motores falsos)."""
    global _manager
    _manager = manager


def shutdown_manager() -> None:
    if _manager is not None:
        _manager.shutdown()


def _suffix_of(upload: UploadFile) -> str:
    suffix = Path((upload.filename or "").lower()).suffix.lstrip(".")
    if suffix not in _ALLOWED_SUFFIXES:
        suffix = _CONTENT_TYPE_SUFFIX.get((upload.content_type or "").split(";")[0].strip().lower(), "")
    if suffix not in _ALLOWED_SUFFIXES:
        raise HTTPException(status_code=400, detail="Formato de audio invalido. Envie webm, m4a, mp4, wav, mp3, ogg ou aac.")
    return suffix


def _session_or_404(sid: str):
    try:
        return get_manager().get(sid)
    except KeyError:
        raise HTTPException(status_code=404, detail="Ligacao nao encontrada ou expirada. Ligue de novo.") from None


@router.post("/start")
async def start_call(
    language: str = Form("pt-BR"),
    system_prompt: Optional[str] = Form(None),
    history: Optional[str] = Form(None),
    speaker: Optional[str] = Form(None),
    voice_ref: Optional[UploadFile] = File(None),
):
    try:
        parsed_history = json.loads(history) if history else []
        if not isinstance(parsed_history, list):
            raise ValueError
    except ValueError:
        raise HTTPException(status_code=400, detail="'history' deve ser uma lista JSON de {role, content}.") from None

    ref_bytes, ref_suffix = None, None
    if voice_ref is not None and (voice_ref.filename or "").strip():
        ref_suffix = _suffix_of(voice_ref)
        ref_bytes = await read_upload_limited(voice_ref, settings.CALL_MAX_AUDIO_MB, "Voz de referencia") or None

    # v8.0 (perfil lite): a ligacao mantem LLM + Whisper + TTS na RAM. Com um job pesado rodando na fila
    # (dublagem/video/anuncio) os dois juntos estouram 8 GB -- recusa em vez de travar a maquina.
    if settings.is_lite and gpu_vram_lock.locked():
        raise HTTPException(
            status_code=409,
            detail="O Nexus esta processando um job pesado da fila. Espere terminar para ligar "
                   "(neste notebook a ligacao e o job juntos nao cabem na RAM).",
        )

    manager = get_manager()
    session = await manager.create(
        language=language,
        system_prompt=system_prompt,
        history=parsed_history,
        reference_bytes=ref_bytes,
        reference_suffix=ref_suffix,
        speaker=speaker,
    )
    return {
        "session_id": session.id,
        "language": session.language,
        "engine": manager.tts.name,
        "model": manager.llm.model,
        "ready": session.ready,
    }


@router.get("/health")
async def call_health():
    manager = get_manager()
    llm_ok, llm_msg = await manager.llm.health()
    tts_pkg = importlib.util.find_spec("TTS") is not None if manager.tts.name == "xtts" else True
    stt_pkg = importlib.util.find_spec("faster_whisper") is not None
    problems = [m for m in (
        llm_msg,
        None if stt_pkg else "Pacote 'faster-whisper' nao instalado.",
        None if tts_pkg else "Pacote 'coqui-tts' nao instalado (XTTS).",
    ) if m]
    return {
        "ok": not problems,
        "ollama": llm_ok,
        "llm_model": manager.llm.model,
        "stt_model": getattr(manager.stt, "model_size", None),
        "tts_engine": manager.tts.name,
        "active_calls": len(manager.sessions),
        "problems": problems,
    }


@router.get("/{sid}/events")
async def call_events(sid: str, after: int = 0):
    _session_or_404(sid)
    return get_manager().events_after(sid, after)


@router.post("/{sid}/turn", status_code=202)
async def call_turn(sid: str, audio: UploadFile = File(...)):
    _session_or_404(sid)
    suffix = _suffix_of(audio)
    # v8.0: leitura em blocos com teto (antes: audio.read() carregava tudo e so DEPOIS checava o tamanho)
    body = await read_upload_limited(audio, settings.CALL_MAX_AUDIO_MB, "Fala")
    if not body:
        raise HTTPException(status_code=400, detail="Audio vazio.")
    turn = await get_manager().start_turn(sid, body, suffix)
    return {"turn": turn}


@router.post("/{sid}/interrupt")
async def call_interrupt(sid: str):
    _session_or_404(sid)
    return {"interrupted": get_manager().interrupt(sid)}


@router.delete("/{sid}")
async def call_hangup(sid: str):
    await get_manager().close(sid)
    return {"ok": True}
