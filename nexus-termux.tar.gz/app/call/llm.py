"""LLM do modo ligacao: chat em STREAM no Ollama, com o modelo pequeno mantido na RAM."""
import json
import logging
from typing import AsyncIterator, Protocol

import httpx

from app.config import settings

logger = logging.getLogger("nexus.call.llm")


class LlmError(Exception):
    """Falha ao falar com o Ollama (offline, modelo ausente, erro de geracao)."""


class Llm(Protocol):
    model: str

    async def warmup(self) -> None: ...
    def stream(self, messages: list[dict]) -> AsyncIterator[str]: ...
    async def health(self) -> tuple[bool, str | None]: ...


class OllamaCallLlm:
    def __init__(self, host: str | None = None, model: str | None = None):
        self.host = (host or settings.OLLAMA_HOST).rstrip("/")
        self.model = model or settings.CALL_OLLAMA_MODEL

    def _options(self) -> dict:
        return settings.ollama_options(
            num_ctx=settings.CALL_OLLAMA_NUM_CTX,
            num_predict=settings.CALL_OLLAMA_NUM_PREDICT,
            temperature=settings.CALL_OLLAMA_TEMPERATURE,
        )

    async def warmup(self) -> None:
        """Pedido vazio ao Ollama = so carrega o modelo (e fixa o keep_alive)."""
        try:
            async with httpx.AsyncClient(timeout=600) as client:
                resp = await client.post(
                    f"{self.host}/api/generate",
                    json={
                        "model": self.model,
                        "keep_alive": settings.CALL_OLLAMA_KEEP_ALIVE,
                        "options": settings.ollama_options(),
                    },
                )
                if resp.status_code == 404:
                    raise LlmError(f"Modelo '{self.model}' nao encontrado no Ollama. Rode: ollama pull {self.model}")
                resp.raise_for_status()
        except httpx.RequestError as exc:
            raise LlmError(f"Ollama indisponivel em {self.host}: {exc!r}") from exc

    async def stream(self, messages: list[dict]) -> AsyncIterator[str]:
        payload = {
            "model": self.model,
            "messages": messages,
            "stream": True,
            "keep_alive": settings.CALL_OLLAMA_KEEP_ALIVE,
            "options": self._options(),
        }
        try:
            async with httpx.AsyncClient(timeout=httpx.Timeout(300, connect=10)) as client:
                async with client.stream("POST", f"{self.host}/api/chat", json=payload) as resp:
                    if resp.status_code == 404:
                        raise LlmError(f"Modelo '{self.model}' nao encontrado. Rode: ollama pull {self.model}")
                    if resp.status_code >= 400:
                        body = (await resp.aread()).decode("utf-8", "replace")[:300]
                        raise LlmError(f"Ollama respondeu {resp.status_code}: {body}")
                    async for line in resp.aiter_lines():
                        if not line.strip():
                            continue
                        try:
                            chunk = json.loads(line)
                        except json.JSONDecodeError:
                            continue
                        if chunk.get("error"):
                            raise LlmError(str(chunk["error"]))
                        piece = (chunk.get("message") or {}).get("content")
                        if piece:
                            yield piece
                        if chunk.get("done"):
                            return
        except httpx.RequestError as exc:
            raise LlmError(f"Ollama indisponivel em {self.host}: {exc!r}") from exc

    async def health(self) -> tuple[bool, str | None]:
        try:
            async with httpx.AsyncClient(timeout=5) as client:
                resp = await client.get(f"{self.host}/api/tags")
                resp.raise_for_status()
                names = [m.get("name", "") for m in resp.json().get("models", [])]
        except Exception as exc:  # noqa: BLE001
            return False, f"Ollama indisponivel em {self.host}: {exc!r}"
        wanted = self.model if ":" in self.model else f"{self.model}:latest"
        if wanted not in names:
            return False, f"Modelo '{self.model}' nao instalado. Rode: ollama pull {self.model}"
        return True, None
