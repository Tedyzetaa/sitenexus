"""TTS do modo ligacao: XTTS v2 (padrao, modelo fica carregado) ou Piper (opcional, mais leve)."""
import asyncio
import logging
import subprocess
import sys
import uuid
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any, Protocol

from app.config import settings

logger = logging.getLogger("nexus.call.tts")


class TtsError(Exception):
    """Falha ao sintetizar uma frase."""


@dataclass
class VoiceCtx:
    """Voz de UMA ligacao: voz embutida (speaker) ou referencia enviada pelo usuario."""

    speaker: str | None = None
    reference_path: Path | None = None
    latents: Any = field(default=None, repr=False)


class Tts(Protocol):
    name: str

    async def warmup(self, language: str) -> None: ...
    async def synthesize(self, text: str, language: str, voice: VoiceCtx, out_dir: Path) -> Path: ...
    def unload(self) -> None: ...


class XttsEngine:
    name = "xtts"

    def __init__(self):
        from app.providers import xtts_provider  # import tardio: torch so carrega se o XTTS for usado

        self._x = xtts_provider

    async def warmup(self, language: str) -> None:
        try:
            self._x.normalize_language(language)
            await asyncio.to_thread(self._x.warmup, settings.XTTS_MODEL_NAME, settings.XTTS_DEVICE)
        except self._x.SynthesisError as exc:
            raise TtsError(str(exc)) from exc

    async def synthesize(self, text: str, language: str, voice: VoiceCtx, out_dir: Path) -> Path:
        x = self._x
        try:
            if voice.reference_path is not None and voice.latents is None:
                voice.latents = await asyncio.to_thread(
                    x.compute_latents, str(voice.reference_path), settings.XTTS_MODEL_NAME, settings.XTTS_DEVICE
                )
            path = await asyncio.to_thread(
                x.synthesize_call,
                text,
                language,
                settings.XTTS_MODEL_NAME,
                settings.XTTS_DEVICE,
                out_dir,
                speaker=voice.speaker or settings.CALL_XTTS_SPEAKER,
                latents=voice.latents,
            )
        except x.SynthesisError as exc:
            raise TtsError(str(exc)) from exc
        return Path(path)

    def unload(self) -> bool:
        # blocking=False: chamado pelo janitor DENTRO do event loop; se uma frase estiver sendo
        # sintetizada o lock esta ocupado e esperar congelaria o servidor. False = tenta no proximo ciclo.
        return self._x.unload(blocking=False)


class PiperEngine:
    """Opcional (CALL_TTS_ENGINE=piper): `pip install piper-tts` + um modelo .onnx de voz pt-BR."""

    name = "piper"

    async def warmup(self, language: str) -> None:
        if not settings.CALL_PIPER_MODEL_PATH or not Path(settings.CALL_PIPER_MODEL_PATH).exists():
            raise TtsError("CALL_PIPER_MODEL_PATH nao aponta para um modelo .onnx existente.")

    async def synthesize(self, text: str, language: str, voice: VoiceCtx, out_dir: Path) -> Path:
        await self.warmup(language)
        out_dir.mkdir(parents=True, exist_ok=True)
        out = out_dir / f"piper_{uuid.uuid4().hex}.wav"  # hash() colidia para frases repetidas na mesma voz

        def run() -> None:
            proc = subprocess.run(
                [sys.executable, "-m", "piper", "-m", settings.CALL_PIPER_MODEL_PATH, "-f", str(out)],
                input=text, text=True, encoding="utf-8", capture_output=True, timeout=120,
            )
            if proc.returncode != 0 or not out.exists():
                raise TtsError(f"Piper falhou: {(proc.stderr or '')[-300:]}")

        try:
            await asyncio.to_thread(run)
        except subprocess.TimeoutExpired as exc:
            raise TtsError("Piper excedeu o tempo limite.") from exc
        return out

    def unload(self) -> None:
        return None


def make_tts_engine() -> Tts:
    engine = (settings.CALL_TTS_ENGINE or "xtts").strip().lower()
    # v8.0, perfil lite: se o usuario NAO escolheu o motor e ha um modelo Piper valido, usa o Piper
    # (~dezenas de MB de RAM e mais rapido que tempo real em CPU; o XTTS pede ~2-3 GB e e lento num i3).
    if (settings.is_lite and "CALL_TTS_ENGINE" not in settings.model_fields_set
            and settings.CALL_PIPER_MODEL_PATH and Path(settings.CALL_PIPER_MODEL_PATH).exists()):
        engine = "piper"
    if engine == "piper":
        return PiperEngine()
    if engine != "xtts":
        raise TtsError(f"CALL_TTS_ENGINE invalido: {engine!r} (use 'xtts' ou 'piper').")
    return XttsEngine()
