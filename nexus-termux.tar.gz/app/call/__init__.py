"""Modo ligacao: conversa por voz (Whisper -> Ollama -> TTS) com sessoes, eventos e interrupcao."""
