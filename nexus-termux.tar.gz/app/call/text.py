"""Texto para fala: limpeza de markdown/emoji e divisao em frases (streaming)."""
import re

_EMOJI = re.compile("[\U0001F000-\U0001FAFF\u2600-\u27BF\uFE0F\u200d]+")
_BOUNDARY_CHARS = ".!?…\n"


def clean_for_speech(text: str) -> str:
    """Remove o que soa mal ou nao deve ser lido: blocos de codigo, links, markdown, emojis."""
    text = re.sub(r"```.*?```", " ", text, flags=re.S)
    text = re.sub(r"\[([^\]]+)\]\([^)]+\)", r"\1", text)
    text = re.sub(r"https?://\S+", " ", text)
    text = re.sub(r"^\s*[-•*]\s+", "", text, flags=re.M)
    text = re.sub(r"[*_`#>~|]+", "", text)
    text = _EMOJI.sub("", text)
    return re.sub(r"\s+", " ", text).strip()


class SentenceSplitter:
    """Recebe pedacos do texto (stream do LLM) e devolve frases prontas para o TTS.

    - So corta em ".", "!", "?", "…" seguidos de espaco/quebra (nao quebra "3.5").
    - Frases muito curtas ("Oi.") sao juntadas com a seguinte (min_chars).
    - Trechos longos sem pontuacao sao cortados na ultima virgula/espaco (max_chars).
    """

    def __init__(self, min_chars: int = 12, max_chars: int = 180):
        self.min_chars = min_chars
        self.max_chars = max_chars
        self.buf = ""

    def feed(self, delta: str) -> list[str]:
        self.buf += delta
        return self._drain(final=False)

    def flush(self) -> list[str]:
        return self._drain(final=True)

    def _boundaries(self) -> list[int]:
        """Indices (exclusivos) onde uma frase pode terminar."""
        out: list[int] = []
        n = len(self.buf)
        i = 0
        while i < n:
            if self.buf[i] in _BOUNDARY_CHARS:
                j = i
                while j + 1 < n and self.buf[j + 1] in ".!?…":
                    j += 1
                nxt = self.buf[j + 1] if j + 1 < n else None
                if self.buf[i] == "\n" or (nxt is not None and nxt.isspace()):
                    out.append(j + 1)
                i = j + 1
            else:
                i += 1
        return out

    def _drain(self, final: bool) -> list[str]:
        sentences: list[str] = []
        while True:
            cut = next((b for b in self._boundaries() if len(clean_for_speech(self.buf[:b])) >= self.min_chars), None)
            if cut is None and len(self.buf) > self.max_chars:
                window = self.buf[: self.max_chars]
                cut = max(window.rfind(","), window.rfind(";"), window.rfind(" ")) + 1 or self.max_chars
            if cut is None:
                break
            piece, self.buf = self.buf[:cut], self.buf[cut:]
            cleaned = clean_for_speech(piece)
            if cleaned:
                sentences.append(cleaned)
        if final:
            rest = clean_for_speech(self.buf)
            self.buf = ""
            if rest:
                sentences.append(rest)
        return sentences
