"""STT do modo ligacao: faster-whisper num processo filho PERSISTENTE (app/workers/whisper_server.py)."""
import asyncio
import json
import logging
import subprocess
import sys
import threading
from pathlib import Path
from typing import Protocol

from app.config import settings

logger = logging.getLogger("nexus.call.stt")

_PROJECT_ROOT = Path(__file__).resolve().parents[2]


class SttError(Exception):
    """Falha ao transcrever (worker caiu, timeout, pacote ausente...)."""


class Stt(Protocol):
    async def warmup(self) -> None: ...
    async def transcribe(self, audio_path: str, language: str) -> str: ...
    def close(self) -> None: ...


class PersistentWhisper:
    def __init__(self, model_size: str | None = None, device: str | None = None, timeout_s: float = 180.0):
        self.model_size = model_size or settings.CALL_WHISPER_MODEL
        self.device = "cpu"
        self.timeout_s = timeout_s
        self._proc: subprocess.Popen | None = None
        self._lock = threading.Lock()
        self._next_id = 0

    @property
    def is_running(self) -> bool:
        return self._proc is not None and self._proc.poll() is None

    def _spawn(self) -> subprocess.Popen:
        logger.info("Iniciando whisper persistente (model=%s, device=%s)...", self.model_size, self.device)
        return subprocess.Popen(
            [sys.executable, "-m", "app.workers.whisper_server"],
            cwd=str(_PROJECT_ROOT),
            stdin=subprocess.PIPE,
            stdout=subprocess.PIPE,
            stderr=None,  # logs do worker aparecem no console do bridge
            text=True,
            encoding="utf-8",
            bufsize=1,
        )

    def _call(self, payload: dict) -> dict:
        """BLOQUEANTE (rodar em thread). Um request por vez; mata o worker se estourar o timeout."""
        with self._lock:
            if not self.is_running:
                self._proc = self._spawn()
            proc = self._proc
            assert proc is not None and proc.stdin is not None and proc.stdout is not None
            self._next_id += 1
            payload = {**payload, "id": self._next_id, "model_size": self.model_size, "device": self.device}

            timer = threading.Timer(self.timeout_s, proc.kill)
            timer.start()
            try:
                proc.stdin.write(json.dumps(payload, ensure_ascii=False) + "\n")
                proc.stdin.flush()
                line = proc.stdout.readline()
            except (BrokenPipeError, OSError) as exc:
                self._proc = None
                raise SttError(f"Whisper persistente caiu: {exc!r}") from exc
            finally:
                timer.cancel()

            if not line:
                self._proc = None
                raise SttError("Whisper persistente parou de responder (timeout ou erro ao carregar o modelo).")
            try:
                resp = json.loads(line)
            except json.JSONDecodeError as exc:
                raise SttError(f"Resposta invalida do whisper persistente: {line[:200]!r}") from exc
            if not resp.get("ok"):
                raise SttError(str(resp.get("error") or "erro desconhecido no whisper"))
            return resp

    async def warmup(self) -> None:
        await asyncio.to_thread(self._call, {"cmd": "load"})

    async def transcribe(self, audio_path: str, language: str) -> str:
        resp = await asyncio.to_thread(
            self._call, {"cmd": "transcribe", "audio_path": audio_path, "language": language}
        )
        return str(resp.get("transcript") or "").strip()

    def close(self) -> None:
        proc, self._proc = self._proc, None
        if proc is not None and proc.poll() is None:
            try:
                proc.terminate()
                proc.wait(timeout=5)
            except Exception:  # noqa: BLE001
                proc.kill()
            logger.info("Whisper persistente encerrado.")
