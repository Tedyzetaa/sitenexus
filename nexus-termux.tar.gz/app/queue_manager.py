"""
Fila assincrona interna (asyncio.Queue) com worker unico.
Garante serializacao estrita: um job por vez, LLM e Imagem nunca
disputam VRAM simultaneamente entre jobs diferentes -- e assim que
evitamos o erro classico de 'alloc_tensor' / CUDA OOM em GPUs com
pouca VRAM (RTX 3050 6GB) rodando dois processos pesados.

O worker segura `gpu_vram_lock` durante cada job, de modo que os endpoints de dublagem sincronos
(que rodam fora da fila) tambem respeitem a exclusao mutua -- ver app/gpu_lock.py.

Para escalar alem de um unico notebook (ex: cluster com Redis),
basta substituir esta classe por uma implementacao usando
`redis` + `arq`/`rq` mantendo a mesma interface publica
(enqueue / get_job / list_jobs / start / stop), sem tocar no restante do sistema.
"""
import asyncio
import contextlib
import logging
from collections import OrderedDict
from typing import Optional

from app.config import settings
from app.gpu_lock import gpu_vram_lock
from app.models import Job, JobStatus
from app.services.orchestrator import NexusOrchestrator
from app.status_manager import status_manager

logger = logging.getLogger("nexus.queue_manager")

_TERMINAL = (JobStatus.COMPLETED, JobStatus.FAILED)


class QueueFullError(RuntimeError):
    """Fila cheia (settings.max_queued_jobs). A API responde 429 em vez de acumular trabalho que um
    notebook de 2 nucleos levaria horas para processar (e que mantem requests/imagens na RAM)."""


class QueueManager:
    def __init__(self, orchestrator: NexusOrchestrator):
        self.orchestrator = orchestrator
        self._queue: "asyncio.Queue[str]" = asyncio.Queue()
        self._jobs: "OrderedDict[str, Job]" = OrderedDict()
        self._worker_task: Optional[asyncio.Task] = None

    def start(self):
        if self._worker_task is None or self._worker_task.done():
            self._worker_task = asyncio.create_task(self._worker_loop(), name="nexus-queue-worker")
            logger.info("Worker da fila Nexus-Bridge iniciado.")

    async def stop(self):
        """Encerra o worker (shutdown limpo). O job em andamento e marcado como falho."""
        task, self._worker_task = self._worker_task, None
        if task is None:
            return
        task.cancel()
        with contextlib.suppress(asyncio.CancelledError):
            await task

    async def enqueue(self, job: Job) -> Job:
        limit = settings.max_queued_jobs
        if self._queue.qsize() >= limit:
            raise QueueFullError(
                f"Fila cheia ({limit} jobs aguardando). Espere alguns terminarem antes de enviar outro "
                "(ajuste MAX_QUEUED_JOBS no .env se precisar)."
            )
        self._jobs[job.id] = job
        self._trim_history()
        await self._queue.put(job.id)
        await status_manager.set_queue_length(self._queue.qsize())
        return job

    def get_job(self, job_id: str) -> Optional[Job]:
        return self._jobs.get(job_id)

    def list_jobs(self, limit: int = 50):
        if limit <= 0:
            return []
        return list(self._jobs.values())[-limit:][::-1]

    def _trim_history(self):
        """Descarta os jobs mais antigos ACIMA do limite -- mas so os ja concluidos/falhos.

        Antes, um job ainda na fila podia ser expulso do historico e o worker o pulava em silencio
        (o cliente recebia 404 em /api/jobs/{id} para um job que nunca rodou).
        """
        excess = len(self._jobs) - settings.JOB_HISTORY_LIMIT
        if excess <= 0:
            return
        for job_id in [jid for jid, j in self._jobs.items() if j.status in _TERMINAL][:excess]:
            self._jobs.pop(job_id, None)

    @staticmethod
    def _fail(job: Job, reason: str) -> None:
        job.status = JobStatus.FAILED
        job.error = reason

    async def _worker_loop(self):
        while True:
            job_id = await self._queue.get()
            job = self._jobs.get(job_id)
            try:
                await status_manager.set_queue_length(self._queue.qsize())
                if job is None:
                    continue
                async with gpu_vram_lock:
                    await self.orchestrator.run(job)
            except asyncio.CancelledError:
                if job is not None and job.status not in _TERMINAL:
                    self._fail(job, "Cancelado: o Nexus-Bridge foi encerrado durante o processamento.")
                raise
            except Exception as exc:  # noqa: BLE001 - o worker nunca pode morrer
                logger.exception("Falha critica processando job %s", job_id)
                if job is not None and job.status not in _TERMINAL:
                    self._fail(job, f"Erro inesperado na fila: {exc}")
            finally:
                self._queue.task_done()
