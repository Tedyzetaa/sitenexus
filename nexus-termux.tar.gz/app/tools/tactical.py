"""
Vigilancia Tatica  (legado: sentinel_system.py, liveuamap_intel.py, intel_war.py)

* get_frontline_report()  -> manchetes de conflitos (Liveuamap RSS, fallback Google News RSS)
* get_war_snapshot()      -> print do mapa/painel + manchetes (Playwright, opt-in)
* get_pizzint_status()    -> leitura textual do PIZZINT/DEFCON watch
* capture_sentinel()      -> foto da webcam local (opt-in + token obrigatorio)

Mudancas deliberadas em relacao ao legado:
 - `webbrowser.open(...)` removido: abrir navegador NO SERVIDOR nao faz sentido
   numa API; o mapa agora volta como URL no resultado.
 - `cloudscraper` removido: contornar protecao anti-bot e fragil e de legitimidade
   duvidosa. Tenta o feed direto e, se bloquear, usa o Google News RSS.
 - Estado `last_update`/`open_source_evidence(index)` removido: os links vem
   no proprio resultado (sem estado global compartilhado entre usuarios).
 - Camera: desligada por padrao, exige TOOLS_API_TOKEN, arquivo em pasta privada.
"""
from __future__ import annotations

import asyncio
import re
import sys
from typing import Optional
from urllib.parse import quote

from app.config import settings
from app.tools.base import (
    ExternalServiceError, ToolError, ToolResult, ToolUnavailableError, cached, clamp_text, http_get,
    new_media_file, safe_tool,
)
from app.tools.browser import BlockedByAntiBotError, capture_page
from app.tools.feeds import parse_feed

THEATERS = {
    "ukraine": {"map": "https://ukraine.liveuamap.com", "rss": "https://ukraine.liveuamap.com/rss",
                "news_q": "Guerra Ucrânia front"},
    "israel": {"map": "https://israelpalestine.liveuamap.com", "rss": "https://israelpalestine.liveuamap.com/rss",
               "news_q": "Guerra Israel Gaza"},
    "syria": {"map": "https://syria.liveuamap.com", "rss": "https://syria.liveuamap.com/rss",
              "news_q": "Guerra Síria"},
    "global": {"map": "https://liveuamap.com", "rss": "https://liveuamap.com/rss",
               "news_q": "conflitos armados guerra mundo"},
}
THEATER_ALIASES = {
    "ucrania": "ukraine", "ucrânia": "ukraine", "ukraine": "ukraine",
    "israel": "israel", "gaza": "israel", "palestina": "israel",
    "siria": "syria", "síria": "syria", "syria": "syria",
    "global": "global", "mundo": "global", "": "global",
}
WAR_PAGES = {
    "global": "https://liveuamap.com/", "ucrania": "https://ukraine.liveuamap.com/",
    "israel": "https://israelpalestine.liveuamap.com/", "defcon": "https://www.defconlevel.com/",
    "pizzint": "https://www.pizzint.watch/",
}
WAR_ALIASES = {**{k: k for k in WAR_PAGES}, "ucrânia": "ucrania", "ukraine": "ucrania", "gaza": "israel",
               "palestina": "israel", "mundo": "global", "": "global"}
WAR_HOSTS = ["liveuamap.com", "defconlevel.com", "pizzint.watch"]


def resolve_theater(name: str) -> str:
    return THEATER_ALIASES.get((name or "").strip().lower(), "global")


def resolve_sector(name: str) -> str:
    return WAR_ALIASES.get((name or "").strip().lower(), "global")


# --------------------------------------------------------------------------- #
# Relatorio de frente (RSS)
# --------------------------------------------------------------------------- #
@safe_tool("get_frontline_report")
async def get_frontline_report(theater: str = "ukraine", limit: int = 5) -> ToolResult:
    key = resolve_theater(theater)
    cfg = THEATERS[key]
    limit = max(1, min(int(limit), 10))

    async def fetch():
        try:
            resp = await http_get("Liveuamap", cfg["rss"], retries=0, timeout=10)
            items, source = parse_feed(resp.content, limit=10), "Liveuamap"
            if items:
                return items, source
        except (ExternalServiceError, ValueError):
            pass  # bloqueado/fora do ar -> fallback
        backup = (f"https://news.google.com/rss/search?q={quote(cfg['news_q'])}&hl=pt-BR&gl=BR&ceid=BR:pt-419")
        resp = await http_get("Google News", backup, retries=1, timeout=10)
        try:
            return parse_feed(resp.content, limit=10), "Google News"
        except ValueError as exc:
            raise ExternalServiceError("Google News", str(exc)) from exc

    (items, source), hit = await cached(f"frontline:{key}", fetch, ttl=300)
    items = items[:limit]
    lines = [f"📊 **RELATÓRIO TÁTICO: {key.upper()}** [{source}]"]
    for i, it in enumerate(items, 1):
        lines.append(f"\n[{i}] ⏰ {it['published'] or 'recente'}\n⚠️ {clamp_text(it['title'], 220)}\n{it['link']}")
    if not items:
        lines.append("\nSetor sem manchetes no momento.")
    lines.append(f"\n🗺️ Mapa interativo: {cfg['map']}")
    return ToolResult(True, "get_frontline_report", "\n".join(lines), source=source, cached=hit,
                      data={"theater": key, "map_url": cfg["map"], "items": items})


# --------------------------------------------------------------------------- #
# Print do painel (Playwright)
# --------------------------------------------------------------------------- #
@safe_tool("get_war_snapshot", timeout=120)
async def get_war_snapshot(sector: str = "global") -> ToolResult:
    key = resolve_sector(sector)
    url = WAR_PAGES[key]
    path, media_url = new_media_file(f"intel_{key}", "png")
    try:
        info = await capture_page(url, path, allowed_hosts=WAR_HOSTS, viewport=(1280, 720), settle_s=6,
                                  text_selector=".title" if "liveuamap" in url else None)
    except BlockedByAntiBotError as exc:
        return await _snapshot_fallback(key, str(exc))
    lines = [f"🛰️ **PAINEL DE INTELIGÊNCIA — {key.upper()}**"]
    lines += [f"• {clamp_text(t, 200)}" for t in info["texts"]]
    return ToolResult(True, "get_war_snapshot", "\n".join(lines), media=[media_url], source=url,
                      data={"sector": key, "headlines": info["texts"]})


_SNAPSHOT_THEATER = {"global": "global", "ucrania": "ukraine", "israel": "israel"}


async def _snapshot_fallback(key: str, reason: str) -> ToolResult:
    """Site bloqueou o navegador automatizado: entrega o equivalente em texto (RSS / leitura publica)."""
    if key in _SNAPSHOT_THEATER:
        rep = await get_frontline_report(_SNAPSHOT_THEATER[key], 5)
    else:
        rep = await get_pizzint_status()
    text = f"⚠️ {reason}\nEm vez do print, segue o relatório em texto:\n\n{rep.text}"
    return ToolResult(rep.ok, "get_war_snapshot", text, data={**rep.data, "sector": key, "blocked": True},
                      source=rep.source)


_DEFCON = re.compile(r"DEFCON\s+(\d)")
_ORDERS = re.compile(r"(\d+)\s+Orders", re.I)


@safe_tool("get_pizzint_status")
async def get_pizzint_status() -> ToolResult:
    async def fetch():
        return (await http_get("PIZZINT", WAR_PAGES["pizzint"], timeout=10, retries=1)).text

    html, hit = await cached("pizzint", fetch, ttl=300)
    d, o = _DEFCON.search(html), _ORDERS.search(html)
    status = f"DEFCON {d.group(1)}" if d else "status não identificado"
    orders = o.group(1) if o else "n/d"
    text = (f"🚨 **PIZZINT WATCH**\n🔹 {status}\n🔹 Atividade: {orders} ordens ativas\n"
            f"_Leitura por regex na página pública — pode quebrar se o site mudar o layout._")
    return ToolResult(True, "get_pizzint_status", text, source="pizzint.watch", cached=hit,
                      data={"defcon": int(d.group(1)) if d else None, "orders": orders})


# --------------------------------------------------------------------------- #
# Sentinela (webcam local)
# --------------------------------------------------------------------------- #
_camera_lock: Optional[asyncio.Lock] = None


def _grab_frame(index: int, out_path) -> str:
    """Bloqueante (OpenCV) -- SEMPRE chamar via asyncio.to_thread."""
    try:
        import cv2
    except ImportError as exc:
        raise ToolUnavailableError("OpenCV nao instalado: `pip install opencv-python`.") from exc

    import time as _t
    cap = None
    try:
        if sys.platform == "win32":
            cap = cv2.VideoCapture(index, cv2.CAP_DSHOW)
        if cap is None or not cap.isOpened():
            cap = cv2.VideoCapture(index)
        if not cap.isOpened():
            raise ToolError("Não foi possível acessar a câmera (ocupada ou sem permissão).")
        cap.set(cv2.CAP_PROP_FRAME_WIDTH, 640)
        cap.set(cv2.CAP_PROP_FRAME_HEIGHT, 480)
        for _ in range(10):  # descarta frames pretos iniciais
            cap.read()
            _t.sleep(0.1)
        ok, frame = cap.read()
        if not ok or frame is None:
            raise ToolError("A câmera abriu, mas a imagem veio vazia.")
        if not cv2.imwrite(str(out_path), frame):
            raise ToolError("Falha ao gravar a imagem capturada.")
        return str(out_path)
    finally:
        if cap is not None:
            cap.release()


@safe_tool("capture_sentinel", timeout=30)
async def capture_sentinel() -> ToolResult:
    global _camera_lock
    if not settings.TOOLS_ENABLE_SENTINEL or not settings.TOOLS_API_TOKEN:
        raise ToolUnavailableError(
            "Sentinela desligado. Para usar a câmera defina TOOLS_ENABLE_SENTINEL=true e TOOLS_API_TOKEN no .env."
        )
    if _camera_lock is None:
        _camera_lock = asyncio.Lock()
    path, url = new_media_file("sentinel", "png", private=True)
    async with _camera_lock:  # uma captura por vez; camera e recurso exclusivo
        await asyncio.to_thread(_grab_frame, settings.TOOLS_CAMERA_INDEX, path)
    return ToolResult(True, "capture_sentinel", "📸 **Sentinela:** imagem capturada (acesso privado, requer token).",
                      media=[url], source="webcam local")
