"""
Trafego aereo e Radio  (legado: air_traffic.py, radar_api.py, radio_scanner.py)

* scan_radar_feeds()     -> aeronaves ao redor de uma cidade (OpenSky) + mapa de radar
                            (unifica air_traffic.radar_scan e radar_api.gerar_radar)
* scan_radio_stations()  -> estacoes de radio da INTERNET (Radio-Browser)

Nota: o "radio_scanner" original NAO varre espectro de RF; consulta o diretorio
publico Radio-Browser (radios online). A ferramenta mantem esse comportamento e
o descreve com esse nome para nao enganar quem le o relatorio.
"""
from __future__ import annotations

import math
import re
from typing import Any, Optional
from urllib.parse import quote

from app.config import settings
from app.tools.base import (
    ExternalServiceError, ToolError, ToolResult, cached, clamp_text, http_json, new_media_file,
    render_figure, safe_float, safe_tool,
)

OPENSKY = "https://opensky-network.org/api/states/all"
NOMINATIM = "https://nominatim.openstreetmap.org/search"
RADIO_HOSTS = ["de1", "at1", "nl1"]


# --------------------------------------------------------------------------- #
# Radar aereo
# --------------------------------------------------------------------------- #
def bounding_box(lat: float, lon: float, radius_km: float) -> dict[str, float]:
    dlat = radius_km / 111.0
    dlon = radius_km / (111.0 * max(math.cos(math.radians(lat)), 0.2))
    return {"lamin": lat - dlat, "lamax": lat + dlat, "lomin": lon - dlon, "lomax": lon + dlon}


def parse_states(states: Any) -> list[dict]:
    """OpenSky devolve `states: null` sem trafego e callsign None -- o legado quebrava nos dois."""
    out = []
    for s in states or []:
        if not isinstance(s, list) or len(s) < 8:
            continue
        lon, lat = safe_float(s[5]), safe_float(s[6])
        if lat is None or lon is None:
            continue
        vel = safe_float(s[9]) if len(s) > 9 else None
        out.append({
            "callsign": (s[1] or "").strip() or "UNK", "icao24": s[0], "country": s[2] or "?",
            "lat": lat, "lon": lon, "alt_m": safe_float(s[7]),
            "speed_kmh": round(vel * 3.6) if vel is not None else None,
        })
    return out


async def geocode(place: str) -> tuple[float, float, str]:
    q = place.strip()
    if q.lower() == settings.TOOLS_HOME_NAME.lower():
        return settings.TOOLS_HOME_LAT, settings.TOOLS_HOME_LON, settings.TOOLS_HOME_NAME

    async def fetch():
        return await http_json("Nominatim", NOMINATIM, params={"q": q, "format": "json", "limit": 1}, timeout=10)

    res, _ = await cached(f"geo:{q.lower()}", fetch, ttl=86400)
    if not res:
        raise ToolError(f"Localização '{place}' não encontrada.")
    return float(res[0]["lat"]), float(res[0]["lon"]), res[0].get("display_name", place).split(",")[0]


def _draw_radar(fig, planes: list[dict], lat: float, lon: float, name: str, radius_km: float) -> None:
    from matplotlib.patches import Ellipse

    ax = fig.add_subplot(111)
    ax.set_facecolor("black")
    box = bounding_box(lat, lon, radius_km)
    for frac in (0.25, 0.5, 0.75, 1.0):
        ax.add_patch(Ellipse(
            (lon, lat), 2 * (box["lomax"] - lon) * frac, 2 * (box["lamax"] - lat) * frac,
            fill=False, color="#00ff00", alpha=0.25, linestyle="--"))
    ax.plot(lon, lat, "P", color="#00ffff", markersize=12, label=f"BASE ({name})")
    for p in planes:
        ax.plot(p["lon"], p["lat"], "^", color="#ff3333", markersize=8)
        alt = f"\n{p['alt_m']:.0f} m" if p["alt_m"] is not None else ""
        ax.annotate(p["callsign"] + alt, (p["lon"], p["lat"]), color="#ffff66", fontsize=7,
                    xytext=(4, 4), textcoords="offset points")
    ax.set_xlim(box["lomin"], box["lomax"])
    ax.set_ylim(box["lamin"], box["lamax"])
    ax.set_aspect(1 / max(math.cos(math.radians(lat)), 0.2))
    ax.grid(True, color="#003300")
    ax.tick_params(colors="#00aa00")
    ax.set_title(f"TACTICAL RADAR — {name.upper()} — {len(planes)} ALVO(S)", color="#00ff00")
    ax.legend(loc="upper right", facecolor="black", labelcolor="white")


@safe_tool("scan_radar_feeds", timeout=60)
async def scan_radar_feeds(location: Optional[str] = None, radius_km: float = 150.0) -> ToolResult:
    location = (location or settings.TOOLS_HOME_NAME).strip()
    if not location or len(location) > 80:
        raise ToolError("Informe uma localização válida (até 80 caracteres).")
    radius_km = max(20.0, min(float(radius_km), 400.0))

    lat, lon, name = await geocode(location)
    box = bounding_box(lat, lon, radius_km)
    key = f"radar:{lat:.2f}:{lon:.2f}:{int(radius_km)}"
    raw, hit = await cached(key, lambda: http_json("OpenSky", OPENSKY, params=box, timeout=20), ttl=30)
    planes = parse_states((raw or {}).get("states"))

    media: list[str] = []
    path, url = new_media_file("radar", "png")
    if await render_figure(lambda fig: _draw_radar(fig, planes, lat, lon, name, radius_km), path, size=(7, 7)):
        media.append(url)

    lines = [f"📡 **RADAR TÁTICO — {name.upper()}** (raio {radius_km:.0f} km)", f"✈️ {len(planes)} aeronave(s) detectada(s)."]
    for p in sorted(planes, key=lambda x: -(x["alt_m"] or 0))[:8]:
        alt = f"{p['alt_m']:.0f} m" if p["alt_m"] is not None else "solo/n-d"
        spd = f"{p['speed_kmh']} km/h" if p["speed_kmh"] is not None else "n/d"
        lines.append(f"• **{p['callsign']}** ({p['country']}) — {alt} — {spd}")
    lines.append("_Fonte: OpenSky Network (cobertura depende de receptores ADS-B voluntários)_")
    return ToolResult(True, "scan_radar_feeds", "\n".join(lines), media=media, source="OpenSky", cached=hit,
                      data={"center": {"lat": lat, "lon": lon, "name": name}, "radius_km": radius_km,
                            "count": len(planes), "aircraft": planes})


# --------------------------------------------------------------------------- #
# Radio (Radio-Browser)
# --------------------------------------------------------------------------- #
_TAG = re.compile(r"^[a-z0-9][a-z0-9 _-]{0,29}$")


def radio_endpoint(mode: str, limit: int) -> tuple[str, dict[str, Any]]:
    """`mode` vira parte do PATH da URL -> validado (sem '/', '..', '?')."""
    mode = (mode or "global").strip().lower()
    base = {"hidebroken": "true"}
    if mode == "global":
        return f"stations/topclick/{limit}", base
    if mode in ("local", "brasil", "brazil"):
        return "stations/bycountrycodeexact/BR", {**base, "limit": limit, "order": "clickcount", "reverse": "true"}
    if not _TAG.match(mode):
        raise ToolError("Modo inválido. Use 'global', 'local' ou uma tag simples (ex.: news, rock, police).")
    return f"stations/bytag/{quote(mode)}", {**base, "limit": limit, "order": "clickcount", "reverse": "true"}


def parse_stations(raw: Any) -> list[dict]:
    out = []
    for s in raw if isinstance(raw, list) else []:
        url = (s.get("url_resolved") or "").strip()
        if not url.lower().startswith(("http://", "https://")):  # nada de file:, javascript: etc.
            continue
        out.append({"name": (s.get("name") or "Desconhecida").strip(), "url": url,
                    "country": s.get("country") or "Intl", "bitrate": s.get("bitrate") or 0,
                    "tags": clamp_text(s.get("tags") or "", 40)})
    return out


@safe_tool("scan_radio_stations")
async def scan_radio_stations(mode: str = "global", limit: int = 8) -> ToolResult:
    limit = max(1, min(int(limit), 20))
    path, params = radio_endpoint(mode, limit)

    async def fetch():
        last: Optional[Exception] = None
        for host in RADIO_HOSTS:  # o diretorio e espelhado; um host fora do ar nao pode matar a ferramenta
            try:
                return await http_json("Radio-Browser", f"https://{host}.api.radio-browser.info/json/{path}",
                                       params=params, retries=0, timeout=10)
            except ExternalServiceError as exc:
                last = exc
        raise last or ExternalServiceError("Radio-Browser", "sem resposta")

    raw, hit = await cached(f"radio:{path}:{limit}", fetch, ttl=600)
    stations = parse_stations(raw)[:limit]
    lines = [f"📻 **RÁDIOS ONLINE — {mode.upper()}**"]
    for i, s in enumerate(stations, 1):
        lines.append(f"{i}. **{s['name']}** ({s['country']}) — {s['bitrate']} kbps"
                     + (f" — _{s['tags']}_" if s["tags"] else "") + f"\n   🔗 {s['url']}")
    if not stations:
        lines.append("Nenhuma transmissão ativa encontrada.")
    return ToolResult(True, "scan_radio_stations", "\n".join(lines), data={"stations": stations},
                      source="Radio-Browser", cached=hit)
