"""Ferramentas do J.A.R.V.I.S. (monitoramento, clima, espaco, trafego, inteligencia).

Uso rapido:
    from app.tools import hub, registry
    await hub.get_solar_status()
    await registry.invoke("check_seismic_activity", {"level": "strong"})
"""
