"""
Registro das ferramentas: nome, parametros tipados, apelidos de comando e
palavras-chave. Fonte unica para (1) a rota HTTP, (2) os comandos de chat e
(3) o manifesto de function-calling que o LLM pode usar para escolher
ferramentas sozinho.
"""
from __future__ import annotations

from dataclasses import dataclass
from typing import Any, Awaitable, Callable, Optional

from app.tools import hub
from app.tools.base import ToolResult


@dataclass(frozen=True)
class Param:
    name: str
    type: str = "string"            # string | integer | number
    description: str = ""
    default: Any = None
    enum: tuple[str, ...] = ()
    minimum: Optional[float] = None
    maximum: Optional[float] = None
    max_length: int = 80


@dataclass(frozen=True)
class ToolSpec:
    name: str
    description: str
    category: str
    handler: Callable[..., Awaitable[ToolResult]]
    params: tuple[Param, ...] = ()
    commands: tuple[str, ...] = ()      # sem a barra, sem acento
    keywords: tuple[str, ...] = ()      # busca em linguagem natural (sem acento, minusculo)
    sensitive: bool = False             # exige token na rota HTTP
    heavy: bool = False                 # navegador/ffmpeg: nao entra no relatorio geral


S, I, N = "string", "integer", "number"

TOOLS: tuple[ToolSpec, ...] = (
    ToolSpec("check_seismic_activity", "Terremotos recentes no mundo (USGS, últimas 24h).", "geofisica",
             hub.check_seismic_activity,
             (Param("level", S, "Filtro de magnitude", "all", ("all", "strong", "significant")),
              Param("limit", I, "Quantidade de eventos", 5, minimum=1, maximum=15)),
             commands=("sismo", "terremoto", "sismico"), keywords=("terremoto", "sismo", "sismic", "tremor", "abalo")),
    ToolSpec("get_volcano_report", "Atividade vulcânica global (Smithsonian GVP, semanal).", "geofisica",
             hub.get_volcano_report, (Param("limit", I, "Quantidade de itens", 5, minimum=1, maximum=10),),
             commands=("vulcao", "vulcoes", "magma"), keywords=("vulcao", "vulcoes", "erupcao", "vulcanic")),
    ToolSpec("get_asteroid_report", "Asteroides próximos da Terra hoje (NASA NeoWs).", "espacial",
             hub.get_asteroid_report, commands=("asteroides", "asteroide", "neo", "astro"),
             keywords=("asteroide", "meteoro", "defesa planetaria", "neo")),
    ToolSpec("track_iss", "Posição atual da ISS com mapa; avisa se está sobre o Brasil.", "espacial",
             hub.track_iss, commands=("iss", "orbita", "orbital"), keywords=("iss", "estacao espacial", "orbita")),
    ToolSpec("get_asteroid_trajectory", "Gráfico 3D da órbita de um asteroide (JPL SBDB, calculado localmente).",
             "espacial", hub.get_asteroid_trajectory,
             (Param("asteroid_name", S, "Nome do asteroide (vazio = maior de hoje)", None),),
             commands=("trajetoria", "orbita3d"), keywords=("trajetoria",),
             # v8.0: renderiza uma figura 3D (matplotlib, varios segundos de CPU e ~150 MB de RAM num
             # notebook sem GPU): so por comando explicito, nunca por linguagem natural. Tambem corrige o
             # teste test_intent_matching_is_conservative, que ja falhava antes e espera exatamente isso.
             heavy=True),
    ToolSpec("get_weather", "Clima atual de uma cidade (OpenWeatherMap).", "clima",
             hub.get_weather, (Param("city", S, "Cidade, ex.: 'Ivinhema MS' (vazio = cidade base)", None),),
             commands=("clima", "tempo", "weather"), keywords=("clima", "temperatura", "previsao do tempo", "vai chover")),
    ToolSpec("fetch_noaa_data", "Clima espacial NOAA: raios-X, Kp, vento solar, prótons, alertas, previsão.", "solar",
             hub.fetch_noaa_data,
             (Param("section", S, "Seção do relatório", "full",
                    ("full", "xray", "kp", "wind", "protons", "alerts", "forecast", "regions")),),
             commands=("noaa", "swpc", "climaespacial"), keywords=("noaa", "clima espacial", "tempestade geomagnetica", "aurora")),
    ToolSpec("get_noaa_media", "Imagens/vídeos solares: D-RAP, SDO, coronógrafo SOHO, ENLIL.", "solar",
             hub.get_noaa_media,
             (Param("kind", S, "Tipo de mídia", "drap", ("drap", "sdo", "cme", "sdo_video", "enlil")),
              Param("band", S, "Banda do coronógrafo (kind=cme)", "C3", ("C2", "C3"))),
             commands=("noaamidia", "sdo", "cme", "drap", "enlil"), keywords=("imagem do sol", "coronografo", "ejecao"),
             heavy=True),
    ToolSpec("get_solar_status", "Resumo da atividade solar: flares, CME, Kp e tendência.", "solar",
             hub.get_solar_status, commands=("solar", "sol"), keywords=("solar", "sol ", "flare", "manchas solares")),
    ToolSpec("scan_radar_feeds", "Radar aéreo: aeronaves ao redor de uma cidade (OpenSky) + mapa.", "trafego",
             hub.scan_radar_feeds,
             (Param("location", S, "Cidade/local (vazio = cidade base)", None),
              Param("radius_km", N, "Raio da varredura em km", 150, minimum=20, maximum=400)),
             commands=("radar", "aviao", "avioes", "voos"), keywords=("radar", "aviao", "avioes", "aeronave", "voo")),
    ToolSpec("scan_radio_stations", "Rádios online mais ouvidas (Radio-Browser). Não é varredura de RF.", "trafego",
             hub.scan_radio_stations,
             (Param("mode", S, "'global', 'local' (Brasil) ou tag (news, rock...)", "global", max_length=30),
              Param("limit", I, "Quantidade", 8, minimum=1, maximum=20)),
             commands=("radio", "radios", "scanner"), keywords=("radio", "radios", "estacao de radio")),
    ToolSpec("get_frontline_report", "Manchetes de conflitos (Liveuamap / Google News).", "tatica",
             hub.get_frontline_report,
             (Param("theater", S, "ukraine | israel | syria | global", "ukraine", max_length=20),
              Param("limit", I, "Quantidade", 5, minimum=1, maximum=10)),
             commands=("frente", "front", "conflito", "intel"), keywords=("guerra", "conflito", "frente de batalha")),
    ToolSpec("get_war_snapshot", "Print do painel/mapa de inteligência + manchetes. Exige navegador; se o site bloquear, devolve o relatório em texto.", "tatica",
             hub.get_war_snapshot,
             (Param("sector", S, "global | ucrania | israel | defcon | pizzint", "global", max_length=20),),
             commands=("guerra", "mapaguerra"), keywords=("mapa de guerra",), heavy=True),
    ToolSpec("get_pizzint_status", "Leitura do PIZZINT / DEFCON watch.", "tatica",
             hub.get_pizzint_status, commands=("pizzint", "defcon"), keywords=("pizzint", "defcon")),
    ToolSpec("capture_sentinel", "Foto da webcam local (Sentinela). Opt-in + token obrigatório.", "tatica",
             hub.capture_sentinel, commands=("sentinela", "camera"), keywords=("sentinela",),
             sensitive=True, heavy=True),
    ToolSpec("get_situation_report", "Painel geral: sismos, vulcões, sol, asteroides e ISS de uma vez.", "geral",
             hub.get_situation_report, commands=("relatorio", "situacao", "painel"),
             keywords=("relatorio geral", "situacao global", "panorama")),
)

_BY_NAME = {t.name: t for t in TOOLS}


def get_spec(name: str) -> Optional[ToolSpec]:
    return _BY_NAME.get(name)


def coerce_args(spec: ToolSpec, raw: dict[str, Any]) -> dict[str, Any]:
    """Valida/converte argumentos vindos de HTTP, chat ou LLM. Levanta ValueError (msg amigavel)."""
    known = {p.name: p for p in spec.params}
    unknown = set(raw) - set(known)
    if unknown:
        raise ValueError(f"Parâmetro(s) desconhecido(s): {', '.join(sorted(unknown))}.")
    out: dict[str, Any] = {}
    for name, p in known.items():
        v = raw.get(name)
        if v is None or (isinstance(v, str) and not v.strip()):
            if p.default is not None:
                out[name] = p.default
            continue
        try:
            if p.type == I:
                v = int(float(v))
            elif p.type == N:
                v = float(v)
            else:
                v = str(v).strip()
                if len(v) > p.max_length:
                    raise ValueError(f"'{name}' excede {p.max_length} caracteres.")
        except (TypeError, ValueError) as exc:
            raise ValueError(str(exc) if "excede" in str(exc) else f"Valor inválido para '{name}'.") from exc
        if p.enum and v not in p.enum:
            raise ValueError(f"'{name}' deve ser um de: {', '.join(p.enum)}.")
        if p.type in (I, N):
            if p.minimum is not None:
                v = max(v, p.minimum)
            if p.maximum is not None:
                v = min(v, p.maximum)
        out[name] = v
    return out


async def invoke(name: str, args: Optional[dict[str, Any]] = None) -> ToolResult:
    """Ponto unico de execucao. Nunca levanta."""
    spec = get_spec(name)
    if spec is None:
        return ToolResult.failure(name, f"Ferramenta '{name}' não existe.")
    try:
        clean = coerce_args(spec, args or {})
    except ValueError as exc:
        return ToolResult.failure(name, str(exc))
    return await spec.handler(**clean)


def manifest(fmt: str = "ollama", include_sensitive: bool = False) -> list[dict[str, Any]]:
    """Descricao das ferramentas no formato de function-calling (OpenAI/Ollama).
    Sensiveis e pesadas ficam de fora por padrao: o LLM nao deve acionar camera sozinho."""
    items = []
    for t in TOOLS:
        if t.sensitive and not include_sensitive:
            continue
        props: dict[str, Any] = {}
        for p in t.params:
            d: dict[str, Any] = {"type": p.type, "description": p.description}
            if p.enum:
                d["enum"] = list(p.enum)
            if p.minimum is not None:
                d["minimum"] = p.minimum
            if p.maximum is not None:
                d["maximum"] = p.maximum
            props[p.name] = d
        schema = {"type": "object", "properties": props}
        if fmt == "anthropic":
            items.append({"name": t.name, "description": t.description, "input_schema": schema})
        else:
            items.append({"type": "function", "function": {"name": t.name, "description": t.description,
                                                           "parameters": schema}})
    return items
