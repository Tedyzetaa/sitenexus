"""
Captura de paginas via Playwright (API ASYNC -- as versoes legadas usavam
`sync_playwright` + `time.sleep`, que congelam o event loop inteiro do bot).

Seguranca:
* So abre URLs https cujo host esta na allowlist passada por quem chama
  (nada de URL arbitraria vinda do chat -> sem SSRF / sem navegar para rede interna).
* Um Chromium por vez (`browser_semaphore`).
* `--no-sandbox` so e usado quando o processo roda como root (container),
  nunca por padrao.
"""
from __future__ import annotations

import asyncio
import os
from pathlib import Path
from typing import Iterable, Optional
from urllib.parse import urlparse

from app.tools.antibot import is_challenge_page
from app.tools.base import ToolError, browser_semaphore, require_browser

_UA = (
    "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 "
    "(KHTML, like Gecko) Chrome/121.0.0.0 Safari/537.36"
)


class BlockedByAntiBotError(ToolError):
    """O site respondeu com verificacao anti-robo. Nao tentamos contornar: o chamador usa outra fonte."""


def assert_allowed(url: str, allowed_hosts: Iterable[str]) -> None:
    parsed = urlparse(url)
    host = (parsed.hostname or "").lower()
    allowed = {h.lower() for h in allowed_hosts}
    if parsed.scheme != "https" or not any(host == h or host.endswith("." + h) for h in allowed):
        raise ToolError("URL fora da lista de fontes permitidas.")


async def capture_page(
    url: str,
    out_path: Path,
    *,
    allowed_hosts: Iterable[str],
    viewport: tuple[int, int] = (1280, 720),
    settle_s: float = 6.0,
    nav_timeout_s: float = 45.0,
    hide_selectors: Optional[list[str]] = None,
    text_selector: Optional[str] = None,
    max_texts: int = 5,
    jpeg: bool = False,
    webgl: bool = False,
) -> dict:
    """Abre `url`, espera `settle_s`, tira print em `out_path`.

    Retorna {"title": str, "texts": [str], "final_url": str}.
    """
    require_browser()
    assert_allowed(url, allowed_hosts)
    from playwright.async_api import Error as PlaywrightError
    from playwright.async_api import async_playwright

    args: list[str] = []
    if hasattr(os, "geteuid") and os.geteuid() == 0:
        args.append("--no-sandbox")  # container rodando como root
    if webgl:
        args += ["--ignore-gpu-blocklist", "--enable-webgl", "--enable-webgl2"]

    async with browser_semaphore():
        try:
            async with async_playwright() as pw:
                browser = await pw.chromium.launch(headless=True, args=args)
                try:
                    ctx = await browser.new_context(
                        viewport={"width": viewport[0], "height": viewport[1]}, user_agent=_UA
                    )
                    page = await ctx.new_page()
                    await page.goto(url, wait_until="domcontentloaded", timeout=nav_timeout_s * 1000)
                    # o redirecionamento final tambem precisa estar na allowlist
                    assert_allowed(page.url, allowed_hosts)

                    # banners de cookie / popups (melhor esforco)
                    try:
                        await page.locator("button:has-text('Accept'), .popup-close").first.click(timeout=2000)
                    except PlaywrightError:
                        pass

                    if hide_selectors:
                        try:
                            await page.evaluate(
                                "sels => sels.forEach(s => document.querySelectorAll(s)"
                                ".forEach(e => e.style.display = 'none'))",
                                hide_selectors,
                            )
                        except PlaywrightError:
                            pass

                    await asyncio.sleep(settle_s)  # camadas do mapa/WebGL (nao bloqueia o loop)

                    # Pagina de verificacao anti-robo? Aborta em vez de mandar um print inutil.
                    try:
                        body = (await page.inner_text("body", timeout=3000))[:3000]
                    except PlaywrightError:
                        body = ""
                    if is_challenge_page(await page.title(), body):
                        host = urlparse(page.url).hostname or "O site"
                        raise BlockedByAntiBotError(f"{host} bloqueou o acesso automatizado (verificação anti-robô).")

                    if jpeg:
                        await page.screenshot(path=str(out_path), type="jpeg", quality=90)
                    else:
                        await page.screenshot(path=str(out_path))

                    texts: list[str] = []
                    if text_selector:
                        raw = await page.locator(text_selector).all_text_contents()
                        texts = [t.strip() for t in raw if t and t.strip()][:max_texts]
                    return {"title": await page.title(), "texts": texts, "final_url": page.url}
                finally:
                    await browser.close()
        except PlaywrightError as exc:
            msg = str(exc).splitlines()[0][:160]
            if "Executable doesn't exist" in str(exc):
                raise ToolError("Chromium do Playwright nao instalado: rode `playwright install chromium`.") from exc
            raise ToolError(f"Falha ao capturar a pagina ({msg}).") from exc
