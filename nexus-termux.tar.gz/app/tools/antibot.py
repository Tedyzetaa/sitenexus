"""Deteccao (so deteccao) de paginas de verificacao anti-robo, sem dependencias.

O Nexus NAO tenta resolver nem contornar esses desafios: ao reconhecer um, a ferramenta
aborta e usa um caminho alternativo (RSS, API oficial) em vez de enviar um print inutil.
"""
from __future__ import annotations

_TITLE_MARKERS = (
    "just a moment", "attention required", "security verification", "verifying you are human",
    "checking your browser", "um momento", "verificação de segurança", "access denied",
)
_BODY_MARKERS = (
    "performing security verification", "verify you are human", "verifying you are human",
    "checking if the site connection is secure", "enable javascript and cookies to continue",
    "this website uses a security service to protect against malicious bots",
    "needs to review the security of your connection",
)


def is_challenge_page(title: str, body_text: str) -> bool:
    t = (title or "").lower()
    b = (body_text or "").lower()
    return any(m in t for m in _TITLE_MARKERS) or any(m in b for m in _BODY_MARKERS)
