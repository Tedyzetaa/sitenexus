"""
Central de Ferramentas -- API publica limpa do J.A.R.V.I.S.

    from app.tools import hub
    res = await hub.check_seismic_activity()
    print(res.text)          # relatorio pronto para o chat
    print(res.data)          # dados estruturados
    print(res.media)         # URLs de imagens/videos gerados

Toda funcao e `async`, nunca levanta excecao (devolve `ToolResult(ok=False)`)
e respeita cache/timeouts definidos em `app/tools/base.py`.
"""
from __future__ import annotations

import asyncio

from app.tools.base import ToolResult, safe_tool
from app.tools.geophysics import check_seismic_activity, get_volcano_report
from app.tools.noaa import fetch_noaa_data, get_noaa_media
from app.tools.solar import get_solar_status
from app.tools.space import get_asteroid_report, get_asteroid_trajectory, track_iss
from app.tools.tactical import (
    capture_sentinel, get_frontline_report, get_pizzint_status, get_war_snapshot,
)
from app.tools.traffic import scan_radar_feeds, scan_radio_stations
from app.tools.weather import get_weather


@safe_tool("get_situation_report", timeout=90)
async def get_situation_report() -> ToolResult:
    """Painel geral (sismos, vulcoes, sol, asteroides, ISS) em paralelo.
    Cada parte falha isoladamente -- o relatorio sai com o que estiver disponivel."""
    parts = await asyncio.gather(
        check_seismic_activity(limit=3), get_volcano_report(limit=3),
        get_solar_status(), get_asteroid_report(), track_iss(),
    )
    ok = [p for p in parts if p.ok]
    text = "\n\n━━━━━━━━━━━━━━\n\n".join(p.text for p in parts)
    media = [m for p in ok for m in p.media]
    return ToolResult(
        bool(ok), "get_situation_report", text, media=media, source="múltiplas",
        error=None if len(ok) == len(parts) else f"{len(parts) - len(ok)} fonte(s) indisponível(is)",
        data={p.tool: p.data if p.ok else {"error": p.error} for p in parts},
    )


__all__ = [
    "check_seismic_activity", "get_volcano_report", "fetch_noaa_data", "get_noaa_media",
    "get_solar_status", "get_asteroid_report", "get_asteroid_trajectory", "track_iss",
    "capture_sentinel", "get_frontline_report", "get_pizzint_status", "get_war_snapshot",
    "scan_radar_feeds", "scan_radio_stations", "get_weather", "get_situation_report",
]
