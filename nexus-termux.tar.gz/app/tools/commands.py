"""
Comandos de chat do J.A.R.V.I.S.

* Comando direto:      "/sismo strong 3", "/clima Dourados MS", "/radar Campo Grande 200"
* Linguagem natural:   "teve algum terremoto hoje?", "como esta o clima em Ivinhema MS?"
                       (so quando chamado via `match_intent`, nunca por padrao no /api/chat)

Funcoes puras (sem I/O) -> faceis de testar.
"""
from __future__ import annotations

import re
import unicodedata
from dataclasses import dataclass, field
from typing import Any, Optional

from app.tools.registry import TOOLS, ToolSpec, get_spec


@dataclass
class Invocation:
    tool: str
    args: dict[str, Any] = field(default_factory=dict)
    via: str = "command"        # command | intent


def _norm(text: str) -> str:
    t = unicodedata.normalize("NFKD", text or "")
    return "".join(c for c in t if not unicodedata.combining(c)).lower().strip()


_COMMAND_INDEX: dict[str, str] = {}
for _t in TOOLS:
    for _c in _t.commands:
        _COMMAND_INDEX.setdefault(_c, _t.name)

# Comandos que fixam um parametro (ex.: /sdo -> kind=sdo)
_PRESETS: dict[str, dict[str, Any]] = {
    "sdo": {"kind": "sdo"}, "cme": {"kind": "cme"}, "drap": {"kind": "drap"}, "enlil": {"kind": "enlil"},
    "terremoto": {}, "defcon": {},
}


def _uint(tok: str) -> Optional[int]:
    """Inteiro nao negativo so com digitos ASCII (str.isdigit() aceita '²' e '٣', e int() quebra neles;
    o teto de 9 digitos evita o limite de conversao de int gigante)."""
    return int(tok) if tok.isascii() and tok.isdigit() and len(tok) <= 9 else None


def _args_for(spec: ToolSpec, rest: str) -> dict[str, Any]:
    """Converte o texto depois do comando em argumentos, conforme a ferramenta."""
    rest = rest.strip()
    n = spec.name
    if not rest:
        return {}
    if n == "check_seismic_activity":
        a: dict[str, Any] = {}
        for tok in rest.split():
            nt = _norm(tok)
            if _uint(tok) is not None:
                a["limit"] = _uint(tok)
            elif nt in ("forte", "fortes", "strong"):
                a["level"] = "strong"
            elif nt in ("significativo", "significativos", "significant"):
                a["level"] = "significant"
        return a
    if n == "scan_radar_feeds":
        m = re.match(r"^(.*?)(?:\s+(\d{2,3})(?:\s*km)?)?$", rest)
        loc, radius = (m.group(1).strip(), m.group(2)) if m else (rest, None)
        return {k: v for k, v in (("location", loc), ("radius_km", radius)) if v}
    if n == "scan_radio_stations":
        parts = rest.split()
        a = {"mode": parts[0]}
        if len(parts) > 1 and _uint(parts[1]) is not None:
            a["limit"] = _uint(parts[1])
        return a
    if n == "get_frontline_report":
        parts = rest.split()
        a = {"theater": parts[0]}
        if len(parts) > 1 and _uint(parts[1]) is not None:
            a["limit"] = _uint(parts[1])
        return a
    if n == "get_noaa_media":
        parts = rest.split()
        a = {"kind": _norm(parts[0])}
        if len(parts) > 1:
            a["band"] = parts[1].upper()
        return a
    # ferramentas com UM parametro de texto: o resto inteiro e o valor (cidades com espaco etc.)
    first = spec.params[0] if spec.params else None
    if first is not None:
        return {first.name: _uint(rest) if first.type == "integer" and _uint(rest) is not None else rest}
    return {}


def parse_command(text: str) -> Optional[Invocation]:
    """'/sismo strong 3' -> Invocation. None se nao for comando conhecido."""
    t = (text or "").strip()
    if not t or t[0] not in "/!":
        return None
    head, _, rest = t[1:].partition(" ")
    cmd = _norm(head).split("@")[0]  # aceita /sismo@bot
    tool = _COMMAND_INDEX.get(cmd)
    if tool is None:
        return None
    spec = get_spec(tool)
    args = {**_PRESETS.get(cmd, {}), **_args_for(spec, rest)}
    return Invocation(tool, args, "command")


# --------------------------------------------------------------------------- #
# Linguagem natural (heuristica por palavras-chave; conservadora de proposito)
# --------------------------------------------------------------------------- #
_PLACE = re.compile(r"\b(?:em|de|para|perto de|ao redor de|sobre)\s+([a-z0-9 \-']{2,60}?)\s*[?.!]*$")


def match_intent(text: str) -> Optional[Invocation]:
    """Devolve a ferramenta mais provavel ou None (conversa comum segue para o LLM).

    Exige correspondencia de palavra INTEIRA e ignora ferramentas pesadas/sensiveis
    (camera, navegador, ffmpeg) -- essas so por comando explicito."""
    n = " " + _norm(text) + " "
    if len(n) < 6:
        return None
    best: tuple[int, ToolSpec] | None = None
    for spec in TOOLS:
        if spec.sensitive or spec.heavy:
            continue
        for kw in spec.keywords:
            if re.search(rf"(?<![a-z0-9]){re.escape(kw.strip())}", n):
                score = len(kw)
                if best is None or score > best[0]:
                    best = (score, spec)
    if best is None:
        return None
    spec = best[1]
    args: dict[str, Any] = {}
    if spec.name in ("get_weather", "scan_radar_feeds"):
        m = _PLACE.search(n.strip())
        if m:
            args["city" if spec.name == "get_weather" else "location"] = m.group(1).strip().title()
    elif spec.name == "check_seismic_activity" and re.search(r"\b(forte|fortes|grande|grandes)\b", n):
        args["level"] = "strong"
    return Invocation(spec.name, args, "intent")


def help_text() -> str:
    by_cat: dict[str, list[ToolSpec]] = {}
    for t in TOOLS:
        by_cat.setdefault(t.category, []).append(t)
    lines = ["🛠️ **Ferramentas do J.A.R.V.I.S.** (use `/comando`)"]
    for cat, specs in by_cat.items():
        lines.append(f"\n**{cat.upper()}**")
        for t in specs:
            flag = " 🔒" if t.sensitive else (" ⚙️" if t.heavy else "")
            lines.append(f"• `/{t.commands[0]}` — {t.description}{flag}")
    lines.append("\n⚙️ = exige recurso extra (navegador/ffmpeg) · 🔒 = exige token e opt-in")
    return "\n".join(lines)
