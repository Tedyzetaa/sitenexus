"""
Defesa e Espacial  (legado: astro_defense.py, orbital_system.py, orbital_trajectory.py)

* get_asteroid_report()     -> NASA NeoWs: objetos proximos da Terra hoje
* track_iss()               -> posicao da ISS + mapa + alerta "sobre o Brasil"
* get_asteroid_trajectory() -> grafico 3D da orbita (elementos do JPL SBDB, calculado localmente)
"""
from __future__ import annotations

import re
import time
from datetime import datetime, timezone
from typing import Optional

from app.config import settings
from app.tools.base import (
    ExternalServiceError, ToolError, ToolResult, cached, http_get, http_json, new_media_file,
    render_figure, safe_float, safe_tool,
)
from app.tools import orbit

NEO_URL = "https://api.nasa.gov/neo/rest/v1/feed"
ISS_URLS = [
    ("open-notify", "http://api.open-notify.org/iss-now.json"),  # so oferece http
    ("wheretheiss.at", "https://api.wheretheiss.at/v1/satellites/25544"),
]
SBDB_URL = "https://ssd-api.jpl.nasa.gov/sbdb.api"

# Caixa aproximada do Brasil (lat -33..+5, lon -74..-34)
_BR = (-33.0, 5.0, -74.0, -34.0)


# --------------------------------------------------------------------------- #
# Asteroides (NASA NeoWs)
# --------------------------------------------------------------------------- #
def parse_neo_feed(data: dict, day: str, top_n: int = 3) -> dict:
    """Pura/testavel. Tolerante a campos ausentes (o legado dava KeyError)."""
    objects = (data.get("near_earth_objects") or {}).get(day) or []
    count = int(data.get("element_count") or len(objects))

    def diameter(o: dict) -> float:
        return safe_float(
            (((o.get("estimated_diameter") or {}).get("meters")) or {}).get("estimated_diameter_max"), 0.0
        ) or 0.0

    top = []
    for o in sorted(objects, key=diameter, reverse=True)[:top_n]:
        approach = (o.get("close_approach_data") or [{}])[0]
        top.append({
            "id": str(o.get("id", "")),
            "name": o.get("name", "desconhecido"),
            "diameter_m": round(diameter(o)),
            "hazardous": bool(o.get("is_potentially_hazardous_asteroid")),
            "velocity_kmh": safe_float((approach.get("relative_velocity") or {}).get("kilometers_per_hour"), 0.0),
            "miss_distance_km": safe_float((approach.get("miss_distance") or {}).get("kilometers"), 0.0),
        })
    return {"date": day, "count": count, "top": top}


@safe_tool("get_asteroid_report")
async def get_asteroid_report() -> ToolResult:
    day = datetime.now(timezone.utc).strftime("%Y-%m-%d")  # NeoWs trabalha em UTC

    async def fetch():
        return await http_json(
            "NASA NeoWs", NEO_URL,
            params={"start_date": day, "end_date": day, "api_key": settings.NASA_API_KEY},
        )

    raw, hit = await cached(f"neo:{day}", fetch, ttl=3600)
    info = parse_neo_feed(raw, day)

    lines = ["☄️ **DEFESA PLANETÁRIA (NASA)**", f"📅 Data (UTC): {day}", f"🛡️ Objetos próximos: {info['count']}"]
    for a in info["top"]:
        icon = "⚠️" if a["hazardous"] else "🪨"
        lines.append(
            f"\n{icon} **{a['name']}** (ID: {a['id']})\n"
            f"   📏 ~{a['diameter_m']} m | 🚀 {int(a['velocity_kmh'] or 0):,} km/h\n"
            f"   📡 Distância: {int(a['miss_distance_km'] or 0):,} km"
        )
    if not info["top"]:
        lines.append("\nNenhum objeto listado para hoje.")
    lines.append("\n_Fonte: NASA/JPL (NeoWs)_")
    if settings.NASA_API_KEY == "DEMO_KEY":
        lines.append("_Usando DEMO_KEY (limite baixo). Defina NASA_API_KEY no .env._")

    principal = info["top"][0] if info["top"] else None
    return ToolResult(True, "get_asteroid_report", "\n".join(lines),
                      data={**info, "principal": principal}, source="NASA NeoWs", cached=hit)


# --------------------------------------------------------------------------- #
# ISS
# --------------------------------------------------------------------------- #
def over_brazil(lat: float, lon: float) -> bool:
    return _BR[0] <= lat <= _BR[1] and _BR[2] <= lon <= _BR[3]


async def _fetch_iss() -> tuple[float, float, str]:
    last: Optional[Exception] = None
    for name, url in ISS_URLS:
        try:
            d = await http_json(name, url, retries=1)
            if "iss_position" in d:
                return float(d["iss_position"]["latitude"]), float(d["iss_position"]["longitude"]), name
            return float(d["latitude"]), float(d["longitude"]), name
        except (ExternalServiceError, KeyError, TypeError, ValueError) as exc:
            last = exc
    raise ExternalServiceError("Rastreio da ISS", f"todas as fontes falharam ({last})")


def _draw_iss(fig, lat: float, lon: float) -> None:
    ax = fig.add_subplot(111)
    ax.set_facecolor("black")
    ax.plot(lon, lat, marker="o", color="#00ffff", markersize=15)
    ax.text(lon, lat + 6, "ISS", color="#00ffff", ha="center", fontsize=9)
    ax.set_xlim(-180, 180)
    ax.set_ylim(-90, 90)
    ax.grid(True, color="#003366", linestyle="--", alpha=0.5)
    ax.axhline(0, color="#004488", linewidth=1)
    ax.axvline(0, color="#004488", linewidth=1)
    ax.tick_params(colors="#66aaff")
    ax.set_title("ORBITAL TRACKER", color="#00ffff")


@safe_tool("track_iss")
async def track_iss() -> ToolResult:
    (lat, lon, src), hit = await cached("iss", _fetch_iss, ttl=10)
    brazil = over_brazil(lat, lon)
    status = "⚠️ ALERTA: ISS SOBRE O BRASIL!" if brazil else "ISS em órbita padrão."

    media: list[str] = []
    path, url = new_media_file("iss", "png")
    if await render_figure(lambda fig: _draw_iss(fig, lat, lon), path, size=(8, 4)):
        media.append(url)

    text = f"🛰️ **TELEMETRIA ORBITAL**\nLat: {lat:.3f}\nLon: {lon:.3f}\n{status}"
    return ToolResult(True, "track_iss", text, data={"lat": lat, "lon": lon, "over_brazil": brazil},
                      media=media, source=src, cached=hit)


# --------------------------------------------------------------------------- #
# Trajetoria 3D (JPL SBDB + calculo local; sem navegador, sem scraping)
# --------------------------------------------------------------------------- #
def make_slug(raw_name: str) -> str:
    """'2340 Hathor (1976 UA)' -> '2340-hathor'; '(2022 SU)' -> '2022-su'. Saida [a-z0-9-]."""
    name = re.sub(r"\s*\(.*?\)", "", raw_name or "").strip()
    if not name:
        m = re.search(r"\((.*?)\)", raw_name or "")
        name = m.group(1) if m else (raw_name or "")
    return re.sub(r"[^a-z0-9-]", "", name.lower().replace(" ", "-")).strip("-")


def sbdb_query_name(raw_name: str) -> str:
    """Nome no formato que o SBDB entende: '(2012 PP28)' -> '2012 PP28'; '433 Eros (A898 PA)' -> '433 Eros'."""
    raw = (raw_name or "").strip()
    m = re.fullmatch(r"\((.+)\)", raw)
    if m:
        return m.group(1).strip()
    return re.sub(r"\s*\(.*?\)\s*$", "", raw).strip() or raw


def _draw_orbit(fig, el: "orbit.Elements", ast_pos, earth_pos, name: str) -> None:
    ax = fig.add_subplot(111, projection="3d")
    ax.set_facecolor("black")
    for axis in (ax.xaxis, ax.yaxis, ax.zaxis):
        axis.set_pane_color((0, 0, 0, 1))
        axis.label.set_color("#66aaff")
    ax.tick_params(colors="#66aaff", labelsize=7)

    e_path = orbit.orbit_path(orbit.EARTH)
    a_path = orbit.orbit_path(el)
    ax.plot(*zip(*e_path), color="#3399ff", linewidth=1.2, label="Terra")
    ax.plot(*zip(*a_path), color="#ff9933", linewidth=1.2, label="Asteroide")
    ax.scatter([0], [0], [0], color="#ffee33", s=120, label="Sol")
    ax.scatter(*[[c] for c in earth_pos], color="#3399ff", s=40)
    ax.scatter(*[[c] for c in ast_pos], color="#ff5533", s=50)
    ax.text(ast_pos[0], ast_pos[1], ast_pos[2], "  " + name, color="#ff9933", fontsize=8)

    lim = max(el.aphelion, 1.2) * 1.05
    ax.set_xlim(-lim, lim); ax.set_ylim(-lim, lim); ax.set_zlim(-lim / 2, lim / 2)
    ax.set_xlabel("UA"); ax.set_ylabel("UA"); ax.set_zlabel("UA")
    ax.view_init(elev=28, azim=-62)
    ax.set_title(f"Órbita de {name}", color="#00ffff")
    ax.legend(loc="upper left", fontsize=7, facecolor="black", labelcolor="white", framealpha=0.6)


async def _fetch_elements(candidates: list[str]) -> tuple["orbit.Elements", str]:
    last_error = "objeto nao encontrado no JPL SBDB"
    for q in candidates:
        resp = await http_get("JPL SBDB", SBDB_URL, params={"sstr": q}, allow_status=(300, 404))
        try:
            data = resp.json()
        except ValueError:
            continue
        if "orbit" not in data:
            continue  # 404 / varios candidatos (300): tenta o proximo nome
        try:
            fullname = (data.get("object") or {}).get("fullname") or q
            return orbit.parse_sbdb(data), str(fullname)
        except ValueError as exc:
            last_error = str(exc)
    raise ToolError(f"Nao consegui os elementos orbitais de '{candidates[0]}' ({last_error}).")


@safe_tool("get_asteroid_trajectory", timeout=60)
async def get_asteroid_trajectory(asteroid_name: Optional[str] = None) -> ToolResult:
    """Sem `asteroid_name`, usa o maior objeto do relatorio NASA de hoje."""
    candidates: list[str] = []
    if asteroid_name:
        candidates.append(sbdb_query_name(asteroid_name))
    else:
        rep = await get_asteroid_report()
        principal = rep.data.get("principal") if rep.ok else None
        if not principal:
            raise ToolError("Nao foi possivel descobrir o asteroide principal de hoje.")
        asteroid_name = principal["name"]
        candidates += [sbdb_query_name(asteroid_name), str(principal.get("id", ""))]
    candidates = [c for c in candidates if c and re.fullmatch(r"[\w .\-/]{1,60}", c)]
    if not candidates:
        raise ToolError("Nome de asteroide invalido.")

    async def fetch():
        return await _fetch_elements(candidates)

    (el, fullname), hit = await cached(f"sbdb:{candidates[0].lower()}", fetch, ttl=6 * 3600)

    jd = orbit.unix_to_jd(time.time())
    ast, earth = orbit.position_at(el, jd), orbit.position_at(orbit.EARTH, jd)
    sun_au = sum(c * c for c in ast) ** 0.5
    earth_km = orbit.distance(ast, earth) * orbit.AU_KM

    media: list[str] = []
    path, url = new_media_file("astro_orbit", "png")
    label = sbdb_query_name(asteroid_name)
    if await render_figure(lambda fig: _draw_orbit(fig, el, ast, earth, label), path, size=(8, 7)):
        media.append(url)

    text = (
        f"🌌 **Órbita 3D de {fullname}**\n"
        f"☀️ Periélio {el.perihelion:.2f} UA · Afélio {el.aphelion:.2f} UA · Período {el.period_days / 365.25:.2f} anos\n"
        f"📐 Inclinação {el.i:.1f}° · Excentricidade {el.e:.3f}\n"
        f"📍 Agora: {sun_au:.2f} UA do Sol, ~{earth_km:,.0f} km da Terra (estimativa)\n"
        f"_Fonte: JPL SBDB. Modelo kepleriano de dois corpos — posição aproximada, sem perturbações planetárias._"
    )
    return ToolResult(True, "get_asteroid_trajectory", text,
                      data={"name": fullname, "a": el.a, "e": el.e, "i": el.i,
                            "distance_sun_au": round(sun_au, 4), "distance_earth_km": round(earth_km)},
                      media=media, source="JPL SBDB", cached=hit)
