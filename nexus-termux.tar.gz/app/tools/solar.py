"""
Monitor solar  (legado: solar_monitor.py + simple_solar_monitor.py)

O legado era um dashboard Tkinter (janelas, matplotlib TkAgg, threads) preso a
uma API de `NOAAService` (register_alert_callback, SpaceWeatherData...) que NAO
existe no noaa_service.py v3.0 enviado. Nao ha como rodar GUI dentro do Nexus,
entao foi portada apenas a LOGICA reutilizavel (indices de atividade, tendencia,
niveis), alimentada pelos dados reais de app/tools/noaa.py.

Os percentuais sao indices HEURISTICOS do monitor original -- nao sao a
previsao oficial da NOAA (esta vem em `fetch_noaa_data("forecast")`).
"""
from __future__ import annotations

import math
from typing import Optional

from app.tools.base import ToolResult, cached, safe_tool
from app.tools.noaa import collect_intel


def flare_probability(peak_flux: Optional[float]) -> float:
    """Escala do legado: min(log10(fluxo/1e-8) * 20, 100) -> C1~40, M1~60, X1~80."""
    if not peak_flux or peak_flux <= 0:
        return 0.0
    return max(0.0, min(math.log10(peak_flux / 1e-8) * 20, 100.0))


def cme_probability(wind_speed: Optional[float], peak_class: str) -> float:
    prob = 0.0
    if wind_speed and wind_speed > 600:
        prob += min((wind_speed - 600) / 2, 50)
    if peak_class in ("M", "X"):
        prob += 10
    return min(prob, 100.0)


def kp_trend(series: list[float]) -> str:
    """Mesma regra do legado (+-20% entre a primeira e a ultima leitura recente)."""
    if len(series) < 2 or series[0] <= 0:
        return "estável"
    if series[-1] > series[0] * 1.2:
        return "subindo"
    if series[-1] < series[0] * 0.8:
        return "caindo"
    return "estável"


def overall(flare_p: float, cme_p: float) -> str:
    if flare_p > 70 or cme_p > 70:
        return "ALTA"
    if flare_p > 40 or cme_p > 40:
        return "MODERADA"
    return "BAIXA"


@safe_tool("get_solar_status", timeout=60)
async def get_solar_status() -> ToolResult:
    intel, hit = await cached("noaa:intel", collect_intel, ttl=120)
    xray, kp, wind = intel["goes_xray"], intel["kp_index"], intel["solar_wind"]

    fp = flare_probability(xray.get("pico_6h_Wm2"))
    cp = cme_probability(wind.get("velocidade_km_s"), xray.get("classe_pico_6h", "A"))
    trend = kp_trend(kp.get("serie_recente") or [])
    level = overall(fp, cp)

    text = (
        f"☀️ **STATUS SOLAR** — atividade **{level}**\n"
        f"• Flare: classe {xray.get('classe_flare', 'N/A')} agora, pico 6h {xray.get('classe_pico_6h', 'N/A')} "
        f"(índice heurístico {fp:.0f}%)\n"
        f"• Ejeção de massa coronal (CME): índice heurístico {cp:.0f}%\n"
        f"• Geomagnetismo: Kp {kp.get('kp_atual', 'n/d')} — {kp.get('nivel', 'n/d')} (tendência {trend})\n"
        f"• Estado geral NOAA: {intel['estado_geral']}\n"
        f"_Índices heurísticos do monitor solar original; previsão oficial: comando 'noaa previsão'._"
    )
    return ToolResult(True, "get_solar_status", text, source="NOAA SWPC", cached=hit, data={
        "activity": level, "flare_index": round(fp, 1), "cme_index": round(cp, 1), "kp_trend": trend,
        "flare_class": xray.get("classe_flare"), "peak_class_6h": xray.get("classe_pico_6h"),
        "kp": kp.get("kp_atual"), "state": intel["estado_geral"], "score": intel["score_alerta"],
    })
