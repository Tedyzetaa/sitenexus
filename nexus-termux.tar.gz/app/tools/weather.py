"""
Clima local  (legado: weather_system.py)  ->  OpenWeatherMap (HTTPS, async)

get_weather("Ivinhema MS") tenta variacoes "cidade,Estado,BR" -> "cidade,sigla,BR"
-> "cidade,BR" -> texto cru, como a versao original.
"""
from __future__ import annotations

from typing import Optional

from app.config import settings
from app.tools.base import ToolError, ToolResult, ToolUnavailableError, cached, http_get, safe_tool

OWM_URL = "https://api.openweathermap.org/data/2.5/weather"

UF = {
    "ac": "Acre", "al": "Alagoas", "ap": "Amapá", "am": "Amazonas", "ba": "Bahia", "ce": "Ceará",
    "df": "Distrito Federal", "es": "Espírito Santo", "go": "Goiás", "ma": "Maranhão",
    "mt": "Mato Grosso", "ms": "Mato Grosso do Sul", "mg": "Minas Gerais", "pa": "Pará",
    "pb": "Paraíba", "pr": "Paraná", "pe": "Pernambuco", "pi": "Piauí", "rj": "Rio de Janeiro",
    "rn": "Rio Grande do Norte", "rs": "Rio Grande do Sul", "ro": "Rondônia", "rr": "Roraima",
    "sc": "Santa Catarina", "sp": "São Paulo", "se": "Sergipe", "to": "Tocantins",
}


def build_queries(user_input: str) -> list[str]:
    parts = user_input.strip().lower().split()
    queries: list[str] = []
    if len(parts) > 1 and parts[-1] in UF:
        city = " ".join(parts[:-1])
        queries += [f"{city},{UF[parts[-1]]},BR", f"{city},{parts[-1]},BR"]
    queries += [f"{user_input.strip()},BR", user_input.strip()]
    return list(dict.fromkeys(queries))  # sem duplicatas, preserva ordem


@safe_tool("get_weather")
async def get_weather(city: Optional[str] = None) -> ToolResult:
    if not settings.OPENWEATHER_API_KEY:
        raise ToolUnavailableError("OPENWEATHER_API_KEY nao configurada no .env.")
    city = (city or settings.TOOLS_HOME_NAME).strip()
    if not city or len(city) > 80:
        raise ToolError("Informe um nome de cidade valido (ate 80 caracteres).")

    async def lookup():
        for q in build_queries(city):
            resp = await http_get(
                "OpenWeather", OWM_URL, allow_status=(404,),
                params={"q": q, "appid": settings.OPENWEATHER_API_KEY, "units": "metric", "lang": "pt_br"},
            )
            if resp.status_code == 200:
                return resp.json()
        return None

    # 401 (chave invalida) cai em ExternalServiceError("HTTP 401") dentro do http_get.
    data, hit = await cached(f"weather:{city.lower()}", lookup, ttl=300)
    if not data:
        raise ToolError(f"Alvo '{city}' não localizado. Tente no formato 'Ivinhema MS'.")

    main, wind = data.get("main") or {}, data.get("wind") or {}
    desc = ((data.get("weather") or [{}])[0].get("description") or "n/d").capitalize()
    name, country = data.get("name", city), (data.get("sys") or {}).get("country", "")
    wind_kmh = (wind.get("speed") or 0) * 3.6
    text = (
        f"🌦️ **TELEMETRIA ATMOSFÉRICA: {name.upper()} ({country})**\n"
        f"🌡️ Temperatura: {main.get('temp', float('nan')):.1f}°C (sensação {main.get('feels_like', float('nan')):.1f}°C)\n"
        f"☁️ Condição: {desc}\n💧 Umidade: {main.get('humidity', 'n/d')}%\n💨 Vento: {wind_kmh:.1f} km/h"
    )
    return ToolResult(True, "get_weather", text, source="OpenWeatherMap", cached=hit, data={
        "city": name, "country": country, "temp_c": main.get("temp"), "feels_like_c": main.get("feels_like"),
        "humidity": main.get("humidity"), "wind_kmh": round(wind_kmh, 1), "description": desc,
    })
