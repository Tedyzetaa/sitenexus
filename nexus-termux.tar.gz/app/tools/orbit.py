"""Mecanica orbital kepleriana (sem dependencias externas).

Usa os elementos orbitais do JPL SBDB para desenhar a orbita de um asteroide. E um modelo de
DOIS CORPOS (Sol + objeto): ignora perturbacoes planetarias, entao a posicao e aproximada --
boa para visualizacao, nao para navegacao.
"""
from __future__ import annotations

import math
from dataclasses import dataclass
from typing import Any

J2000 = 2451545.0
AU_KM = 149_597_870.7


@dataclass(frozen=True)
class Elements:
    a: float      # semieixo maior (UA)
    e: float      # excentricidade
    i: float      # inclinacao (graus)
    om: float     # longitude do nodo ascendente (graus)
    w: float      # argumento do periélio (graus)
    ma: float     # anomalia media na epoca (graus)
    epoch: float  # epoca (JD)
    n: float      # movimento medio (graus/dia)

    @property
    def perihelion(self) -> float:
        return self.a * (1 - self.e)

    @property
    def aphelion(self) -> float:
        return self.a * (1 + self.e)

    @property
    def period_days(self) -> float:
        return 360.0 / self.n


# Terra (elementos medios, J2000; om=0 e w = longitude do perihelio)
EARTH = Elements(a=1.00000261, e=0.01671123, i=0.0, om=0.0, w=102.93768, ma=357.52911,
                 epoch=J2000, n=0.98560028)


def parse_sbdb(data: dict[str, Any]) -> Elements:
    """Extrai Elements da resposta de https://ssd-api.jpl.nasa.gov/sbdb.api. ValueError se invalida."""
    orbit = data.get("orbit") or {}
    raw = {str(el.get("name")): el.get("value") for el in orbit.get("elements") or []}
    try:
        a, e = float(raw["a"]), float(raw["e"])
        i, om, w, ma = (float(raw[k]) for k in ("i", "om", "w", "ma"))
        epoch = float(orbit["epoch"])
    except (KeyError, TypeError, ValueError) as exc:
        raise ValueError("elementos orbitais ausentes ou invalidos") from exc
    if not (0 <= e < 1) or a <= 0:
        raise ValueError("orbita nao elíptica (hiperbolica/parabolica)")
    try:
        n = float(raw["n"])
    except (KeyError, TypeError, ValueError):
        n = 0.9856076686014 / a ** 1.5  # lei de Kepler, graus/dia
    return Elements(a, e, i, om, w, ma, epoch, n)


def solve_kepler(mean_anomaly_deg: float, e: float) -> float:
    """Anomalia excentrica (rad) por Newton-Raphson."""
    m = math.radians(mean_anomaly_deg % 360.0)
    if m > math.pi:
        m -= 2 * math.pi
    big_e = m if e < 0.8 else math.pi
    for _ in range(60):
        delta = (big_e - e * math.sin(big_e) - m) / (1 - e * math.cos(big_e))
        big_e -= delta
        if abs(delta) < 1e-12:
            break
    return big_e


def _rotate(el: Elements, xo: float, yo: float) -> tuple[float, float, float]:
    ci, si = math.cos(math.radians(el.i)), math.sin(math.radians(el.i))
    co, so = math.cos(math.radians(el.om)), math.sin(math.radians(el.om))
    cw, sw = math.cos(math.radians(el.w)), math.sin(math.radians(el.w))
    x = xo * (cw * co - sw * so * ci) - yo * (sw * co + cw * so * ci)
    y = xo * (cw * so + sw * co * ci) + yo * (cw * co * ci - sw * so)
    z = xo * (sw * si) + yo * (cw * si)
    return x, y, z


def _from_eccentric(el: Elements, big_e: float) -> tuple[float, float, float]:
    xo = el.a * (math.cos(big_e) - el.e)
    yo = el.a * math.sqrt(1 - el.e ** 2) * math.sin(big_e)
    return _rotate(el, xo, yo)


def position_at(el: Elements, jd: float) -> tuple[float, float, float]:
    """Posicao heliocentrica eclíptica (UA) na data juliana `jd`."""
    mean = el.ma + el.n * (jd - el.epoch)
    return _from_eccentric(el, solve_kepler(mean, el.e))


def orbit_path(el: Elements, points: int = 360) -> list[tuple[float, float, float]]:
    return [_from_eccentric(el, 2 * math.pi * k / points) for k in range(points + 1)]


def distance(p: tuple[float, float, float], q: tuple[float, float, float]) -> float:
    return math.dist(p, q)


def unix_to_jd(ts: float) -> float:
    return ts / 86400.0 + 2440587.5
