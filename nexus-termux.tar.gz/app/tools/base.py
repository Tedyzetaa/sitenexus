"""
Infraestrutura comum das ferramentas do J.A.R.V.I.S.

Garantias que TODA ferramenta herda daqui:

* Nunca levanta excecao para o chamador: `@safe_tool` converte qualquer falha
  (rede, timeout, JSON invalido, bug) em `ToolResult(ok=False, ...)`.
  Falha de servico externo NAO derruba o Nexus nem o loop do bot.
* Nunca bloqueia o event loop: HTTP via `httpx.AsyncClient`; matplotlib,
  OpenCV e afins rodam em `asyncio.to_thread`.
* Cache TTL curto + single-flight por chave: varias perguntas iguais em
  sequencia viram UMA chamada ao servico externo (OpenSky/USGS/NOAA tem rate limit).
* Arquivos gerados tem nome unico (sem corrida entre chamadas concorrentes) e
  expiram sozinhos.
"""
from __future__ import annotations

import asyncio
import functools
import logging
import re
import time
import uuid
from dataclasses import asdict, dataclass, field
from pathlib import Path
from typing import Any, Awaitable, Callable, Optional

import httpx

from app.config import settings

logger = logging.getLogger("nexus.tools")

_USER_AGENT = "NexusBridge-JARVIS/1.0 (+personal assistant; contact: owner)"


# --------------------------------------------------------------------------- #
# Erros
# --------------------------------------------------------------------------- #
class ToolError(Exception):
    """Falha ESPERADA (mensagem ja e amigavel e pode ir para o chat)."""


class ToolUnavailableError(ToolError):
    """Ferramenta desligada/sem dependencia/sem credencial (nao e bug)."""


class ExternalServiceError(ToolError):
    """Servico externo (USGS, NOAA, OpenSky...) falhou apos os retries."""

    def __init__(self, service: str, detail: str):
        super().__init__(f"{service} indisponivel no momento ({detail}).")
        self.service = service


# --------------------------------------------------------------------------- #
# Resultado padronizado
# --------------------------------------------------------------------------- #
@dataclass
class ToolResult:
    ok: bool
    tool: str
    text: str                                   # relatorio pronto para o chat (pt-BR)
    data: dict[str, Any] = field(default_factory=dict)
    media: list[str] = field(default_factory=list)   # URLs servidas por /api/v1/tools/media/...
    source: str = ""
    error: Optional[str] = None
    cached: bool = False
    elapsed_ms: int = 0

    def to_dict(self) -> dict[str, Any]:
        return asdict(self)

    @classmethod
    def failure(cls, tool: str, message: str, **kw: Any) -> "ToolResult":
        return cls(ok=False, tool=tool, text=f"⚠️ {message}", error=message, **kw)


# --------------------------------------------------------------------------- #
# HTTP async compartilhado
# --------------------------------------------------------------------------- #
_client: Optional[httpx.AsyncClient] = None


def _get_client() -> httpx.AsyncClient:
    global _client
    if _client is None or _client.is_closed:
        _client = httpx.AsyncClient(
            headers={"User-Agent": _USER_AGENT},
            timeout=httpx.Timeout(settings.TOOLS_HTTP_TIMEOUT_S),
            follow_redirects=True,
            limits=httpx.Limits(max_connections=20, max_keepalive_connections=5),
        )
    return _client


async def close_http() -> None:
    """Chamar no shutdown da aplicacao."""
    global _client
    if _client is not None and not _client.is_closed:
        await _client.aclose()
    _client = None


async def http_get(
    service: str,
    url: str,
    *,
    params: Optional[dict[str, Any]] = None,
    headers: Optional[dict[str, str]] = None,
    timeout: Optional[float] = None,
    retries: Optional[int] = None,
    max_bytes: int = 50_000_000,
    allow_status: tuple[int, ...] = (),
) -> httpx.Response:
    """GET com retry/backoff em erro de rede, 429 e 5xx.

    `allow_status`: codigos 4xx que o chamador quer tratar sozinho (ex.: 404 =
    "cidade nao encontrada") -- voltam como resposta normal, sem excecao.
    Levanta `ExternalServiceError` (nunca httpx cru) -> mensagem limpa para o chat.
    """
    attempts = 1 + (settings.TOOLS_HTTP_RETRIES if retries is None else retries)
    last = "erro desconhecido"
    for i in range(attempts):
        try:
            resp = await _get_client().get(
                url, params=params, headers=headers,
                timeout=timeout or settings.TOOLS_HTTP_TIMEOUT_S,
            )
            if resp.status_code in allow_status:
                return resp
            if resp.status_code == 429 or resp.status_code >= 500:
                last = f"HTTP {resp.status_code}"
            elif resp.status_code >= 400:
                # 4xx (exceto 429) nao melhora com retry
                raise ExternalServiceError(service, f"HTTP {resp.status_code}")
            else:
                if len(resp.content) > max_bytes:
                    raise ExternalServiceError(service, "resposta grande demais")
                return resp
        except ExternalServiceError:
            raise
        except httpx.TimeoutException:
            last = "timeout"
        except httpx.HTTPError as exc:
            last = type(exc).__name__
        if i < attempts - 1:
            await asyncio.sleep(0.6 * (2 ** i))
    logger.warning("[%s] falhou apos %d tentativa(s): %s (%s)", service, attempts, last, url)
    raise ExternalServiceError(service, last)


async def http_json(service: str, url: str, **kw: Any) -> Any:
    resp = await http_get(service, url, **kw)
    try:
        return resp.json()
    except ValueError as exc:
        raise ExternalServiceError(service, "resposta nao e JSON valido") from exc


# --------------------------------------------------------------------------- #
# Cache TTL com single-flight
# --------------------------------------------------------------------------- #
_cache: dict[str, tuple[float, Any]] = {}
_locks: dict[str, asyncio.Lock] = {}
_CACHE_MAX = 256


async def cached(key: str, factory: Callable[[], Awaitable[Any]], ttl: Optional[float] = None) -> tuple[Any, bool]:
    """Retorna (valor, veio_do_cache). So guarda resultados de SUCESSO (excecao nao entra)."""
    ttl = settings.TOOLS_CACHE_TTL_S if ttl is None else ttl
    now = time.monotonic()
    hit = _cache.get(key)
    if ttl > 0 and hit and hit[0] > now:
        return hit[1], True
    lock = _locks.setdefault(key, asyncio.Lock())
    async with lock:
        hit = _cache.get(key)
        if ttl > 0 and hit and hit[0] > time.monotonic():
            return hit[1], True
        value = await factory()
        if ttl > 0:
            if len(_cache) >= _CACHE_MAX:
                for k in [k for k, (exp, _) in _cache.items() if exp <= time.monotonic()] or [next(iter(_cache))]:
                    _cache.pop(k, None)
            _cache[key] = (time.monotonic() + ttl, value)
        return value, False


def clear_cache() -> None:
    _cache.clear()


# --------------------------------------------------------------------------- #
# Arquivos gerados
# --------------------------------------------------------------------------- #
_SAFE_NAME = re.compile(r"^[A-Za-z0-9][A-Za-z0-9_.-]{0,120}$")
MEDIA_URL_PREFIX = "/api/v1/tools/media"
PRIVATE_URL_PREFIX = "/api/v1/tools/private"


def media_dir(private: bool = False) -> Path:
    d = settings.OUTPUT_DIR_TOOLS / ("private" if private else "public")
    d.mkdir(parents=True, exist_ok=True)
    return d


def new_media_file(prefix: str, ext: str, *, private: bool = False) -> tuple[Path, str]:
    """Caminho unico + URL de acesso. `private=True` exige X-Nexus-Token para baixar."""
    _prune(media_dir(private))
    name = f"{prefix}_{int(time.time())}_{uuid.uuid4().hex[:8]}.{ext.lstrip('.')}"
    base = PRIVATE_URL_PREFIX if private else MEDIA_URL_PREFIX
    return media_dir(private) / name, f"{base}/{name}"


def resolve_media(name: str, *, private: bool = False) -> Optional[Path]:
    """Valida o nome (sem path traversal) e devolve o arquivo se existir."""
    if not _SAFE_NAME.match(name):
        return None
    base = media_dir(private).resolve()
    path = (base / name).resolve()
    if base not in path.parents or not path.is_file():
        return None
    return path


def _prune(directory: Path) -> None:
    ttl = settings.TOOLS_MEDIA_TTL_H * 3600
    if ttl <= 0:
        return
    cutoff = time.time() - ttl
    try:
        for f in directory.iterdir():
            if f.is_file() and f.stat().st_mtime < cutoff:
                f.unlink(missing_ok=True)
    except OSError as exc:  # limpeza e "best effort"
        logger.debug("prune falhou em %s: %s", directory, exc)


# --------------------------------------------------------------------------- #
# Matplotlib sem pyplot (thread-safe, sem GUI, sem estado global)
# --------------------------------------------------------------------------- #
async def render_figure(draw: Callable[[Any], None], path: Path, *, size: tuple[float, float] = (8, 6), dpi: int = 110) -> bool:
    """Executa `draw(fig)` numa thread e salva PNG. Retorna False se matplotlib faltar
    (o relatorio em texto continua valido -- grafico e um extra)."""
    try:
        from matplotlib.backends.backend_agg import FigureCanvasAgg
        from matplotlib.figure import Figure
    except ImportError:
        logger.warning("matplotlib nao instalado -- imagem ignorada (pip install matplotlib)")
        return False

    def _work() -> None:
        fig = Figure(figsize=size, dpi=dpi)
        FigureCanvasAgg(fig)
        fig.patch.set_facecolor("black")
        draw(fig)
        fig.savefig(str(path), facecolor="black")

    await asyncio.to_thread(_work)
    return path.is_file()


# --------------------------------------------------------------------------- #
# Decorator: "nenhuma ferramenta derruba o Nexus"
# --------------------------------------------------------------------------- #
ToolFn = Callable[..., Awaitable[ToolResult]]


def safe_tool(name: str, *, timeout: Optional[float] = None) -> Callable[[ToolFn], ToolFn]:
    def deco(fn: ToolFn) -> ToolFn:
        @functools.wraps(fn)
        async def wrapper(*args: Any, **kwargs: Any) -> ToolResult:
            if not settings.TOOLS_ENABLED:
                return ToolResult.failure(name, "Ferramentas desabilitadas (TOOLS_ENABLED=false).")
            t0 = time.monotonic()
            limit = timeout or settings.TOOLS_CALL_TIMEOUT_S
            try:
                result = await asyncio.wait_for(fn(*args, **kwargs), timeout=limit)
            except asyncio.CancelledError:
                raise
            except asyncio.TimeoutError:
                result = ToolResult.failure(name, f"A consulta '{name}' excedeu {limit:.0f}s e foi cancelada.")
            except ToolError as exc:
                logger.info("[%s] falha esperada: %s", name, exc)
                result = ToolResult.failure(name, str(exc))
            except Exception:  # bug inesperado: loga stack, devolve msg generica
                logger.exception("[%s] erro inesperado", name)
                result = ToolResult.failure(name, f"Erro interno na ferramenta '{name}'. Detalhes no log do servidor.")
            result.elapsed_ms = int((time.monotonic() - t0) * 1000)
            return result

        return wrapper

    return deco


# --------------------------------------------------------------------------- #
# Utilitarios pequenos
# --------------------------------------------------------------------------- #
def safe_float(value: Any, default: Optional[float] = None) -> Optional[float]:
    try:
        f = float(value)
        return f if f == f else default  # descarta NaN
    except (TypeError, ValueError):
        return default


def clamp_text(text: str, limit: int) -> str:
    text = (text or "").strip()
    return text if len(text) <= limit else text[: limit - 1].rstrip() + "…"


def require_browser() -> None:
    """Playwright e pesado e executa conteudo remoto: so com opt-in explicito."""
    if not settings.TOOLS_ENABLE_BROWSER:
        raise ToolUnavailableError(
            "Captura via navegador esta desligada. Defina TOOLS_ENABLE_BROWSER=true no .env "
            "e rode `pip install playwright && playwright install chromium`."
        )
    try:
        import playwright.async_api  # noqa: F401
    except ImportError as exc:
        raise ToolUnavailableError(
            "Playwright nao instalado: `pip install playwright && playwright install chromium`."
        ) from exc


_browser_sem: Optional[asyncio.Semaphore] = None


def browser_semaphore() -> asyncio.Semaphore:
    """Um Chromium por vez (RAM/VRAM da maquina compartilhada com Ollama/ComfyUI)."""
    global _browser_sem
    if _browser_sem is None:
        _browser_sem = asyncio.Semaphore(1)
    return _browser_sem
