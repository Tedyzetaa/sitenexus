"""
Geofisica e Riscos Naturais  (legado: geo_seismic.py, volcano_monitor.py)

* check_seismic_activity() -> USGS: terremotos recentes (M2.5+ por padrao)
* get_volcano_report()     -> Smithsonian GVP: relatorio semanal de vulcoes
"""
from __future__ import annotations

from datetime import datetime, timezone

from app.tools.base import ExternalServiceError, ToolResult, cached, clamp_text, http_get, http_json, safe_float, safe_tool
from app.tools.feeds import parse_feed

USGS_FEEDS = {
    "all": "https://earthquake.usgs.gov/earthquakes/feed/v1.0/summary/2.5_day.geojson",
    "significant": "https://earthquake.usgs.gov/earthquakes/feed/v1.0/summary/significant_day.geojson",
    "strong": "https://earthquake.usgs.gov/earthquakes/feed/v1.0/summary/4.5_day.geojson",
}
VOLCANO_RSS = "https://volcano.si.edu/news/WeeklyVolcanoRSS.xml"


def magnitude_icon(mag: float) -> str:
    if mag >= 6.5:
        return "🔴"
    if mag >= 5.5:
        return "🟠"
    if mag >= 4.5:
        return "🟡"
    return "🟢"


def parse_quakes(geojson: dict, limit: int) -> list[dict]:
    """Pura/testavel. `mag` pode ser null no USGS (o legado quebrava no :.1f)."""
    quakes = []
    for f in (geojson.get("features") or []):
        p = f.get("properties") or {}
        mag = safe_float(p.get("mag"))
        if mag is None:
            continue
        ts = safe_float(p.get("time"))
        when = datetime.fromtimestamp(ts / 1000, tz=timezone.utc) if ts else None
        quakes.append({
            "magnitude": mag,
            "place": p.get("place") or "local desconhecido",
            "time_utc": when.strftime("%d/%m %H:%M UTC") if when else "?",
            "tsunami": bool(p.get("tsunami")),
            "url": p.get("url"),
        })
    return quakes[: max(1, min(limit, 15))]


@safe_tool("check_seismic_activity")
async def check_seismic_activity(level: str = "all", limit: int = 5) -> ToolResult:
    """level: 'all' (M2.5+), 'strong' (M4.5+) ou 'significant'."""
    key = level if level in USGS_FEEDS else "all"
    raw, hit = await cached(f"usgs:{key}", lambda: http_json("USGS", USGS_FEEDS[key]), ttl=120)
    quakes = parse_quakes(raw, limit)
    total = (raw.get("metadata") or {}).get("count", len(raw.get("features") or []))

    titles = {"all": "M2.5+", "strong": "M4.5+", "significant": "significativos"}
    lines = ["🌋 **MONITOR SÍSMICO GLOBAL**", f"_Últimas 24h — {titles[key]} — {total} evento(s) no total_"]
    for q in quakes:
        tsu = " 🌊 alerta de tsunami" if q["tsunami"] else ""
        lines.append(f"\n{magnitude_icon(q['magnitude'])} **M{q['magnitude']:.1f}** — {q['place']}{tsu}\n   🕒 {q['time_utc']}")
    if not quakes:
        lines.append("\nNenhum evento neste filtro nas últimas 24h.")
    lines.append("\n_Fonte: USGS Real-time Network_")
    return ToolResult(True, "check_seismic_activity", "\n".join(lines),
                      data={"level": key, "total": total, "events": quakes}, source="USGS", cached=hit)


@safe_tool("get_volcano_report")
async def get_volcano_report(limit: int = 5) -> ToolResult:
    async def fetch():
        resp = await http_get("Smithsonian GVP", VOLCANO_RSS)
        try:
            return parse_feed(resp.content, limit=15)
        except ValueError as exc:
            raise ExternalServiceError("Smithsonian GVP", str(exc)) from exc

    items, hit = await cached("volcano", fetch, ttl=1800)
    items = items[: max(1, min(limit, 10))]
    lines = ["🌋 **RELATÓRIO DE ATIVIDADE VULCÂNICA**", "_Fonte: Smithsonian / USGS (semanal)_"]
    for it in items:
        short = clamp_text(it["description"].split(". ")[0], 160) or "Detalhes não disponíveis."
        icon = "🔥" if "new activity" in it["title"].lower() else ("💥" if "eruption" in short.lower() else "🌋")
        lines.append(f"\n{icon} **{it['title']}**\n   📝 _{short}_")
    if not items:
        lines.append("\nNenhuma atividade nova reportada no feed.")
    return ToolResult(True, "get_volcano_report", "\n".join(lines),
                      data={"items": items}, source="Smithsonian GVP", cached=hit)
