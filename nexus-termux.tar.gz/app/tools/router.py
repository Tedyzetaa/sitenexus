"""
Rotas HTTP das ferramentas (prefixo /api/v1/tools).

  GET  /api/v1/tools                       -> catalogo (para a UI)
  GET  /api/v1/tools/manifest?format=ollama-> function-calling para o LLM escolher ferramentas
  POST /api/v1/tools/chat      {message}   -> comando "/..." (ou linguagem natural se auto_intent=true)
  POST /api/v1/tools/dispatch  {text}      -> linguagem natural -> ferramenta
  POST /api/v1/tools/{name}    {args}      -> executa uma ferramenta
  GET  /api/v1/tools/media/{file}          -> imagem/video publico gerado
  GET  /api/v1/tools/private/{file}        -> arquivo sensivel (exige token)

Autenticacao: se TOOLS_API_TOKEN estiver definido, TODAS as rotas (exceto /media)
exigem o header `X-Nexus-Token`. Ferramentas `sensitive` (camera) exigem o token
sempre -- sem token configurado elas ficam indisponiveis.
"""
from __future__ import annotations

import hmac
import logging
import mimetypes
from typing import Any, Optional

from fastapi import APIRouter, Depends, Header, HTTPException, Query
from fastapi.responses import FileResponse
from pydantic import BaseModel, Field

from app.config import settings
from app.tools import commands, registry
from app.tools.base import ToolResult, resolve_media

logger = logging.getLogger("nexus.tools.router")


def _token_ok(provided: Optional[str]) -> bool:
    return bool(settings.TOOLS_API_TOKEN) and bool(provided) and hmac.compare_digest(
        provided.encode(), settings.TOOLS_API_TOKEN.encode()
    )


async def require_auth(x_nexus_token: Optional[str] = Header(default=None)) -> bool:
    """Retorna True se autenticado com token. Bloqueia 401 quando ha token configurado e ele nao confere."""
    if not settings.TOOLS_API_TOKEN:
        return False
    if not _token_ok(x_nexus_token):
        raise HTTPException(status_code=401, detail="Token invalido ou ausente (header X-Nexus-Token).")
    return True


router = APIRouter(prefix="/api/v1/tools", tags=["tools"])


class InvokeBody(BaseModel):
    args: dict[str, Any] = Field(default_factory=dict)


class ChatBody(BaseModel):
    message: str = Field(..., min_length=1, max_length=2000)
    auto_intent: bool = False   # True = tenta linguagem natural alem de "/comandos"


class DispatchBody(BaseModel):
    text: str = Field(..., min_length=1, max_length=2000)
    run: bool = True            # False = so diz qual ferramenta casaria (dry-run)


def _guard_sensitive(name: str, authed: bool) -> None:
    spec = registry.get_spec(name)
    if spec and spec.sensitive and not authed:
        raise HTTPException(status_code=403, detail=f"'{name}' exige TOOLS_API_TOKEN configurado e enviado.")


@router.get("")
async def list_tools(authed: bool = Depends(require_auth)):
    return {
        "enabled": settings.TOOLS_ENABLED,
        "tools": [
            {"name": t.name, "category": t.category, "description": t.description,
             "commands": [f"/{c}" for c in t.commands], "sensitive": t.sensitive, "heavy": t.heavy,
             "params": [{"name": p.name, "type": p.type, "default": p.default, "enum": list(p.enum),
                         "description": p.description} for p in t.params]}
            for t in registry.TOOLS if authed or not t.sensitive
        ],
    }


@router.get("/help")
async def tools_help(authed: bool = Depends(require_auth)):
    return {"text": commands.help_text()}


@router.get("/manifest")
async def tools_manifest(format: str = Query("ollama", pattern="^(ollama|openai|anthropic)$"),
                         authed: bool = Depends(require_auth)):
    return {"format": format, "tools": registry.manifest("anthropic" if format == "anthropic" else "ollama")}


@router.post("/chat")
async def tools_chat(body: ChatBody, authed: bool = Depends(require_auth)):
    """Camada de comando do bot: `handled=false` => o front segue para /api/chat (Langflow)."""
    text = body.message.strip()
    if text.lower() in ("/ferramentas", "/tools", "/ajuda", "/help"):
        return {"handled": True, "reply": commands.help_text(), "media": [], "tool": None}
    inv = commands.parse_command(text) or (commands.match_intent(text) if body.auto_intent else None)
    if inv is None:
        return {"handled": False}
    _guard_sensitive(inv.tool, authed)
    res = await registry.invoke(inv.tool, inv.args)
    return {"handled": True, "via": inv.via, "tool": inv.tool, "args": inv.args, "ok": res.ok,
            "reply": res.text, "media": res.media, "result": res.to_dict()}


@router.post("/dispatch")
async def tools_dispatch(body: DispatchBody, authed: bool = Depends(require_auth)):
    inv = commands.parse_command(body.text) or commands.match_intent(body.text)
    if inv is None:
        return {"matched": False}
    _guard_sensitive(inv.tool, authed)
    out: dict[str, Any] = {"matched": True, "tool": inv.tool, "args": inv.args, "via": inv.via}
    if body.run:
        out["result"] = (await registry.invoke(inv.tool, inv.args)).to_dict()
    return out


@router.get("/media/{filename}")
async def get_media(filename: str):
    path = resolve_media(filename)
    if path is None:
        raise HTTPException(status_code=404, detail="Arquivo nao encontrado ou expirado.")
    return FileResponse(path, media_type=mimetypes.guess_type(path.name)[0] or "application/octet-stream",
                        headers={"Cache-Control": "private, max-age=300", "X-Content-Type-Options": "nosniff"})


@router.get("/private/{filename}")
async def get_private_media(filename: str, x_nexus_token: Optional[str] = Header(default=None)):
    if not _token_ok(x_nexus_token):
        raise HTTPException(status_code=401, detail="Token invalido ou ausente.")
    path = resolve_media(filename, private=True)
    if path is None:
        raise HTTPException(status_code=404, detail="Arquivo nao encontrado ou expirado.")
    return FileResponse(path, media_type=mimetypes.guess_type(path.name)[0] or "application/octet-stream",
                        headers={"Cache-Control": "no-store", "X-Content-Type-Options": "nosniff"})


# IMPORTANTE: rota generica por ultimo, senao "/chat", "/help" etc. seriam capturadas como nome de ferramenta.
@router.post("/{name}")
async def run_tool(name: str, body: InvokeBody | None = None, authed: bool = Depends(require_auth)):
    if registry.get_spec(name) is None:
        raise HTTPException(status_code=404, detail=f"Ferramenta '{name}' nao existe.")
    _guard_sensitive(name, authed)
    res: ToolResult = await registry.invoke(name, (body.args if body else {}))
    return res.to_dict()
