"""
Clima espacial NOAA/SWPC  (legado: noaa_service.py v3.0)

* fetch_noaa_data(section)  -> telemetria (raios-X, Kp, vento solar, protons),
                               alertas, previsao 3 dias, regioes solares
* get_noaa_media(kind)      -> imagens/videos (D-RAP, SDO, CME SOHO, ENLIL)

Correcoes em relacao ao legado (todas marcadas com "FIX"):
 - FIX raios-X: o feed mistura duas bandas; a classe do flare usa so 0.1-0.8nm.
 - FIX protons: o feed mistura energias; o limiar S1 vale para >=10 MeV.
 - FIX escala S: S1>=10, S2>=100, S3>=1e3, S4>=1e4, S5>=1e5 pfu.
 - FIX vento solar/Kp: os JSON atuais vem como lista-de-listas com cabecalho
   (ou lista de dicts, formato novo); o legado assumia dicts e estourava.
 - FFmpeg via asyncio.create_subprocess_exec (nunca shell=True, nunca bloqueia).
"""
from __future__ import annotations

import asyncio
import logging
import shutil
import time
from typing import Any

from app.config import settings
from app.tools.base import (
    ExternalServiceError, ToolError, ToolResult, ToolUnavailableError, cached, clamp_text,
    http_get, http_json, new_media_file, safe_float, safe_tool,
)

logger = logging.getLogger("nexus.tools.noaa")

SWPC = "https://services.swpc.noaa.gov"
URL = {
    "xray": f"{SWPC}/json/goes/primary/xrays-6-hour.json",
    "kp": f"{SWPC}/products/noaa-planetary-k-index.json",
    "plasma": f"{SWPC}/products/solar-wind/plasma-6-hour.json",
    "mag": f"{SWPC}/products/solar-wind/mag-6-hour.json",
    "proton": f"{SWPC}/json/goes/primary/integral-protons-6-hour.json",
    "alerts": f"{SWPC}/products/alerts.json",
    "forecast": f"{SWPC}/text/3-day-forecast.txt",
    "regions": f"{SWPC}/text/solar-region-summary.txt",
    "drap": f"{SWPC}/images/animations/d-rap/global/d-rap/latest.png",
    "enlil_static": f"{SWPC}/images/animations/enlil/latest.jpg",
}
SDO = {
    "SDO 193 (corona/UV extremo)": "https://sdo.gsfc.nasa.gov/assets/img/latest/latest_1024_0193.jpg",
    "SDO 304 (cromosfera)": "https://sdo.gsfc.nasa.gov/assets/img/latest/latest_1024_0304.jpg",
    "SDO 171 (loops coronais)": "https://sdo.gsfc.nasa.gov/assets/img/latest/latest_1024_0171.jpg",
    "SDO 131 (flares)": "https://sdo.gsfc.nasa.gov/assets/img/latest/latest_1024_0131.jpg",
    "SDO HMI (campo magnético)": "https://sdo.gsfc.nasa.gov/assets/img/latest/latest_1024_HMIBC.jpg",
}
CME_GIF = {"C2": "https://soho.nascom.nasa.gov/data/LATEST/current_c2.gif",
           "C3": "https://soho.nascom.nasa.gov/data/LATEST/current_c3.gif"}
SDO_MP4 = "https://sdo.gsfc.nasa.gov/assets/img/latest/latest_1024_0193.mp4"

SECTIONS = ("full", "xray", "kp", "wind", "protons", "alerts", "forecast", "regions")


# --------------------------------------------------------------------------- #
# Normalizacao de formatos (puro / testavel)
# --------------------------------------------------------------------------- #
def rows_to_dicts(data: Any) -> list[dict]:
    """Aceita lista de dicts OU lista-de-listas com cabecalho na 1a linha."""
    if not isinstance(data, list) or not data:
        return []
    if isinstance(data[0], dict):
        return [r for r in data if isinstance(r, dict)]
    if isinstance(data[0], list) and len(data) > 1:
        header = [str(h) for h in data[0]]
        return [dict(zip(header, row)) for row in data[1:] if isinstance(row, list)]
    return []


def flare_class(flux: float) -> str:
    for limit, cls in ((1e-4, "X"), (1e-5, "M"), (1e-6, "C"), (1e-7, "B")):
        if flux >= limit:
            return cls
    return "A"


def parse_xray(data: Any) -> dict:
    rows = [r for r in rows_to_dicts(data) if str(r.get("energy", "0.1-0.8nm")) == "0.1-0.8nm"]  # FIX
    vals = [(safe_float(r.get("flux")), r.get("time_tag")) for r in rows]
    vals = [(f, t) for f, t in vals if f is not None and f > 0]
    if not vals:
        return {"erro": "sem dados", "classe_flare": "N/A", "alerta": False}
    flux, ts = vals[-1]
    peak = max(f for f, _ in vals)
    cls = flare_class(flux)
    return {"fluxo_atual_Wm2": flux, "classe_flare": cls, "classe_pico_6h": flare_class(peak),
            "pico_6h_Wm2": peak, "timestamp": ts, "amostras": len(vals), "alerta": cls in ("M", "X")}


def kp_level(kp: float) -> str:
    for limit, label in ((9, "G5 — EXTREMO 🔴"), (8, "G4 — SEVERO 🔴"), (7, "G3 — FORTE 🟠"),
                         (6, "G2 — MODERADO 🟡"), (5, "G1 — MENOR 🟡"), (4, "ATIVO ⚪")):
        if kp >= limit:
            return label
    return "QUIETO ✅"


def parse_kp(data: Any) -> dict:
    rows = rows_to_dicts(data)
    series: list[tuple[float, Any]] = []
    for r in rows:
        v = safe_float(r.get("Kp", r.get("kp_index", r.get("kp"))))
        if v is not None:
            series.append((v, r.get("time_tag")))
    if not series:
        return {"erro": "sem dados", "kp_atual": None, "tempestade": False}
    kp, ts = series[-1]
    recent = [v for v, _ in series[-8:]]
    return {"kp_atual": kp, "nivel": kp_level(kp), "pico_recente": max(recent), "serie_recente": recent,
            "timestamp": ts, "tempestade": kp >= 5}


def parse_wind(plasma: Any, mag: Any) -> dict:
    out: dict[str, Any] = {"velocidade_km_s": None, "densidade_p_cm3": None, "temperatura_K": None,
                           "campo_Bz_nT": None, "alerta": False}
    p = [r for r in rows_to_dicts(plasma) if safe_float(r.get("speed")) is not None]
    if p:
        last = p[-1]
        out.update(velocidade_km_s=safe_float(last.get("speed")), densidade_p_cm3=safe_float(last.get("density")),
                   temperatura_K=safe_float(last.get("temperature")), timestamp=last.get("time_tag"))
    m = [r for r in rows_to_dicts(mag) if safe_float(r.get("bz_gsm")) is not None]
    if m:
        out["campo_Bz_nT"] = safe_float(m[-1].get("bz_gsm"))
    bz, v = out["campo_Bz_nT"], out["velocidade_km_s"]
    out["alerta"] = bool(bz is not None and v is not None and bz < -10 and v > 500)
    return out


def proton_level(flux: float) -> str:
    for limit, label in ((1e5, "S5 — EXTREMO 🔴"), (1e4, "S4 — SEVERO 🔴"), (1e3, "S3 — FORTE 🟠"),
                         (1e2, "S2 — MODERADO 🟡"), (10, "S1 — MENOR 🟡")):
        if flux >= limit:
            return label  # FIX: escala correta
    return "Normal ✅"


def parse_protons(data: Any) -> dict:
    rows = [r for r in rows_to_dicts(data) if str(r.get("energy", ">=10 MeV")).replace(" ", "") == ">=10MeV"]  # FIX
    vals = [(safe_float(r.get("flux")), r.get("time_tag")) for r in rows]
    vals = [(f, t) for f, t in vals if f is not None]
    if not vals:
        return {"erro": "sem dados", "evento": False}
    flux, ts = vals[-1]
    return {"fluxo_pfu": flux, "nivel": proton_level(flux), "timestamp": ts, "evento": flux >= 10}


def parse_alerts(data: Any, limit: int = 10) -> list[dict]:
    out = []
    for item in (data if isinstance(data, list) else [])[:limit]:
        if isinstance(item, dict):
            out.append({"produto": item.get("product_id", "N/A"), "emissao": item.get("issue_datetime", "N/A"),
                        "mensagem": clamp_text(str(item.get("message", "")), 500)})
    return out


def alert_score(intel: dict) -> tuple[int, str]:
    score = 0
    score += 2 if intel["goes_xray"].get("alerta") else 0
    score += 2 if intel["kp_index"].get("tempestade") else 0
    score += 2 if intel["proton_flux"].get("evento") else 0
    score += 3 if intel["solar_wind"].get("alerta") else 0
    score += min(len(intel["alertas"]), 3)  # teto: 10 avisos de rotina nao devem gerar "CRITICO"
    state = ("🔴 CRÍTICO" if score >= 8 else "🟠 ELEVADO" if score >= 5 else
             "🟡 MODERADO" if score >= 2 else "✅ NOMINAL")
    return score, state


# --------------------------------------------------------------------------- #
# Coleta
# --------------------------------------------------------------------------- #
async def _soft(coro, fallback):
    """Uma fonte fora do ar nao pode derrubar o relatorio inteiro."""
    try:
        return await coro
    except ToolError as exc:
        logger.info("fonte NOAA indisponivel: %s", exc)
        return fallback


async def _json(key: str):
    return await http_json("NOAA SWPC", URL[key], timeout=20)


async def _text(key: str) -> str:
    return (await http_get("NOAA SWPC", URL[key], timeout=20)).text.strip()


async def collect_intel() -> dict:
    t0 = time.monotonic()
    xray, kp, plasma, mag, proton, alerts, forecast, regions = await asyncio.gather(
        _soft(_json("xray"), None), _soft(_json("kp"), None), _soft(_json("plasma"), None),
        _soft(_json("mag"), None), _soft(_json("proton"), None), _soft(_json("alerts"), []),
        _soft(_text("forecast"), "Previsão indisponível."), _soft(_text("regions"), "Regiões solares indisponíveis."),
    )
    intel = {
        "goes_xray": parse_xray(xray) if xray else {"erro": "indisponível", "classe_flare": "N/A", "alerta": False},
        "kp_index": parse_kp(kp) if kp else {"erro": "indisponível", "kp_atual": None, "tempestade": False},
        "solar_wind": parse_wind(plasma, mag) if plasma or mag else {"erro": "indisponível", "alerta": False},
        "proton_flux": parse_protons(proton) if proton else {"erro": "indisponível", "evento": False},
        "alertas": parse_alerts(alerts),
        "previsao_3d": forecast,
        "solar_region": regions,
        "fontes_ok": sum(x is not None and x != [] for x in (xray, kp, plasma, mag, proton, alerts)),
    }
    if intel["fontes_ok"] == 0:
        raise ExternalServiceError("NOAA SWPC", "nenhuma fonte respondeu")
    intel["score_alerta"], intel["estado_geral"] = alert_score(intel)
    intel["timestamp_coleta"] = time.strftime("%d/%m/%Y %H:%M:%S UTC", time.gmtime())
    intel["duracao_s"] = round(time.monotonic() - t0, 1)
    return intel


def _fmt(v: Any, spec: str = "", dash: str = "n/d") -> str:
    return dash if v is None else format(v, spec)


def render_text(intel: dict, section: str = "full") -> str:
    x, k, w, p = intel["goes_xray"], intel["kp_index"], intel["solar_wind"], intel["proton_flux"]
    blocks = {
        "xray": f"☀️ **GOES Raios-X** — classe **{x.get('classe_flare', 'N/A')}** "
                f"(pico 6h: {x.get('classe_pico_6h', 'N/A')}) | fluxo {_fmt(x.get('fluxo_atual_Wm2'), '.2e')} W/m² "
                f"| {'⚠️ ALERTA' if x.get('alerta') else '✅ sem alerta'}",
        "kp": f"🌍 **Índice Kp** — {_fmt(k.get('kp_atual'))} | {k.get('nivel', 'n/d')} "
              f"| pico recente {_fmt(k.get('pico_recente'))}",
        "wind": f"💨 **Vento solar** — {_fmt(w.get('velocidade_km_s'), '.0f')} km/s | "
                f"{_fmt(w.get('densidade_p_cm3'), '.1f')} p/cm³ | Bz {_fmt(w.get('campo_Bz_nT'))} nT "
                f"| {'⚠️ ALERTA' if w.get('alerta') else '✅ sem alerta'}",
        "protons": f"⚡ **Prótons (≥10 MeV)** — {_fmt(p.get('fluxo_pfu'), '.2f')} pfu | {p.get('nivel', 'n/d')}",
    }
    alerts = intel["alertas"]
    if section in blocks:
        return blocks[section]
    if section == "alerts":
        return "📋 **Alertas SWPC**\n" + ("\n".join(f"• [{a['produto']}] {a['emissao']}\n  {clamp_text(a['mensagem'], 200)}"
                                                    for a in alerts[:5]) or "Nenhum alerta ativo.")
    if section == "forecast":
        return "🔮 **Previsão 3 dias (NOAA)**\n```\n" + clamp_text(intel["previsao_3d"], 1800) + "\n```"
    if section == "regions":
        return "☀️ **Regiões solares ativas**\n```\n" + clamp_text(intel["solar_region"], 1800) + "\n```"
    head = (f"🛰️ **NOAA SPACE WEATHER** — {intel['timestamp_coleta']}\n"
            f"Estado geral: **{intel['estado_geral']}** (score {intel['score_alerta']})")
    tail = f"📋 Alertas SWPC ativos: {len(alerts)}" + "".join(f"\n   • [{a['produto']}] {a['emissao']}" for a in alerts[:5])
    return "\n\n".join([head, blocks["xray"], blocks["kp"], blocks["wind"], blocks["protons"], tail])


@safe_tool("fetch_noaa_data", timeout=60)
async def fetch_noaa_data(section: str = "full") -> ToolResult:
    """section: full | xray | kp | wind | protons | alerts | forecast | regions"""
    if section not in SECTIONS:
        raise ToolError(f"Seção inválida '{section}'. Use: {', '.join(SECTIONS)}.")
    intel, hit = await cached("noaa:intel", collect_intel, ttl=120)
    media: list[str] = []
    if section == "full" and settings.TOOLS_NOAA_MEDIA:
        res = await get_noaa_media("drap")
        media += res.media
    return ToolResult(True, "fetch_noaa_data", render_text(intel, section), data=intel, media=media,
                      source="NOAA SWPC", cached=hit)


# --------------------------------------------------------------------------- #
# Midia (imagens e videos)
# --------------------------------------------------------------------------- #
async def _save(url: str, prefix: str, ext: str, *, min_bytes: int = 500, timeout: float = 30) -> tuple[Any, str]:
    resp = await http_get("NOAA/NASA", url, timeout=timeout)
    if len(resp.content) < min_bytes:
        raise ExternalServiceError("NOAA/NASA", "arquivo vazio ou corrompido")
    path, media_url = new_media_file(prefix, ext)
    await asyncio.to_thread(path.write_bytes, resp.content)
    return path, media_url


async def _gif_to_mp4(gif, mp4) -> bool:
    ffmpeg = settings.FFMPEG_BINARY
    if not shutil.which(ffmpeg):
        raise ToolUnavailableError(f"FFmpeg ('{ffmpeg}') nao encontrado. Instale ou ajuste FFMPEG_BINARY.")
    proc = await asyncio.create_subprocess_exec(
        ffmpeg, "-y", "-i", str(gif), "-vf", "pad=ceil(iw/2)*2:ceil(ih/2)*2,format=yuv420p",
        "-c:v", "libx264", "-pix_fmt", "yuv420p", "-movflags", "faststart", str(mp4),
        stdout=asyncio.subprocess.DEVNULL, stderr=asyncio.subprocess.PIPE,
    )
    try:
        _, err = await asyncio.wait_for(proc.communicate(), timeout=120)
    except asyncio.TimeoutError:
        proc.kill()
        await proc.wait()
        raise ToolError("FFmpeg excedeu o tempo limite ao converter o vídeo.")
    if proc.returncode != 0:
        logger.warning("ffmpeg rc=%s: %s", proc.returncode, err.decode("utf-8", "replace")[-300:])
        return False
    return mp4.is_file() and mp4.stat().st_size > 1000


@safe_tool("get_noaa_media", timeout=150)
async def get_noaa_media(kind: str = "drap", band: str = "C3") -> ToolResult:
    """kind: drap | sdo | cme | sdo_video | enlil"""
    media: list[str] = []
    if kind == "drap":
        _, u = await _save(URL["drap"], "noaa_drap", "png")
        media, text = [u], "📡 **D-RAP** — absorção de rádio HF (blackout) em tempo quase real."
    elif kind == "sdo":
        got = await asyncio.gather(*(_soft(_save(u, "sdo", "jpg", timeout=20), None) for u in SDO.values()))
        media = [g[1] for g in got if g]
        if not media:
            raise ExternalServiceError("NASA SDO", "nenhuma imagem disponível")
        text = f"☀️ **SDO** — {len(media)}/{len(SDO)} bandas do Sol obtidas."
    elif kind == "cme":
        if band not in CME_GIF:
            raise ToolError("Banda inválida. Use C2 ou C3.")
        gif, _ = await _save(CME_GIF[band], f"cme_{band.lower()}", "gif", min_bytes=1000)
        mp4, u = new_media_file(f"cme_{band.lower()}", "mp4")
        try:
            ok = await _gif_to_mp4(gif, mp4)
        finally:
            gif.unlink(missing_ok=True)
        if not ok:
            raise ToolError("Falha ao converter o coronógrafo SOHO em vídeo.")
        media, text = [u], f"🌞 **SOHO LASCO {band}** — coronógrafo (ejeções de massa coronal)."
    elif kind == "sdo_video":
        _, u = await _save(SDO_MP4, "sdo_aia193", "mp4", min_bytes=50_000, timeout=90)
        media, text = [u], "🎞️ **SDO AIA 193Å** — coroa solar (UV extremo)."
    elif kind == "enlil":
        _, u = await _save(URL["enlil_static"], "enlil", "jpg", timeout=20)
        media, text = [u], "🌬️ **WSA-ENLIL** — simulação do vento solar (imagem mais recente)."
    else:
        raise ToolError("Tipo inválido. Use: drap, sdo, cme, sdo_video, enlil.")
    return ToolResult(True, "get_noaa_media", text, media=media, source="NOAA/NASA")
