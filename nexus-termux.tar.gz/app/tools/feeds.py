"""Parser RSS/Atom minimalista (sem `feedparser`), seguro contra XML malicioso.

Usa `defusedxml` quando instalado (recomendado); caso contrario cai no
ElementTree da stdlib. Entrada e sempre tratada como NAO confiavel.
"""
from __future__ import annotations

import html
import re
from typing import Any

try:  # pragma: no cover - depende do ambiente
    from defusedxml import ElementTree as ET
except ImportError:  # pragma: no cover
    import xml.etree.ElementTree as ET  # type: ignore[no-redef]

_TAG = re.compile(r"<[^>]+>")


def strip_html(text: str) -> str:
    return re.sub(r"\s+", " ", html.unescape(_TAG.sub(" ", text or ""))).strip()


def _local(tag: str) -> str:
    return tag.rsplit("}", 1)[-1]


def parse_feed(content: bytes, limit: int = 10) -> list[dict[str, Any]]:
    """Retorna [{title, link, published, description}] de RSS 2.0 ou Atom."""
    try:
        root = ET.fromstring(content)
    except Exception as exc:  # ParseError, EntitiesForbidden, etc.
        raise ValueError(f"XML invalido: {type(exc).__name__}") from exc

    items = []
    for node in root.iter():
        if _local(node.tag) not in ("item", "entry"):
            continue
        fields: dict[str, str] = {"title": "", "link": "", "published": "", "description": ""}
        for child in node:
            name = _local(child.tag)
            if name == "title":
                fields["title"] = strip_html(child.text or "")
            elif name == "link":
                fields["link"] = (child.text or child.attrib.get("href", "") or "").strip()
            elif name in ("pubDate", "published", "updated"):
                fields["published"] = (child.text or "").strip()
            elif name in ("description", "summary", "content"):
                fields["description"] = strip_html(child.text or "")
        if fields["title"]:
            items.append(fields)
        if len(items) >= limit:
            break
    return items
