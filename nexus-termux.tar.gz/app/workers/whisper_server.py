"""
Whisper PERSISTENTE para o modo ligacao (processo filho que fica vivo).

Diferenca para whisper_worker.py (um processo por transcricao): aqui o modelo
fica carregado entre as falas -- recarregar do HDD a cada turno custaria varios
segundos. Continua isolado do processo principal (torch/XTTS), enquanto o
Whisper usa CPU.

Protocolo: uma linha JSON por requisicao em stdin, uma linha JSON por resposta em stdout.
    {"id": 1, "cmd": "load", "model_size": "base", "device": "auto"}
    {"id": 2, "cmd": "transcribe", "audio_path": "...", "model_size": "base", "device": "auto", "language": "pt"}
    {"id": 3, "cmd": "exit"}
Resposta: {"id": N, "ok": true, "transcript": "..."} | {"id": N, "ok": false, "error": "..."}
Silencio/sem fala NAO e erro: devolve transcript "".
"""
import json
import sys


def main() -> int:
    # Libs costumam imprimir lixo em stdout; o protocolo usa o stdout ORIGINAL.
    proto = sys.stdout
    sys.stdout = sys.stderr

    def reply(payload: dict) -> None:
        proto.write(json.dumps(payload, ensure_ascii=False) + "\n")
        proto.flush()

    from app.providers import whisper_stt

    def get_model(size: str, device: str):
        if whisper_stt._model is None or whisper_stt._loaded_config != (size, "cpu"):
            whisper_stt._load_model(size, device)
        return whisper_stt._model

    for line in sys.stdin:
        line = line.strip()
        if not line:
            continue
        try:
            req = json.loads(line)
        except json.JSONDecodeError:
            continue
        rid = req.get("id")
        cmd = req.get("cmd")
        try:
            if cmd == "exit":
                reply({"id": rid, "ok": True})
                return 0
            model = get_model(req.get("model_size", "base"), req.get("device", "auto"))
            if cmd == "load":
                reply({"id": rid, "ok": True, "transcript": ""})
            elif cmd == "transcribe":
                segments, _info = model.transcribe(
                    req["audio_path"],
                    language=req.get("language") or None,
                    vad_filter=True,
                    beam_size=whisper_stt.settings.whisper_beam_size,  # 1 (guloso) no lite: bem mais rapido em CPU
                    condition_on_previous_text=False,
                )
                text = " ".join(seg.text.strip() for seg in segments).strip()
                reply({"id": rid, "ok": True, "transcript": text})
            else:
                reply({"id": rid, "ok": False, "error": f"comando desconhecido: {cmd!r}"})
        except Exception as exc:  # noqa: BLE001 - qualquer falha vira resposta JSON
            reply({"id": rid, "ok": False, "error": f"{type(exc).__name__}: {exc}"})
    return 0


if __name__ == "__main__":
    sys.exit(main())
