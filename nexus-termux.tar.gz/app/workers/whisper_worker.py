"""
Worker standalone para transcricao com faster-whisper, executado em um
PROCESSO SEPARADO (via subprocess, chamado por app/providers/whisper_stt.py).

O Whisper roda em CPU e permanece isolado do processo principal do XTTS para
que cada estagio possa liberar seus recursos ao terminar.

Uso (chamado internamente por whisper_stt.transcribe_isolated):
    python -m app.workers.whisper_worker <audio_path> <model_size> <device> <language>

Imprime em stdout uma UNICA linha JSON:
    {"ok": true, "transcript": "..."}
    {"ok": false, "error": "mensagem de erro"}
"""
import json
import sys


def main() -> int:
    if len(sys.argv) != 5:
        print(json.dumps({
            "ok": False,
            "error": f"Uso: whisper_worker.py <audio_path> <model_size> <device> <language> (recebi {sys.argv[1:]!r})",
        }))
        return 1

    audio_path, model_size, device, language = sys.argv[1:5]

    try:
        # Import local (nao no topo do modulo) para nao carregar faster-whisper
        # nem torch antes de sabermos que os argumentos estao ok.
        from app.providers import whisper_stt

        transcript = whisper_stt.transcribe(audio_path, model_size, device, language)
        print(json.dumps({"ok": True, "transcript": transcript}))
        return 0
    except Exception as exc:  # noqa: BLE001 - queremos capturar QUALQUER falha e reportar via JSON
        print(json.dumps({"ok": False, "error": f"{type(exc).__name__}: {exc}"}))
        return 1


if __name__ == "__main__":
    sys.exit(main())
