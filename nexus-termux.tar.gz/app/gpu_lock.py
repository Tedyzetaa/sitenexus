import asyncio
from contextlib import asynccontextmanager

# Lock global para serializar modelos pesados locais.
# Perfil gpu : a RTX 3050 6GB exige exclusao mutua entre XTTS, Whisper, Ollama e ComfyUI (VRAM).
# Perfil lite: o mesmo lock serializa CPU/RAM (i3 de 2 nucleos + 8 GB): dois modelos pesados ao
#              mesmo tempo estouram a RAM e o Windows passa a paginar no HDD.
#
# Quem usa:
#   * QueueManager._worker_loop  -> segura o lock durante TODO job da fila (um por vez);
#   * endpoints sincronos de dublagem (/process abaixo do limiar, /preview, /synthesize) -> usam
#     `gpu_slot()`, que falha rapido (GpuBusyError -> HTTP 503) em vez de disputar a GPU com a fila.
# Jobs de audio que JA estao na fila NAO devem pegar o lock de novo (asyncio.Lock nao e reentrante).
gpu_vram_lock = asyncio.Lock()


class GpuBusyError(RuntimeError):
    """A GPU esta ocupada por outro job; tente de novo daqui a pouco."""


@asynccontextmanager
async def gpu_slot(timeout_s: float = 5.0):
    """Adquire o lock da GPU esperando no maximo `timeout_s`; senao levanta GpuBusyError."""
    try:
        await asyncio.wait_for(gpu_vram_lock.acquire(), timeout=timeout_s)
    except asyncio.TimeoutError as exc:
        raise GpuBusyError(
            "Nexus ocupado com outro job pesado (geracao na fila ou outra dublagem). "
            "Tente novamente em instantes ou envie um arquivo grande para processar pela fila."
        ) from exc
    try:
        yield
    finally:
        gpu_vram_lock.release()
