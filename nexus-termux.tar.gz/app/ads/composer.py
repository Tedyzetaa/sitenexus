"""
Montagem final do video (ffmpeg): junta os clipes, adiciona a narracao, musica opcional
(com "ducking": abaixa sozinha quando a voz fala), marca d'agua opcional e legendas queimadas.

Formato de saida: 1080x1920 (9:16), 30 fps, H.264 + AAC, igual ao video de exemplo.

Decisoes:
- Legendas e marca d'agua sao renderizadas como PNG transparente (PIL) e sobrepostas com
  `overlay=enable='between(t,a,b)'`. Evita o filtro `subtitles`/`drawtext`, cujo escape de
  caminhos/fontes no Windows (C:\\..., ':') e fragil.
- Cada clipe e esticado/cortado para caber na sua fatia da narracao. Estiramento > 1.15x usa
  `minterpolate` (interpolacao de quadros) na resolucao NATIVA do clipe (barato); acima de
  MAX_SLOWDOWN o ultimo quadro e congelado em vez de esticar demais.
- Tempo das legendas e APROXIMADO (proporcional ao no de caracteres de cada trecho sobre a
  duracao da voz). Para sincronia palavra-a-palavra seria preciso rodar o Whisper sobre a
  narracao gerada -- evolucao possivel, nao implementada.
"""
from __future__ import annotations

import json
import logging
import re
import shutil
import subprocess
from dataclasses import dataclass
from pathlib import Path

from PIL import Image, ImageDraw, ImageFont

from app.config import settings
from app.providers.base import ProviderUnavailableError

logger = logging.getLogger("nexus.ads.composer")

OUT_W, OUT_H, OUT_FPS = 1080, 1920, 30
MAX_SLOWDOWN = 2.0
MIN_SPEEDUP = 0.75  # nao acelera clipe mais que 1/0.75 (corta o excedente)
TAIL_S = 0.6        # respiro depois da ultima palavra
LEAD_S = 0.3        # silencio antes da voz
CAPTION_Y, WATERMARK_Y = 1560, 1440

_FONT_CANDIDATES = [
    "C:/Windows/Fonts/arialbd.ttf", "C:/Windows/Fonts/segoeuib.ttf",
    "/usr/share/fonts/truetype/dejavu/DejaVuSans-Bold.ttf",
    "/System/Library/Fonts/Supplemental/Arial Bold.ttf",
]


def _ffmpeg() -> str:
    exe = shutil.which(settings.FFMPEG_BINARY)
    if not exe:
        raise ProviderUnavailableError(
            f"ffmpeg nao encontrado ('{settings.FFMPEG_BINARY}'). Instale o ffmpeg e coloque no PATH "
            f"ou ajuste FFMPEG_BINARY no .env (a montagem do video final depende dele)."
        )
    return exe


def _ffprobe() -> str:
    exe = shutil.which(settings.FFPROBE_BINARY) or shutil.which("ffprobe")
    if not exe:
        raise ProviderUnavailableError("ffprobe nao encontrado (vem junto com o ffmpeg). Ajuste FFPROBE_BINARY no .env.")
    return exe


def probe_duration(path: str | Path) -> float:
    out = subprocess.run(
        [_ffprobe(), "-v", "error", "-show_entries", "format=duration", "-of", "json", str(path)],
        capture_output=True, text=True, timeout=60,
    )
    try:
        return float(json.loads(out.stdout)["format"]["duration"])
    except (KeyError, ValueError, json.JSONDecodeError) as exc:
        raise ProviderUnavailableError(f"Nao foi possivel ler a duracao de '{path}': {out.stderr[-200:]}") from exc


def _font(size: int) -> ImageFont.FreeTypeFont | ImageFont.ImageFont:
    for cand in _FONT_CANDIDATES:
        if Path(cand).exists():
            return ImageFont.truetype(cand, size)
    try:
        return ImageFont.load_default(size)  # Pillow >= 10.1
    except TypeError:
        return ImageFont.load_default()


# --------------------------------------------------------------------------- legendas

@dataclass
class Caption:
    text: str
    start: float
    end: float


def plan_captions(narration: str, voice_start: float, voice_dur: float, words_per_caption: int = 3) -> list[Caption]:
    """Divide a narracao em trechos de ~3 palavras e distribui no tempo por no de caracteres."""
    words = narration.split()
    if not words or voice_dur <= 0:
        return []
    chunks: list[str] = []
    cur: list[str] = []
    for w in words:
        cur.append(w)
        if len(cur) >= words_per_caption or re.search(r"[.!?;:]$", w):
            chunks.append(" ".join(cur))
            cur = []
    if cur:
        chunks.append(" ".join(cur))
    weights = [max(len(c), 1) for c in chunks]
    total = sum(weights)
    t = voice_start
    caps: list[Caption] = []
    for c, w in zip(chunks, weights):
        dur = voice_dur * w / total
        caps.append(Caption(c, round(t, 3), round(t + dur, 3)))
        t += dur
    return caps


def render_caption_png(text: str, path: Path, font_size: int = 68) -> None:
    img = Image.new("RGBA", (OUT_W, 220), (0, 0, 0, 0))
    draw = ImageDraw.Draw(img)
    font = _font(font_size)
    # quebra em ate 2 linhas dentro de 88% da largura
    lines, cur = [], ""
    for w in text.split():
        trial = f"{cur} {w}".strip()
        if draw.textlength(trial, font=font) <= OUT_W * 0.88 or not cur:
            cur = trial
        else:
            lines.append(cur)
            cur = w
    lines.append(cur)
    line_h = int(font_size * 1.2)
    y = max(0, (220 - line_h * len(lines)) // 2)
    for ln in lines[:2]:
        tw = draw.textlength(ln, font=font)
        draw.text(((OUT_W - tw) / 2, y), ln, font=font, fill=(255, 255, 255, 255),
                  stroke_width=5, stroke_fill=(0, 0, 0, 255))
        y += line_h
    img.save(path)


def render_watermark_png(path: Path, text: str | None, image_bytes: bytes | None, opacity: float) -> None:
    if image_bytes:
        import io
        mark = Image.open(io.BytesIO(image_bytes)).convert("RGBA")
        mark.thumbnail((int(OUT_W * 0.45), 200), Image.LANCZOS)
    else:
        font = _font(60)
        probe = ImageDraw.Draw(Image.new("RGBA", (1, 1)))
        w = int(probe.textlength(text or "", font=font)) + 20
        mark = Image.new("RGBA", (max(w, 10), 90), (0, 0, 0, 0))
        ImageDraw.Draw(mark).text((10, 10), text or "", font=font, fill=(255, 255, 255, 255),
                                  stroke_width=2, stroke_fill=(0, 0, 0, 160))
    alpha = mark.split()[-1].point(lambda a: int(a * opacity))
    mark.putalpha(alpha)
    canvas = Image.new("RGBA", (OUT_W, mark.height + 20), (0, 0, 0, 0))
    canvas.paste(mark, ((OUT_W - mark.width) // 2, 10), mark)
    canvas.save(path)


# --------------------------------------------------------------------------- composicao

def build_command(
    ffmpeg: str, clips: list[Path], clip_durs: list[float], narration: Path, narration_dur: float,
    out_path: Path, work_dir: Path, music: Path | None = None, music_volume: float = 0.14,
    watermark_png: Path | None = None, captions: list[Caption] | None = None,
) -> tuple[list[str], float]:
    n = len(clips)
    total = LEAD_S + narration_dur + TAIL_S
    slice_t = total / n

    cmd: list[str] = [ffmpeg, "-y", "-hide_banner", "-loglevel", "error"]
    for c in clips:
        cmd += ["-i", str(c)]
    cmd += ["-i", str(narration)]
    nar_idx = n
    music_idx = None
    if music:
        cmd += ["-stream_loop", "-1", "-i", str(music)]
        music_idx = n + 1
    next_idx = n + 1 + (1 if music else 0)

    f: list[str] = []
    for i, (d) in enumerate(clip_durs):
        factor = slice_t / d  # >1 = mais lento
        factor = min(max(factor, MIN_SPEEDUP), MAX_SLOWDOWN)
        stretched = d * factor
        chain = [f"[{i}:v]setpts={factor:.4f}*PTS"]
        chain.append(f"minterpolate=fps={OUT_FPS}:mi_mode=mci:mc_mode=aobmc:vsbmc=1" if factor > 1.15 else f"fps={OUT_FPS}")
        chain.append(f"scale={OUT_W}:{OUT_H}:force_original_aspect_ratio=increase:flags=lanczos")
        chain.append(f"crop={OUT_W}:{OUT_H}")
        chain.append("unsharp=5:5:0.4:5:5:0.0")
        chain.append("setsar=1,format=yuv420p")
        if stretched < slice_t:  # congela o ultimo quadro para completar a fatia
            chain.append(f"tpad=stop_mode=clone:stop_duration={slice_t - stretched + 0.1:.3f}")
        chain.append(f"trim=duration={slice_t:.4f},setpts=PTS-STARTPTS[v{i}]")
        f.append(",".join(chain))
    f.append("".join(f"[v{i}]" for i in range(n)) + f"concat=n={n}:v=1:a=0[vcat]")

    last = "vcat"
    if watermark_png:
        cmd += ["-i", str(watermark_png)]
        f.append(f"[{last}][{next_idx}:v]overlay=0:{WATERMARK_Y}[vwm]")
        last, next_idx = "vwm", next_idx + 1
    for k, cap in enumerate(captions or []):
        png = work_dir / f"cap_{k:03d}.png"
        render_caption_png(cap.text, png)
        cmd += ["-i", str(png)]
        f.append(f"[{last}][{next_idx}:v]overlay=0:{CAPTION_Y}:enable='between(t,{cap.start:.3f},{cap.end:.3f})'[vc{k}]")
        last, next_idx = f"vc{k}", next_idx + 1
    f.append(f"[{last}]null[vout]")

    # audio
    lead_ms = int(LEAD_S * 1000)
    if music_idx is not None:
        f.append(f"[{nar_idx}:a]aresample=44100,adelay={lead_ms}:all=1,apad=whole_dur={total:.3f},asplit=2[nar][nsc]")
        f.append(
            f"[{music_idx}:a]aresample=44100,volume={music_volume:.3f},atrim=0:{total:.3f},asetpts=PTS-STARTPTS,"
            f"afade=t=in:d=1,afade=t=out:st={max(total - 1.5, 0):.3f}:d=1.5[mus]"
        )
        f.append("[mus][nsc]sidechaincompress=threshold=0.04:ratio=10:attack=20:release=450[duck]")
        f.append("[nar][duck]amix=inputs=2:normalize=0:duration=longest,loudnorm=I=-16:TP=-1.5:LRA=11[aout]")
    else:
        f.append(f"[{nar_idx}:a]aresample=44100,adelay={lead_ms}:all=1,apad=whole_dur={total:.3f},loudnorm=I=-16:TP=-1.5:LRA=11[aout]")

    cmd += ["-filter_complex", ";".join(f), "-map", "[vout]", "-map", "[aout]",
            "-t", f"{total:.3f}", "-r", str(OUT_FPS),
            "-c:v", "libx264", "-preset", "medium", "-crf", "20", "-pix_fmt", "yuv420p",
            "-c:a", "aac", "-b:a", "192k", "-ar", "44100", "-movflags", "+faststart", str(out_path)]
    return cmd, total


def compose(
    clips: list[Path], narration: Path, narration_text: str, out_path: Path, work_dir: Path,
    music: Path | None = None, music_volume: float = 0.14, watermark_text: str | None = None,
    watermark_image: bytes | None = None, watermark_opacity: float = 0.35, captions: bool = True,
    timeout_s: int = 900,
) -> Path:
    """BLOQUEANTE -- chamar via asyncio.to_thread."""
    if not clips:
        raise ProviderUnavailableError("Nenhum clipe de video para montar.")
    ffmpeg = _ffmpeg()
    work_dir.mkdir(parents=True, exist_ok=True)
    clip_durs = [probe_duration(c) for c in clips]
    nar_dur = probe_duration(narration)

    wm_png = None
    if watermark_text or watermark_image:
        wm_png = work_dir / "watermark.png"
        render_watermark_png(wm_png, watermark_text, watermark_image, watermark_opacity)
    caps = plan_captions(narration_text, LEAD_S, nar_dur) if captions else []

    cmd, total = build_command(ffmpeg, clips, clip_durs, narration, nar_dur, out_path, work_dir,
                               music, music_volume, wm_png, caps)
    logger.info("[composer] ffmpeg: %d clipes, narracao %.1fs, total %.1fs, %d legendas", len(clips), nar_dur, total, len(caps))
    try:
        proc = subprocess.run(cmd, capture_output=True, text=True, timeout=timeout_s)
    except subprocess.TimeoutExpired as exc:
        raise ProviderUnavailableError(f"ffmpeg excedeu {timeout_s}s na montagem do video.") from exc
    if proc.returncode != 0 or not out_path.exists() or out_path.stat().st_size == 0:
        raise ProviderUnavailableError(f"ffmpeg falhou ao montar o video: {proc.stderr[-600:]}")
    return out_path
