"""
Roteirista: transforma ProductData em AdPlan (narracao unica + prompts de cena).

Pedido do usuario: "atue como um profissional de marketing digital e especialista em
criar prompts e roteiros", separando (a) o texto de voz num prompt/saida unico e
(b) os prompts de animacao por cena.

Decisoes:
- O LLM NAO ve as imagens (modelo de texto), entao NAO escolhe qual foto usar: a atribuicao
  foto->cena e feita aqui (round-robin sobre as fotos reais) e fica editavel na UI.
- Fidelidade ao produto: o prompt de cena descreve so UM movimento de camera e proibe
  pessoas/maos/texto; um sufixo fixo (FIDELITY_SUFFIX) reforca "produto nao muda".
- Anti-alucinacao comercial: o prompt proibe inventar numeros/promocoes e o codigo marca
  em `warnings` qualquer numero da narracao que nao exista nos dados do produto.
"""
from __future__ import annotations

import json
import logging
import re

from pydantic import ValidationError

from app.ads.models import AdPlan, AdPlanRequest, AdScene, ProductData
from app.providers.base import ProviderUnavailableError

logger = logging.getLogger("nexus.ads.copywriter")

WORDS_PER_SECOND_PT = 2.5  # fala publicitaria em pt-BR, ritmo medio
FIDELITY_SUFFIX = (
    " The product keeps its exact shape, colors and details throughout, rigid and unchanged. "
    "No people, no hands, no text, no logos."
)

SYSTEM_PROMPT = """Atue como um profissional de marketing digital e especialista em criar prompts e roteiros para videos curtos de propaganda (Reels/TikTok/Shorts, formato vertical 9:16).

Voce recebe os dados REAIS de um produto e deve devolver APENAS um JSON valido, sem texto fora do JSON, com este formato:
{
  "hook": "frase de abertura de ate 10 palavras",
  "narration": "texto corrido da locucao, pronto para ser lido por uma voz",
  "scenes": [
    {"visual_prompt": "...", "narration_hint": "trecho da locucao que esta cena cobre"}
  ],
  "caption": "legenda curta para a postagem",
  "hashtags": ["#exemplo"]
}

REGRAS DA "narration" (sera enviada a um motor de voz):
- Idioma: {language}. Tom: {tone}.
- Aproximadamente {words} palavras (video de ~{duration}s). Nao ultrapasse {max_words} palavras.
- Comece com o gancho, destaque 2 a 4 caracteristicas/beneficios, termine com uma chamada para acao curta.
- Use SOMENTE fatos presentes nos dados do produto. NUNCA invente medidas, materiais, precos, descontos, garantias, prazos ou numeros.
- Sem emojis, sem hashtags, sem markdown, sem aspas, sem listas, sem rubricas ("Cena 1"). Escreva numeros e simbolos por extenso.
- Frases curtas, de ate ~15 palavras, pontuadas (a pontuacao define as pausas da voz).

REGRAS DE CADA "visual_prompt" (sera enviado a um modelo imagem-para-video; a primeira imagem ja e a FOTO REAL do produto):
- Escreva em INGLES, 20 a 35 palavras, uma unica frase descritiva.
- Descreva SOMENTE o produto como aparece na foto e UM movimento de camera simples (ex.: "slow push-in", "gentle orbit to the left", "slow pan upward", "subtle pull-back").
- O produto nao se move, nao muda de forma nem de cor. Nunca invente cenario, pessoas, maos, texto ou logotipos que nao estejam na foto.
- Varie o movimento de camera entre as cenas.

Devolva exatamente {n_scenes} cenas."""


def _count_words(text: str) -> int:
    return len(re.findall(r"\w+", text, flags=re.UNICODE))


_EMOJI_RE = re.compile(
    "[\U0001F300-\U0001FAFF\U00002600-\U000027BF\U0001F000-\U0001F2FF\U0000FE0F\U0000200D]+", flags=re.UNICODE
)


def clean_narration(text: str) -> str:
    """Deixa o texto seguro para TTS: sem emoji, markdown, hashtags, rubricas de cena, URLs."""
    t = text or ""
    t = re.sub(r"https?://\S+", " ", t)
    t = _EMOJI_RE.sub(" ", t)
    t = re.sub(r"#\w+", " ", t)
    t = re.sub(r"[*_`~>]+", "", t)
    t = re.sub(r"(?im)^\s*(cena|scene|narrador|locu[cç][aã]o)\s*\d*\s*[:\-–]\s*", "", t)
    t = t.replace("\u201c", "").replace("\u201d", "").replace('"', "")
    t = re.sub(r"\s+", " ", t).strip()
    return t


def _clean_visual(text: str) -> str:
    t = re.sub(r"\s+", " ", (text or "").replace('"', "")).strip()
    words = t.split()
    if len(words) > 60:
        t = " ".join(words[:60])
    return t


def _numbers(text: str) -> set[str]:
    return {n.replace(",", ".") for n in re.findall(r"\d+(?:[.,]\d+)?", text or "")}


def _product_text(p: ProductData) -> str:
    return " ".join([p.title, p.description, " ".join(p.features), p.price or "", p.brand or ""])


def build_user_prompt(product: ProductData, req: AdPlanRequest) -> str:
    feats = "\n".join(f"- {f}" for f in product.features[:14]) or "(nenhuma lista de caracteristicas)"
    return (
        f"PRODUTO: {product.title}\n"
        f"MARCA: {product.brand or 'nao informada'}\n"
        f"PRECO (nao cite se nao fizer sentido): {product.price or 'nao informado'}\n"
        f"CARACTERISTICAS:\n{feats}\n"
        f"DESCRICAO:\n{product.description[:2500] or '(sem descricao)'}\n"
    )


def parse_plan(raw: str, product: ProductData, req: AdPlanRequest) -> AdPlan:
    """Valida/normaliza a saida do LLM. Levanta ValueError com motivo legivel (usado no retry)."""
    text = raw.strip()
    text = re.sub(r"^```(?:json)?|```$", "", text, flags=re.MULTILINE).strip()
    try:
        data = json.loads(text)
    except json.JSONDecodeError as exc:
        # tenta recortar o primeiro objeto {...}
        m = re.search(r"\{.*\}", text, flags=re.DOTALL)
        if not m:
            raise ValueError(f"resposta nao e JSON valido: {exc}") from exc
        try:
            data = json.loads(m.group(0))
        except json.JSONDecodeError as exc2:
            raise ValueError(f"resposta nao e JSON valido: {exc2}") from exc2
    if not isinstance(data, dict):
        raise ValueError("o JSON precisa ser um objeto")

    narration = clean_narration(str(data.get("narration", "")))
    if _count_words(narration) < 12:
        raise ValueError("campo 'narration' ausente ou curto demais")

    raw_scenes = data.get("scenes")
    if not isinstance(raw_scenes, list) or not raw_scenes:
        raise ValueError("campo 'scenes' ausente")
    n_images = max(1, len(product.image_files))
    scenes: list[AdScene] = []
    for i, sc in enumerate(raw_scenes[: max(req.scenes_count, 3) + 2]):
        vp = _clean_visual(sc.get("visual_prompt", "") if isinstance(sc, dict) else str(sc))
        if len(vp) < 8:
            continue
        scenes.append(AdScene(
            index=len(scenes), visual_prompt=vp, reference_image=len(scenes) % n_images,
            narration_hint=str(sc.get("narration_hint", ""))[:300] if isinstance(sc, dict) else "",
        ))
    scenes = scenes[: req.scenes_count]
    if len(scenes) < 3:
        raise ValueError("menos de 3 cenas validas")

    warnings: list[str] = []
    max_words = int(req.target_duration_s * WORDS_PER_SECOND_PT * 1.25)
    words = _count_words(narration)
    if words > max_words:
        warnings.append(f"Narracao com {words} palavras (~{words / WORDS_PER_SECOND_PT:.0f}s de voz), acima do alvo de {req.target_duration_s}s -- considere encurtar.")
    unknown = sorted(_numbers(narration) - _numbers(_product_text(product)))
    if unknown:
        warnings.append("Numeros na narracao que NAO aparecem nos dados do produto (confira antes de publicar): " + ", ".join(unknown))

    hashtags = [h if h.startswith("#") else f"#{h}" for h in map(str, data.get("hashtags", []) or [])][:10]
    return AdPlan(
        hook=str(data.get("hook", ""))[:200], narration=narration, scenes=scenes,
        caption=str(data.get("caption", ""))[:500], hashtags=hashtags, warnings=warnings,
    )


async def generate_plan(llm, product: ProductData, req: AdPlanRequest, model: str | None = None,
                        max_attempts: int = 3) -> AdPlan:
    words = int(req.target_duration_s * WORDS_PER_SECOND_PT)
    system = (SYSTEM_PROMPT
              .replace("{language}", req.language).replace("{tone}", req.tone)
              .replace("{words}", str(words)).replace("{max_words}", str(int(words * 1.2)))
              .replace("{duration}", str(req.target_duration_s)).replace("{n_scenes}", str(req.scenes_count)))
    user = build_user_prompt(product, req)
    last_err = ""
    for attempt in range(1, max_attempts + 1):
        prompt = user if not last_err else (
            user + f"\n\nATENCAO: sua resposta anterior foi rejeitada ({last_err}). "
                   f"Responda de novo, apenas com o JSON no formato pedido."
        )
        raw = await llm.generate_json(system, prompt, model=model, temperature=0.6 if attempt == 1 else 0.3)
        try:
            return parse_plan(raw, product, req)
        except (ValueError, ValidationError) as exc:
            last_err = str(exc)[:200]
            logger.warning("Plano rejeitado (tentativa %d/%d): %s", attempt, max_attempts, last_err)
    raise ProviderUnavailableError(
        f"O modelo do Ollama nao devolveu um roteiro valido apos {max_attempts} tentativas ({last_err}). "
        f"Use um modelo instruct multilingue (ex.: AD_OLLAMA_MODEL=qwen2.5:7b-instruct) em vez do modelo padrao."
    )


def scene_prompt_for_video(scene: AdScene) -> str:
    """Prompt final enviado ao LTX-Video: texto da cena + sufixo fixo de fidelidade."""
    base = scene.visual_prompt.rstrip(". ")
    return base + "." + FIDELITY_SUFFIX
