"""
Pipeline "Criar Propaganda". Roda DENTRO do worker unico da fila (um job por vez), entao
herda a serializacao de GPU do projeto. Duas fases, cada uma um Job:

  ad_plan   : link -> dados do produto -> fotos de referencia -> roteiro/prompts (Ollama)
              (o usuario revisa/edita antes de gastar GPU)
  ad_render : (plano revisado) -> [img2img opcional] -> N clipes LTX-Video (retrato)
              -> libera ComfyUI -> narracao XTTS v2 -> libera XTTS -> ffmpeg -> mp4

TODA geracao de midia (imagem e video) passa EXCLUSIVAMENTE pelo ComfyUI via API:
  - imagem : ComfyUIImageProvider (workflows comfyui_t2i_api.json / comfyui_i2i_api.json)
  - video  : ComfyUIVideoProvider (workflow ltxv_i2v_api.json)
Nao existe fallback para outro backend de imagem: se o ComfyUI estiver fora do ar, o job
falha de imediato com uma mensagem clara (ComfyUIOfflineError).

Ordem de VRAM (nunca dois modelos pesados juntos): Ollama (unload) -> ComfyUI/LTX
(POST /free) -> XTTS (unload) -> ffmpeg (CPU).
"""
from __future__ import annotations

import asyncio
import base64
import io
import logging
import random
import shutil
from pathlib import Path

import httpx
from PIL import Image, ImageFilter

from app.ads import composer, copywriter, imagegen, scraper
from app.ads.models import AdPlanRequest, AdRenderRequest
from app.config import settings
from app.constants import NEGATIVE_PROMPT_DEFAULT
from app.image_utils import resize_image_b64
from app.models import GenerateRequest, Job, JobStatus
from app.providers import xtts_provider
from app.providers.base import ProviderUnavailableError, ResourceExhaustedError
from app.providers.comfyui_provider import ComfyUIImageProvider
from app.providers.comfyui_video_provider import ComfyUIVideoProvider
from app.resource_manager import generate_video_with_guard, get_free_vram_mb
from app.status_manager import status_manager

logger = logging.getLogger("nexus.ads.pipeline")

AD_KINDS = ("ad_plan", "ad_render")


class ComfyUIOfflineError(ProviderUnavailableError):
    """O servidor ComfyUI nao respondeu. Subclasse de ProviderUnavailableError, entao o
    orchestrator/handlers existentes continuam tratando como 503/job FAILED."""

    def __init__(self, host: str):
        super().__init__(
            f"O servidor ComfyUI nao esta respondendo em {host}. Ele precisa estar ativo para gerar "
            f"imagens e videos da propaganda: inicie-o (ex.: `python main.py --listen`) e confira "
            f"COMFYUI_HOST no .env."
        )


def fit_to_portrait(image_bytes: bytes, width: int, height: int) -> bytes:
    """Encaixa a foto em 2:3 SEM cortar o produto: foto inteira centralizada sobre o proprio
    fundo ampliado e desfocado. (Um crop central de foto quadrada cortaria as laterais.)"""
    src = Image.open(io.BytesIO(image_bytes)).convert("RGB")
    bg = src.copy()
    scale = max(width / bg.width, height / bg.height)
    bg = bg.resize((int(bg.width * scale) + 1, int(bg.height * scale) + 1), Image.LANCZOS)
    left, top = (bg.width - width) // 2, (bg.height - height) // 2
    bg = bg.crop((left, top, left + width, top + height)).filter(ImageFilter.GaussianBlur(24))
    fg_scale = min(width / src.width, height / src.height)
    fg = src.resize((max(1, int(src.width * fg_scale)), max(1, int(src.height * fg_scale))), Image.LANCZOS)
    bg.paste(fg, ((width - fg.width) // 2, (height - fg.height) // 2))
    buf = io.BytesIO()
    bg.save(buf, "PNG")
    return buf.getvalue()


def _safe_ref_path(assets_id: str, name: str) -> Path:
    base = (settings.OUTPUT_DIR_ADS / assets_id / "refs").resolve()
    p = (base / name).resolve()
    if base not in p.parents or not p.exists():
        raise ProviderUnavailableError(f"Imagem de referencia '{name}' nao encontrada (o job de plano expirou?).")
    return p


class AdPipeline:
    def __init__(self, llm_provider, image_provider: ComfyUIImageProvider | None = None,
                 video_provider: ComfyUIVideoProvider | None = None):
        # Garantia em tempo de construcao: so ComfyUI gera midia neste modulo.
        if image_provider is not None and not isinstance(image_provider, ComfyUIImageProvider):
            raise TypeError(
                f"AdPipeline aceita apenas ComfyUIImageProvider para imagens (recebido: "
                f"{type(image_provider).__name__}). Defina IMAGE_PROVIDER/injecao em app/main.py para ComfyUI.")
        if video_provider is not None and not isinstance(video_provider, ComfyUIVideoProvider):
            raise TypeError(
                f"AdPipeline aceita apenas ComfyUIVideoProvider para videos (recebido: "
                f"{type(video_provider).__name__}).")
        self.llm = llm_provider
        self.image = image_provider
        self.video = video_provider

    async def run(self, job: Job) -> None:
        if job.kind == "ad_plan":
            await self._plan(job)
        elif job.kind == "ad_render":
            await self._render(job)
        else:
            raise ProviderUnavailableError(f"Tipo de job de propaganda desconhecido: {job.kind}")

    def _progress(self, job: Job, stage: str, message: str, current: int = 0, total: int = 0) -> None:
        job.progress = {"stage": stage, "message": message, "current": current, "total": total}

    # ----------------------------------------------------------------- ComfyUI: disponibilidade
    async def _require_comfyui(self, need_image: bool) -> None:
        """Falha rapido (antes de qualquer etapa pesada) se o ComfyUI estiver offline."""
        providers = [self.video] + ([self.image] if need_image else [])
        for prov in providers:
            if prov is None:
                continue
            if not await prov.health_check():
                raise ComfyUIOfflineError(getattr(prov, "host", settings.COMFYUI_HOST))

    async def _comfy_call(self, factory, host: str):
        """Executa uma chamada ao ComfyUI; se falhar por indisponibilidade, confirma com um
        health check e devolve o erro claro de servidor offline (em vez do erro cru do httpx)."""
        try:
            return await factory()
        except ProviderUnavailableError as exc:
            if isinstance(exc, ComfyUIOfflineError):
                raise
            try:
                async with httpx.AsyncClient(timeout=5) as client:
                    up = (await client.get(f"{host.rstrip('/')}/system_stats")).status_code == 200
            except httpx.HTTPError:
                up = False
            if not up:
                raise ComfyUIOfflineError(host) from exc
            raise

    # ----------------------------------------------------------------- fase 1: plano
    async def _plan(self, job: Job) -> None:
        req: AdPlanRequest = job.request
        self._progress(job, "scraping", "Lendo os dados do produto...")
        if req.manual is not None and not req.url.strip():
            product = scraper.from_manual(req.manual)
        else:
            try:
                product = await scraper.fetch_product(req.url)
            except scraper.ScrapeError as exc:
                if req.manual is None:
                    raise ProviderUnavailableError(str(exc)) from exc
                product = scraper.from_manual(req.manual)
                product.source_url = req.url
                product.warnings.append(f"Leitura automatica falhou ({exc}); usando os dados manuais.")
            else:
                if req.manual is not None:  # manual complementa/sobrescreve o que o usuario informou
                    product.image_urls = list(dict.fromkeys(product.image_urls + req.manual.image_urls))
                    if product.platform == "mercadolivre_parcial":
                        # Leitura parcial (API negou o anuncio): o que o usuario digitou vale mais
                        # que o titulo aproximado tirado do link.
                        product.title = req.manual.title
                        product.price = req.manual.price or product.price
                        if req.manual.description:
                            product.description = req.manual.description
                        product.features = (req.manual.features or product.features)[:20]

        self._progress(job, "images", "Baixando fotos de referencia do produto...")
        product.assets_id = job.id
        files, warns = await scraper.download_reference_images(
            product.image_urls, settings.OUTPUT_DIR_ADS / job.id / "refs", max_images=6)
        product.image_files = files
        product.warnings += warns
        if not files:
            files, gen_warns = await self._generate_reference_images(job, product)
            product.image_files = files
            product.images_generated = True
            product.warnings += gen_warns

        self._progress(job, "script", "Escrevendo roteiro e prompts de cena (Ollama)...")
        job.status = JobStatus.GENERATING_SCRIPT
        await status_manager.set_ollama("busy")
        try:
            plan = await copywriter.generate_plan(self.llm, product, req, model=settings.AD_OLLAMA_MODEL or None)
        finally:
            await self.llm.clear_context()
        job.refined_prompt = plan.narration
        job.result = {"product": product.model_dump(), "plan": plan.model_dump()}
        self._progress(job, "done", "Roteiro pronto para revisao.")

    async def _generate_text_image(self, prompt: str, seed: int | None) -> bytes:
        """text2image no ComfyUI (comfyui_t2i_api.json), em RETRATO. Mesma politica de OOM do img2img:
        tenta de novo, no MESMO ComfyUI, com menos steps/resolucao."""
        assert self.image is not None
        steps, width, height = settings.AD_IMAGE_STEPS, settings.AD_IMAGE_WIDTH, settings.AD_IMAGE_HEIGHT
        free = get_free_vram_mb()
        if free is not None and free < settings.VRAM_SAFETY_MARGIN_MB:
            logger.warning("VRAM livre baixa (%d MB) antes do text2image -- usando parametros reduzidos.", free)
            steps, width, height = (settings.AD_IMAGE_FALLBACK_STEPS, settings.AD_IMAGE_FALLBACK_WIDTH,
                                    settings.AD_IMAGE_FALLBACK_HEIGHT)
        negative = f"{settings.COMFYUI_DEFAULT_NEGATIVE_PROMPT}, {imagegen.EXTRA_NEGATIVE}"
        gen_req = GenerateRequest(user_prompt=prompt, skip_refinement=True, mode="t2i",
                                  negative_prompt=negative, seed=seed)
        attempt = 0
        while True:
            try:
                path = await self._comfy_call(
                    lambda: self.image.generate(prompt, gen_req, steps=steps, resolution=f"{width}*{height}"),
                    self.image.host)
                return Path(path).read_bytes()
            except ResourceExhaustedError as exc:
                attempt += 1
                logger.error("OOM no ComfyUI (text2image, tentativa %d): %s", attempt, exc)
                if attempt > settings.MAX_RETRIES_ON_OOM:
                    raise
                steps, width, height = (settings.AD_IMAGE_FALLBACK_STEPS, settings.AD_IMAGE_FALLBACK_WIDTH,
                                        settings.AD_IMAGE_FALLBACK_HEIGHT)

    async def _generate_reference_images(self, job: Job, product) -> tuple[list[str], list[str]]:
        """Sem fotos reais: cria imagens de referencia pela DESCRICAO do produto (Ollama -> prompt;
        ComfyUI T2I -> imagens). Devolve (ref_N.jpg, avisos) ou levanta ProviderUnavailableError."""
        no_photo = ("Nao consegui baixar nenhuma foto utilizavel do produto. Informe links de imagens "
                    "manualmente (a fidelidade do video depende das fotos reais).")
        if not settings.AD_GENERATE_IMAGES_WHEN_MISSING or self.image is None:
            raise ProviderUnavailableError(no_photo)

        refs = settings.OUTPUT_DIR_ADS / job.id / "refs"
        refs.mkdir(parents=True, exist_ok=True)
        count = max(1, min(6, settings.AD_GENERATED_IMAGES_COUNT))
        files: list[str] = []
        try:
            await self._require_comfyui(need_image=True)  # falha cedo se o ComfyUI estiver fora
            self._progress(job, "images", "Sem fotos do produto: escrevendo o prompt das imagens (Ollama)...")
            await status_manager.set_ollama("busy")
            try:
                base = await imagegen.build_image_prompt(self.llm, product, model=settings.AD_OLLAMA_MODEL or None)
            finally:
                await self.llm.clear_context()  # Ollama fora da VRAM antes do ComfyUI
            seed0 = random.randint(0, 2**31 - 1)
            for i in range(count):
                self._progress(job, "images", f"Criando imagem {i + 1}/{count} pela descricao do produto (ComfyUI)...", i, count)
                raw = await self._generate_text_image(imagegen.view_prompt(base, i), seed0 + i)
                name = f"ref_{len(files)}.jpg"
                if await asyncio.to_thread(scraper.save_reference_jpeg, raw, refs / name):
                    files.append(name)
            await self._free_comfyui()
        except (ProviderUnavailableError, ResourceExhaustedError) as exc:
            if files:  # gerou ao menos uma: segue com as que saíram e avisa
                logger.warning("Geracao de imagens parou apos %d/%d: %s", len(files), count, exc)
            else:
                raise ProviderUnavailableError(f"{no_photo} Tentei criar imagens pela descricao, mas falhou: {exc}") from exc
        if not files:
            raise ProviderUnavailableError(f"{no_photo} As imagens geradas por IA foram descartadas por serem invalidas.")
        warn = (f"Sem fotos reais do produto: {len(files)} imagem(ns) foram CRIADAS POR IA a partir da descricao. "
                "O produto mostrado no video pode diferir do real -- prefira fotos reais antes de publicar.")
        return files, [warn]

    # ----------------------------------------------------------------- fase 2: render
    async def _render(self, job: Job) -> None:
        if self.video is None:
            raise ProviderUnavailableError("Nenhum ComfyUIVideoProvider configurado.")
        req: AdRenderRequest = job.request
        product, plan, opt = req.product, req.plan, req.options
        if not product.image_files:
            raise ProviderUnavailableError("O produto nao tem fotos de referencia.")
        if opt.image_mode == "i2i" and self.image is None:
            raise ProviderUnavailableError("image_mode='i2i' exige ComfyUIImageProvider configurado.")

        # Falha ANTES de gastar tempo (Ollama unload, upload de arquivos...) se o ComfyUI estiver fora.
        await self._require_comfyui(need_image=opt.image_mode == "i2i")

        work = settings.OUTPUT_DIR_ADS / job.id
        work.mkdir(parents=True, exist_ok=True)
        try:
            await self.llm.clear_context()  # garante Ollama fora da VRAM antes do ComfyUI
            job.status = JobStatus.GENERATING_VIDEO
            clips = await self._generate_clips(job, req, work)

            await self._free_comfyui()
            job.status = JobStatus.GENERATING_AUDIO
            self._progress(job, "narration", "Gerando a narracao (XTTS v2)...", 0, 1)
            narration = await self._synthesize_narration(req, work)

            job.status = JobStatus.COMPOSING
            self._progress(job, "compose", "Montando o video final (ffmpeg)...", 0, 1)
            music_path = None
            if req.music_bytes:
                music_path = work / f"music.{req.music_suffix}"
                music_path.write_bytes(req.music_bytes)
            out = settings.OUTPUT_DIR_VIDEOS / f"ad_{job.id}.mp4"
            await asyncio.to_thread(
                composer.compose, clips, narration, plan.narration, out, work / "compose",
                music_path, opt.music_volume, opt.watermark_text, req.watermark_bytes,
                opt.watermark_opacity, opt.captions)
            job.file_path = str(out)
            job.result = {"video_file": out.name, "narration_file": Path(narration).name,
                          "clips": [c.name for c in clips]}
            self._progress(job, "done", "Video pronto.", 1, 1)
        finally:
            req.music_bytes = req.watermark_bytes = req.voice_bytes = None
            await asyncio.to_thread(xtts_provider.unload)
            shutil.rmtree(work / "compose", ignore_errors=True)

    async def _generate_scene_image(self, scene_prompt: str, image_bytes: bytes, seed: int | None) -> bytes:
        """img2img no ComfyUI (comfyui_i2i_api.json), em RETRATO. Em OOM tenta de novo, no
        MESMO ComfyUI, com menos steps/resolucao (sem qualquer troca de backend)."""
        assert self.image is not None
        steps, width, height = settings.AD_IMAGE_STEPS, settings.AD_IMAGE_WIDTH, settings.AD_IMAGE_HEIGHT
        free = get_free_vram_mb()
        if free is not None and free < settings.VRAM_SAFETY_MARGIN_MB:
            logger.warning("VRAM livre baixa (%d MB) antes do img2img -- usando parametros reduzidos.", free)
            steps, width, height = (settings.AD_IMAGE_FALLBACK_STEPS, settings.AD_IMAGE_FALLBACK_WIDTH,
                                    settings.AD_IMAGE_FALLBACK_HEIGHT)
        gen_req = GenerateRequest(
            user_prompt=scene_prompt, skip_refinement=True, mode="i2i",
            image_base64=base64.b64encode(image_bytes).decode(), seed=seed)
        attempt = 0
        while True:
            try:
                path = await self._comfy_call(
                    lambda: self.image.generate(scene_prompt, gen_req, steps=steps, resolution=f"{width}*{height}"),
                    self.image.host)
                return Path(path).read_bytes()
            except ResourceExhaustedError as exc:
                attempt += 1
                logger.error("OOM no ComfyUI (img2img, tentativa %d): %s", attempt, exc)
                if attempt > settings.MAX_RETRIES_ON_OOM:
                    raise
                steps, width, height = (settings.AD_IMAGE_FALLBACK_STEPS, settings.AD_IMAGE_FALLBACK_WIDTH,
                                        settings.AD_IMAGE_FALLBACK_HEIGHT)

    async def _generate_clips(self, job: Job, req: AdRenderRequest, work: Path) -> list[Path]:
        product, plan, opt = req.product, req.plan, req.options
        w, h = settings.AD_VIDEO_WIDTH, settings.AD_VIDEO_HEIGHT
        clips: list[Path] = []
        total = len(plan.scenes)
        for i, scene in enumerate(plan.scenes):
            self._progress(job, "clips", f"Gerando clipe {i + 1}/{total} (LTX-Video via ComfyUI)...", i, total)
            ref_name = product.image_files[min(scene.reference_image, len(product.image_files) - 1)]
            image_bytes = _safe_ref_path(product.assets_id, ref_name).read_bytes()
            prompt = copywriter.scene_prompt_for_video(scene)

            if opt.image_mode == "i2i":
                self._progress(job, "images", f"Variando a imagem da cena {i + 1}/{total} (img2img via ComfyUI)...", i, total)
                image_bytes = await self._generate_scene_image(scene.visual_prompt, image_bytes, opt.seed)

            portrait = fit_to_portrait(image_bytes, w, h)
            await status_manager.set_ltx_video("busy")
            video_path = await self._comfy_call(
                lambda: generate_video_with_guard(
                    self.video, positive_prompt=prompt, negative_prompt=NEGATIVE_PROMPT_DEFAULT,
                    image_bytes=resize_image_b64(base64.b64encode(portrait).decode(), max(w, h)),
                    seed=(opt.seed + i) if opt.seed is not None else None, width=w, height=h),
                self.video.host)
            dest = work / f"clip_{i}{Path(video_path).suffix or '.mp4'}"
            shutil.copyfile(video_path, dest)
            clips.append(dest)
        await status_manager.set_ltx_video("ready")
        return clips

    async def _free_comfyui(self) -> None:
        """Pede ao ComfyUI que descarregue modelos/VRAM (endpoint nativo POST /free) antes do XTTS."""
        try:
            async with httpx.AsyncClient(timeout=15) as client:
                await client.post(f"{settings.COMFYUI_HOST.rstrip('/')}/free",
                                  json={"unload_models": True, "free_memory": True})
        except httpx.HTTPError:
            logger.warning("Nao consegui pedir /free ao ComfyUI; a VRAM pode nao ter sido liberada antes do XTTS.")

    async def _synthesize_narration(self, req: AdRenderRequest, work: Path) -> Path:
        if req.voice_bytes:
            ref = work / f"voice_ref.{req.voice_suffix}"
            ref.write_bytes(req.voice_bytes)
        elif settings.AD_VOICE_REFERENCE_PATH and Path(settings.AD_VOICE_REFERENCE_PATH).exists():
            ref = Path(settings.AD_VOICE_REFERENCE_PATH)
        else:
            raise ProviderUnavailableError(
                "Sem voz de referencia: envie um audio de voz (10-20 s, limpo) ou defina "
                "AD_VOICE_REFERENCE_PATH no .env.")
        await status_manager.set_dubbing("busy")
        try:
            out = await asyncio.to_thread(
                xtts_provider.synthesize, req.plan.narration, str(ref), req.options.voice_language,
                settings.XTTS_MODEL_NAME, settings.XTTS_DEVICE, work)
        except xtts_provider.SynthesisError as exc:
            raise ProviderUnavailableError(str(exc)) from exc
        return Path(out)
