"""
Leitura dos dados do produto para o modulo "Criar Propaganda".

Mercado Livre -> API OFICIAL (api.mercadolibre.com), autenticada com o app criado no DevCenter
(ML_CLIENT_ID / ML_CLIENT_SECRET no .env). Nao baixamos o HTML da pagina: o site redireciona
clientes automatizados para /gz/account-verification, e a API devolve JSON estavel.

Outros sites -> leitura simples e honesta das meta tags OpenGraph (1 tentativa, sem tentar
driblar bloqueios). Se falhar, ScrapeError e o pipeline cai no preenchimento manual.

Contrato usado por app/ads/pipeline.py:
    fetch_product(url)                       -> ProductData   (ou levanta ScrapeError)
    from_manual(manual)                      -> ProductData
    download_reference_images(urls, dir, n)  -> (nomes ref_N.jpg, avisos)
"""
from __future__ import annotations

import asyncio
import html as html_lib
import io
import ipaddress
import logging
import re
import time
from pathlib import Path
from urllib.parse import quote, unquote, urlparse

import httpx
from PIL import Image

from app.ads.models import ManualProduct, ProductData
from app.config import settings
from app.net_safety import UnsafeURLError, assert_public_url, safe_get

logger = logging.getLogger("nexus.ads.scraper")

ML_API = "https://api.mercadolibre.com"
_ML_HOST_RE = re.compile(r"(^|\.)(mercadolivre|mercadolibre)\.(com|com\.br)$", re.I)
_ML_SHORT_HOSTS = ("meli.la",)
_CACHE_TTL_S = 15 * 60
_UA = "Mozilla/5.0 (compatible; NexusBridge/1.0)"

# Permite injetar httpx.MockTransport nos testes.
_TRANSPORT: httpx.AsyncBaseTransport | None = None

_token: dict = {"value": None, "exp": 0.0}
_cache: dict[str, tuple[float, ProductData]] = {}


class ScrapeError(Exception):
    """Falha ao ler o produto automaticamente (o pipeline cai no preenchimento manual)."""


class ScrapeAccessDenied(ScrapeError):
    """A API respondeu 401/403 para o recurso (ex.: anuncio de outro vendedor)."""


# ----------------------------------------------------------------------------- helpers
def _client(**kw) -> httpx.AsyncClient:
    return httpx.AsyncClient(transport=_TRANSPORT, timeout=kw.pop("timeout", 15.0), **kw)


def _creds() -> tuple[str, str]:
    return (settings.ML_CLIENT_ID or "").strip(), (settings.ML_CLIENT_SECRET or "").strip()


def _fmt_price(value, currency: str | None) -> str | None:
    if value is None:
        return None
    try:
        txt = f"{float(value):,.2f}".replace(",", "X").replace(".", ",").replace("X", ".")
    except (TypeError, ValueError):
        return str(value)
    symbol = "R$" if (currency or "BRL") == "BRL" else (currency or "")
    return f"{symbol} {txt}".strip()


def _is_ml_host(host: str) -> bool:
    host = (host or "").lower()
    return bool(_ML_HOST_RE.search(host)) or host in _ML_SHORT_HOSTS


def extract_ml_ids(url: str) -> tuple[str | None, str | None]:
    """Devolve (item_id, product_id) a partir de qualquer link do Mercado Livre.

    Funciona com links de afiliado cheios de parametros (pdp_filters=item_id:MLB...,
    wid=MLB..., ...), URLs de redirecionamento (go=<url codificada>) e paths classicos
    (/MLB-123456-titulo, /p/MLB123456).
    """
    text = url
    for _ in range(3):  # decodifica %3A, %253A (url dentro de url) etc.
        dec = unquote(text)
        if dec == text:
            break
        text = dec
    item = None
    for pat in (r"item_id[:=]\s*(MLB\d+)", r"[?&#]wid=(MLB\d+)", r"(?<!/p)/(MLB)-?(\d{6,})"):
        m = re.search(pat, text, re.I)
        if m:
            item = m.group(1).upper() if m.lastindex == 1 else f"MLB{m.group(2)}"
            break
    pm = re.search(r"/p/(MLB\d+)", text, re.I)
    return item, (pm.group(1).upper() if pm else None)


async def _resolve_short_link(client: httpx.AsyncClient, url: str) -> str:
    """Segue os redirecionamentos de links curtos (meli.la, /sec/...) SEM abrir a pagina final:
    so le o cabecalho Location de cada salto e para assim que aparecer um ID de item."""
    current = url
    for _ in range(6):
        try:
            await assert_public_url(current)
            r = await client.get(current, follow_redirects=False, headers={"User-Agent": _UA})
        except UnsafeURLError as exc:
            raise ScrapeError(f"Link recusado: {exc}") from exc
        except httpx.HTTPError as exc:
            raise ScrapeError(f"Nao consegui abrir o link curto: {exc}") from exc
        loc = r.headers.get("location")
        if not loc:
            break
        current = str(httpx.URL(current).join(loc))
        if any(extract_ml_ids(current)):
            return current
    return current


# ----------------------------------------------------------------------------- API oficial
async def _get_token(client: httpx.AsyncClient, force: bool = False) -> str | None:
    cid, secret = _creds()
    if not cid or not secret:
        return None
    if not force and _token["value"] and time.time() < _token["exp"]:
        return _token["value"]
    try:
        r = await client.post(
            f"{ML_API}/oauth/token",
            data={"grant_type": "client_credentials", "client_id": cid, "client_secret": secret},
            headers={"accept": "application/json"},
        )
    except httpx.HTTPError as exc:
        raise ScrapeError(f"Falha de rede ao autenticar na API do Mercado Livre: {exc}") from exc
    if r.status_code != 200:
        logger.warning("ML oauth/token HTTP %s: %s", r.status_code, r.text[:300])
        raise ScrapeError(
            f"A API do Mercado Livre recusou as credenciais (HTTP {r.status_code}). Confira "
            "ML_CLIENT_ID e ML_CLIENT_SECRET no .env (sem aspas/espacos) e reinicie o servidor.")
    data = r.json()
    _token["value"] = data["access_token"]
    _token["exp"] = time.time() + int(data.get("expires_in", 21600)) - 60
    return _token["value"]


async def check_mercadolivre_credentials() -> tuple[bool, str]:
    """Usado no startup do main.py: confirma que o .env foi lido e que o token sai."""
    cid, secret = _creds()
    if not cid or not secret:
        return False, "ML_CLIENT_ID/ML_CLIENT_SECRET nao configurados no .env (leitura automatica de links do ML desativada)."
    try:
        async with _client(timeout=10.0) as client:
            await _get_token(client, force=True)
    except ScrapeError as exc:
        return False, str(exc)
    return True, f"credenciais OK (app {cid})."


async def _api_get(client: httpx.AsyncClient, path: str) -> httpx.Response:
    async def once(force: bool = False) -> httpx.Response:
        headers = {"accept": "application/json"}
        token = await _get_token(client, force=force)
        if token:
            headers["Authorization"] = f"Bearer {token}"
        return await client.get(f"{ML_API}{path}", headers=headers)

    try:
        r = await once()
        if r.status_code == 401 and _creds()[0]:  # token expirado/revogado: renova uma vez
            r = await once(force=True)
    except httpx.HTTPError as exc:
        raise ScrapeError(f"Falha de rede ao consultar a API do Mercado Livre: {exc}") from exc
    return r


def _check_status(r: httpx.Response, what: str) -> None:
    if r.status_code == 200:
        return
    logger.warning("ML API %s -> HTTP %s: %s", what, r.status_code, (r.text or "")[:400])
    if r.status_code in (401, 403):
        hint = ("" if _creds()[0] else " Configure ML_CLIENT_ID e ML_CLIENT_SECRET no .env.")
        raise ScrapeAccessDenied(f"A API do Mercado Livre negou acesso a {what} (HTTP {r.status_code}).{hint} "
                                 "Use o preenchimento manual.")
    if r.status_code == 404:
        raise ScrapeError(f"{what.capitalize()} nao encontrado no Mercado Livre.")
    raise ScrapeError(f"A API do Mercado Livre respondeu HTTP {r.status_code} para {what}. Use o preenchimento manual.")


def _attrs_to_features(attrs: list[dict]) -> tuple[list[str], str | None]:
    features, brand = [], None
    for a in attrs or []:
        val = (a.get("value_name") or "").strip()
        name = (a.get("name") or "").strip()
        if not val or not name:
            continue
        if a.get("id") == "BRAND":
            brand = val
        features.append(f"{name}: {val}")
    return features[:20], brand


def _build_product(*, source_url: str, title: str, description: str, features: list[str],
                   price: str | None, brand: str | None, image_urls: list[str]) -> ProductData:
    return ProductData(
        source_url=source_url,
        platform="mercadolivre",
        title=(title or "Produto do Mercado Livre").strip()[:300] or "Produto do Mercado Livre",
        description=(description or "").strip()[:8000],
        features=features[:20],
        price=price,
        brand=brand,
        image_urls=list(dict.fromkeys(u for u in image_urls if u)),
    )


async def _fetch_ml_item(client: httpx.AsyncClient, item_id: str, url: str) -> ProductData:
    r = await _api_get(client, f"/items/{item_id}")
    _check_status(r, f"o item {item_id}")
    d = r.json()
    features, brand = _attrs_to_features(d.get("attributes"))
    description = ""
    try:  # descricao e opcional: nao derruba a leitura se falhar
        rd = await _api_get(client, f"/items/{item_id}/description")
        if rd.status_code == 200:
            description = (rd.json().get("plain_text") or "").strip()
    except ScrapeError:
        pass
    pics = [p.get("secure_url") or p.get("url") for p in d.get("pictures") or []]
    if not any(pics) and d.get("thumbnail"):
        pics = [d["thumbnail"].replace("http://", "https://")]
    return _build_product(
        source_url=d.get("permalink") or url,
        title=d.get("title", ""),
        description=description,
        features=features,
        price=_fmt_price(d.get("price"), d.get("currency_id")),
        brand=brand,
        image_urls=pics,
    )


async def _fetch_ml_catalog_product(client: httpx.AsyncClient, product_id: str, url: str) -> ProductData:
    r = await _api_get(client, f"/products/{product_id}")
    _check_status(r, f"o produto {product_id}")
    d = r.json()
    features, brand = _attrs_to_features(d.get("attributes"))
    short = d.get("short_description") or {}
    return _build_product(
        source_url=url,
        title=d.get("name", ""),
        description=(short.get("content") if isinstance(short, dict) else "") or "",
        features=features,
        price=None,
        brand=brand,
        image_urls=[p.get("url") for p in d.get("pictures") or []],
    )


# ----------------------------------------------------------------------------- fallback parcial
_STOP = {"de", "da", "do", "para", "com", "sem", "e", "em", "kit", "uma", "um"}


def _norm_tokens(text: str) -> set[str]:
    import unicodedata
    t = unicodedata.normalize("NFKD", text.lower()).encode("ascii", "ignore").decode()
    return {w for w in re.findall(r"[a-z0-9]+", t) if len(w) > 2 and w not in _STOP}


def title_from_url(url: str) -> str | None:
    """Titulo aproximado a partir do slug do link (o ML nao deixa ler o titulo exato pela API)."""
    path = unquote(urlparse(url).path)
    m = re.search(r"MLB-?\d+-(.+?)-_", path)
    if not m:
        segs = [x for x in path.split("/") if x]
        m = re.match(r"(.+)", segs[0]) if segs and segs[0] not in ("p", "up", "gz") else None
    if not m:
        return None
    words = re.sub(r"[-_]+", " ", m.group(1)).strip()
    return words.title() if len(words) >= 3 else None


async def _fetch_ml_fallback(client: httpx.AsyncClient, item_id: str, url: str, denied: ScrapeError) -> ProductData:
    """Quando a API nega /items/{id} (anuncio de outro vendedor), monta o que as rotas ABERTAS
    permitem: descricao (exata) + titulo do link; e so adota fotos/atributos de um produto do
    catalogo se o nome bater de verdade com o do link (nunca o 'mais parecido')."""
    title = title_from_url(url)
    description = ""
    try:
        rd = await _api_get(client, f"/items/{item_id}/description")
        if rd.status_code == 200:
            description = (rd.json().get("plain_text") or "").strip()
    except ScrapeError:
        pass
    if not title and not description:
        raise denied

    warnings = [
        "A API do Mercado Livre nao libera os dados completos deste anuncio (anuncio de outro vendedor): "
        "titulo tirado do link e descricao lida pela API. Preco e fotos precisam ser informados manualmente."
    ]
    features: list[str] = []
    brand = None
    images: list[str] = []
    if title:
        want = _norm_tokens(title)
        try:
            rs = await _api_get(client, "/products/search?site_id=MLB&status=active&limit=5&q=" + quote(title))
            cands = rs.json().get("results", [])[:5] if rs.status_code == 200 else []
            for cand in cands:
                got = _norm_tokens(cand.get("name") or cand.get("id", ""))
                score = len(want & got) / max(1, len(want | got))
                if score >= 0.8:
                    rp = await _api_get(client, f"/products/{cand['id']}")
                    if rp.status_code == 200:
                        d = rp.json()
                        features, brand = _attrs_to_features(d.get("attributes"))
                        images = [p.get("url") for p in d.get("pictures") or []]
                        title = d.get("name") or title
                        warnings.append(f"Fotos e atributos do produto de catalogo '{title}' (correspondencia {score:.0%}): confira se e o mesmo produto.")
                        break
        except (ScrapeError, ValueError, KeyError):
            pass

    prod = _build_product(source_url=url, title=title or "Produto do Mercado Livre", description=description,
                          features=features, price=None, brand=brand, image_urls=images)
    prod.platform = "mercadolivre_parcial"
    prod.warnings = warnings
    return prod


# ----------------------------------------------------------------------------- outros sites
def _og(text: str, prop: str) -> str | None:
    for pat in (
        rf'<meta[^>]+property=["\']{prop}["\'][^>]+content=["\']([^"\']*)["\']',
        rf'<meta[^>]+content=["\']([^"\']*)["\'][^>]+property=["\']{prop}["\']',
    ):
        m = re.search(pat, text, re.I)
        if m and m.group(1).strip():
            return html_lib.unescape(m.group(1).strip())
    return None


async def _fetch_generic(client: httpx.AsyncClient, url: str) -> ProductData:
    try:
        r = await safe_get(
            client, url, max_bytes=3 * 1024 * 1024,
            headers={"User-Agent": _UA, "Accept-Language": "pt-BR,pt;q=0.9"},
        )
    except UnsafeURLError as exc:
        raise ScrapeError(f"Link recusado: {exc}") from exc
    except httpx.HTTPError as exc:
        raise ScrapeError(f"Falha na leitura automatica do link: {exc}") from exc
    final = str(r.url)
    if r.status_code != 200 or any(k in final for k in ("account-verification", "captcha", "challenge", "/login")):
        raise ScrapeError(f"O site bloqueou a leitura automatica (HTTP {r.status_code}). Utilize o preenchimento manual.")
    title = _og(r.text, "og:title")
    if not title:
        raise ScrapeError("Nao encontrei os dados do produto na pagina. Utilize o preenchimento manual.")
    price = _og(r.text, "product:price:amount") or _og(r.text, "og:price:amount")
    img = _og(r.text, "og:image")
    return ProductData(
        source_url=final, platform="generic", title=title[:300],
        description=(_og(r.text, "og:description") or "")[:8000],
        price=price, image_urls=[img] if img else [],
    )


# ----------------------------------------------------------------------------- API publica
def from_manual(manual: ManualProduct) -> ProductData:
    return ProductData(
        source_url="", platform="manual", title=manual.title, description=manual.description,
        features=list(manual.features), price=manual.price, image_urls=list(manual.image_urls),
    )


async def fetch_product(url: str) -> ProductData:
    url = (url or "").strip()
    parsed = urlparse(url)
    if parsed.scheme not in ("http", "https") or not parsed.hostname:
        raise ScrapeError("Link invalido. Cole o endereco completo do produto (https://...).")

    if not _is_ml_host(parsed.hostname):
        async with _client() as client:
            return await _fetch_generic(client, url)

    item_id, product_id = extract_ml_ids(url)
    async with _client() as client:
        if not item_id and not product_id and (parsed.hostname or "").lower() in _ML_SHORT_HOSTS + ("mercadolivre.com", "mercadolivre.com.br"):
            item_id, product_id = extract_ml_ids(await _resolve_short_link(client, url))
        if not item_id and not product_id:
            raise ScrapeError("Nao consegui identificar o ID do produto no link. Utilize o preenchimento manual.")

        key = item_id or product_id
        hit = _cache.get(key)
        if hit and time.time() - hit[0] < _CACHE_TTL_S:
            return hit[1].model_copy(deep=True)

        if item_id:
            try:
                product = await _fetch_ml_item(client, item_id, url)
            except ScrapeAccessDenied as denied:
                product = await _fetch_ml_fallback(client, item_id, url, denied)
        else:
            product = await _fetch_ml_catalog_product(client, product_id, url)

    _cache[key] = (time.time(), product)
    return product.model_copy(deep=True)


# ----------------------------------------------------------------------------- fotos de referencia
def _blocked_host(host: str) -> bool:
    host = (host or "").lower()
    if host in ("localhost", "") or host.endswith(".local"):
        return True
    try:
        ip = ipaddress.ip_address(host)
        return ip.is_private or ip.is_loopback or ip.is_link_local
    except ValueError:
        return False


def _to_jpeg(raw: bytes) -> bytes | None:
    try:
        img = Image.open(io.BytesIO(raw))
        img.load()
    except Exception:
        return None
    if min(img.size) < 200:
        return None
    if img.mode in ("RGBA", "LA", "P"):
        img = img.convert("RGBA")
        bg = Image.new("RGB", img.size, (255, 255, 255))
        bg.paste(img, mask=img.split()[-1])
        img = bg
    else:
        img = img.convert("RGB")
    if max(img.size) > 2048:
        img.thumbnail((2048, 2048), Image.LANCZOS)
    buf = io.BytesIO()
    img.save(buf, "JPEG", quality=92)
    return buf.getvalue()


def save_reference_jpeg(raw: bytes, dest: Path) -> bool:
    """Converte bytes de imagem (ex.: gerada por IA) em JPEG de referencia. False se invalida."""
    jpg = _to_jpeg(raw)
    if jpg is None:
        return False
    Path(dest).write_bytes(jpg)
    return True


async def download_reference_images(urls: list[str], dest_dir: Path, max_images: int = 6) -> tuple[list[str], list[str]]:
    """Baixa as fotos do produto e salva como ref_0.jpg, ref_1.jpg... (nomes sequenciais,
    como o validador de ProductData.image_files exige). Devolve (arquivos, avisos)."""
    dest_dir = Path(dest_dir)
    dest_dir.mkdir(parents=True, exist_ok=True)
    files: list[str] = []
    warnings: list[str] = []
    async with _client(timeout=20.0, follow_redirects=True) as client:
        for url in urls:
            if len(files) >= max_images:
                break
            p = urlparse(url)
            if p.scheme not in ("http", "https") or _blocked_host(p.hostname or ""):
                warnings.append(f"Imagem ignorada (link invalido): {url[:80]}")
                continue
            try:
                r = await safe_get(client, url, max_bytes=15 * 1024 * 1024, headers={"User-Agent": _UA})
            except UnsafeURLError as exc:
                warnings.append(f"Imagem ignorada ({exc}): {url[:80]}")
                continue
            except httpx.HTTPError as exc:
                warnings.append(f"Falha ao baixar imagem {url[:80]}: {exc}")
                continue
            if r.status_code != 200:
                warnings.append(f"Imagem ignorada (HTTP {r.status_code}): {url[:80]}")
                continue
            jpg = await asyncio.to_thread(_to_jpeg, r.content)
            if jpg is None:
                warnings.append(f"Imagem ignorada (formato invalido ou muito pequena): {url[:80]}")
                continue
            name = f"ref_{len(files)}.jpg"
            (dest_dir / name).write_bytes(jpg)
            files.append(name)
    return files, warnings
