"""
Imagens de referencia geradas por IA, para quando NAO ha fotos reais do produto
(link bloqueado/sem fotos, download falhou, dados so digitados a mao).

Fluxo (usado por app/ads/pipeline.py):
  1. Ollama transforma os dados do produto em UM prompt de imagem em ingles (so o produto,
     fundo de estudio limpo). Se o Ollama falhar, usa-se um prompt-modelo montado do titulo.
  2. ComfyUI (T2I) gera N variacoes mudando so o angulo de camera, em retrato.
  3. O pipeline salva como ref_N.jpg e segue o fluxo normal (roteiro -> clipes).

ATENCAO: sao imagens inventadas a partir do TEXTO; o produto retratado pode diferir do real.
O pipeline marca ProductData.images_generated=True e adiciona um aviso para a UI.
"""
from __future__ import annotations

import json
import logging
import re

from app.ads.models import ProductData

logger = logging.getLogger("nexus.ads.imagegen")

SYSTEM_PROMPT = """You write prompts for a text-to-image model (Stable Diffusion XL).
You receive the data of a product (in Portuguese). Return ONLY valid JSON: {"prompt": "..."}

Rules for "prompt":
- English, 25 to 45 words, a single descriptive sentence made of comma-separated phrases.
- Describe ONLY the product itself: what it is, its shape, materials, colors and the key visible
  features that appear in the data.
- Place it alone, centered, on a clean light studio background with soft studio lighting
  (professional product photography).
- Do NOT invent brands, logos, text, numbers, accessories or features that are not in the data.
- No people, no hands, no packaging text."""

# Variacao de angulo por imagem (so muda a camera, nao o produto).
VIEWS = [
    "front view, centered composition",
    "three-quarter angle view, slightly elevated camera",
    "close-up detail shot of the main feature",
    "top-down overview, product centered",
    "side profile view, centered composition",
    "low angle hero shot, centered composition",
]
QUALITY_SUFFIX = ", sharp focus, high detail, professional product photo, plain studio background"
EXTRA_NEGATIVE = "people, person, hands, text, watermark, logo, multiple products, collage, cluttered background"


def fallback_prompt(product: ProductData) -> str:
    """Prompt-modelo sem LLM: usa o titulo (em pt) + uma ou duas caracteristicas."""
    bits = [product.title.strip()] + [f.split(":", 1)[-1].strip() for f in product.features[:2]]
    subject = ", ".join(b for b in bits if b)
    return f"{subject}, single product centered on a clean light studio background, soft studio lighting"


def _user_prompt(product: ProductData) -> str:
    feats = "\n".join(f"- {f}" for f in product.features[:12]) or "(none)"
    return (f"PRODUCT: {product.title}\nBRAND: {product.brand or 'unknown'}\n"
            f"FEATURES:\n{feats}\nDESCRIPTION:\n{(product.description or '(none)')[:1500]}\n")


def parse_prompt(raw: str) -> str:
    """Extrai o campo 'prompt' do JSON do LLM. Levanta ValueError se invalido."""
    text = re.sub(r"^```(?:json)?|```$", "", raw.strip(), flags=re.MULTILINE).strip()
    m = re.search(r"\{.*\}", text, flags=re.DOTALL)
    data = json.loads(m.group(0) if m else text)
    prompt = str(data.get("prompt", "")).strip().strip('"')
    if len(prompt.split()) < 8:
        raise ValueError("prompt curto demais")
    return prompt[:600]


async def build_image_prompt(llm, product: ProductData, model: str | None = None) -> str:
    try:
        raw = await llm.generate_json(SYSTEM_PROMPT, _user_prompt(product), model=model, temperature=0.4)
        return parse_prompt(raw)
    except Exception as exc:  # qualquer falha do LLM cai no prompt-modelo; nunca derruba o plano
        logger.warning("Prompt de imagem via Ollama falhou (%s); usando prompt-modelo.", exc)
        return fallback_prompt(product)


def view_prompt(base: str, index: int) -> str:
    return f"{base.rstrip('. ,')}, {VIEWS[index % len(VIEWS)]}{QUALITY_SUFFIX}"
