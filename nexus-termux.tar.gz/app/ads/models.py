"""Schemas do modulo Criar Propaganda (planejamento e renderizacao)."""
import re
from typing import Literal, Optional

from pydantic import BaseModel, Field, field_validator

_ASSETS_ID_RE = re.compile(r"^[0-9a-fA-F-]{8,64}$")
_REF_NAME_RE = re.compile(r"^ref_\d{1,2}\.jpg$")


class ManualProduct(BaseModel):
    """Fallback quando a plataforma bloqueia o scraping (ex.: Shopee): usuario digita os dados."""
    title: str = Field(..., min_length=2, max_length=300)
    description: str = Field("", max_length=6000)
    features: list[str] = Field(default_factory=list, max_length=20)
    price: Optional[str] = Field(None, max_length=40)
    image_urls: list[str] = Field(default_factory=list, max_length=10)


class ProductData(BaseModel):
    source_url: str = ""
    platform: str = "generic"
    title: str = Field(..., min_length=2, max_length=300)
    description: str = Field("", max_length=8000)
    features: list[str] = Field(default_factory=list, max_length=20)
    price: Optional[str] = None
    brand: Optional[str] = None
    image_urls: list[str] = Field(default_factory=list)
    # Pasta (dentro de OUTPUT_DIR_ADS) onde as fotos de referencia baixadas foram salvas
    # e os nomes dos arquivos (ref_0.jpg ...). Preenchido pelo job de plano.
    assets_id: str = ""
    image_files: list[str] = Field(default_factory=list)
    # True quando NAO havia fotos reais e as imagens de referencia foram criadas por IA a partir
    # da descricao (app/ads/imagegen.py). A UI deve avisar que o produto retratado pode diferir.
    images_generated: bool = False
    warnings: list[str] = Field(default_factory=list)

    @field_validator("assets_id")
    @classmethod
    def _check_assets_id(cls, v: str) -> str:
        if v and not _ASSETS_ID_RE.match(v):
            raise ValueError("assets_id invalido")
        return v

    @field_validator("image_files")
    @classmethod
    def _check_files(cls, v: list[str]) -> list[str]:
        for name in v:
            if not _REF_NAME_RE.match(name):
                raise ValueError(f"nome de imagem de referencia invalido: {name!r}")
        return v


class AdScene(BaseModel):
    index: int = 0
    # Prompt do clipe (INGLES -- LTX-Video entende melhor), editavel na UI.
    visual_prompt: str = Field(..., min_length=5, max_length=600)
    # Indice em product.image_files usado como primeiro quadro do clipe.
    reference_image: int = Field(0, ge=0, le=9)
    narration_hint: str = ""


class AdPlan(BaseModel):
    hook: str = ""
    # UM unico texto para a voz (sem emoji/markdown) -- e exatamente isso que vai ao XTTS.
    narration: str = Field(..., min_length=10, max_length=3000)
    scenes: list[AdScene] = Field(..., min_length=1, max_length=8)
    caption: str = ""
    hashtags: list[str] = Field(default_factory=list)
    warnings: list[str] = Field(default_factory=list)


class AdPlanRequest(BaseModel):
    url: str = Field("", max_length=2000)
    manual: Optional[ManualProduct] = None
    target_duration_s: int = Field(20, ge=10, le=45)
    scenes_count: int = Field(5, ge=3, le=6)
    tone: str = Field("persuasivo, direto e amigavel", max_length=120)
    language: str = Field("pt-BR", max_length=10)

    def has_source(self) -> bool:
        return bool(self.url.strip()) or self.manual is not None


class AdRenderOptions(BaseModel):
    # "original": usa a foto real do anuncio como 1o quadro (maxima fidelidade ao produto).
    # "i2i": passa a foto pelo ComfyUI img2img (denoise baixo) com o prompt da cena (variacao de cenario).
    image_mode: Literal["original", "i2i"] = "original"
    captions: bool = True
    watermark_text: Optional[str] = Field(None, max_length=60)
    watermark_opacity: float = Field(0.35, ge=0.05, le=1.0)
    music_volume: float = Field(0.14, ge=0.0, le=1.0)
    voice_language: str = Field("pt", max_length=10)
    seed: Optional[int] = None


class AdRenderRequest(BaseModel):
    product: ProductData
    plan: AdPlan
    options: AdRenderOptions = Field(default_factory=AdRenderOptions)
    # Uploads opcionais -- NUNCA serializados no Job (mesmo padrao de DubbingRequest.file_content).
    music_bytes: Optional[bytes] = Field(default=None, exclude=True, repr=False)
    music_suffix: str = Field(default="mp3", exclude=True, repr=False)
    watermark_bytes: Optional[bytes] = Field(default=None, exclude=True, repr=False)
    voice_bytes: Optional[bytes] = Field(default=None, exclude=True, repr=False)
    voice_suffix: str = Field(default="wav", exclude=True, repr=False)
