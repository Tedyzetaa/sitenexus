"""Modulo "Criar Propaganda": link de produto -> roteiro + clipes + narracao -> video vertical final."""
