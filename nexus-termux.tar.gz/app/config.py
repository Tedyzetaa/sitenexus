"""
Configuração centralizada do Nexus-Bridge.
Todos os parâmetros sensíveis a hardware ficam aqui, permitindo
ajuste rápido para diferentes GPUs/CPUs sem tocar no core.
"""
from typing import Annotated

from pydantic import field_validator, model_validator
from pydantic_settings import BaseSettings, NoDecode, SettingsConfigDict
from pathlib import Path

from app import hardware

# Valores aplicados no perfil "lite" (notebook sem GPU dedicada, ~8 GB de RAM) SOMENTE quando o
# campo NAO foi definido no .env / ambiente. Quem escreve o valor no .env sempre ganha.
_LITE_DEFAULTS: dict = {
    "WHISPER_MODEL_SIZE": "base",              # small int8 em i3 de 2 nucleos e lento demais
    "VIDEO_PROVIDER": "kaggle_wan",            # sem GPU local: video so no Kaggle
    "AD_GENERATE_IMAGES_WHEN_MISSING": False,  # imagens por IA exigiriam o ComfyUI local
    "JOB_HISTORY_LIMIT": 50,                   # cada job guarda o request (imagens em base64) na RAM
    "OLLAMA_KEEP_ALIVE_ACTIVE": "2m",          # libera RAM do LLM logo depois do uso
    "DUBBING_BACKGROUND_THRESHOLD_BYTES": 256 * 1024,  # so clipes curtos (~15 s) respondem na hora
    "DUBBING_MAX_UPLOAD_MB": 50,
    "XTTS_IDLE_UNLOAD_S": 90,                  # XTTS ocupa ~2-3 GB: nao deixe residente
    "CALL_IDLE_UNLOAD_S": 300,
}


class Settings(BaseSettings):
    # --- Ollama (LLM) ---
    OLLAMA_HOST: str = "http://localhost:11434"
    OLLAMA_MODEL: str = "jarvis"
    OLLAMA_KEEP_ALIVE_ACTIVE: str = "5m"   # tempo que o modelo fica em VRAM durante uso
    OLLAMA_KEEP_ALIVE_IDLE: str = "0"      # 0 = descarrega o modelo imediatamente apos uso
    OLLAMA_NUM_CTX: int = 2048             # contexto fixo para refinamento de prompt (evita estouro de memoria)

    # --- Fooocus (Imagem) ---
    # Fooocus nativo (webui.py/Gradio) rodando no container Docker oficial --
    # nao ha API REST, a integracao usa gradio_client (ver fooocus_gradio_provider.py).
    FOOOCUS_HOST: str = "http://127.0.0.1:7865"
    FOOOCUS_DEFAULT_STEPS: int = 30
    FOOOCUS_FALLBACK_STEPS: int = 15               # usado em retry apos OOM
    FOOOCUS_DEFAULT_RESOLUTION: str = "1152*896"
    FOOOCUS_FALLBACK_RESOLUTION: str = "896*640"   # resolucao reduzida em retry apos OOM

    # Nome do endpoint Gradio descoberto via tools/discover_fooocus_api.py.
    # Deixe em branco para o provider tentar a lista de candidatos automaticamente.
    FOOOCUS_API_NAME: str = ""

    # Defaults usados quando o request nao especifica (equivalentes aos defaults
    # de fabrica do Fooocus em modules/config.py -- ajuste se seu config.txt
    # ou variaveis de ambiente do container definirem outros modelos).
    # ATENCAO: "model.safetensors" e so o default generico de fabrica do
    # Fooocus (modules/config.py). Confira o nome real do seu checkpoint em
    # config.txt / models/checkpoints dentro do volume do container e ajuste.
    FOOOCUS_BASE_MODEL: str = "model.safetensors"
    FOOOCUS_SAMPLER: str = "dpmpp_2m_sde_gpu"
    FOOOCUS_SCHEDULER: str = "karras"

    # --- Selecao do provider de imagem ---
    # "fooocus" (default, comportamento atual) ou "comfyui" (novo pipeline
    # T2I/I2I via SDXL/Pony Diffusion, ver app/providers/comfyui_provider.py).
    # Trocar aqui NAO exige mudar app/main.py nem o orchestrator.
    IMAGE_PROVIDER: str = "fooocus"

    # --- ComfyUI (Imagem - T2I/I2I via SDXL/Pony Diffusion) ---
    # So relevante quando IMAGE_PROVIDER=comfyui. Reaproveita COMFYUI_HOST/
    # COMFYUI_POLL_INTERVAL_S/COMFYUI_TIMEOUT_S definidos abaixo (mesmo
    # servidor ComfyUI usado pelo pipeline de video).
    COMFYUI_T2I_WORKFLOW_PATH: Path = Path("app/workflows/comfyui_t2i_api.json")
    COMFYUI_I2I_WORKFLOW_PATH: Path = Path("app/workflows/comfyui_i2i_api.json")
    COMFYUI_I2I_DENOISE: float = 0.3   # preserva a estrutura da imagem de entrada (baixo = mais fiel ao original)
    COMFYUI_DEFAULT_LORA_NAME: str = ""  # vazio = usa o lora ja fixado no workflow.json exportado
    COMFYUI_DEFAULT_NEGATIVE_PROMPT: str = "worst quality, low quality, anime, cartoon, deformed"

    # --- ComfyUI (Video - LTX-Video) ---
    # ComfyUI roda como servidor HTTP (diferente do antigo subprocesso que
    # chamava inference.py direto) -- suba com `python main.py --listen`
    # (ou o entrypoint do seu setup) e aponte COMFYUI_HOST pra ele.
    COMFYUI_HOST: str = "http://127.0.0.1:8188"

    # Workflow exportado do ComfyUI em formato API (menu "Workflow > Export
    # (API Format)"). O provider edita este grafo em runtime localizando os
    # nos pelo campo _meta.title -- ver app/workflows/ltxv_i2v_api.json
    # (arquivo de referencia incluso) e o dict _NODE_TITLES em
    # app/providers/comfyui_video_provider.py.
    COMFYUI_WORKFLOW_PATH: Path = Path("app/workflows/ltxv_i2v_api.json")

    COMFYUI_POLL_INTERVAL_S: float = 2.0
    COMFYUI_TIMEOUT_S: int = 600  # 10min -- LTX-Video numa 3050 6GB pode demorar

    # --- ComfyUI (3D - Hunyuan3D 2.0, imagem -> malha) ---
    # Pipeline NATIVO do ComfyUI-Core (sem custom node packs), so gera
    # GEOMETRIA (sem textura/PBR -- ver docstring de
    # app/providers/comfyui_3d_provider.py). Reaproveita COMFYUI_HOST/
    # COMFYUI_POLL_INTERVAL_S/COMFYUI_TIMEOUT_S acima (mesmo servidor
    # ComfyUI usado pelos pipelines de imagem/video).
    COMFYUI_3D_WORKFLOW_PATH: Path = Path("app/workflows/hunyuan3d_i2mesh_api.json")
    # Checkpoint unico (repackaged) que combina MODEL+CLIP_VISION+VAE --
    # baixar de https://huggingface.co/Comfy-Org/hunyuan3D_2.0_repackaged/resolve/main/split_files/hunyuan3d-dit-v2_fp16.safetensors
    # e salvar em ComfyUI/models/checkpoints/.
    COMFYUI_3D_CKPT_NAME: str = "hunyuan3d-dit-v2_fp16.safetensors"
    COMFYUI_3D_STEPS: int = 20     # KSampler -- 20 e o default do template oficial
    COMFYUI_3D_CFG: float = 8.0    # entre 4 e 8 (nota do proprio template oficial)
    COMFYUI_3D_OCTREE_RESOLUTION: int = 256  # detalhe da malha (VAEDecodeHunyuan3D); maior = mais VRAM/tempo
    COMFYUI_3D_OCTREE_RESOLUTION_FALLBACK: int = 128  # usado em retry apos OOM
    COMFYUI_3D_NUM_CHUNKS: int = 8000
    COMFYUI_3D_INPUT_IMAGE_MAX_SIDE: int = 1024  # teto de redimensionamento da imagem de entrada

    # --- Conversao de malha GLB -> FBX (opcional, via Blender headless) ---
    # So usada quando ThreeDGenerateRequest.export_format="fbx". Roblox
    # Studio importa .glb nativamente com o mesmo suporte de .fbx -- ver
    # docstring de app/providers/mesh_converter.py antes de habilitar.
    BLENDER_EXECUTABLE: str = "blender"  # ajuste para o caminho completo se nao estiver no PATH
    BLENDER_TIMEOUT_S: int = 180

    # --- Parametros RIGIDOS do pipeline de video (NUNCA vem do request) ---
    # Fixos deliberadamente no backend, nao em VideoGenerateRequest: numa
    # RTX 3050 6GB, image-to-video acima disso estoura VRAM com facilidade.
    # O orchestrator monta o payload do ComfyUI sempre com estes valores
    # (ver app/services/orchestrator.py e app/providers/comfyui_video_provider.py).
    LTX_INPUT_IMAGE_MAX_SIDE: int = 768   # teto de redimensionamento da imagem de entrada (bate com LTX_WIDTH)
    LTX_WIDTH: int = 768                  # largura do latente de video (no LTXVImgToVideo)
    LTX_HEIGHT: int = 512                 # altura do latente de video
    LTX_LENGTH: int = 81                  # frames do latente de video (faixa validada: 65-97)
    LTX_LENGTH_FALLBACK: int = 65         # usado em retry apos OOM -- piso da faixa validada, nunca abaixo disso
    LTX_DENOISE: float = 1.0              # denoise no KSampler -- NUNCA reduzir, quebra o LTXVImgToVideo (nem no fallback)

    # --- Video remoto: Kaggle (GPU gratis) + ComfyUI + Wan 2.2 5B (T2V/I2V) ---
    # "local_ltx" (default, comportamento atual: LTX-Video no ComfyUI local) ou
    # "kaggle_wan" (o Nexus sobe sozinho um notebook no Kaggle com ComfyUI + Wan 2.2 5B,
    # exposto por um tunel ngrok de URL aleatoria publicada via ntfy.sh, e desliga quando fica ocioso).
    VIDEO_PROVIDER: str = "local_ltx"

    # Credenciais do Kaggle. KAGGLE_USERNAME e sempre obrigatorio.
    # Chave legada (kaggle.json) -> KAGGLE_KEY. Token novo (comeca com KGAT_) -> KAGGLE_API_TOKEN
    # (se voce colar um KGAT_ em KAGGLE_KEY, o Nexus detecta e trata como token).
    KAGGLE_USERNAME: str = ""
    KAGGLE_KEY: str = ""
    KAGGLE_API_TOKEN: str = ""
    KAGGLE_KERNEL_SLUG: str = "nexus-comfyui-wan"   # vira kaggle.com/code/<usuario>/<slug> (privado)
    KAGGLE_ACCELERATOR: str = ""                    # vazio = GPU padrao do Kaggle; ver LIGACAO_KAGGLE.md
    KAGGLE_STARTUP_TIMEOUT_S: int = 1800            # fila do Kaggle + instalar + baixar ~18GB de modelos
    KAGGLE_IDLE_TIMEOUT_MIN: int = 10               # ocioso por tanto tempo -> o notebook se desliga sozinho
    KAGGLE_MAX_SESSION_MIN: int = 180               # teto duro por sessao (protege a cota semanal de GPU)

    # ngrok: so o authtoken e necessario. A URL do tunel e aleatoria a cada sessao.
    NGROK_AUTHTOKEN: str = ""
    NGROK_DOMAIN: str = ""          # LEGADO/ignorado: a URL agora e aleatoria e chega pelo ntfy.sh
    # ntfy.sh: o notebook publica a URL do ngrok neste topico e o Nexus a le. Vazio = o Nexus gera um
    # topico aleatorio e o guarda em .kaggle_state.json. Se definir, use algo longo e dificil de adivinhar.
    NTFY_TOPIC: str = ""
    NTFY_SERVER: str = "https://ntfy.sh"
    HF_TOKEN: str = ""              # opcional (so para modelos que exigem login no Hugging Face)

    # Parametros do Wan 2.2 5B. A resolucao vem do orchestrator (arredondada p/ multiplo de 32);
    # frames/steps/cfg/fps vem daqui. Em retry apos OOM o guard reduz os frames sozinho.
    # Perfil do Wan no Kaggle (define quais modelos o notebook baixa ao iniciar):
    #   draft   = Wan 2.2 5B (rapido, T2V + I2V; qualidade de teste)
    #   quality = Wan 2.2 A14B I2V em GGUF Q4 + Lightning de 4 passos (so I2V; bem melhor, mais lento)
    #   hunyuan = HunyuanVideo 1.5 I2V 480p (so I2V)
    #   r2v     = Wan 2.1 VACE 1.3B REFERENCE-TO-VIDEO (padrao): a foto vira referencia do sujeito, nao o 1o frame
    #   minimax = MiniMax H3 Ref2VA (r2v + audio) -- EXPERIMENTAL no Kaggle (T4/P100 16 GB), ver bloco MINIMAX_* abaixo
    # Trocou o perfil com o notebook ligado? Rode `python tools/kaggle_smoke_test.py stop` antes.
    WAN_PROFILE: str = "r2v"
    WAN14B_I2V_WORKFLOW_PATH: Path = Path("app/workflows/wan22_i2v_a14b_api.json")
    WAN14B_LENGTH: int = 81           # frames (4n+1). O A14B roda a 16 fps: 81 frames = 5 s
    WAN14B_LENGTH_FALLBACK: int = 57  # so apos OOM remoto (4n+1)
    WAN14B_FPS: int = 16
    WAN14B_STEPS: int = 4             # Lightning: 4 passos (2 de ruido alto + 2 de baixo), cfg 1
    WAN14B_CFG: float = 1.0           # com cfg 1 o prompt negativo NAO tem efeito
    WAN14B_MAX_PIXELS: int = 589824   # 576x1024 em 9:16; 768x768 em 1:1. Mais = mais lento/mais VRAM na T4
    WAN_I2V_WORKFLOW_PATH: Path = Path("app/workflows/wan22_i2v_api.json")
    WAN_T2V_WORKFLOW_PATH: Path = Path("app/workflows/wan22_t2v_api.json")
    WAN_LENGTH: int = 121           # frames (4n+1). 121 @ 24fps = 5s (duracao nativa do Wan 5B); 81 = 3.4s
    WAN_LENGTH_FALLBACK: int = 81   # usado so depois de um OOM REMOTO no ComfyUI (4n+1)
    # Orcamento de pixels do video (largura*altura). A proporcao vem da imagem de entrada (quadrada ->
    # 768x768; 16:9 -> 1024x576), em multiplos de 32. Mais pixels = mais detalhe, mas bem mais lento na T4.
    WAN_MAX_PIXELS: int = 589824
    # Prompt negativo do Wan: o oficial (chines) e o que o modelo foi treinado para evitar. Se
    # WAN_APPEND_NEGATIVE=true, o negativo do app (app/constants.py: sem pessoas/maos etc.) vai junto.
    WAN_NEGATIVE_PROMPT: str = "色调艳丽,过曝,静态,细节模糊不清,字幕,风格,作品,画作,画面,静止,整体发灰,最差质量,低质量,JPEG压缩残留,丑陋的,残缺的,多余的手指,画得不好的手部,画得不好的脸部,畸形的,毁容的,形态畸形的肢体,手指融合,静止不动的画面,杂乱的背景,三条腿,背景人很多,倒着走"
    WAN_APPEND_NEGATIVE: bool = True
    WAN_STEPS: int = 20
    WAN_CFG: float = 5.0
    WAN_FPS: int = 24
    WAN_JOB_TIMEOUT_S: int = 2700   # a T4/P100 e bem mais lenta que uma 4090

    # Perfil "hunyuan" (WAN_PROFILE=hunyuan): HunyuanVideo 1.5 imagem->video, 480p, no mesmo notebook do
    # Kaggle. So I2V. O padrao e o checkpoint 480p "step distilled" fp8 (8 passos, cfg 1: o negativo
    # NAO tem efeito). Para o modelo sem destilacao use HUNYUAN_UNET=hunyuanvideo1.5_480p_i2v_fp16.safetensors,
    # HUNYUAN_STEPS=20 e HUNYUAN_CFG=6 (bem mais lento). Trocou o modelo/perfil com o notebook ligado?
    # Rode `python tools/kaggle_smoke_test.py stop` antes.
    HUNYUAN_I2V_WORKFLOW_PATH: Path = Path("app/workflows/hunyuan15_i2v_api.json")
    HUNYUAN_UNET: str = "hunyuanvideo1.5_480p_i2v_step_distilled_fp8_scaled.safetensors"
    HUNYUAN_LENGTH: int = 121            # frames (4n+1); 121 @ 24 fps = 5 s
    HUNYUAN_LENGTH_FALLBACK: int = 81    # so apos OOM remoto (4n+1)
    HUNYUAN_FPS: int = 24
    HUNYUAN_STEPS: int = 8
    HUNYUAN_CFG: float = 1.0
    HUNYUAN_SHIFT: float = 7.0
    HUNYUAN_MAX_PIXELS: int = 409600     # ~480p: 640x640 em 1:1, 848x480 em 16:9, 480x848 em 9:16
    HUNYUAN_NEGATIVE_PROMPT: str = ""    # so tem efeito com HUNYUAN_CFG > 1

    # Perfil "r2v" (WAN_PROFILE=r2v): Wan 2.1 VACE 1.3B em modo reference-to-video. A imagem enviada em
    # `input_image_base64` e usada como REFERENCIA (o sujeito/produto aparece numa cena nova descrita pelo
    # prompt), nao como primeiro frame. Cabe na T4 de 16 GB (modelo ~6,5 GB em fp16). cfg > 1, entao o
    # prompt negativo TEM efeito. Trocou o perfil com o notebook ligado? Rode
    # `python tools/kaggle_smoke_test.py stop` antes.
    R2V_WORKFLOW_PATH: Path = Path("app/workflows/wan21_r2v_vace_api.json")
    R2V_UNET: str = "wan2.1_vace_1.3B_fp16.safetensors"
    R2V_LENGTH: int = 81              # frames (4n+1). 81 @ 16 fps = ~5 s
    R2V_LENGTH_FALLBACK: int = 49     # so apos OOM remoto (4n+1)
    R2V_FPS: int = 16
    R2V_STEPS: int = 30
    R2V_CFG: float = 6.0
    R2V_SHIFT: float = 8.0
    R2V_STRENGTH: float = 1.0         # forca do condicionamento da referencia (WanVaceToVideo.strength)
    R2V_MAX_PIXELS: int = 409600      # ~480p: 640x640 em 1:1, 864x480 em 16:9, 480x864 em 9:16
    R2V_NEGATIVE_PROMPT: str = "色调艳丽,过曝,静态,细节模糊不清,字幕,风格,作品,画作,画面,静止,整体发灰,最差质量,低质量,JPEG压缩残留,丑陋的,残缺的,多余的手指,画得不好的手部,画得不好的脸部,畸形的,毁容的,形态畸形的肢体,手指融合,静止不动的画面,杂乱的背景,三条腿,背景人很多,倒着走"

    # Perfil "minimax" (WAN_PROFILE=minimax): MiniMax H3 Ref2VA (reference-to-video com audio) no Kaggle.
    # EXPERIMENTAL / gambiarra: o modelo e podado de ~20 GB + encoder Qwen3-VL-32B (~15 GB) numa GPU de
    # 16 GB, entao o ComfyUI roda com --lowvram (pesos em streaming da RAM). Precisa de HF_TOKEN de uma conta
    # que aceitou a licenca de Comfy-Org/MiniMax-H3 (repo gated). Na T4 (sem fp8/bf16 nativos) use o
    # checkpoint fp8_scaled; o int8_convrot so vale com pytorch cu130. Trocou o modelo/perfil com o notebook
    # ligado? Rode `python tools/kaggle_smoke_test.py stop` antes.
    MINIMAX_WORKFLOW_PATH: Path = Path("app/workflows/minimax_h3_r2v_api.json")
    MINIMAX_UNET: str = "minimax_h3_ref2va_pruned_fp8_scaled.safetensors"
    MINIMAX_TEXT_ENCODER: str = "qwen3vl_32b_minimax_h3_nvfp4_awq.safetensors"
    MINIMAX_TURBO: bool = True          # LoRA turbo de 4 passos (se o notebook conseguir baixa-lo); senao 20 passos
    MINIMAX_TURBO_LORA: str = "minimax_h3_ref2v_turbo_4step_v0.1_comfyui_bf16.safetensors"
    MINIMAX_LENGTH: int = 39            # frames, formato 17n+5 (22, 39, 56, 73, 124...). 39 @ 24 fps = ~1,6 s
    MINIMAX_LENGTH_FALLBACK: int = 22   # so apos OOM remoto (17n+5)
    MINIMAX_FPS: int = 24
    MINIMAX_STEPS: int = 20             # usado sem o turbo
    MINIMAX_TURBO_STEPS: int = 4
    MINIMAX_MAX_PIXELS: int = 245760    # ~0,25 MP (640x384 em 5:3; 512x480 em ~1:1). O nativo e ~1 MP: nao suba na T4
    MINIMAX_JOB_TIMEOUT_S: int = 5400   # a T4 com offload e MUITO mais lenta que uma 5090

    # --- Gestao de Recursos ---
    VRAM_TOTAL_MB: int = 6144           # RTX 3050 6GB
    VRAM_SAFETY_MARGIN_MB: int = 512    # margem de seguranca
    MAX_RETRIES_ON_OOM: int = 2

    # --- Armazenamento ---
    OUTPUT_DIR: Path = Path("./generated_images")
    OUTPUT_DIR_VIDEOS: Path = Path("./generated_videos")
    OUTPUT_DIR_MESHES: Path = Path("./generated_meshes")
    JOB_HISTORY_LIMIT: int = 200

    # --- Dublagem / Speech-to-Speech ---
    ELEVENLABS_API_KEY: str = ""
    ELEVENLABS_HOST: str = "https://api.elevenlabs.io"
    # Speech-to-Speech exige um modelo com can_do_voice_conversion. "eleven_multilingual_v2"
    # e um modelo de TTS e e rejeitado nesse endpoint.
    ELEVENLABS_DEFAULT_MODEL: str = "eleven_multilingual_sts_v2"
    ELEVENLABS_TIMEOUT_S: int = 120
    # voz usada quando o frontend nao envia voice_id (opcional; ex.: um voice_id da sua biblioteca)
    ELEVENLABS_DEFAULT_VOICE_ID: str = ""
    DEFAULT_DUBBING_PROVIDER: str = "elevenlabs"
    DEFAULT_PROVIDER_TIMEOUT_S: int = 120
    DUBBING_BACKGROUND_THRESHOLD_BYTES: int = 10 * 1024 * 1024
    DUBBING_MAX_UPLOAD_MB: int = 200      # teto de upload nos endpoints de dublagem (413 acima disso)

    # --- Dublagem por traducao local (XTTS v2 + faster-whisper + Ollama) ---
    # Modo default do endpoint de dublagem: "translation_dubbing" preserva a
    # voz original do falante e TRADUZ o audio (hoje fixado para entrada em
    # ingles -> saida em portugues); "voice_conversion" e o Speech-to-Speech
    # da ElevenLabs (troca a voz, NAO traduz).
    DUBBING_DEFAULT_MODE: str = "translation_dubbing"

    # XTTS v2 roda DENTRO do processo do nexus-bridge (torch). Requer uma venv
    # com Python < 3.14 (coqui-tts hoje so suporta >=3.10,<3.14) e o pacote
    # "coqui-tts" instalado -- ver requirements.txt.
    XTTS_MODEL_NAME: str = "tts_models/multilingual/multi-dataset/xtts_v2"
    XTTS_DEVICE: str = "auto"  # "auto" | "cuda" | "cpu"

    # faster-whisper para transcrever o audio de entrada antes da traducao.
    # "small" e um bom equilibrio para ingles numa RTX 3050 6GB, dado que o
    # modelo e carregado/descarregado por job (nunca fica residente junto
    # com XTTS/Ollama/Fooocus -- ver app/providers/whisper_stt.py).
    WHISPER_MODEL_SIZE: str = "small"
    WHISPER_DEVICE: str = "auto"  # "auto" | "cuda" | "cpu"
    WHISPER_SOURCE_LANGUAGE: str = "en"  # idioma de entrada fixo (nao detectado automaticamente)

    # Traducao do texto transcrito: reaproveita o Ollama ja configurado acima
    # (OLLAMA_HOST/OLLAMA_MODEL). Deixe em branco para usar OLLAMA_MODEL.
    TRANSLATION_OLLAMA_MODEL: str = ""
    TRANSLATION_TARGET_LANGUAGE: str = "pt"  # codigo curto aceito pelo XTTS v2 (nao "pt-BR")

    # --- Modo ligacao (conversa por voz: Whisper -> Ollama -> TTS) ---
    # Pensado para PC sem GPU: modelo pequeno, contexto curto, respostas curtas.
    CALL_OLLAMA_MODEL: str = "qwen2.5:1.5b-instruct-q4_0"
    CALL_OLLAMA_NUM_CTX: int = 2048
    CALL_OLLAMA_NUM_PREDICT: int = 160          # teto de tokens por resposta (frases curtas)
    CALL_OLLAMA_TEMPERATURE: float = 0.6
    CALL_OLLAMA_KEEP_ALIVE: str = "30m"         # mantem o modelo na RAM durante a ligacao
    CALL_HISTORY_TURNS: int = 6                 # pares pergunta/resposta lembrados
    CALL_SYSTEM_PROMPT: str = (
        "Voce esta em uma ligacao de voz com o usuario. Responda em {language}, "
        "em frases curtas e naturais (no maximo 3 frases), como numa conversa. "
        "Nao use listas, markdown, emojis nem codigo. Se nao entender, peca para repetir."
    )
    CALL_WHISPER_MODEL: str = "base"            # tiny | base | small (CPU: base e o minimo decente em PT)
    CALL_WHISPER_DEVICE: str = "auto"           # "auto" | "cpu" | "cuda"
    CALL_TTS_ENGINE: str = "xtts"               # "xtts" | "piper"
    CALL_XTTS_SPEAKER: str = "Ana Florence"     # voz embutida do XTTS (sem precisar de audio de referencia)
    CALL_PIPER_MODEL_PATH: str = ""             # so se CALL_TTS_ENGINE=piper (arquivo .onnx)
    CALL_SESSION_TTL_S: int = 1800              # ligacao sem atividade por 30 min e encerrada
    CALL_AUDIO_TTL_S: int = 900                 # audios da ligacao (call_*.wav) apagados apos 15 min
    CALL_IDLE_UNLOAD_S: int = 600               # sem ligacoes ativas: libera Whisper/XTTS da RAM
    CALL_MAX_AUDIO_MB: int = 10                 # tamanho maximo de cada fala enviada

    # --- Mercado Livre (API oficial, usada por app/ads/scraper.py) ---
    # Credenciais do app criado em https://developers.mercadolivre.com.br/devcenter
    # (client_id = "APP ID", client_secret = "Secret Key"). Nunca commitar o .env.
    ML_CLIENT_ID: str = ""
    ML_CLIENT_SECRET: str = ""

    # --- API ---
    # --- OpenHands (agente de codigo; Agent Canvas -> agent-server na 18000) ---
    OPENHANDS_HOST: str = "http://127.0.0.1:18000"
    OPENHANDS_AGENT_PROFILE_ID: str = ""      # id do perfil de agente (GET /api/agent-profiles)
    OPENHANDS_SESSION_API_KEY: str = ""       # so se o agent-server exigir X-Session-API-Key
    OPENHANDS_WORKSPACE: str = r"C:\Cyberverse\workspace"  # o agente so trabalha DENTRO desta pasta
    OPENHANDS_TIMEOUT_S: float = 20.0
    OPENHANDS_MAX_ITERATIONS: int = 60

    # --- Langflow (chat com RAG) ---
    LANGFLOW_HOST: str = "http://127.0.0.1:7860"
    LANGFLOW_FLOW_ID: str = ""
    LANGFLOW_KNOWLEDGE_NODE_ID: str = ""
    LANGFLOW_API_KEY: str = ""
    LANGFLOW_TIMEOUT_S: float = 60.0
    # Descoberta automática de bases (GET /api/rags). Cache em segundos.
    LANGFLOW_RAGS_CACHE_S: float = 30.0
    # Fallback manual se o Langflow não listar: "prog:Programação,juridico:Jurídico"
    LANGFLOW_RAGS: str = ""

    # NoDecode: sem isso o pydantic-settings tenta json.loads() no valor do .env ANTES do
    # validator abaixo e quebra com "error parsing value for field CORS_ORIGINS" quando o
    # valor e "a,b" (separado por virgula). Com NoDecode ambos os formatos funcionam.
    CORS_ORIGINS: Annotated[list[str], NoDecode] = [
        "http://localhost:3000", "http://127.0.0.1:3000",
        "http://localhost:5173", "http://127.0.0.1:5173",
    ]

    # --- Logs ---
    LOG_LEVEL: str = "INFO"

    # --- Saída de áudio ---
    # --- Criar Propaganda (app/ads) ---
    # Modelo do Ollama para roteiro/prompts. Vazio = usa OLLAMA_MODEL. Recomendado: um modelo
    # instruct multilingue que siga JSON (ex.: qwen2.5:7b-instruct), NAO o "jarvis" nem um coder.
    AD_OLLAMA_MODEL: str = ""
    OUTPUT_DIR_ADS: Path = Path("./generated_ads")
    # Video do anuncio em RETRATO (9:16). Multiplos de 32; 512x768 cabe nos 6GB da RTX 3050.
    AD_VIDEO_WIDTH: int = 512
    AD_VIDEO_HEIGHT: int = 768
    # Voz padrao (wav/mp3 de ~10-20s de fala limpa) usada pelo XTTS se o usuario nao enviar uma.
    # img2img (ComfyUI) do modo image_mode="i2i": retrato, com fallback menor em caso de OOM.
    AD_IMAGE_STEPS: int = 25
    AD_IMAGE_WIDTH: int = 768
    AD_IMAGE_HEIGHT: int = 1024
    AD_IMAGE_FALLBACK_STEPS: int = 15
    AD_IMAGE_FALLBACK_WIDTH: int = 512
    AD_IMAGE_FALLBACK_HEIGHT: int = 768
    AD_VOICE_REFERENCE_PATH: str = ""
    # Sem fotos reais do produto (link bloqueado / download falhou): cria imagens de referencia por
    # IA (ComfyUI T2I) a partir da descricao. False = o job de plano falha pedindo fotos manuais.
    AD_GENERATE_IMAGES_WHEN_MISSING: bool = True
    AD_GENERATED_IMAGES_COUNT: int = 3  # 1 a 6 (cada uma vira o primeiro quadro de um clipe)
    AD_MAX_UPLOAD_MB: int = 30
    FFMPEG_BINARY: str = "ffmpeg"
    FFPROBE_BINARY: str = "ffprobe"

    OUTPUT_DIR_AUDIO: Path = Path("./generated_audio")

    # --- Ferramentas J.A.R.V.I.S. (app/tools) ---
    # Monitores de espaco, geofisica, clima, trafego aereo, radio e inteligencia.
    TOOLS_ENABLED: bool = True
    # Se preenchido, TODAS as rotas /api/v1/tools exigem o header "X-Nexus-Token".
    # Obrigatorio para habilitar a camera (TOOLS_ENABLE_SENTINEL).
    TOOLS_API_TOKEN: str = ""
    # true = TODAS as rotas /api (exceto /api/health, midia publica e fotos de referencia) exigem o
    # header X-Nexus-Token = TOOLS_API_TOKEN. Use sempre que expuser o Nexus fora de 127.0.0.1.
    API_REQUIRE_TOKEN: bool = False
    TOOLS_HTTP_TIMEOUT_S: float = 15.0
    TOOLS_HTTP_RETRIES: int = 2
    TOOLS_CACHE_TTL_S: float = 120.0       # evita martelar OpenSky/USGS/NOAA (rate limit)
    TOOLS_CALL_TIMEOUT_S: float = 90.0     # teto duro por chamada de ferramenta
    OUTPUT_DIR_TOOLS: Path = Path("./generated_tools")
    TOOLS_MEDIA_TTL_H: float = 24.0        # arquivos gerados (mapas/prints) expiram
    # Chaves/URLs externas (todas opcionais -- a ferramenta correspondente avisa se faltar).
    NASA_API_KEY: str = "DEMO_KEY"         # DEMO_KEY tem rate limit baixo; crie a sua em api.nasa.gov
    OPENWEATHER_API_KEY: str = ""
    # Ponto "casa" para radar aereo e clima quando nenhuma cidade for informada.
    TOOLS_HOME_NAME: str = "Ivinhema"
    TOOLS_HOME_LAT: float = -22.3044
    TOOLS_HOME_LON: float = -53.8197
    # Recursos pesados/sensiveis: desligados por padrao.
    TOOLS_ENABLE_BROWSER: bool = False     # Playwright (prints de mapas / trajetoria 3D). pip install playwright
    TOOLS_ENABLE_SENTINEL: bool = False    # webcam local. Exige TOOLS_API_TOKEN.
    TOOLS_CAMERA_INDEX: int = 0
    TOOLS_NOAA_MEDIA: bool = False         # baixar imagens SDO/D-RAP no relatorio completo

    # --- v8.0: perfil de hardware ---------------------------------------------------------------
    # "auto" = "gpu" se houver driver NVIDIA (nvidia-smi), senao "lite". "lite" = notebook sem GPU
    # dedicada (ex.: i3-3110M, 8 GB de RAM): tudo em CPU, um modelo pesado por vez, modelos pequenos.
    NEXUS_PROFILE: str = "auto"
    # Threads de calculo (torch/XTTS, faster-whisper, Ollama). 0 = automatico (nucleos fisicos estimados).
    CPU_THREADS: int = 0
    OLLAMA_NUM_THREAD: int = 0              # 0 = usa CPU_THREADS no perfil lite; no perfil gpu deixa o Ollama decidir
    WHISPER_BEAM_SIZE: int = 0              # 0 = automatico: 1 (guloso) no lite, 5 no gpu
    XTTS_IDLE_UNLOAD_S: int = 300           # descarrega o XTTS apos tanto tempo sem uso
    # Guardas de RAM livre (MB) antes de carregar modelos pesados. 0 desliga a guarda.
    MIN_FREE_RAM_XTTS_MB: int = 2500
    MIN_FREE_RAM_WHISPER_MB: int = 600
    # Maximo de jobs AGUARDANDO na fila (HTTP 429 acima disso). 0 = automatico: 10 no lite, 30 no gpu.
    MAX_QUEUED_JOBS: int = 0
    # Cache dos health checks (s): /api/status e chamado em loop pelo front; sem cache cada chamada
    # abria varias conexoes HTTP (Ollama, ComfyUI, Kaggle...) numa CPU que ja esta ocupada.
    HEALTH_CACHE_TTL_S: float = 10.0
    # Aviso no startup se o modelo do Ollama for maior que isto (GB) no perfil lite.
    LITE_MODEL_WARN_GB: float = 3.5
    # true = 500s devolvem {exc!r} ao cliente (so para depurar; o traceback SEMPRE vai para logs/).
    DEBUG_ERRORS: bool = False
    LOG_TO_FILE: bool = True
    LOG_DIR: Path = Path("./logs")
    # --- Mapas/codigo Roblox (roblox_map.py). Antes lidos por os.getenv, o que IGNORAVA o .env. ---
    ROBLOX_OLLAMA_MODEL: str = ""
    ROBLOX_CODE_MODEL: str = ""
    ROBLOX_NUM_CTX: int = 0                 # 0 = automatico: 4096 no lite, 8192 no gpu
    ROBLOX_NUM_PREDICT: int = 0             # 0 = automatico: 3072 no lite, 6144 no gpu
    ROBLOX_CODE_NUM_CTX: int = 0            # 0 = automatico: 4096 no lite, 8192 no gpu
    ROBLOX_CODE_NUM_PREDICT: int = 3072

    model_config = SettingsConfigDict(env_file=".env", extra="ignore")

    @field_validator(
        "ELEVENLABS_API_KEY", "ML_CLIENT_ID", "ML_CLIENT_SECRET",
        "NASA_API_KEY", "OPENWEATHER_API_KEY", "TOOLS_API_TOKEN", mode="before",
    )
    @classmethod
    def clean_api_key(cls, v):
        # remove espacos, quebras de linha e aspas coladas por engano no .env
        return v.strip().strip("\"'").strip() if isinstance(v, str) else v

    @field_validator(
        "KAGGLE_USERNAME", "KAGGLE_KEY", "KAGGLE_API_TOKEN", "NGROK_AUTHTOKEN", "HF_TOKEN",
        "KAGGLE_KERNEL_SLUG", "KAGGLE_ACCELERATOR", "NTFY_TOPIC", "NTFY_SERVER", mode="before",
    )
    @classmethod
    def clean_remote_secrets(cls, v):
        return v.strip().strip("\"'").strip() if isinstance(v, str) else v

    @field_validator("NGROK_DOMAIN", mode="before")
    @classmethod
    def clean_ngrok_domain(cls, v):
        # aceita "https://x.ngrok-free.app/" colado por engano
        if not isinstance(v, str):
            return v
        v = v.strip().strip("\"'").strip()
        for prefix in ("https://", "http://"):
            if v.lower().startswith(prefix):
                v = v[len(prefix):]
        return v.strip("/")


    @field_validator("CORS_ORIGINS", mode="before")
    @classmethod
    def parse_cors(cls, v):
        if isinstance(v, str):
            v = v.strip()
            if v.startswith("["):
                import json
                return json.loads(v)
            return [o.strip() for o in v.split(",") if o.strip()]
        return v

    @model_validator(mode="after")
    def apply_profile(self):
        """Aplica os padroes do perfil escolhido aos campos que o usuario NAO definiu."""
        if self.NEXUS_PROFILE not in ("auto", "lite", "gpu"):
            raise ValueError("NEXUS_PROFILE deve ser 'auto', 'lite' ou 'gpu'. Corrija o .env.")
        if self.profile == "lite":
            explicit = self.model_fields_set
            for name, value in _LITE_DEFAULTS.items():
                if name not in explicit:
                    setattr(self, name, value)
        return self

    # --- v8.0: valores derivados do perfil ---------------------------------------------------
    @property
    def profile(self) -> str:
        if self.NEXUS_PROFILE != "auto":
            return self.NEXUS_PROFILE
        return "gpu" if hardware.has_nvidia_gpu() else "lite"

    @property
    def is_lite(self) -> bool:
        return self.profile == "lite"

    @property
    def cpu_threads(self) -> int:
        return self.CPU_THREADS if self.CPU_THREADS > 0 else hardware.auto_cpu_threads()

    @property
    def whisper_beam_size(self) -> int:
        return self.WHISPER_BEAM_SIZE if self.WHISPER_BEAM_SIZE > 0 else (1 if self.is_lite else 5)

    @property
    def max_queued_jobs(self) -> int:
        return self.MAX_QUEUED_JOBS if self.MAX_QUEUED_JOBS > 0 else (10 if self.is_lite else 30)

    @property
    def roblox_num_ctx(self) -> int:
        return self.ROBLOX_NUM_CTX if self.ROBLOX_NUM_CTX > 0 else (4096 if self.is_lite else 8192)

    @property
    def roblox_num_predict(self) -> int:
        return self.ROBLOX_NUM_PREDICT if self.ROBLOX_NUM_PREDICT > 0 else (3072 if self.is_lite else 6144)

    @property
    def roblox_code_num_ctx(self) -> int:
        return self.ROBLOX_CODE_NUM_CTX if self.ROBLOX_CODE_NUM_CTX > 0 else (4096 if self.is_lite else 8192)

    def ollama_options(self, **extra) -> dict:
        """Opcoes comuns de TODA chamada ao Ollama: CPU-only (num_gpu=0, decisao original do projeto
        para nao disputar GPU com o XTTS) + num_thread. `extra` sobrescreve (ex.: num_ctx, temperature)."""
        opts: dict = {"num_gpu": 0}
        threads = self.OLLAMA_NUM_THREAD if self.OLLAMA_NUM_THREAD > 0 else (self.cpu_threads if self.is_lite else 0)
        if threads > 0:
            opts["num_thread"] = threads
        opts.update(extra)
        return opts

    @model_validator(mode="after")
    def validate_vram(self):
        if self.VRAM_SAFETY_MARGIN_MB >= self.VRAM_TOTAL_MB:
            raise ValueError(
                f"VRAM_SAFETY_MARGIN_MB ({self.VRAM_SAFETY_MARGIN_MB}) nao pode ser "
                f">= VRAM_TOTAL_MB ({self.VRAM_TOTAL_MB}). Corrija o .env."
            )
        if not 1 <= self.AD_GENERATED_IMAGES_COUNT <= 6:
            raise ValueError("AD_GENERATED_IMAGES_COUNT deve estar entre 1 e 6. Corrija o .env.")
        if self.VIDEO_PROVIDER not in ("local_ltx", "kaggle_wan"):
            raise ValueError("VIDEO_PROVIDER deve ser 'local_ltx' ou 'kaggle_wan'. Corrija o .env.")
        if (self.WAN_LENGTH - 1) % 4 != 0 or self.WAN_LENGTH < 5:
            raise ValueError("WAN_LENGTH deve ser 4n+1 (ex.: 49, 65, 81, 97, 121). Corrija o .env.")
        if (self.WAN_LENGTH_FALLBACK - 1) % 4 != 0 or self.WAN_LENGTH_FALLBACK < 5:
            raise ValueError("WAN_LENGTH_FALLBACK deve ser 4n+1 (ex.: 65, 81). Corrija o .env.")
        if self.WAN_PROFILE not in ("draft", "quality", "hunyuan", "r2v", "minimax"):
            raise ValueError("WAN_PROFILE deve ser 'draft', 'quality', 'hunyuan', 'r2v' ou 'minimax'. Corrija o .env.")
        for nm in ("MINIMAX_LENGTH", "MINIMAX_LENGTH_FALLBACK"):
            v = getattr(self, nm)
            if v < 5 or (v - 5) % 17 != 0:
                raise ValueError(f"{nm} deve ser 17n+5 (ex.: 22, 39, 56, 73, 124). Corrija o .env.")
        if self.MINIMAX_STEPS < 1 or self.MINIMAX_TURBO_STEPS < 1:
            raise ValueError("MINIMAX_STEPS e MINIMAX_TURBO_STEPS devem ser >= 1.")
        if self.MINIMAX_MAX_PIXELS < 65536:
            raise ValueError("MINIMAX_MAX_PIXELS muito baixo (minimo 65536, ex.: 245760).")
        import re as _re2
        if not _re2.fullmatch(r"minimax_h3_ref2va_[A-Za-z0-9_]+\.safetensors", self.MINIMAX_UNET):
            raise ValueError("MINIMAX_UNET deve ser um checkpoint ref2va de Comfy-Org/MiniMax-H3 "
                             "(ex.: minimax_h3_ref2va_pruned_fp8_scaled.safetensors).")
        for nm in ("R2V_LENGTH", "R2V_LENGTH_FALLBACK"):
            v = getattr(self, nm)
            if (v - 1) % 4 != 0 or v < 5:
                raise ValueError(f"{nm} deve ser 4n+1 (ex.: 49, 65, 81). Corrija o .env.")
        if self.R2V_STEPS < 1:
            raise ValueError("R2V_STEPS deve ser >= 1.")
        if self.R2V_MAX_PIXELS < 65536:
            raise ValueError("R2V_MAX_PIXELS muito baixo (minimo 65536, ex.: 409600).")
        if not 0.0 <= self.R2V_STRENGTH <= 2.0:
            raise ValueError("R2V_STRENGTH deve estar entre 0 e 2 (padrao 1.0).")
        if not self.R2V_UNET.endswith(".safetensors") or "vace" not in self.R2V_UNET.lower():
            raise ValueError("R2V_UNET deve ser um checkpoint VACE do Wan 2.1 (ex.: wan2.1_vace_1.3B_fp16.safetensors).")
        for nm in ("HUNYUAN_LENGTH", "HUNYUAN_LENGTH_FALLBACK"):
            v = getattr(self, nm)
            if (v - 1) % 4 != 0 or v < 5:
                raise ValueError(f"{nm} deve ser 4n+1 (ex.: 57, 81, 97, 121). Corrija o .env.")
        if self.HUNYUAN_STEPS < 1:
            raise ValueError("HUNYUAN_STEPS deve ser >= 1.")
        if self.HUNYUAN_MAX_PIXELS < 65536:
            raise ValueError("HUNYUAN_MAX_PIXELS muito baixo (minimo 65536, ex.: 409600).")
        import re as _re
        if not _re.fullmatch(r"hunyuanvideo1\.5_[A-Za-z0-9_]+\.safetensors", self.HUNYUAN_UNET):
            raise ValueError("HUNYUAN_UNET deve ser um arquivo do repositorio Comfy-Org/HunyuanVideo_1.5_repackaged "
                             "(ex.: hunyuanvideo1.5_480p_i2v_step_distilled_fp8_scaled.safetensors).")
        for nm in ("WAN14B_LENGTH", "WAN14B_LENGTH_FALLBACK"):
            v = getattr(self, nm)
            if (v - 1) % 4 != 0 or v < 5:
                raise ValueError(f"{nm} deve ser 4n+1 (ex.: 57, 65, 81). Corrija o .env.")
        if self.WAN14B_STEPS < 2 or self.WAN14B_STEPS % 2 != 0:
            raise ValueError("WAN14B_STEPS deve ser par e >= 2 (metade vai para cada especialista).")
        if self.WAN14B_MAX_PIXELS < 65536:
            raise ValueError("WAN14B_MAX_PIXELS muito baixo (minimo 65536, ex.: 589824).")
        if self.WAN_MAX_PIXELS < 65536:
            raise ValueError("WAN_MAX_PIXELS muito baixo (minimo 65536, ex.: 589824 = 768x768).")
        if self.MAX_RETRIES_ON_OOM < 0:
            raise ValueError("MAX_RETRIES_ON_OOM nao pode ser negativo.")
        if self.TOOLS_ENABLE_SENTINEL and not self.TOOLS_API_TOKEN:
            raise ValueError(
                "TOOLS_ENABLE_SENTINEL=true exige TOOLS_API_TOKEN definido no .env "
                "(a camera nao pode ficar exposta sem autenticacao)."
            )
        if self.API_REQUIRE_TOKEN and not self.TOOLS_API_TOKEN:
            raise ValueError("API_REQUIRE_TOKEN=true exige TOOLS_API_TOKEN definido no .env.")
        if self.DUBBING_MAX_UPLOAD_MB < 1:
            raise ValueError("DUBBING_MAX_UPLOAD_MB deve ser >= 1.")
        if self.CPU_THREADS < 0 or self.OLLAMA_NUM_THREAD < 0:
            raise ValueError("CPU_THREADS/OLLAMA_NUM_THREAD nao podem ser negativos.")
        if self.HEALTH_CACHE_TTL_S < 0:
            raise ValueError("HEALTH_CACHE_TTL_S nao pode ser negativo.")
        if not (-90 <= self.TOOLS_HOME_LAT <= 90 and -180 <= self.TOOLS_HOME_LON <= 180):
            raise ValueError("TOOLS_HOME_LAT/TOOLS_HOME_LON fora do intervalo valido.")
        return self


settings = Settings()
settings.OUTPUT_DIR.mkdir(parents=True, exist_ok=True)
settings.OUTPUT_DIR_VIDEOS.mkdir(parents=True, exist_ok=True)
settings.OUTPUT_DIR_AUDIO.mkdir(parents=True, exist_ok=True)
settings.OUTPUT_DIR_MESHES.mkdir(parents=True, exist_ok=True)
settings.OUTPUT_DIR_ADS.mkdir(parents=True, exist_ok=True)
settings.OUTPUT_DIR_TOOLS.mkdir(parents=True, exist_ok=True)
if settings.LOG_TO_FILE:
    settings.LOG_DIR.mkdir(parents=True, exist_ok=True)
