"""Protecao contra SSRF para downloads de URLs fornecidas pelo usuario.

Regras:
  * so http/https, com hostname;
  * o hostname e RESOLVIDO e TODOS os enderecos precisam ser publicos (`ip.is_global`):
    bloqueia loopback, rede privada, link-local (169.254.x.x, metadados de nuvem), CGNAT, multicast,
    reservados e IPv6 equivalentes (inclui IPv4 mapeado em IPv6);
  * redirecionamentos sao seguidos MANUALMENTE e cada salto e revalidado (um site publico nao pode
    redirecionar para http://127.0.0.1:11434);
  * o corpo e lido em streaming com teto de bytes (nada de baixar 2 GB para a RAM).

Limite conhecido: resolve-e-depois-conecta deixa uma janela de DNS rebinding. Para ambientes hostis,
complemente com firewall de saida; para uso local/LAN isto fecha os vetores praticos.
"""
from __future__ import annotations

import asyncio
import ipaddress
import socket
from dataclasses import dataclass
from typing import TYPE_CHECKING, Optional
from urllib.parse import urljoin, urlparse

if TYPE_CHECKING:  # pragma: no cover
    import httpx

_ALLOWED_SCHEMES = ("http", "https")
_REDIRECT_CODES = (301, 302, 303, 307, 308)


class UnsafeURLError(ValueError):
    """URL recusada pela politica anti-SSRF (ou resposta grande demais)."""


@dataclass
class SafeResponse:
    url: str
    status_code: int
    headers: dict
    content: bytes
    encoding: str = "utf-8"

    @property
    def text(self) -> str:
        try:
            return self.content.decode(self.encoding or "utf-8", errors="replace")
        except LookupError:
            return self.content.decode("utf-8", errors="replace")


def _ip_is_public(ip: ipaddress._BaseAddress) -> bool:
    if isinstance(ip, ipaddress.IPv6Address) and ip.ipv4_mapped is not None:
        ip = ip.ipv4_mapped
    return ip.is_global and not ip.is_multicast


async def assert_public_url(url: str) -> None:
    """Levanta UnsafeURLError se a URL nao for http(s) publica."""
    p = urlparse((url or "").strip())
    if p.scheme.lower() not in _ALLOWED_SCHEMES or not p.hostname:
        raise UnsafeURLError("Link invalido (use http:// ou https://).")
    host = p.hostname
    try:
        infos = await asyncio.get_running_loop().getaddrinfo(
            host, p.port or (443 if p.scheme.lower() == "https" else 80),
            type=socket.SOCK_STREAM,
        )
    except socket.gaierror as exc:
        raise UnsafeURLError(f"Nao consegui resolver o endereco '{host}'.") from exc
    if not infos:
        raise UnsafeURLError(f"Nao consegui resolver o endereco '{host}'.")
    for info in infos:
        addr = info[4][0].split("%", 1)[0]  # remove scope id do IPv6 (fe80::1%eth0)
        try:
            ip = ipaddress.ip_address(addr)
        except ValueError as exc:
            raise UnsafeURLError(f"Endereco invalido para '{host}'.") from exc
        if not _ip_is_public(ip):
            raise UnsafeURLError("Endereco bloqueado (rede interna/local nao e permitida).")


async def safe_get(
    client: "httpx.AsyncClient",
    url: str,
    *,
    headers: Optional[dict] = None,
    max_bytes: int = 5 * 1024 * 1024,
    max_redirects: int = 5,
) -> SafeResponse:
    """GET com validacao anti-SSRF em cada salto e teto de tamanho. O `client` NAO pode seguir
    redirecionamentos sozinho (este helper passa follow_redirects=False por requisicao)."""
    current = url
    for _ in range(max_redirects + 1):
        await assert_public_url(current)
        async with client.stream("GET", current, headers=headers, follow_redirects=False) as resp:
            if resp.status_code in _REDIRECT_CODES and resp.headers.get("location"):
                current = urljoin(current, resp.headers["location"])
                continue
            declared = resp.headers.get("content-length")
            if declared and declared.isdigit() and int(declared) > max_bytes:
                raise UnsafeURLError(f"Resposta maior que {max_bytes // (1024 * 1024)} MB.")
            buf = bytearray()
            async for chunk in resp.aiter_bytes():
                buf.extend(chunk)
                if len(buf) > max_bytes:
                    raise UnsafeURLError(f"Resposta maior que {max_bytes // (1024 * 1024)} MB.")
            return SafeResponse(
                url=current, status_code=resp.status_code, headers=dict(resp.headers),
                content=bytes(buf), encoding=resp.encoding or "utf-8",
            )
    raise UnsafeURLError("Redirecionamentos demais.")
