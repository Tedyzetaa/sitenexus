"""Catálogo de RAGs (bases de conhecimento) exposto em GET /api/rags.

Fonte principal: o próprio Langflow (GET /api/v1/knowledge_bases/). Criou uma
base nova lá? Ela aparece nos clientes (web e app) em até LANGFLOW_RAGS_CACHE_S
segundos, sem editar código nem recompilar nada.

Fallback: LANGFLOW_RAGS="prog:Programação,juridico:Jurídico" no .env, usado
quando o Langflow está fora do ar ou a listagem não é permitida (401/403/404).
"""
from __future__ import annotations

import logging
import time
from typing import Any, Callable, Protocol

logger = logging.getLogger("nexus.rag_catalog")

# "geral" = conversa direta com o Ollama (sem RAG). Sempre existe.
GENERAL_ENTRY: dict[str, Any] = {"id": "geral", "label": "Geral", "source": "ollama"}

# Bases que não adianta oferecer ao utilizador.
_HIDDEN_STATUS = {"failed", "empty"}

# Se a listagem falhar, tenta de novo só depois deste tempo (evita martelar o Langflow).
_FAILURE_TTL_S = 5.0


class _KbLister(Protocol):
    async def list_knowledge_bases(self) -> list[dict]: ...


def parse_fallback(raw: str) -> list[dict[str, Any]]:
    """'prog:Programação, juridico' -> [{id:'prog',label:'Programação'},{id:'juridico',...}]"""
    entries: list[dict[str, Any]] = []
    for part in (raw or "").split(","):
        part = part.strip()
        if not part:
            continue
        rag_id, _, label = part.partition(":")
        rag_id = rag_id.strip()
        if not rag_id or rag_id == GENERAL_ENTRY["id"]:
            continue
        entries.append(
            {"id": rag_id, "label": label.strip() or rag_id, "source": "langflow"}
        )
    return entries


def kb_to_entry(info: dict) -> dict[str, Any] | None:
    """Converte um KnowledgeBaseInfo do Langflow em item do catálogo.

    O `id` tem de ser o valor que o dropdown `knowledge_base` do nó aceita, que
    é o nome da pasta (`dir_name`, com "_"). `name` é só o rótulo de tela
    (o Langflow troca "_" por espaço nele).
    """
    name = str(info.get("name") or "").strip()
    dir_name = str(info.get("dir_name") or "").strip() or name.replace(" ", "_")
    if not dir_name or dir_name == GENERAL_ENTRY["id"]:
        return None
    status = info.get("status")
    if status in _HIDDEN_STATUS:
        return None
    return {
        "id": dir_name,
        "label": name or dir_name,
        "source": "langflow",
        "chunks": info.get("chunks"),
        "status": status,
    }


class RagCatalog:
    def __init__(
        self,
        provider: _KbLister,
        fallback_raw: str = "",
        ttl_s: float = 30.0,
        clock: Callable[[], float] = time.monotonic,
    ) -> None:
        self._provider = provider
        self._fallback = parse_fallback(fallback_raw)
        self._ttl_s = ttl_s
        self._clock = clock
        self._cached: dict[str, Any] | None = None
        self._expires_at = 0.0

    async def get(self, force: bool = False) -> dict[str, Any]:
        now = self._clock()
        if not force and self._cached is not None and now < self._expires_at:
            return self._cached

        try:
            infos = await self._provider.list_knowledge_bases()
            dynamic = [e for e in (kb_to_entry(i) for i in infos) if e]
            # rótulos definidos no .env têm prioridade sobre o nome do Langflow
            labels = {e["id"]: e["label"] for e in self._fallback}
            for entry in dynamic:
                entry["label"] = labels.get(entry["id"], entry["label"])
            dynamic.sort(key=lambda e: e["label"].lower())
            result = {"items": [GENERAL_ENTRY, *dynamic], "dynamic": True, "warning": None}
            self._cached, self._expires_at = result, now + self._ttl_s
        except Exception as exc:  # noqa: BLE001 - qualquer falha cai no fallback
            logger.warning("Listagem de bases no Langflow falhou: %s", exc)
            result = {
                "items": [GENERAL_ENTRY, *self._fallback],
                "dynamic": False,
                "warning": f"Não foi possível listar as bases no Langflow: {exc}",
            }
            self._cached, self._expires_at = result, now + _FAILURE_TTL_S
        return result
