import asyncio
import contextlib
import faulthandler
import hmac
import logging
import logging.handlers
import re
import time
from contextlib import asynccontextmanager
from pathlib import Path

from typing import Optional

import uuid

from fastapi import FastAPI, File, Form, HTTPException, Query, Request, UploadFile
from fastapi.exceptions import RequestValidationError
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import FileResponse, JSONResponse
from fastapi.staticfiles import StaticFiles

from app.ads import scraper
from app.ads.models import AdPlanRequest, AdRenderRequest
from app.ads.pipeline import AdPipeline, _safe_ref_path
from app import hardware
from app.config import settings
from app.gpu_lock import GpuBusyError, gpu_slot, gpu_vram_lock
from app.uploads import read_upload_limited
from app.models import (
    DubbingPreviewResponse,
    DubbingRequest,
    DubbingResponse,
    ChatRequest,
    GenerateRequest,
    Job,
    SystemStatus,
    ThreeDGenerateRequest,
    VideoGenerateRequest,
)
from app.providers.comfyui_provider import ComfyUIImageProvider
from app.providers.comfyui_video_provider import ComfyUIVideoProvider
from app.providers.kaggle_runtime import kaggle_manager
from app.providers.kaggle_wan_provider import KaggleWanVideoProvider
from app.providers.comfyui_3d_provider import ComfyUI3DProvider
from app.providers.dubbing_provider import DubbingProvider
from app.providers.translation_dubbing_provider import TranslationDubbingProvider
from app.providers.ollama_provider import OllamaProvider
from app.rag_catalog import RagCatalog
from app.providers.langflow_provider import (
    LangflowConnectionError,
    LangflowNotConfiguredError,
    LangflowProvider,
    LangflowResponseError,
    LangflowTimeoutError,
)
from app.providers.base import ProviderUnavailableError, ResourceExhaustedError
from app.queue_manager import QueueFullError, QueueManager
from app.resource_manager import get_free_vram_mb
from app.services.orchestrator import NexusOrchestrator
from app.status_manager import status_manager
from roblox_map import router as roblox_router
from app.call.router import router as call_router, shutdown_manager as shutdown_call_manager
from app.tools.base import close_http as close_tools_http
from app.tools.router import router as tools_router

VERSION = "8.0.0"

_LOG_FORMAT = "%(asctime)s [%(name)s] %(levelname)s: %(message)s"
_fault_file = None  # mantido aberto: o faulthandler escreve nele quando o processo crasha


def _setup_logging() -> None:
    """Console + arquivo rotativo (logs/nexus.log) + faulthandler (logs/faulthandler.log).

    Resolve o problema de docs/need-fix.md: a janela do console fechava no crash e nao sobrava NENHUM
    traceback. Agora todo log vai tambem para arquivo, e crashes nativos (segfault em ctranslate2/torch,
    que o Python nao consegue capturar) deixam a pilha em faulthandler.log. Idempotente.
    """
    global _fault_file
    root = logging.getLogger()
    if root.handlers:  # ja configurado (uvicorn --reload, testes)
        return
    logging.basicConfig(level=getattr(logging, settings.LOG_LEVEL.upper(), logging.INFO), format=_LOG_FORMAT)
    if not settings.LOG_TO_FILE:
        return
    try:
        fh = logging.handlers.RotatingFileHandler(
            settings.LOG_DIR / "nexus.log", maxBytes=2 * 1024 * 1024, backupCount=3, encoding="utf-8")
        fh.setFormatter(logging.Formatter(_LOG_FORMAT))
        root.addHandler(fh)
        _fault_file = open(settings.LOG_DIR / "faulthandler.log", "a", encoding="utf-8")  # noqa: SIM115
        faulthandler.enable(file=_fault_file, all_threads=True)
    except OSError:
        logging.getLogger("nexus.main").warning("Nao consegui abrir os arquivos de log em %s", settings.LOG_DIR)


_setup_logging()
logger = logging.getLogger("nexus.main")


@asynccontextmanager
async def lifespan(_app: FastAPI):
    """Startup/shutdown (substitui @app.on_event, deprecado no FastAPI)."""
    await _startup()
    try:
        yield
    finally:
        await queue_manager.stop()  # encerra o worker da fila (job em andamento vira 'failed')
        shutdown_call_manager()  # encerra o whisper persistente da ligacao
        await close_tools_http()  # fecha o cliente HTTP compartilhado das ferramentas


app = FastAPI(title="Nexus-Bridge", version=VERSION, lifespan=lifespan)
app.include_router(roblox_router)
app.include_router(call_router)
app.include_router(tools_router)  # J.A.R.V.I.S.: /api/v1/tools (sismos, NOAA, radar, etc.)
from app.openhands_router import router as openhands_router  # noqa: E402
app.include_router(openhands_router)  # /api/v1/openhands (exige TOOLS_API_TOKEN)

_ADS_REF_RE = re.compile(r"^/api/v1/ads/[^/]+/refs/[^/]+$")

if settings.API_REQUIRE_TOKEN:
    @app.middleware("http")
    async def require_api_token(request: Request, call_next):
        """Exige X-Nexus-Token em /api/* (opt-in: API_REQUIRE_TOKEN=true).

        Ficam de fora: preflight CORS, /api/health (watchdogs), midia publica e fotos de referencia
        (usadas em <img>, que nao envia headers). Estaticos (/images, /videos...) nao comecam com /api.
        """
        path = request.url.path
        if (request.method == "OPTIONS" or not path.startswith("/api") or path == "/api/health"
                or path.startswith("/api/v1/tools/media/") or _ADS_REF_RE.match(path)):
            return await call_next(request)
        provided = (request.headers.get("x-nexus-token") or "").encode()
        if not hmac.compare_digest(provided, settings.TOOLS_API_TOKEN.encode()):
            return JSONResponse(status_code=401, content={"error": "unauthorized",
                                                          "detail": "Token invalido ou ausente (header X-Nexus-Token)."})
        return await call_next(request)

app.add_middleware(
    CORSMiddleware,
    allow_origins=settings.CORS_ORIGINS,
    allow_methods=["*"],
    allow_headers=["*"],
)

# --- Injecao de dependencias: ComfyUI para imagem e video ---
# Pipeline unificado: ComfyUI para T2I/I2I (imagem) e LTX-Video (video).
# Ambos provedores implementam o contrato ImageProvider/VideoProvider
# (app/providers/base.py), entao o orchestrator e o resource_manager
# funcionam identicamente com qualquer backend.
llm_provider = OllamaProvider()
image_provider = ComfyUIImageProvider()  # T2I/I2I via ComfyUI
# VIDEO_PROVIDER=local_ltx (default): LTX-Video no ComfyUI local (settings.COMFYUI_HOST).
# VIDEO_PROVIDER=kaggle_wan: Wan 2.2 5B (T2V/I2V) no ComfyUI do Kaggle, ligado sob demanda.
if settings.VIDEO_PROVIDER == "kaggle_wan":
    video_provider = KaggleWanVideoProvider()
else:
    video_provider = ComfyUIVideoProvider()
mesh_provider = ComfyUI3DProvider()      # Hunyuan3D (imagem -> malha) via ComfyUI, mesmo host
dubbing_provider = DubbingProvider(
    api_key=settings.ELEVENLABS_API_KEY,
    host=settings.ELEVENLABS_HOST,
    timeout_s=settings.ELEVENLABS_TIMEOUT_S,
)
# translation_dubbing (modo default) reaproveita o MESMO OllamaProvider usado
# no refinamento de prompt de imagem/video -- um so cliente Ollama no processo.
translation_dubbing_provider = TranslationDubbingProvider(llm_provider=llm_provider)
langflow_provider = LangflowProvider(
    host=settings.LANGFLOW_HOST,
    flow_id=settings.LANGFLOW_FLOW_ID,
    knowledge_node_id=settings.LANGFLOW_KNOWLEDGE_NODE_ID,
    api_key=settings.LANGFLOW_API_KEY,
    timeout_s=settings.LANGFLOW_TIMEOUT_S,
)
rag_catalog = RagCatalog(
    langflow_provider,
    fallback_raw=settings.LANGFLOW_RAGS,
    ttl_s=settings.LANGFLOW_RAGS_CACHE_S,
)
ad_pipeline = AdPipeline(llm_provider, image_provider, video_provider)
orchestrator = NexusOrchestrator(
    llm_provider, image_provider, video_provider,
    dubbing_provider=dubbing_provider,
    translation_dubbing_provider=translation_dubbing_provider,
    mesh_provider=mesh_provider,
    ad_pipeline=ad_pipeline,
)
queue_manager = QueueManager(orchestrator)

_health_cache: dict[tuple[int, str], tuple[float, bool]] = {}


async def _safe_health(check, *, fresh: bool = False) -> bool:
    """Health check que nunca levanta: excecao = servico offline (antes derrubava o startup/rotas).

    v8.0: resultado em cache por HEALTH_CACHE_TTL_S. O front consulta /api/status em loop e cada chamada
    abria 5 conexoes HTTP (Ollama, ComfyUI, Kaggle/ngrok...) -- com timeouts de 5-8 s quando o servico esta
    fora do ar -- numa CPU que ja esta ocupada gerando. `fresh=True` ignora o cache (startup).
    """
    key = (id(getattr(check, "__self__", check)), getattr(check, "__name__", "check"))
    ttl = settings.HEALTH_CACHE_TTL_S
    now = time.monotonic()
    hit = _health_cache.get(key)
    if not fresh and ttl > 0 and hit is not None and now - hit[0] < ttl:
        return hit[1]
    try:
        ok = bool(await check())
    except Exception:  # noqa: BLE001
        logger.exception("health_check levantou excecao; tratando como offline")
        ok = False
    _health_cache[key] = (time.monotonic(), ok)
    return ok


def _default_dubbing_strategy():
    """Estrategia de dublagem usada nos health checks agregados (/api/status, /api/health,
    startup). Reflete settings.DUBBING_DEFAULT_MODE -- um request individual pode escolher
    a outra estrategia via dubbing_mode, mas os health checks agregados mostram o default."""
    if settings.DUBBING_DEFAULT_MODE == "voice_conversion":
        return dubbing_provider
    return translation_dubbing_provider


def _internal_detail(action: str, exc: Exception) -> str:
    """Detalhe do HTTP 500: o `repr` da excecao so vai ao cliente com DEBUG_ERRORS=true (pode vazar
    caminhos/itens internos). O traceback completo SEMPRE fica em logs/nexus.log."""
    if settings.DEBUG_ERRORS:
        return f"Erro interno ao {action}: {exc!r}"
    return f"Erro interno ao {action}. Detalhes em logs/nexus.log (ou ligue DEBUG_ERRORS=true no .env)."


app.mount("/images", StaticFiles(directory=str(settings.OUTPUT_DIR)), name="images")
app.mount("/videos", StaticFiles(directory=str(settings.OUTPUT_DIR_VIDEOS)), name="videos")
app.mount("/audio", StaticFiles(directory=str(settings.OUTPUT_DIR_AUDIO)), name="audio")
app.mount("/meshes", StaticFiles(directory=str(settings.OUTPUT_DIR_MESHES)), name="meshes")


# --- Exception handlers globais -------------------------------------------
# Cobrem falhas que escapam do try/except interno do orchestrator (ex: erro
# sincrono nos proprios endpoints, ou no enqueue) para que a API nunca derrube
# a conexao com um 500 cru sem contexto.

@app.exception_handler(ProviderUnavailableError)
async def provider_unavailable_handler(request: Request, exc: ProviderUnavailableError):
    logger.warning(f"Provider indisponivel em {request.url.path}: {exc}")
    return JSONResponse(
        status_code=503,
        content={"error": "provider_unavailable", "detail": str(exc)},
    )


@app.exception_handler(QueueFullError)
async def queue_full_handler(request: Request, exc: QueueFullError):
    logger.warning("Fila cheia em %s: %s", request.url.path, exc)
    return JSONResponse(status_code=429, content={"error": "queue_full", "detail": str(exc)})


@app.exception_handler(ResourceExhaustedError)
async def resource_exhausted_handler(request: Request, exc: ResourceExhaustedError):
    logger.error(f"VRAM/recurso esgotado em {request.url.path}: {exc}")
    return JSONResponse(
        status_code=503,
        content={"error": "resource_exhausted", "detail": str(exc)},
    )


@app.exception_handler(RequestValidationError)
async def validation_exception_handler(request: Request, exc: RequestValidationError):
    """Loga POR QUE o 422 aconteceu (campo ausente, tipo invalido, corpo truncado...)."""
    errors = [
        {"loc": list(e.get("loc", [])), "msg": e.get("msg"), "type": e.get("type")}
        for e in exc.errors()
    ]
    content_length = request.headers.get("content-length")
    logger.error(
        "422 em %s %s | content-type=%s | content-length=%s | erros=%s",
        request.method, request.url.path,
        request.headers.get("content-type", "")[:60], content_length, errors,
    )
    hint = None
    if any(e["loc"][-1:] == ["file"] and e["type"] == "missing" for e in errors):
        hint = (
            "Campo multipart 'file' ausente. Causas: (1) o frontend usa outro nome de campo; "
            "(2) o corpo chegou TRUNCADO (proxy do Next.js limita o body bufferizado a 10MB "
            "quando ha middleware/proxy) -- envie direto ao FastAPI ou aumente "
            "experimental.middlewareClientMaxBodySize / proxyClientMaxBodySize."
        )
    return JSONResponse(status_code=422, content={"error": "validation_error", "detail": errors, "hint": hint})


@app.exception_handler(Exception)
async def unhandled_exception_handler(request: Request, exc: Exception):
    logger.exception(f"Erro nao tratado em {request.url.path}")
    return JSONResponse(
        status_code=500,
        content={"error": "internal_error", "detail": "Erro interno. Verifique os logs do nexus-bridge."},
    )


async def _lite_startup_warnings(ollama_ok: bool, hw: dict) -> None:
    """Avisos objetivos para o perfil lite (nada aqui bloqueia o startup)."""
    free, total = hw.get("ram_available_mb"), hw.get("ram_total_mb")
    if total is not None and total < 6000:
        logger.warning("RAM total de %d MB: perfil lite ativo. XTTS (~2-3 GB) e LLM nunca rodam juntos.", total)
    if free is not None and free < 3000:
        logger.warning("Apenas %d MB de RAM livres agora. Feche o navegador/outros programas antes de dublar.", free)
    if ollama_ok:
        for label, model in (("OLLAMA_MODEL", settings.OLLAMA_MODEL),
                             ("CALL_OLLAMA_MODEL", settings.CALL_OLLAMA_MODEL)):
            size_mb = await llm_provider.model_size_mb(model)
            if size_mb and size_mb > settings.LITE_MODEL_WARN_GB * 1024:
                logger.warning(
                    "%s='%s' tem ~%.1f GB: em 8 GB de RAM e uma CPU de 2 nucleos ele vai ser MUITO lento (e pode "
                    "faltar memoria). Prefira um modelo 1.5B-3B quantizado (ex.: qwen2.5:3b-instruct-q4_K_M).",
                    label, model, size_mb / 1024)


async def _startup():
    queue_manager.start()
    hw = hardware.snapshot()
    logger.info(
        "Nexus-Bridge v%s | perfil=%s | CPU %d threads logicas (usando %d) | RAM %s MB total / %s MB livre | GPU NVIDIA=%s",
        VERSION, settings.profile, hw["cpu_logical"], settings.cpu_threads,
        hw["ram_total_mb"], hw["ram_available_mb"], hw["nvidia_gpu"],
    )
    ollama_ok, fooocus_ok, ltx_ok, mesh_ok, dubbing_ok, langflow_ok = await asyncio.gather(
        _safe_health(llm_provider.health_check, fresh=True),
        _safe_health(image_provider.health_check, fresh=True),
        _safe_health(video_provider.health_check, fresh=True),
        _safe_health(mesh_provider.health_check, fresh=True),
        _safe_health(_default_dubbing_strategy().health_check, fresh=True),
        _safe_health(langflow_provider.health_check, fresh=True),
    )
    await status_manager.set_ollama("ready" if ollama_ok else "offline")
    await status_manager.set_fooocus("ready" if fooocus_ok else "offline")
    await status_manager.set_ltx_video("ready" if ltx_ok else "offline")
    await status_manager.set_comfyui_3d("ready" if mesh_ok else "offline")
    await status_manager.set_dubbing("ready" if dubbing_ok else "offline")
    logger.info(
        f"Startup: Ollama={ollama_ok} Fooocus={fooocus_ok} LTX-Video={ltx_ok} "
        f"Hunyuan3D={mesh_ok} Langflow={langflow_ok} Dubbing={dubbing_ok}"
    )
    if settings.is_lite:
        await _lite_startup_warnings(ollama_ok, hw)
    # Mercado Livre (API oficial): le ML_CLIENT_ID/ML_CLIENT_SECRET do .env e testa o token.
    ml_ok, ml_msg = await scraper.check_mercadolivre_credentials()
    (logger.info if ml_ok else logger.warning)(f"Mercado Livre API: {ml_msg}")
    if settings.VIDEO_PROVIDER == "kaggle_wan":
        logger.info(
            "Video: Wan 2.2 5B no Kaggle (sob demanda) -- offline agora e normal; "
            "o notebook sobe sozinho no primeiro job de video."
        )
    elif not ltx_ok:
        logger.warning(
            f"ComfyUI nao respondeu em {settings.COMFYUI_HOST} -- "
            f"jobs de video vao falhar ate COMFYUI_HOST ser corrigido no .env "
            f"(e o servidor do ComfyUI estiver de pe)."
        )


@app.post("/api/generate", response_model=Job)
async def generate(req: GenerateRequest):
    job = Job(user_prompt=req.user_prompt, request=req)
    if req.skip_refinement:
        job.refined_prompt = req.user_prompt
    await queue_manager.enqueue(job)
    return job


# --- Criar Propaganda (app/ads) -------------------------------------------
# Fluxo em 2 jobs na MESMA fila (um por vez -> sem disputa de VRAM):
#   POST /api/v1/ads/plan   -> job ad_plan   (job.result = {product, plan})  [usuario revisa]
#   POST /api/v1/ads/render -> job ad_render (job.file_path = mp4 em /videos, job.progress = etapa)

_AD_EXT = {"music": {"mp3", "wav", "m4a"}, "voice": {"mp3", "wav", "m4a"}, "watermark": {"png", "jpg", "jpeg", "webp"}}


async def _read_ad_upload(upload: Optional[UploadFile], kind: str) -> tuple[Optional[bytes], str]:
    if upload is None or not (upload.filename or "").strip():
        return None, ""
    suffix = Path(upload.filename).suffix.lstrip(".").lower()
    if suffix not in _AD_EXT[kind]:
        raise HTTPException(status_code=400, detail=f"Formato invalido para '{kind}': use {', '.join(sorted(_AD_EXT[kind]))}.")
    body = await read_upload_limited(upload, settings.AD_MAX_UPLOAD_MB, f"Arquivo '{kind}'")
    if not body:
        raise HTTPException(status_code=400, detail=f"Arquivo '{kind}' vazio.")
    return body, suffix


@app.post("/api/v1/ads/plan", response_model=Job)
async def ads_plan(req: AdPlanRequest):
    """Passo 1: le o produto (link ou dados manuais), baixa as fotos de referencia e escreve o roteiro."""
    if not req.has_source():
        raise HTTPException(status_code=422, detail="Informe o link do produto ou preencha os dados manualmente.")
    job = Job(user_prompt=req.url.strip() or req.manual.title, request=req, kind="ad_plan")
    await queue_manager.enqueue(job)
    return job


@app.post("/api/v1/ads/render", response_model=Job)
async def ads_render(
    payload: str = Form(..., description="JSON de AdRenderRequest (product, plan, options)"),
    music: Optional[UploadFile] = File(None),
    watermark: Optional[UploadFile] = File(None),
    voice: Optional[UploadFile] = File(None),
):
    """Passo 2: gera clipes + narracao e monta o video final com o plano (ja revisado) do passo 1."""
    try:
        req = AdRenderRequest.model_validate_json(payload)
    except ValueError as exc:
        raise HTTPException(status_code=422, detail=f"payload invalido: {exc}") from exc
    if not req.product.image_files or not req.product.assets_id:
        raise HTTPException(status_code=422, detail="O produto precisa ter fotos de referencia (rode o passo /plan).")
    try:
        for name in req.product.image_files:
            _safe_ref_path(req.product.assets_id, name)
    except Exception as exc:  # ProviderUnavailableError -> 422 legivel
        raise HTTPException(status_code=422, detail=str(exc)) from exc
    req.music_bytes, req.music_suffix = await _read_ad_upload(music, "music")
    req.watermark_bytes, _ = await _read_ad_upload(watermark, "watermark")
    req.voice_bytes, req.voice_suffix = await _read_ad_upload(voice, "voice")
    job = Job(user_prompt=f"Propaganda: {req.product.title[:80]}", request=req, kind="ad_render")
    await queue_manager.enqueue(job)
    return job


@app.get("/api/v1/ads/{assets_id}/refs/{name}")
async def ads_reference_image(assets_id: str, name: str):
    """Serve SOMENTE as fotos de referencia (nao expoe clipes/uploads da pasta de trabalho)."""
    try:
        path = _safe_ref_path(assets_id, name)
    except Exception:
        raise HTTPException(status_code=404, detail="Imagem nao encontrada.")
    if not name.startswith("ref_") or path.suffix != ".jpg":
        raise HTTPException(status_code=404, detail="Imagem nao encontrada.")
    return FileResponse(path, media_type="image/jpeg")


@app.get("/api/rags")
async def list_rags(refresh: bool = False):
    """Bases de conhecimento disponíveis (descobertas no Langflow).

    Resposta: {"items":[{"id","label","source"}], "dynamic": bool, "warning": str|null}.
    `geral` (Ollama direto) vem sempre primeiro. `?refresh=1` ignora o cache.
    """
    return await rag_catalog.get(force=refresh)


@app.post("/api/chat")
async def chat(req: ChatRequest):
    """Encaminha a mensagem e a seleção RAG ao flow configurado no Langflow."""
    try:
        return await langflow_provider.run_chat(req.message, req.selected_rag)
    except LangflowNotConfiguredError as exc:
        raise HTTPException(status_code=503, detail=str(exc)) from exc
    except LangflowTimeoutError as exc:
        raise HTTPException(status_code=504, detail=str(exc)) from exc
    except (LangflowConnectionError, LangflowResponseError) as exc:
        raise HTTPException(status_code=502, detail=str(exc)) from exc


@app.get("/api/kaggle/status")
async def kaggle_status():
    """Estado do ComfyUI remoto no Kaggle (online?, status do kernel, URL)."""
    if settings.VIDEO_PROVIDER != "kaggle_wan":
        return {"enabled": False, "video_provider": settings.VIDEO_PROVIDER}
    return {"enabled": True, **(await kaggle_manager.status())}


@app.post("/api/kaggle/stop")
async def kaggle_stop():
    """Pede ao notebook do Kaggle para se desligar agora (libera a GPU e poupa a cota)."""
    if settings.VIDEO_PROVIDER != "kaggle_wan":
        raise HTTPException(status_code=400, detail="VIDEO_PROVIDER nao e kaggle_wan.")
    return {"stop_requested": await kaggle_manager.stop()}


@app.post("/api/generate-video", response_model=Job)
async def generate_video(req: VideoGenerateRequest):
    job = Job(user_prompt=req.user_prompt, request=req, kind="video")
    if req.skip_refinement:
        job.refined_prompt = req.user_prompt
    await queue_manager.enqueue(job)
    return job


@app.post("/api/generate-3d", response_model=Job)
async def generate_3d(req: ThreeDGenerateRequest):
    """Gera uma malha 3D (imagem -> .glb/.fbx) via Hunyuan3D (ComfyUI).

    Sem refinamento de prompt (nao ha campo de texto): a geracao usa so a
    imagem de entrada. export_format="fbx" aciona conversao adicional via
    Blender headless (ver app/providers/mesh_converter.py) -- "glb" (default)
    e o formato nativo do ComfyUI e o Roblox Studio importa ambos igualmente bem.
    """
    job = Job(user_prompt="[image-to-3d]", request=req, kind="3d")
    job.refined_prompt = "[sem refinamento -- pipeline 3D usa somente a imagem de entrada]"
    await queue_manager.enqueue(job)
    return job


@app.get("/api/jobs/{job_id}", response_model=Job)
async def get_job(job_id: str):
    job = queue_manager.get_job(job_id)
    if not job:
        raise HTTPException(status_code=404, detail="Job nao encontrado")
    return job


@app.get("/api/gallery", response_model=list[Job])
async def gallery(offset: int = Query(0, ge=0), limit: int = Query(20, ge=1, le=200)):
    all_jobs = queue_manager.list_jobs(limit=settings.JOB_HISTORY_LIMIT)
    completed = [j for j in all_jobs if j.status == "completed"]
    return completed[offset: offset + limit]


@app.get("/api/status", response_model=SystemStatus)
async def status():
    live_ollama, live_fooocus, live_ltx, live_mesh, live_dubbing = await asyncio.gather(
        _safe_health(llm_provider.health_check),
        _safe_health(image_provider.health_check),
        _safe_health(video_provider.health_check),
        _safe_health(mesh_provider.health_check),
        _safe_health(_default_dubbing_strategy().health_check),
    )
    await status_manager.set_ollama("ready" if live_ollama else "offline")
    await status_manager.set_fooocus("ready" if live_fooocus else "offline")
    await status_manager.set_ltx_video("ready" if live_ltx else "offline")
    await status_manager.set_comfyui_3d("ready" if live_mesh else "offline")
    await status_manager.set_dubbing("ready" if live_dubbing else "offline")
    return await status_manager.snapshot()


@app.get("/api/system")
async def system_info():
    """Diagnostico leve do hardware/perfil (RAM, threads, modelos residentes). Nao chama servicos externos."""
    from app.providers import whisper_stt, xtts_provider  # imports leves (torch so carrega no 1o uso)

    return {
        "version": VERSION,
        "profile": settings.profile,
        "hardware": hardware.snapshot(),
        "cpu_threads_in_use": settings.cpu_threads,
        "heavy_job_running": gpu_vram_lock.locked(),
        "queue": {"max_queued_jobs": settings.max_queued_jobs},
        "resident_models": {
            "xtts_in_this_process": xtts_provider._model is not None,
            "whisper_in_this_process": whisper_stt._model is not None,
        },
        "models": {
            "ollama": settings.OLLAMA_MODEL,
            "call_ollama": settings.CALL_OLLAMA_MODEL,
            "whisper": settings.WHISPER_MODEL_SIZE,
            "call_whisper": settings.CALL_WHISPER_MODEL,
            "call_tts_engine": settings.CALL_TTS_ENGINE,
        },
        "video_provider": settings.VIDEO_PROVIDER,
    }


@app.get("/api/health")
async def health():
    """
    Health check ativo: nao retorna so um 200 fixo. Verifica de fato se o
    Ollama esta respondendo na porta configurada E se o modelo definido em
    OLLAMA_MODEL esta instalado/pronto, alem do status do Fooocus e da VRAM
    livre no momento. Retorna 503 quando algo essencial esta fora do ar, para
    que qualquer watchdog/orquestrador externo detecte o problema de verdade.
    """
    (ollama_ready, ollama_detail), fooocus_ok, ltx_ok, mesh_ok, dubbing_ok = await asyncio.gather(
        llm_provider.model_ready(),
        _safe_health(image_provider.health_check),
        _safe_health(video_provider.health_check),
        _safe_health(mesh_provider.health_check),
        _safe_health(_default_dubbing_strategy().health_check),
    )
    free_vram = get_free_vram_mb()

    # LTX-Video e o pipeline 3D ficam FORA do overall_ok de proposito: sao
    # recursos opcionais, o pipeline de imagem (Ollama+Fooocus) deve
    # continuar reportando "ok" mesmo se COMFYUI_HOST estiver mal configurado.
    # v8.0, perfil lite: nao ha gerador de imagem local (sem GPU), entao exigi-lo deixaria o
    # /api/health SEMPRE em 503 "degraded". Aqui o essencial e o Ollama.
    overall_ok = ollama_ready if settings.is_lite else (ollama_ready and fooocus_ok)

    return JSONResponse(
        status_code=200 if overall_ok else 503,
        content={
            "status": "ok" if overall_ok else "degraded",
            "service": "nexus-bridge",
            "version": VERSION,
            "profile": settings.profile,
            "ollama": {"ready": ollama_ready, "detail": ollama_detail},
            "fooocus": {"ready": fooocus_ok},
            "ltx_video": {"ready": ltx_ok},
            "comfyui_3d": {"ready": mesh_ok},
            "dubbing": {"ready": dubbing_ok},
            "vram_free_mb": free_vram,
        },
    )


@app.post("/api/v1/dubbing/process", response_model=DubbingResponse)
async def process_dubbing(
    file: UploadFile = File(...),
    dubbing_mode: Optional[str] = Form(None),
    source_language: Optional[str] = Form("en"),
    target_language: Optional[str] = Form("pt-BR"),
    provider: Optional[str] = Form("elevenlabs"),
    voice_id: Optional[str] = Form(None),
    model_id: Optional[str] = Form(None),
    language_code: Optional[str] = Form(None),
    stability: float = Form(0.5),
    similarity_boost: float = Form(0.75),
    style: float = Form(0.0),
    speaker_boost: bool = Form(True),
    output_format: str = Form("mp3"),
):
    """Endpoint de dublagem com upload de áudio.

    dubbing_mode escolhe a estratégia (default: settings.DUBBING_DEFAULT_MODE =
    "translation_dubbing" -- preserva a voz original e TRADUZ o áudio via pipeline
    local whisper->Ollama->XTTS v2). "voice_conversion" usa o Speech-to-Speech da
    ElevenLabs (troca a voz, NÃO traduz) e nesse caso voice_id é obrigatório.

    Arquivos >= DUBBING_BACKGROUND_THRESHOLD_BYTES vão para a fila (retorna job_id para polling
    em /api/jobs/{job_id}); menores são processados de forma síncrona.
    """
    # Captura TUDO aqui: um 500 vindo do handler global (ServerErrorMiddleware) fica fora do
    # CORSMiddleware e, num fetch direto do browser, vira "Failed to fetch" sem mensagem.
    # HTTPException passa pelo CORS e chega ao cliente com o corpo JSON legível.
    try:
        resolved_mode = (dubbing_mode or settings.DUBBING_DEFAULT_MODE or "translation_dubbing").strip()
        if resolved_mode not in {"voice_conversion", "translation_dubbing"}:
            raise HTTPException(
                status_code=400,
                detail=f"dubbing_mode inválido: {resolved_mode!r}. Use 'voice_conversion' ou 'translation_dubbing'.",
            )

        voice_id = (voice_id or "").strip() or settings.ELEVENLABS_DEFAULT_VOICE_ID.strip()
        if resolved_mode == "voice_conversion" and not voice_id:
            raise HTTPException(
                status_code=400,
                detail="Informe o voice_id da ElevenLabs (campo 'voice_id') ou defina "
                       "ELEVENLABS_DEFAULT_VOICE_ID no .env do nexus-bridge (obrigatório "
                       "apenas em dubbing_mode='voice_conversion').",
            )

        name = (file.filename or "audio").lower()
        suffix = Path(name).suffix.lstrip(".").lower()
        if suffix not in {"wav", "mp3", "m4a"}:
            raise HTTPException(status_code=400, detail="Formato de áudio inválido. Envie WAV, MP3 ou M4A.")

        raw_audio = await read_upload_limited(file, settings.DUBBING_MAX_UPLOAD_MB, "Arquivo de áudio")
        if not raw_audio:
            raise HTTPException(status_code=400, detail="Arquivo de áudio vazio.")
        logger.info("Dublagem: recebido %s (%.1f MB), voice_id=%s", file.filename, len(raw_audio) / 1e6, voice_id)

        try:
            request = DubbingRequest(
                dubbing_mode=resolved_mode,
                voice_id=voice_id or None,
                file_name=file.filename or name,
                format=suffix,
                output_format=output_format.lower(),
                model_id=model_id or settings.ELEVENLABS_DEFAULT_MODEL,
                provider=provider or "elevenlabs",
                source_language=source_language,
                target_language=target_language,
                language_code=language_code,
                file_content=raw_audio,
                voice_settings={
                    "stability": stability,
                    "similarity_boost": similarity_boost,
                    "style": style,
                    "speaker_boost": speaker_boost,
                },
            )
        except ValueError as exc:  # pydantic.ValidationError herda de ValueError
            raise HTTPException(status_code=422, detail=f"Parâmetros de dublagem inválidos: {exc}") from exc

        job_label = voice_id if resolved_mode == "voice_conversion" else "voz original (traduzido)"
        if len(raw_audio) >= settings.DUBBING_BACKGROUND_THRESHOLD_BYTES:
            job = Job(user_prompt=f"Dublagem ({resolved_mode}) para {job_label}", request=request, kind="audio")
            await queue_manager.enqueue(job)
            return DubbingResponse(
                job_id=job.id,
                provider=request.provider,
                output_format=request.output_format,
                message="Arquivo em processamento em background. Consulte o job em /api/jobs/{job_id}.",
                voice_id=request.voice_id or "",
            )

        strategy = dubbing_provider if resolved_mode == "voice_conversion" else translation_dubbing_provider
        # translation_dubbing usa GPU local (XTTS): exclusao mutua com a fila. voice_conversion e nuvem.
        guard = gpu_slot() if resolved_mode == "translation_dubbing" else contextlib.nullcontext()
        async with guard:
            output_path = Path(await strategy.generate(raw_audio, request))
        # translation_dubbing (XTTS v2) sempre grava .wav, independente do output_format
        # pedido -- refletir a extensao REAL do arquivo gerado na resposta.
        actual_format = output_path.suffix.lstrip(".").lower() or request.output_format
        return DubbingResponse(
            job_id=str(uuid.uuid4()),
            provider=request.provider,
            output_format=actual_format if actual_format in {"wav", "mp3", "m4a"} else request.output_format,
            file_path=str(output_path),
            audio_url=f"/audio/{output_path.name}",
            message="Dublagem concluída com sucesso.",
            voice_id=request.voice_id or "",
            bytes_written=output_path.stat().st_size,
        )

    except HTTPException:
        raise
    except GpuBusyError as exc:
        raise HTTPException(status_code=503, detail=str(exc)) from exc
    except ValueError as exc:
        raise HTTPException(status_code=400, detail=str(exc)) from exc
    except TimeoutError as exc:
        raise HTTPException(status_code=504, detail=str(exc)) from exc
    except (ProviderUnavailableError, ResourceExhaustedError) as exc:
        logger.error("Dublagem indisponível: %s", exc)
        raise HTTPException(status_code=503, detail=str(exc)) from exc
    except Exception as exc:
        logger.exception("Erro ao processar dublagem")
        raise HTTPException(status_code=500, detail=_internal_detail("processar a dublagem", exc)) from exc


@app.post("/api/v1/dubbing/preview", response_model=DubbingPreviewResponse)
async def dubbing_preview(
    file: UploadFile = File(...),
    source_language: Optional[str] = Form("en"),
    target_language: Optional[str] = Form("pt-BR"),
):
    """Passo 1 do fluxo revisável de translation_dubbing: transcreve (whisper) e
    traduz (Ollama), mas NÃO sintetiza ainda. Devolve translated_text para o
    usuário corrigir na caixa de texto do frontend antes de confirmar a síntese
    em POST /api/v1/dubbing/synthesize (usando o session_id retornado aqui).

    Só cobre o modo translation_dubbing (voz clonada) -- voice_conversion
    continua usando /api/v1/dubbing/process normalmente.
    """
    try:
        name = (file.filename or "audio").lower()
        suffix = Path(name).suffix.lstrip(".").lower()
        if suffix not in {"wav", "mp3", "m4a"}:
            raise HTTPException(status_code=400, detail="Formato de áudio inválido. Envie WAV, MP3 ou M4A.")

        raw_audio = await read_upload_limited(file, settings.DUBBING_MAX_UPLOAD_MB, "Arquivo de áudio")
        if not raw_audio:
            raise HTTPException(status_code=400, detail="Arquivo de áudio vazio.")
        logger.info("Dublagem (preview): recebido %s (%.1f MB)", file.filename, len(raw_audio) / 1e6)

        async with gpu_slot():
            result = await translation_dubbing_provider.create_preview(
                raw_audio, suffix, source_language, target_language
            )
        return DubbingPreviewResponse(**result, expires_in_seconds=1800)

    except HTTPException:
        raise
    except GpuBusyError as exc:
        raise HTTPException(status_code=503, detail=str(exc)) from exc
    except ValueError as exc:
        raise HTTPException(status_code=400, detail=str(exc)) from exc
    except (ProviderUnavailableError, ResourceExhaustedError) as exc:
        logger.error("Preview de dublagem indisponível: %s", exc)
        raise HTTPException(status_code=503, detail=str(exc)) from exc
    except Exception as exc:
        logger.exception("Erro ao gerar preview de dublagem")
        raise HTTPException(status_code=500, detail=_internal_detail("gerar o preview", exc)) from exc


@app.post("/api/v1/dubbing/synthesize", response_model=DubbingResponse)
async def dubbing_synthesize(
    session_id: str = Form(...),
    translated_text: str = Form(...),
    target_language: Optional[str] = Form(None),
    reference_voice: Optional[UploadFile] = File(None),
):
    """Passo 2 do fluxo revisável: sintetiza translated_text (já revisado/corrigido
    pelo usuário no frontend) com XTTS v2, usando session_id devolvido por
    POST /api/v1/dubbing/preview.

    reference_voice é OPCIONAL: se enviado, clona essa voz; se vazio/ausente,
    clona a voz do próprio áudio original enviado no passo 1.
    """
    try:
        ref_bytes: Optional[bytes] = None
        ref_suffix: Optional[str] = None
        if reference_voice is not None and (reference_voice.filename or "").strip():
            ref_name = reference_voice.filename.lower()
            ref_suffix = Path(ref_name).suffix.lstrip(".").lower() or "wav"
            if ref_suffix not in {"wav", "mp3", "m4a"}:
                raise HTTPException(
                    status_code=400,
                    detail="Formato da voz de referência inválido. Envie WAV, MP3 ou M4A.",
                )
            body = await read_upload_limited(reference_voice, settings.DUBBING_MAX_UPLOAD_MB, "Voz de referência")
            ref_bytes = body or None  # arquivo enviado vazio == tratar como "não enviado"

        async with gpu_slot():
            output_path = Path(await translation_dubbing_provider.synthesize_from_preview(
                session_id, translated_text, target_language, ref_bytes, ref_suffix
            ))
        actual_format = output_path.suffix.lstrip(".").lower() or "wav"
        return DubbingResponse(
            job_id=str(uuid.uuid4()),
            provider="local_flow_matching",
            output_format=actual_format if actual_format in {"wav", "mp3", "m4a"} else "wav",
            file_path=str(output_path),
            audio_url=f"/audio/{output_path.name}",
            message="Dublagem concluída com sucesso.",
            voice_id="",
            bytes_written=output_path.stat().st_size,
        )

    except HTTPException:
        raise
    except GpuBusyError as exc:
        raise HTTPException(status_code=503, detail=str(exc)) from exc
    except ValueError as exc:
        raise HTTPException(status_code=400, detail=str(exc)) from exc
    except (ProviderUnavailableError, ResourceExhaustedError) as exc:
        logger.error("Síntese de dublagem indisponível: %s", exc)
        raise HTTPException(status_code=503, detail=str(exc)) from exc
    except Exception as exc:
        logger.exception("Erro ao sintetizar dublagem")
        raise HTTPException(status_code=500, detail=_internal_detail("sintetizar", exc)) from exc
