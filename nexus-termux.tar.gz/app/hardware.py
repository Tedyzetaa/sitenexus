"""Deteccao leve de hardware (v8.0): RAM livre, threads de CPU e presenca de GPU NVIDIA.

POR QUE EXISTE
--------------
A v8.0 foi otimizada para um notebook SEM GPU dedicada (i3-3110M, 2 nucleos/4 threads, 8 GB de
RAM, Intel HD 4000). Nesse perfil ("lite") o gargalo e a RAM, nao a VRAM: XTTS v2 (~2-3 GB), um LLM
de 1.5B-3B (~1-2 GB) e o proprio Windows nao cabem juntos em 8 GB. Quando a RAM acaba o Windows
passa a usar o arquivo de paginacao (HDD) e a maquina trava -- ou o processo morre sem traceback,
exatamente o sintoma descrito em docs/need-fix.md. Por isso medimos a RAM livre ANTES de carregar um
modelo pesado e falhamos com uma mensagem clara em vez de derrubar a maquina.

Este modulo NAO importa torch, ctranslate2 nem app.config (evita ciclos e custo de import).
"""
from __future__ import annotations

import ctypes
import logging
import os
import shutil
import sys
from functools import lru_cache

logger = logging.getLogger("nexus.hardware")


class _MemoryStatusEx(ctypes.Structure):
    _fields_ = [
        ("dwLength", ctypes.c_ulong),
        ("dwMemoryLoad", ctypes.c_ulong),
        ("ullTotalPhys", ctypes.c_ulonglong),
        ("ullAvailPhys", ctypes.c_ulonglong),
        ("ullTotalPageFile", ctypes.c_ulonglong),
        ("ullAvailPageFile", ctypes.c_ulonglong),
        ("ullTotalVirtual", ctypes.c_ulonglong),
        ("ullAvailVirtual", ctypes.c_ulonglong),
        ("sullAvailExtendedVirtual", ctypes.c_ulonglong),
    ]


def _windows_memory() -> tuple[int, int] | None:
    """(total_mb, disponivel_mb) via GlobalMemoryStatusEx. None se a chamada falhar."""
    try:
        stat = _MemoryStatusEx()
        stat.dwLength = ctypes.sizeof(_MemoryStatusEx)
        if not ctypes.windll.kernel32.GlobalMemoryStatusEx(ctypes.byref(stat)):  # type: ignore[attr-defined]
            return None
        return int(stat.ullTotalPhys // (1024 * 1024)), int(stat.ullAvailPhys // (1024 * 1024))
    except Exception:  # noqa: BLE001 - deteccao e best-effort
        return None


def _linux_memory() -> tuple[int, int] | None:
    try:
        info: dict[str, int] = {}
        with open("/proc/meminfo", encoding="ascii") as fh:
            for line in fh:
                key, _, rest = line.partition(":")
                parts = rest.split()
                if parts:
                    info[key] = int(parts[0])  # kB
        total = info["MemTotal"] // 1024
        avail = info.get("MemAvailable", info.get("MemFree", 0)) // 1024
        return total, avail
    except Exception:  # noqa: BLE001
        return None


def memory_mb() -> tuple[int, int] | None:
    """(total_mb, disponivel_mb) ou None quando o SO nao permite descobrir."""
    if sys.platform == "win32":
        return _windows_memory()
    if sys.platform.startswith("linux"):
        return _linux_memory()
    return None


def available_ram_mb() -> int | None:
    mem = memory_mb()
    return mem[1] if mem else None


def total_ram_mb() -> int | None:
    mem = memory_mb()
    return mem[0] if mem else None


def ensure_ram(min_free_mb: int, what: str) -> None:
    """Levanta ResourceExhaustedError se a RAM livre for menor que `min_free_mb`.

    `min_free_mb <= 0` desliga a checagem. Se o SO nao informa a RAM, nao bloqueia (so avisa no log).
    """
    if min_free_mb <= 0:
        return
    free = available_ram_mb()
    if free is None:
        logger.debug("RAM livre desconhecida neste SO; checagem de %s ignorada.", what)
        return
    if free < min_free_mb:
        from app.providers.base import ResourceExhaustedError  # import tardio: evita ciclo

        raise ResourceExhaustedError(
            f"RAM livre insuficiente para carregar {what}: {free} MB livres, preciso de ~{min_free_mb} MB. "
            "Feche o navegador/outros programas, ou espere o job anterior terminar, e tente de novo."
        )


@lru_cache(maxsize=1)
def logical_cpus() -> int:
    return max(1, os.cpu_count() or 1)


def auto_cpu_threads() -> int:
    """Threads de calculo recomendadas = nucleos FISICOS (estimativa: metade das logicas quando ha HT).

    Em um i3-3110M (2 nucleos / 4 threads) isso da 2. Rodar 4 threads de matmul em 2 nucleos com
    Hyper-Threading nao acelera e ainda disputa a CPU com o proprio Windows/uvicorn.
    """
    n = logical_cpus()
    return max(1, n // 2) if n >= 4 else n


@lru_cache(maxsize=1)
def has_nvidia_gpu() -> bool:
    """True se o driver NVIDIA esta instalado (nvidia-smi no PATH). Nao importa torch."""
    if shutil.which("nvidia-smi"):
        return True
    if sys.platform == "win32":
        root = os.environ.get("SystemRoot", r"C:\Windows")
        return os.path.exists(os.path.join(root, "System32", "nvidia-smi.exe"))
    return False


def snapshot() -> dict:
    """Resumo para /api/system e para o log de startup."""
    mem = memory_mb()
    return {
        "cpu_logical": logical_cpus(),
        "cpu_threads_suggested": auto_cpu_threads(),
        "ram_total_mb": mem[0] if mem else None,
        "ram_available_mb": mem[1] if mem else None,
        "nvidia_gpu": has_nvidia_gpu(),
        "platform": sys.platform,
    }
